import React from 'react';

/**
 * BrandLogo — офіційний бренд-знак FluxControl.
 *
 * ТЗ «іконка агента всюди»: спершу пробуємо ЖИВУ ІКОНКУ ПРОГРАМИ з
 * /assets/logo.png — її туди кладе Deploy Manager при кожному деплої агента
 * (assets\logo.ico + assets\logo.png у репозиторії сайту). Якщо файл ще не
 * залитий / недоступний — плавний фолбек на векторний знак (той самий path,
 * що в public/favicon.svg та MainWindow.xaml), тож логотип ніколи не «ламається».
 *
 * viewBox 512×512, той самий path, що в public/favicon.svg та MainWindow.xaml.
 */
export const BrandLogo: React.FC<{
  /** Розмір плитки в px (за замовчуванням 36). */
  size?: number;
  className?: string;
  /** Прибрати скляну плитку (коли знак малюється на власній плитці). */
  bare?: boolean;
}> = ({ size = 36, className = '', bare = false }) => {
  // Унікальні id градієнтів — щоб кілька інстансів на сторінці не конфліктували.
  const uid = React.useId().replace(/[:]/g, '');
  const gradId = `fcx-brand-grad-${uid}`;
  const boltId = `fcx-brand-bolt-${uid}`;
  // Жива іконка з /assets/logo.png; false = ще не виявлено помилку.
  const [assetFailed, setAssetFailed] = React.useState(false);
  const onError = React.useCallback(() => setAssetFailed(true), []);

  // Жива іконка агента (assets/logo.png кладе Deploy Manager при деплої агента).
  const liveIcon = (
    <img
      src="/assets/logo.png"
      alt=""
      width={size}
      height={size}
      onError={onError}
      draggable={false}
      style={{
        width: '100%',
        height: '100%',
        objectFit: 'cover',
        borderRadius: '30%',
        display: 'block',
      }}
    />
  );

  // Векторний фолбек — той самий знак, що й в exe/favicon агента.
  const vectorIcon = (
    <svg
      viewBox="0 0 512 512"
      width={size}
      height={size}
      className={className}
      aria-hidden="true"
      role="img"
    >
      <defs>
        <linearGradient id={gradId} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#A78BFA" />
          <stop offset=".55" stopColor="#7C3AED" />
          <stop offset="1" stopColor="#4F46E5" />
        </linearGradient>
        <linearGradient id={boltId} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#FFFFFF" />
          <stop offset="1" stopColor="#DDE3FF" />
        </linearGradient>
      </defs>
      {!bare && (
        <path
          fill={`url(#${gradId})`}
          d="M256 20C126 20 20 126 20 256s106 236 236 236 236-106 236-236S386 20 256 20Zm0 44c106 0 192 86 192 192s-86 192-192 192S64 362 64 256 150 64 256 64Z"
        />
      )}
      <path
        fill={`url(#${boltId})`}
        d="M272 116Q190 190 143 287Q135 296 147 296L255 296Q266 296 263 307L245 388Q242 400 253 391Q300 340 378 232Q385 223 374 223L263 223Q252 223 255 212L274 130Q278 116 272 116Z"
      />
    </svg>
  );

  if (bare) {
    return (
      <span
        className={`relative inline-flex overflow-hidden ${className}`}
        style={{ width: size, height: size, borderRadius: '30%' }}
        aria-hidden="true"
      >
        {!assetFailed ? liveIcon : vectorIcon}
      </span>
    );
  }

  return (
    <span
      className={`relative inline-flex items-center justify-center overflow-hidden rounded-[30%] shadow-lg shadow-indigo-600/30 ${className}`}
      style={{
        width: size,
        height: size,
        background: 'linear-gradient(135deg,#8B5CF6 0%,#6366F1 100%)',
      }}
      aria-hidden="true"
    >
      {!assetFailed ? liveIcon : (
        <svg viewBox="0 0 512 512" width={size * 0.66} height={size * 0.66}>
          <defs>
            <linearGradient id={boltId} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor="#FFFFFF" />
              <stop offset="1" stopColor="#DDE3FF" />
            </linearGradient>
          </defs>
          <path
            fill={`url(#${boltId})`}
            d="M272 116Q190 190 143 287Q135 296 147 296L255 296Q266 296 263 307L245 388Q242 400 253 391Q300 340 378 232Q385 223 374 223L263 223Q252 223 255 212L274 130Q278 116 272 116Z"
          />
        </svg>
      )}
    </span>
  );
};

BrandLogo.displayName = 'BrandLogo';
