import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Activity,
  BatteryCharging,
  BatteryFull,
  Bluetooth,
  Camera as CameraIcon,
  Clock,
  Cpu,
  Disc3,
  Download,
  Gamepad2,
  Gauge,
  Globe,
  HardDrive,
  Headphones,
  Keyboard,
  Layers,
  Maximize,
  Monitor,
  Mouse,
  Printer,
  RefreshCw,
  Ruler,
  Server,
  Timer,
  Upload,
  Usb,
  Wifi,
  X,
  Zap
} from 'lucide-react';
import { Device, DeviceEntryInfo, DeviceMetrics, DiskInfo, SpeedTestResult } from '../../types';
import { deviceClient } from '../../services/deviceClient';
import { toast } from '../../utils/toast';
import { pick } from './fcEvents';

interface InfoTabProps {
  device: Device;
  /** Live metrics accessor — telemetry is stored in a ref up the tree to keep this tab the only re-rendering part. */
  getMetrics: () => DeviceMetrics | null;
  hasTelemetry?: boolean;
  /** Live end-to-end session status from the WebSocket client. */
  sessionLive?: boolean;
}

/** Smart size formatting: small drives must show MB, not “0.05 GB”. */
export const formatSmartSize = (bytes?: number, fallbackGb?: number): string => {
  if (bytes !== undefined && bytes !== null && bytes > 0) {
    if (bytes >= 1024 ** 4) return `${(bytes / 1024 ** 4).toFixed(2)} ТБ`;
    if (bytes >= 1024 ** 3) return `${(bytes / 1024 ** 3).toFixed(bytes >= 10 * 1024 ** 3 ? 0 : 1)} ГБ`;
    if (bytes >= 1024 ** 2) return `${(bytes / 1024 ** 2).toFixed(0)} МБ`;
    if (bytes >= 1024) return `${(bytes / 1024).toFixed(0)} КБ`;
    return `${bytes} Б`;
  }
  if (fallbackGb !== undefined && fallbackGb > 0) {
    if (fallbackGb < 0.01) return `${Math.round(fallbackGb * 1024 * 1024)} МБ`;
    if (fallbackGb < 1) return `${Math.round(fallbackGb * 1024)} МБ`;
    return `${Number(fallbackGb.toFixed(fallbackGb >= 10 ? 0 : 1))} ГБ`;
  }
  return '—';
};

/** "Останній тест: сьогодні о 09:24" — людський час останнього заміру. */
const formatSpeedTestTime = (ts?: number): string => {
  if (!ts) return '';
  const d = new Date(ts);
  const now = new Date();
  const time = d.toLocaleTimeString('uk-UA', { hour: '2-digit', minute: '2-digit' });
  const sameDay = d.toDateString() === now.toDateString();
  if (sameDay) return `сьогодні о ${time}`;
  const yesterday = new Date(now);
  yesterday.setDate(now.getDate() - 1);
  if (d.toDateString() === yesterday.toDateString()) return `вчора о ${time}`;
  const date = d.toLocaleDateString('uk-UA', { day: 'numeric', month: 'short' });
  return `${date} о ${time}`;
};

const formatDuration = (ms?: number): string => {
  if (!ms || ms <= 0) return '';
  const total = Math.round(ms / 1000);
  return ` · ${Math.floor(total / 60)} хв ${total % 60} с`;
};

const tempColor = (t: number): string => (t >= 85 ? 'text-rose-400' : t >= 70 ? 'text-amber-300' : 'text-emerald-300');

const DiskIcon: React.FC<{ disk: DiskInfo }> = ({ disk }) => {
  if (disk.driveType === 'removable') return <Usb className="h-5 w-5 text-cyan-300" />;
  if (disk.driveType === 'network') return <Server className="h-5 w-5 text-amber-300" />;
  return <HardDrive className="h-5 w-5 text-indigo-300" />;
};

/** «≈ 2 год 15 хв» — орієнтовний залишок роботи батареї (ТЗ). */
const formatBatteryTime = (sec?: number): string => {
  if (!sec || sec <= 0) return '';
  const total = Math.round(sec / 60);
  if (total < 1) return 'менше хвилини';
  const h = Math.floor(total / 60);
  const m = total % 60;
  if (h === 0) return `≈ ${m} хв`;
  return m > 0 ? `≈ ${h} год ${m} хв` : `≈ ${h} год`;
};

/** Точка живої історії: час (мс) + значення 0..100. */
export type HistPoint = { t: number; v: number };
/** Вікно графіка — ТЗ: рівно останні 5 хвилин. */
const HIST_WINDOW_MS = 5 * 60 * 1000;

/** Живий графік навантаження у стилі Диспетчера задач Windows (ТЗ: клік по рамці). */
const LiveMetricModal: React.FC<{
  title: string;
  subtitle: string;
  accent: 'indigo' | 'purple' | 'emerald';
  history: HistPoint[];
  current: number;
  extra?: React.ReactNode;
  onClose: () => void;
}> = ({ title, subtitle, accent, history, current, extra, onClose }) => {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  const gradId = `fcgrad-${accent}`;
  const lineColor = accent === 'indigo' ? '#818cf8' : accent === 'purple' ? '#c084fc' : '#34d399';

  // Усі точки за 5-хвилинне вікно → SVG-полілайн у viewBox 0..100 × 0..100.
  // X масштабується за ЧАСОМ (не за індексом): при рідкій телеметрії (8с)
  // графік чесно показує реальні проміжки, а не рівномірні кроки.
  const pts = history;
  const nowMs = pts.length > 0 ? pts[pts.length - 1].t : 0;
  const tStart = nowMs - HIST_WINDOW_MS;
  const span = Math.max(1, HIST_WINDOW_MS);
  const path = pts.map((p, i) => {
    const x = Math.max(0, Math.min(100, ((p.t - tStart) / span) * 100));
    const y = 100 - Math.max(0, Math.min(100, p.v));
    return `${i === 0 ? 'M' : 'L'}${x.toFixed(2)},${y.toFixed(2)}`;
  }).join(' ');
  const areaPath = pts.length > 1 ? `${path} L100,100 L0,100 Z` : '';

  const maxV = pts.length > 0 ? Math.max(100, ...pts.map(p => p.v)) : 100;
  const avgV = pts.length > 0 ? Math.round(pts.reduce((a, p) => a + p.v, 0) / pts.length) : 0;
  const minV = pts.length > 0 ? Math.round(Math.min(...pts.map(p => p.v))) : 0;
  const coveredMin = pts.length > 1 ? Math.round((nowMs - pts[0].t) / 60000) : 0;

  return (
    <div
      className="fixed inset-0 z-[90] flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm"
      onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div className="fc-card w-full max-w-2xl overflow-hidden bg-[#0a0d18] p-6 shadow-2xl">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="rounded-xl border border-white/10 bg-white/5 p-2.5">
              <Activity className="h-5 w-5" style={{ color: lineColor }} />
            </div>
            <div>
              <h3 className="text-base font-black text-white">{title}</h3>
              <p className="max-w-[420px] truncate text-xs text-zinc-500">{subtitle}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="grid h-8 w-8 flex-none cursor-pointer place-items-center rounded-lg border border-white/10 bg-white/5 text-zinc-400 transition-colors hover:bg-white/10 hover:text-white"
            aria-label="Закрити"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="mt-4 flex items-end gap-4">
          <div className="font-mono text-5xl font-black leading-none text-white">{Math.round(current)}<span className="text-2xl text-zinc-500">%</span></div>
          <div className="mb-1 flex flex-wrap gap-x-4 gap-y-1 text-[11px] text-zinc-500">
            <span className="rounded-md border border-white/10 bg-white/5 px-2 py-0.5 font-bold text-zinc-300">Останні 5 хв</span>
            <span>ср <b className="text-zinc-300">{avgV}%</b></span>
            <span>мін <b className="text-zinc-300">{minV}%</b></span>
            <span>макс <b className="text-zinc-300">{Math.round(maxV)}%</b></span>
            {coveredMin >= 1 && coveredMin < 5 && <span className="text-zinc-600">(накопичено {coveredMin} хв)</span>}
          </div>
        </div>

        {/* Сітка + градієнтна заливка — як у Диспетчера задач */}
        <div className="mt-4 overflow-hidden rounded-2xl border border-white/10 bg-black/60">
          <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="h-48 w-full sm:h-56">
            <defs>
              <linearGradient id={gradId} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={lineColor} stopOpacity="0.45" />
                <stop offset="100%" stopColor={lineColor} stopOpacity="0.02" />
              </linearGradient>
            </defs>
            {[25, 50, 75].map(y => (
              <line key={y} x1="0" y1={y} x2="100" y2={y} stroke="rgba(255,255,255,0.07)" strokeWidth="0.4" />
            ))}
            {[20, 40, 60, 80].map(x => (
              <line key={x} x1={x} y1="0" x2={x} y2="100" stroke="rgba(255,255,255,0.05)" strokeWidth="0.4" />
            ))}
            <line x1="0" y1="100" x2="100" y2="100" stroke="rgba(255,255,255,0.12)" strokeWidth="0.5" />
            {areaPath && <path d={areaPath} fill={`url(#${gradId})`} />}
            {pts.length > 1 && (
              <path d={path} fill="none" stroke={lineColor} strokeWidth="1.4" vectorEffect="non-scaling-stroke" />
            )}
          </svg>
          <div className="flex justify-between border-t border-white/10 px-3 py-1.5 font-mono text-[9px] text-zinc-600">
            <span>-2 хв</span><span>-90 с</span><span>-1 хв</span><span>-30 с</span><span>зараз</span>
          </div>
        </div>

        {extra && <div className="mt-4 border-t border-white/10 pt-3 text-xs text-zinc-400">{extra}</div>}
        <p className="mt-3 text-[10px] text-zinc-600">Графік оновлюється наживо щосекунди · клік поза вікном або Esc — закрити</p>
      </div>
    </div>
  );
};

const MetricRow: React.FC<{ label: string; children: React.ReactNode }> = ({ label, children }) => (
  <div className="flex justify-between gap-3 text-xs text-zinc-400">
    <span className="flex-none">{label}</span>
    <span className="min-w-0 break-words text-right font-medium text-zinc-200">{children}</span>
  </div>
);

// ================= ТЗ: рамка «Пристрої» (Диспетчер пристроїв) =================

const DEVICE_GROUP_META: Record<string, { label: string; icon: React.ReactNode }> = {
  Audio: { label: 'Звук і мікрофони', icon: <Headphones className="h-4 w-4" /> },
  Camera: { label: 'Камери', icon: <CameraIcon className="h-4 w-4" /> },
  Keyboard: { label: 'Клавіатури', icon: <Keyboard className="h-4 w-4" /> },
  Mouse: { label: 'Миші', icon: <Mouse className="h-4 w-4" /> },
  Gamepad: { label: 'Геймпади', icon: <Gamepad2 className="h-4 w-4" /> },
  Printer: { label: 'Принтери', icon: <Printer className="h-4 w-4" /> },
  DiskDrive: { label: 'Накопичувачі', icon: <HardDrive className="h-4 w-4" /> },
  Monitor: { label: 'Монітори', icon: <Monitor className="h-4 w-4" /> },
  Bluetooth: { label: 'Bluetooth', icon: <Bluetooth className="h-4 w-4" /> },
  USB: { label: 'USB-пристрої', icon: <Usb className="h-4 w-4" /> },
  Net: { label: 'Мережеві адаптери', icon: <Wifi className="h-4 w-4" /> },
  HID: { label: 'Інші HID-пристрої', icon: <Mouse className="h-4 w-4" /> },
  Display: { label: 'Відеоадаптери', icon: <Zap className="h-4 w-4" /> },
};

const DevicesCard: React.FC<{ sessionLive: boolean }> = ({ sessionLive }) => {
  const [devices, setDevices] = useState<DeviceEntryInfo[] | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    const off = deviceClient.on('devices_list', (raw: any) => {
      if (!mounted) return;
      const d = raw?.data ?? raw;
      const arr = Array.isArray(d?.devices) ? d.devices : [];
      setDevices(arr.map((x: any) => ({
        cls: String(x?.cls ?? ''),
        name: String(x?.name ?? ''),
        manufacturer: x?.manufacturer ? String(x.manufacturer) : undefined,
      })));
      setLoading(false);
    });
    deviceClient.requestDevicesList();
    const retry = setTimeout(() => { if (mounted && loading) deviceClient.requestDevicesList(); }, 6000);
    return () => { mounted = false; off(); clearTimeout(retry); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Групування за категорією, алфавіт усередині групи (ТЗ).
  const groups = useMemo(() => {
    if (!devices) return [];
    const map = new Map<string, DeviceEntryInfo[]>();
    for (const d of devices) {
      if (!d.name) continue;
      const key = d.cls || 'HID';
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(d);
    }
    return Array.from(map.entries())
      .map(([cls, list]) => ({
        cls,
        meta: DEVICE_GROUP_META[cls] ?? { label: cls, icon: <Usb className="h-4 w-4" /> },
        list: list.sort((a, b) => a.name.localeCompare(b.name, 'uk', { numeric: true })),
      }))
      .sort((a, b) => a.list.length === b.list.length
        ? a.meta.label.localeCompare(b.meta.label, 'uk')
        : b.list.length - a.list.length);
  }, [devices]);

  return (
    <div className="fc-card bg-[#090b14]/80 p-6">
      <div className="fc-section-head mb-5">
        <div className="fc-section-icon"><Usb className="h-5 w-5" /></div>
        <div className="min-w-0">
          <h3>Пристрої та периферія</h3>
          <p>Реальні моделі з Диспетчера пристроїв — клавіатури, миші, звук, принтери, USB</p>
        </div>
        <button
          type="button"
          onClick={() => { setLoading(true); deviceClient.requestDevicesList(); }}
          disabled={loading || !sessionLive}
          title="Оновити список пристроїв"
          aria-label="Оновити список пристроїв"
          className="ml-auto grid h-8 w-8 flex-none cursor-pointer place-items-center rounded-lg border border-white/10 bg-white/5 text-zinc-400 transition-colors hover:bg-white/10 hover:text-white disabled:opacity-50"
        >
          <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {loading && groups.length === 0 ? (
        <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="h-12 animate-pulse rounded-xl border border-white/5 bg-white/[.03]" />
          ))}
        </div>
      ) : groups.length === 0 ? (
        <p className="py-6 text-center text-xs text-zinc-500">
          Агент ще не повернув список — потрібне оновлення програми на ПК до останньої версії
        </p>
      ) : (
        <div className="space-y-4">
          {groups.map((g) => (
            <div key={g.cls}>
              <p className="mb-1.5 flex items-center gap-1.5 text-[10px] font-black uppercase tracking-wider text-zinc-400">
                <span className="text-indigo-300">{g.meta.icon}</span>
                {g.meta.label}
                <span className="rounded-full border border-white/10 bg-white/5 px-1.5 text-[9px] font-bold text-zinc-500">{g.list.length}</span>
              </p>
              <div className="grid grid-cols-1 gap-1.5 sm:grid-cols-2 lg:grid-cols-3">
                {g.list.map((d, i) => (
                  <div key={`${d.name}|${i}`} className="flex min-w-0 items-center gap-2.5 rounded-xl border border-white/8 bg-white/[.03] px-3 py-2" title={d.manufacturer ? `${d.name} — ${d.manufacturer}` : d.name}>
                    <span className="h-1.5 w-1.5 flex-none rounded-full bg-emerald-400/80" aria-hidden="true" />
                    <span className="min-w-0">
                      <span className="block truncate text-xs font-semibold text-zinc-100">{d.name}</span>
                      {d.manufacturer && d.manufacturer !== 'Standard' && (
                        <span className="block truncate text-[10px] text-zinc-500">{d.manufacturer}</span>
                      )}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );};

export const InfoTab: React.FC<InfoTabProps> = React.memo(({ device, getMetrics, hasTelemetry, sessionLive = true }) => {
  const [metrics, setMetrics] = useState<DeviceMetrics | null>(() => getMetrics?.() ?? null);
  const [networkInfo, setNetworkInfo] = useState<any>(null);
  const [speedTest, setSpeedTest] = useState<SpeedTestResult | null>(() => getMetrics?.()?.speedTest ?? null);
  const [speedRunning, setSpeedRunning] = useState(false);
  const [speedStage, setSpeedStage] = useState<string>('');
  const mountedRef = useRef(true);
  // Distinguish a manual run (button) from the automatic startup run so the
  // completion toast fires only for user-initiated tests.
  const manualRunRef = useRef(false);
  // Живі історії навантаження для клік-модалок (ТЗ: як у Диспетчері задач).
  // Тепер з таймстампами — вікно рівно 5 хвилин (не 120 точок).
  const histRef = useRef<{ cpu: HistPoint[]; gpu: HistPoint[]; ram: HistPoint[] }>({ cpu: [], gpu: [], ram: [] });
  const [graphModal, setGraphModal] = useState<null | 'cpu' | 'gpu' | 'ram'>(null);
  const [screenInfo, setScreenInfo] = useState<{ model?: string; resolution?: string; refreshHz?: number; scalePercent?: number } | null>(null);

  // Subscribe to live telemetry. Metrics flow through a ref in the parent, so
  // this setState re-renders ONLY this tab (about once per second), never the
  // whole session view — that was the lag source on the Control tab.
  useEffect(() => {
    mountedRef.current = true;
    const applyMetrics = (raw: any) => {
      const m = (pick<any>(raw) ?? undefined) as DeviceMetrics | undefined;
      if (!mountedRef.current || !m) return;
      setMetrics(m);
      if (m.speedTest !== undefined) setSpeedTest(m.speedTest ?? null);
      // Копим історію для живих графіків: вікно 5 ХВИЛИН за часом (ТЗ),
      // а не «120 точок» — при рідкій телеметрії теж тримаємо рівно 5 хв.
      const push = (arr: HistPoint[], v: number) => {
        const now = Date.now();
        arr.push({ t: now, v });
        const cutoff = now - HIST_WINDOW_MS;
        while (arr.length > 0 && arr[0].t < cutoff) arr.shift();
        // Захист від аномального роздуття (частота >1Гц тривалий час).
        if (arr.length > 1200) arr.splice(0, arr.length - 1200);
      };
      push(histRef.current.cpu, Math.min(100, Math.max(0, m.cpuUsage ?? m.cpuPercent ?? 0)));
      push(histRef.current.gpu, Math.min(100, Math.max(0, m.gpuUsage ?? 0)));
      push(histRef.current.ram, Math.min(100, Math.max(0, m.ramUsage ?? m.ramPercent ?? 0)));
      // Екран може прийти і через телеметрію (нові агенти шлють у метриках).
      if (m.screenResolution || m.screenModel) {
        setScreenInfo({ model: m.screenModel, resolution: m.screenResolution, refreshHz: m.screenRefreshHz, scalePercent: m.screenScalePercent });
      }
    };
    const unsubMetrics = deviceClient.on('metrics', applyMetrics);
    const unsubTelemetry = deviceClient.on('telemetry', applyMetrics);
    const unsubNet = deviceClient.on('network_info', (n) => {
      if (mountedRef.current) setNetworkInfo(pick<any>(n));
    });
    const unsubScreen = deviceClient.on('screen_info', (n: any) => {
      const s = pick<any>(n);
      if (mountedRef.current && s) setScreenInfo(s);
    });
    const unsubSpeed = deviceClient.on('speedtest_result', (r: any) => {
      if (!mountedRef.current) return;
      const data = pick<any>(r);
      if (data?.running) {
        setSpeedRunning(true);
        setSpeedStage(data.stage || '');
        return;
      }
      setSpeedRunning(false);
      setSpeedStage('');
      if (data && !data.error) {
        setSpeedTest(data);
        if (manualRunRef.current) {
          manualRunRef.current = false;
          const dl = typeof data.downloadMbps === 'number' ? `${data.downloadMbps.toFixed(1)} Мбіт/с ↓` : '—';
          const ul = typeof data.uploadMbps === 'number' ? `${data.uploadMbps.toFixed(1)} Мбіт/с ↑` : '—';
          const ping = typeof data.pingMs === 'number' ? ` · ${data.pingMs} мс` : '';
          toast.success(`Speedtest: ${dl} / ${ul}${ping}`);
        }
      } else if (data?.error) {
        if (manualRunRef.current) {
          manualRunRef.current = false;
          toast.error(`Speedtest не вдався: ${data.error}`);
        }
        setSpeedTest(data);
      }
    });
    const unsubProgress = deviceClient.on('speedtest_progress', (r: any) => {
      if (!mountedRef.current) return;
      const data = pick<any>(r);
      setSpeedRunning(true);
      setSpeedStage(data?.stage || '');
    });

    deviceClient.send('ping', {});
    deviceClient.send('get_network_info', {});
    deviceClient.send('get_screen_info', {}); // рамка «Екран» (ТЗ)

    return () => {
      mountedRef.current = false;
      unsubMetrics();
      unsubTelemetry();
      unsubNet();
      unsubScreen();
      unsubSpeed();
      unsubProgress();
    };
  }, []);

  const handleRunSpeedTest = useCallback(() => {
    if (speedRunning) return;
    setSpeedRunning(true);
    setSpeedStage('підготовка…');
    manualRunRef.current = true;
    deviceClient.send('run_speedtest', {});
    // Safety: if the agent never answers, unlock the button again.
    setTimeout(() => {
      if (mountedRef.current) {
        setSpeedRunning(current => {
          if (current) manualRunRef.current = false;
          return current ? false : current;
        });
      }
    }, 75000);
  }, [speedRunning]);

  // Real CPU data from agent
  const cpuVal = Math.min(100, Math.max(0, Math.round(metrics?.cpuUsage ?? metrics?.cpuPercent ?? 0)));
  // Full model name — never truncated (the user could not read long names).
  const cpuModel = metrics?.cpuName || metrics?.cpuModel || device.cpuInfo || 'Процесор ПК';
  const rawCpuTemp = metrics?.cpuTempC ?? metrics?.cpuTemp ?? null;
  // TEMPERATURE RULE: no sensor / zero reading → the row is not rendered at all.
  const cpuTemp = typeof rawCpuTemp === 'number' && rawCpuTemp > 0 ? rawCpuTemp : null;
  const cpuCores = metrics?.cpuCores ?? null;
  const cpuThreads = metrics?.cpuThreads ?? null;

  // Real GPU data from agent
  const gpuVal = Math.min(100, Math.max(0, Math.round(metrics?.gpuUsage ?? 0)));
  const gpuModel = metrics?.gpuName || metrics?.gpuModel || device.gpuInfo || 'Графічний процесор';
  // ТЗ «встройка»: у вбудованої графіки Немає власного сенсора температури і
  // власної пам'яті → температура = температура ПРОЦЕСОРА, «відеопам'ять» =
  // скільки GPU бере з ОЗУ (спільна пам'ять).
  const gpuIntegrated = metrics?.gpuIntegrated === true;
  const rawGpuTemp = metrics?.gpuTemp ?? null;
  const rawGpuTempValue = typeof rawGpuTemp === 'number' && rawGpuTemp > 0 ? rawGpuTemp : null;
  const gpuTemp = gpuIntegrated
    ? (typeof cpuTemp === 'number' && cpuTemp > 0 ? cpuTemp : rawGpuTempValue)
    : rawGpuTempValue;
  const gpuVramUsed = gpuIntegrated ? (metrics?.gpuSharedUsedGb ?? metrics?.gpuVramUsedGb ?? null) : (metrics?.gpuVramUsedGb ?? null);
  const gpuVramTotal = gpuIntegrated ? (metrics?.gpuSharedTotalGb ?? metrics?.gpuVramTotalGb ?? null) : (metrics?.gpuVramTotalGb ?? null);
  const gpuSharedUsed = metrics?.gpuSharedUsedGb ?? null; // зберігається, але ТЗ: у UI не показуємо
  const gpuSharedTotal = metrics?.gpuSharedTotalGb ?? null;
  // Частоти ядра/пам'яті GPU прибрано за фідбеком (ТЗ: «це не треба»).

  // Real RAM data from agent
  const ramVal = Math.min(100, Math.max(0, Math.round(metrics?.ramUsage ?? metrics?.ramPercent ?? 0)));
  const ramTotal = metrics?.ramTotalGb ?? (device.ramInfo ? parseFloat(device.ramInfo) : 0);
  const ramUsed = metrics?.ramUsedGb ?? (ramTotal > 0 && ramVal > 0 ? Number(((ramTotal * ramVal) / 100).toFixed(1)) : 0);
  const ramSpeed = metrics?.ramSpeed || '';
  // Тип і частота ОЗУ окремо. Нові агенти шлють RamType/RamFreqMhz; для
  // старих агентів розпарсимо «DDR4 @ 1600 MHz» з ramSpeed.
  const parsedSpeed = ramSpeed.match(/^(.*?DDR\d*)\s*@\s*(\d+)\s*MHz/i);
  const ramType = metrics?.ramType || (parsedSpeed?.[1]?.trim() || (/DDR\d/.test(ramSpeed) ? ramSpeed.match(/DDR\d/i)?.[0] : '')) || '';
  const ramFreq = metrics?.ramFreqMhz || (parsedSpeed ? Number(parsedSpeed[2]) : 0);

  // Real Disks from agent
  const disks: DiskInfo[] = Array.isArray(metrics?.disks) ? metrics!.disks! : [];
  const lanIp = networkInfo?.lanIp || metrics?.lanIp || device.lanIp || '';
  const wanIp = networkInfo?.wanIp || metrics?.wanIp || device.wanIp || '';

  // Акумулятор ноутбука (нові агенти шлють batteryPresent/batteryPercent)
  const batteryPresent = metrics?.batteryPresent === true;
  const batteryVal = Math.min(100, Math.max(0, Math.round(metrics?.batteryPercent ?? 0)));
  const batteryCharging = metrics?.batteryCharging === true;
  const batteryColor = batteryCharging
    ? 'from-emerald-500 to-teal-500'
    : batteryVal <= 20
      ? 'from-rose-500 to-red-600'
      : batteryVal <= 45
        ? 'from-amber-500 to-yellow-500'
        : 'from-emerald-500 to-teal-500';

  // Системна картка прибрана (ТЗ): ОС показуємо у шапці, материнку — теж.
  const boardLabel = metrics?.motherboard || '';

  // Екран (ТЗ): модель монітора / роздільність / герцовка / масштаб
  const screen = screenInfo ?? (metrics?.screenResolution || metrics?.screenModel
    ? { model: metrics?.screenModel, resolution: metrics?.screenResolution, refreshHz: metrics?.screenRefreshHz, scalePercent: metrics?.screenScalePercent }
    : null);

  // Орієнтовний залишок роботи батареї (ТЗ)
  const batteryTimeLabel = formatBatteryTime(metrics?.batteryRunTimeSec);

  // ТЗ «багатша батарея»: час до повного заряду, потужність, здоров'я, напруга.
  const batteryTimeToFull = formatBatteryTime(metrics?.batteryTimeToFullSec);
  const batteryRateLabel = useMemo(() => {
    const rate = metrics?.batteryRateMw ?? 0;
    if (!rate) return '';
    return `${Math.abs(rate) >= 1000 ? (Math.abs(rate) / 1000).toFixed(1) + ' Вт' : Math.abs(rate) + ' мВт'}`;
  }, [metrics?.batteryRateMw]);
  const batteryHealth = useMemo<number | null>(() => {
    const design = metrics?.batteryDesignCapacityMWh ?? 0;
    const full = metrics?.batteryFullCapacityMWh ?? 0;
    if (design > 0 && full > 0) return Math.min(100, Math.round((full / design) * 100));
    return null;
  }, [metrics?.batteryDesignCapacityMWh, metrics?.batteryFullCapacityMWh]);
  const batteryCapacitiesLabel = useMemo(() => {
    const design = metrics?.batteryDesignCapacityMWh ?? 0;
    const full = metrics?.batteryFullCapacityMWh ?? 0;
    if (design > 0 && full > 0) return `(${Math.round(full / 1000)} з ${Math.round(design / 1000)} Вт·год)`;
    return '';
  }, [metrics?.batteryDesignCapacityMWh, metrics?.batteryFullCapacityMWh]);
  const batteryVoltageLabel = useMemo(() => {
    const mv = metrics?.batteryVoltageMv ?? 0;
    return mv > 0 ? `${(mv / 1000).toFixed(2)} В` : '';
  }, [metrics?.batteryVoltageMv]);

  const getDiskBarColor = (pct: number) => {
    if (pct >= 85) return 'from-rose-500 to-red-600';
    if (pct >= 60) return 'from-amber-500 to-yellow-500';
    return 'from-indigo-500 to-purple-600';
  };

  return (
    <div className="space-y-6">

      {/* Top PC Overview Banner */}
      <div className="fc-card flex flex-col items-start justify-between gap-4 bg-[#090b14]/90 p-6 sm:flex-row sm:items-center">
        <div className="flex items-center gap-4">
          <div className="grid place-items-center rounded-2xl border border-indigo-500/30 bg-indigo-600/20 p-3.5 text-indigo-400">
            <Monitor className="h-7 w-7" />
          </div>
          <div>
            <h2 className="text-xl font-black text-white sm:text-2xl">
              {device.name || metrics?.machineName || 'Мій ПК'}
            </h2>
            <p className="mt-0.5 font-mono text-xs text-zinc-400">
              {metrics?.userName || 'Користувач'} • {device.osInfo || metrics?.osVersion || 'Windows'}
            </p>
            {/* ТЗ: рамку «Система» прибрано — материнка тепер у шапці */}
            {boardLabel && (
              <p className="mt-0.5 max-w-md truncate text-[11px] text-zinc-500" title={boardLabel}>
                Материнська плата: <span className="font-semibold text-zinc-400">{boardLabel}</span>
              </p>
            )}
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {sessionLive ? (
            <span className="flex items-center gap-1.5 rounded-full border border-emerald-500/30 bg-emerald-500/15 px-3 py-1 text-xs font-bold text-emerald-400">
              <span className="h-2 w-2 animate-pulse rounded-full bg-emerald-400" />
              <span>В мережі</span>
            </span>
          ) : (
            <span className="flex items-center gap-1.5 rounded-full border border-amber-500/30 bg-amber-500/15 px-3 py-1 text-xs font-bold text-amber-400">
              <span className="h-2 w-2 animate-pulse rounded-full bg-amber-400" />
              <span>З&apos;єднання втрачено — перепідключення…</span>
            </span>
          )}
          {metrics?.uptime && (
            <span className="flex items-center gap-1.5 rounded-full border border-white/10 bg-black/60 px-3 py-1 text-xs font-bold text-zinc-300">
              <Clock className="h-3.5 w-3.5 text-indigo-400" />
              <span>Аптайм: {metrics.uptime}</span>
            </span>
          )}
        </div>
      </div>

      {/* Hardware Cards Grid */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">

        {/* 1. CPU Card — клік відкриває живий графік (ТЗ) */}
        <div
          onClick={() => setGraphModal('cpu')}
          className="fc-card flex cursor-pointer flex-col justify-between bg-[#090b14]/80 p-6 transition-colors hover:border-indigo-500/30 hover:bg-[#0b0e1a]/90"
          title="Клік — живий графік навантаження"
        >
          <div>
            <div className="fc-section-head mb-4">
              <div className="fc-section-icon"><Cpu className="h-5 w-5" /></div>
              <div className="min-w-0">
                <h3>Процесор (CPU)</h3>
                <p className="break-words leading-snug" title={cpuModel}>{cpuModel}</p>
              </div>
              <span className="ml-auto flex-none font-mono text-2xl font-black text-white">{cpuVal}%</span>
            </div>

            <div className="mb-4 h-2.5 w-full overflow-hidden rounded-full border border-white/10 bg-black/70 p-0.5">
              <div
                className="h-full rounded-full bg-gradient-to-r from-indigo-500 to-purple-600 transition-all duration-700"
                style={{ width: `${cpuVal}%` }}
              />
            </div>
          </div>

          <div className="space-y-1.5 border-t border-white/10 pt-3">
            {(cpuCores !== null || cpuThreads !== null) && (
              <MetricRow label="Ядра / Потоки:">{cpuCores ?? '—'} / {cpuThreads ?? '—'}</MetricRow>
            )}
            {/* Temperature row is rendered ONLY when a real sensor value exists. */}
            {cpuTemp !== null && (
              <MetricRow label="Температура:">
                <span className={`font-mono ${tempColor(cpuTemp)}`}>~{cpuTemp}°C</span>
              </MetricRow>
            )}
          </div>
        </div>

        {/* 2. GPU Card — клік відкриває живий графік (ТЗ) */}
        <div
          onClick={() => setGraphModal('gpu')}
          className="fc-card flex cursor-pointer flex-col justify-between bg-[#090b14]/80 p-6 transition-colors hover:border-purple-500/30 hover:bg-[#0b0e1a]/90"
          title="Клік — живий графік навантаження"
        >
          <div>
            <div className="fc-section-head mb-4">
              <div className="fc-section-icon"><Zap className="h-5 w-5" /></div>
              <div className="min-w-0">
                <h3>Відеокарта (GPU)</h3>
                <p className="break-words leading-snug" title={gpuModel}>{gpuModel}</p>
              </div>
              <span className="ml-auto flex-none font-mono text-2xl font-black text-white">{gpuVal}%</span>
            </div>

            <div className="mb-4 h-2.5 w-full overflow-hidden rounded-full border border-white/10 bg-black/70 p-0.5">
              <div
                className="h-full rounded-full bg-gradient-to-r from-purple-500 to-pink-600 transition-all duration-700"
                style={{ width: `${gpuVal}%` }}
              />
            </div>
          </div>

          <div className="space-y-1.5 border-t border-white/10 pt-3">
            {gpuTemp !== null && (
              <MetricRow label={gpuIntegrated ? 'Температура (від процесора):' : 'Температура:'}>
                <span className={`font-mono ${gpuTemp >= 85 ? 'text-rose-400' : gpuTemp >= 70 ? 'text-amber-300' : 'text-purple-300'}`}>~{gpuTemp}°C</span>
              </MetricRow>
            )}
            {/* ТЗ: у встройки пам'ять СПІЛЬНА з ОЗУ; у дискретної — власна */}
            {gpuVramTotal !== null && gpuVramTotal > 0 && (
              <MetricRow label={gpuIntegrated ? "Пам'ять (з ОЗУ):" : "Відеопам'ять:"}>
                {formatSmartSize(undefined, gpuVramUsed ?? 0)} з {formatSmartSize(undefined, gpuVramTotal)}{gpuIntegrated ? ' · спільна' : ''}
              </MetricRow>
            )}
            {!gpuVramTotal && metrics?.gpuVram && (
              <MetricRow label="Відеопам&apos;ять:">{metrics.gpuVram}</MetricRow>
            )}
            {/* ТЗ: «Спільну пам&apos;ять» прибрано — лишилися тільки температура і відеопам&apos;ять */}
          </div>
        </div>

        {/* 3. RAM Card — клік відкриває живий графік (ТЗ) */}
        <div
          onClick={() => setGraphModal('ram')}
          className="fc-card flex cursor-pointer flex-col justify-between bg-[#090b14]/80 p-6 transition-colors hover:border-emerald-500/30 hover:bg-[#0b0e1a]/90"
          title="Клік — живий графік навантаження"
        >
          <div>
            <div className="fc-section-head mb-4">
              <div className="fc-section-icon"><Layers className="h-5 w-5" /></div>
              <div>
                <h3>Пам&apos;ять (RAM)</h3>
                <p>{ramTotal > 0 ? `${ramUsed} ГБ з ${ramTotal} ГБ` : 'Оперативна пам&apos;ять'}</p>
              </div>
              <span className="ml-auto flex-none font-mono text-2xl font-black text-white">{ramVal}%</span>
            </div>

            <div className="mb-4 h-2.5 w-full overflow-hidden rounded-full border border-white/10 bg-black/70 p-0.5">
              <div
                className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-teal-500 transition-all duration-700"
                style={{ width: `${ramVal}%` }}
              />
            </div>
          </div>

          <div className="space-y-1.5 border-t border-white/10 pt-3">
            {/* ЗА ФІДБЕКОМ: без «Всього/Використано/Відсоток» — це видно на
                шапці картки та прогрес-барі. Замість них частота і тип. */}
            {ramFreq > 0 && (
              <MetricRow label="Частота пам&apos;яті:"><span className="font-mono text-emerald-300">{ramFreq} МГц</span></MetricRow>
            )}
            {ramType && (
              <MetricRow label="Тип пам&apos;яті:">
                <span className="rounded-lg border border-emerald-500/25 bg-emerald-500/10 px-2 py-0.5 font-mono text-[10px] font-bold text-emerald-300">{ramType}</span>
              </MetricRow>
            )}
            {!ramFreq && !ramType && ramSpeed && (
              <MetricRow label="Пам&apos;ять:"><span className="font-mono text-emerald-300">{ramSpeed}</span></MetricRow>
            )}
          </div>
        </div>

      </div>

      {/* Екран + Акумулятор (ТЗ: рамка «Екран» — redesign, час роботи батареї).
          ТЗ: дубліючу рамку «Система» (ОС/ім'я ПК/користувач/материнка) ВИДАЛЕНО —
          усе це вже у шапці зверху. */}
      <div className={`grid grid-cols-1 gap-6 ${batteryPresent ? 'lg:grid-cols-2' : ''}`}>
        {screen && (screen.resolution || screen.model || screen.refreshHz) ? (
          <div className="fc-card bg-[#090b14]/80 p-6">
            <div className="fc-section-head mb-5">
              <div className="fc-section-icon"><Monitor className="h-5 w-5" /></div>
              <div className="min-w-0">
                <h3>Екран</h3>
                <p className="break-words leading-snug" title={screen.model || 'Монітор'}>{screen.model || 'Монітор'}</p>
              </div>
              {!!screen.refreshHz && (
                <span className="ml-auto flex-none rounded-full border border-indigo-400/30 bg-indigo-500/10 px-2.5 py-1 font-mono text-[11px] font-black text-indigo-300">
                  {screen.refreshHz} Гц
                </span>
              )}
            </div>

            {/* Стилізований монітор: роздільність — «на екрані», масштаб — на підставці (ТЗ: виглядає красиво) */}
            <div className="flex flex-col items-center">
              <div className="w-full max-w-sm rounded-2xl border border-white/15 bg-gradient-to-b from-[#12102a] to-[#0a0918] p-2.5 shadow-[0_20px_50px_-20px_rgba(124,58,237,.45),inset_0_1px_rgba(255,255,255,.08)]">
                <div className="relative overflow-hidden rounded-xl border border-indigo-400/20 bg-[radial-gradient(ellipse_at_top,rgba(124,58,237,.28),rgba(5,5,8,.98)_70%)] px-4 py-7 text-center">
                  <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(rgba(255,255,255,.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,.03)_1px,transparent_1px)] bg-[size:26px_26px]" />
                  {screen.resolution ? (
                    <p className="relative font-mono text-3xl font-black tracking-tight text-white sm:text-4xl">{screen.resolution}</p>
                  ) : (
                    <p className="relative text-sm font-bold text-zinc-400">Дані дисплея з&apos;являться після оновлення агента</p>
                  )}
                  <p className="relative mt-1.5 text-[11px] font-bold uppercase tracking-wider text-indigo-300/80">роздільність екрана</p>
                </div>
              </div>
              <div className="h-3 w-16 rounded-b-lg bg-gradient-to-b from-[#1c1a33] to-[#100f1f]" />
              <div className="h-1.5 w-36 rounded-full bg-[#1c1a33]" />

              <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
                {!!screen.scalePercent && (
                  <span className="inline-flex items-center gap-1 rounded-full border border-white/10 bg-white/5 px-3 py-1 font-mono text-[11px] font-bold text-zinc-300">
                    <Ruler className="h-3 w-3 text-indigo-300" /> масштаб {screen.scalePercent}%
                  </span>
                )}
                {screen.resolution && (
                  <span className="inline-flex items-center gap-1 rounded-full border border-white/10 bg-white/5 px-3 py-1 font-mono text-[11px] font-bold text-zinc-300">
                    <Maximize className="h-3 w-3 text-indigo-300" /> {screen.resolution}
                  </span>
                )}
              </div>
            </div>
          </div>
        ) : null}

        {batteryPresent && (
          <div className="fc-card bg-[#090b14]/80 p-6">
            <div className="fc-section-head mb-4">
              <div className="fc-section-icon">
                {batteryCharging
                  ? <BatteryCharging className="h-5 w-5" />
                  : <BatteryFull className="h-5 w-5" />}
              </div>
              <div>
                <h3>Акумулятор</h3>
                <p>{batteryCharging ? 'Заряджання' : 'Від батареї'}</p>
              </div>
              <span className="ml-auto flex-none font-mono text-2xl font-black text-white">{batteryVal}%</span>
            </div>
            <div className="h-2.5 w-full overflow-hidden rounded-full border border-white/10 bg-black/70 p-0.5">
              <div
                className={`h-full rounded-full bg-gradient-to-r ${batteryColor} transition-all duration-700`}
                style={{ width: `${batteryVal}%` }}
              />
            </div>
            <div className="mt-3 space-y-1.5 border-t border-white/10 pt-3">
              <MetricRow label="Стан:">
                {batteryCharging
                  ? <span className="text-emerald-300">На зарядці</span>
                  : batteryVal <= 20
                    ? <span className="text-rose-300">Низький заряд</span>
                    : <span className="text-emerald-300">Норма</span>}
              </MetricRow>
              {/* Орієнтовний залишок роботи — ЛИШЕ коли реально відомий (ТЗ:
                  «на зарядці пиши реальну потужність, а якщо невідомо — не пиши»).
                  Заглушку «заряджання…» прибрано — більше не вводить в оману. */}
              {!batteryCharging && batteryTimeLabel && (
                <MetricRow label="Залишок роботи:">
                  <span className="font-mono text-amber-300">{batteryTimeLabel}</span>
                </MetricRow>
              )}
              {batteryCharging && !!batteryTimeToFull && (
                <MetricRow label="До повного заряду:">
                  <span className="font-mono text-emerald-300">{batteryTimeToFull}</span>
                </MetricRow>
              )}
              {/* Потужність: на зарядці — скільки реально приходить (Вт), від
                  батареї — скільки реально споживається. Якщо сенсор віддає 0
                  (ноутбук не вміє) — рядок НЕ показуємо взагалі (ТЗ). */}
              {(batteryRateLabel) && (
                <MetricRow label={batteryCharging ? 'Потужність заряду:' : 'Споживає з батареї:'}>
                  <span className={`font-mono ${batteryCharging ? 'text-emerald-300' : 'text-amber-300'}`}>{batteryRateLabel}</span>
                </MetricRow>
              )}
              {(batteryHealth !== null) && (
                <MetricRow label="Стан батареї (здоров'я):">
                  <span className={`font-mono ${batteryHealth >= 80 ? 'text-emerald-300' : batteryHealth >= 60 ? 'text-amber-300' : 'text-rose-300'}`}>{batteryHealth}%</span>
                  {batteryCapacitiesLabel && <span className="ml-1.5 text-[10px] text-zinc-500">{batteryCapacitiesLabel}</span>}
                </MetricRow>
              )}
              {(batteryVoltageLabel) && (
                <MetricRow label="Напруга:">
                  <span className="font-mono text-zinc-300">{batteryVoltageLabel}</span>
                </MetricRow>
              )}
              {(metrics?.batteryCycleCount ?? 0) > 0 && (
                <MetricRow label="Циклів заряду:">
                  <span className="font-mono text-zinc-300">{metrics!.batteryCycleCount}</span>
                </MetricRow>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Network & Speedtest Card */}
      <div className="fc-card bg-[#090b14]/80 p-6">
        <div className="fc-section-head mb-5 flex-wrap gap-3">
          <div className="fc-section-icon"><Wifi className="h-5 w-5" /></div>
          <div>
            <h3>Мережа та Інтернет</h3>
            <p>IP-адреси та швидкість з&apos;єднання</p>
          </div>
          <button
            onClick={handleRunSpeedTest}
            disabled={speedRunning || !sessionLive}
            className="fc-btn fc-btn-primary ml-auto disabled:cursor-not-allowed disabled:opacity-50"
          >
            {speedRunning ? <RefreshCw className="h-3.5 w-3.5 animate-spin" /> : <Gauge className="h-3.5 w-3.5" />}
            <span>{speedRunning ? 'Вимірювання…' : 'Запустити Speedtest'}</span>
          </button>
        </div>

        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-5">
          <div className="fc-card-static space-y-1 p-4">
            <div className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-wide text-zinc-400">
              <Globe className="h-3.5 w-3.5 text-cyan-300" /> Внутрішній IP
            </div>
            <p className="break-all font-mono text-sm text-white">{lanIp || '—'}</p>
          </div>
          <div className="fc-card-static space-y-1 p-4">
            <div className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-wide text-zinc-400">
              <Server className="h-3.5 w-3.5 text-cyan-300" /> Зовнішній IP
            </div>
            <p className="break-all font-mono text-sm text-white">{wanIp || '—'}</p>
          </div>
          <div className="fc-card-static space-y-1 p-4">
            <div className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-wide text-zinc-400">
              <Download className="h-3.5 w-3.5 text-emerald-400" /> Завантаження
            </div>
            <p className="font-mono text-sm text-white">
              {speedTest?.downloadMbps !== undefined ? `${speedTest.downloadMbps.toFixed(1)} Мбіт/с` : '—'}
            </p>
          </div>
          <div className="fc-card-static space-y-1 p-4">
            <div className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-wide text-zinc-400">
              <Upload className="h-3.5 w-3.5 text-indigo-300" /> Віддача
            </div>
            <p className="font-mono text-sm text-white">
              {speedTest?.uploadMbps !== undefined ? `${speedTest.uploadMbps.toFixed(1)} Мбіт/с` : '—'}
            </p>
          </div>
          <div className="fc-card-static space-y-1 p-4">
            <div className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-wide text-zinc-400">
              <Activity className="h-3.5 w-3.5 text-cyan-300" /> Пінг
            </div>
            <p className="font-mono text-sm text-white">
              {speedTest?.pingMs !== undefined ? `${speedTest.pingMs} мс` : '—'}
            </p>
          </div>
        </div>

        {speedRunning && (
          <div className="mt-4 flex items-center gap-2 rounded-2xl border border-cyan-500/25 bg-cyan-950/30 p-3 text-xs text-cyan-200">
            <Activity className="h-4 w-4 animate-pulse" />
            <span>Тестування швидкості: {speedStage || 'вимірювання каналу…'}</span>
          </div>
        )}
        {!speedRunning && speedTest?.timestamp && !speedTest.error && (
          <div className="mt-4 flex flex-wrap items-center gap-2 text-[11px] text-zinc-500">
            <Timer className="h-3.5 w-3.5" />
            <span>Останній тест: {formatSpeedTestTime(speedTest.timestamp)}{formatDuration(speedTest.durationMs)}</span>
            {/* Режим запуску: manually pressed button vs the automatic startup test. */}
            {speedTest.mode === 'manual' ? (
              <span className="fc-badge fc-badge-ok">
                <Gauge className="h-3 w-3" /> запущено вручну
              </span>
            ) : speedTest.mode === 'auto' ? (
              <span className="fc-badge fc-badge-info">
                <Zap className="h-3 w-3" /> автоматично при підключенні
              </span>
            ) : null}
          </div>
        )}
        {speedTest?.error && (
          <div className="mt-4 text-[11px] text-amber-300">{speedTest.error}</div>
        )}
      </div>

      {/* Disks Real Storage Grid */}
      {disks.length > 0 && (
        <div className="fc-card bg-[#090b14]/80 p-6">
          <div className="fc-section-head mb-5">
            <div className="fc-section-icon"><Disc3 className="h-5 w-5" /></div>
            <div>
              <h3>Накопичувачі та диски</h3>
              <p>Фактичний обсяг пам&apos;яті на машині</p>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
            {disks.map((d, i) => (
              <div key={i} className="fc-card-static space-y-3 p-4 transition-transform duration-200 hover:-translate-y-0.5">
                {/* Шапка: літера + бейдж типу носія (SSD/HDD) — крупно і одразу видно */}
                <div className="flex items-center justify-between gap-2">
                  <div className="flex min-w-0 items-center gap-2.5">
                    <div className="flex-none rounded-lg border border-white/10 bg-white/5 p-1.5">
                      <DiskIcon disk={d} />
                    </div>
                    <span className="truncate font-mono text-base font-black text-white">{d.name}</span>
                  </div>
                  {d.mediaType && (
                    <span className={`flex-none rounded-md px-2 py-0.5 text-[10px] font-black uppercase tracking-wide ${
                      d.mediaType === 'SSD' || d.mediaType === 'NVMe'
                        ? 'border border-emerald-500/25 bg-emerald-500/10 text-emerald-300'
                        : d.mediaType === 'HDD'
                          ? 'border border-amber-500/25 bg-amber-500/10 text-amber-300'
                          : 'border border-white/10 bg-white/5 text-zinc-300'
                    }`}>{d.mediaType === 'NVMe' ? 'SSD · NVMe' : d.mediaType}</span>
                  )}
                </div>
                {/* МОДЕЛЬ ДИСКА (ТЗ: бачити точну модель, напр. «KingSpec KP200»)
                    — крупніше за метадані, з перенесенням замість обрізання */}
                {(d.model || d.label) && (
                  <p className="break-words text-xs font-semibold leading-snug text-zinc-300" title={d.model || d.label}>
                    {d.model || d.label}
                  </p>
                )}
                <div>
                  <div className="h-2 w-full overflow-hidden rounded-full bg-white/10">
                    <div
                      className={`h-full rounded-full bg-gradient-to-r ${getDiskBarColor(d.percentUsed)} transition-all duration-700`}
                      style={{ width: `${d.percentUsed}%` }}
                    />
                  </div>
                  <div className="mt-2 flex justify-between text-[11px] text-zinc-400">
                    {/* ТЗ: «вільно/всього — БІЛИМ», без кольорових акцентів */}
                    <span>Вільно: <b className="text-white">{formatSmartSize(d.freeBytes, d.freeGb)}</b></span>
                    <span>Всього: <b className="text-white">{formatSmartSize(d.totalBytes, d.totalGb)}</b></span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ТЗ: Пристрої та периферія (Диспетчер пристроїв: клавіатури/миші/звук/принтери/USB) */}
      <DevicesCard sessionLive={sessionLive} />

      {/* Живі графіки навантаження (ТЗ: клік по CPU/GPU/RAM) */}
      {graphModal === 'cpu' && (
        <LiveMetricModal
          title="Процесор — живий графік"
          subtitle={cpuModel}
          accent="indigo"
          history={histRef.current.cpu}
          current={cpuVal}
          onClose={() => setGraphModal(null)}
          extra={
            <div className="grid grid-cols-2 gap-x-8 gap-y-1.5">
              <MetricRow label="Ядра / Потоки:">{cpuCores ?? '—'} / {cpuThreads ?? '—'}</MetricRow>
              {cpuTemp !== null && <MetricRow label="Температура:"><span className={`font-mono ${tempColor(cpuTemp)}`}>~{cpuTemp}°C</span></MetricRow>}
            </div>
          }
        />
      )}
      {graphModal === 'gpu' && (
        <LiveMetricModal
          title="Відеокарта — живий графік"
          subtitle={gpuModel}
          accent="purple"
          history={histRef.current.gpu}
          current={gpuVal}
          onClose={() => setGraphModal(null)}
          extra={
            <div className="grid grid-cols-2 gap-x-8 gap-y-1.5">
              {gpuTemp !== null && <MetricRow label="Температура:"><span className="font-mono text-purple-300">~{gpuTemp}°C</span></MetricRow>}
              {gpuVramTotal !== null && gpuVramTotal > 0 && (
                <MetricRow label="Відеопам&apos;ять:">{formatSmartSize(undefined, gpuVramUsed ?? 0)} з {formatSmartSize(undefined, gpuVramTotal)}</MetricRow>
              )}
            </div>
          }
        />
      )}
      {graphModal === 'ram' && (
        <LiveMetricModal
          title="Пам&apos;ять — живий графік"
          subtitle={ramTotal > 0 ? `${ramUsed} ГБ з ${ramTotal} ГБ` : 'Оперативна пам&apos;ять'}
          accent="emerald"
          history={histRef.current.ram}
          current={ramVal}
          onClose={() => setGraphModal(null)}
          extra={
            <div className="grid grid-cols-2 gap-x-8 gap-y-1.5">
              {ramType && <MetricRow label="Тип пам&apos;яті:"><span className="font-mono text-emerald-300">{ramType}</span></MetricRow>}
              {ramFreq > 0 && <MetricRow label="Частота:"><span className="font-mono text-emerald-300">{ramFreq} МГц</span></MetricRow>}
            </div>
          }
        />
      )}

    </div>
  );
});
