import React, { useEffect, useRef, useState, useCallback, useMemo } from 'react';
import {
  AppWindow,
  Ban,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChevronUp,
  Circle,
  Clock,
  CloudMoon,
  Globe,
  Keyboard,
  Lock,
  Maximize2,
  Minus,
  Monitor,
  Moon,
  Mouse,
  MousePointer,
  MousePointerClick,
  Move,
  Pause,
  Play,
  Plus,
  Power,
  RefreshCw,
  Rocket,
  History,
  RotateCcw,
  ScreenShare,
  Search,
  SkipBack,
  SkipForward,
  Timer,
  Touchpad,
  Type,
  Volume2,
  VolumeX,
  X
} from 'lucide-react';
import { Device } from '../../types';
import { deviceClient } from '../../services/deviceClient';
import { RemoteCaptureTools } from './RemoteCaptureTools';
import { VirtualKeyboardLauncher } from './VirtualKeyboard';
import { WinLockCard } from './WinLockCard';
import { toast } from '../../utils/toast';
import { clampPercent, formatSeconds, loadStoredNumber, pick, storeValue } from './fcEvents';

interface ControlTabProps {
  device: Device;
}

/* ============================================================ */
/* Touchpad gestures: shared accumulate + flush logic            */
/* ============================================================ */

/** Спільна логіка тачпада: накопичує дельти і шле рух мишки ПК не частіше
 *  ніж раз на 16 мс (події тачпада значно частіші за потребу релея). */
function useTouchpadMove(scale: number) {
  const lastRef = useRef<{ x: number; y: number } | null>(null);
  const accRef = useRef({ x: 0, y: 0, lastSent: 0 });

  const begin = (x: number, y: number) => {
    lastRef.current = { x, y };
    accRef.current = { x: 0, y: 0, lastSent: performance.now() };
  };

  const move = (x: number, y: number, s = scale) => {
    if (!lastRef.current) return;
    const dx = (x - lastRef.current.x) * s;
    const dy = (y - lastRef.current.y) * s;
    lastRef.current = { x, y };
    const acc = accRef.current;
    acc.x += dx;
    acc.y += dy;
    const now = performance.now();
    if (now - acc.lastSent >= 16) {
      const rx = Math.round(acc.x);
      const ry = Math.round(acc.y);
      if (rx !== 0 || ry !== 0) {
        deviceClient.sendMouseMove(rx, ry);
        acc.x -= rx;
        acc.y -= ry;
      }
      acc.lastSent = now;
    }
  };

  const end = () => { lastRef.current = null; };

  return {
    onTouchStart: (e: React.TouchEvent) => {
      if (e.touches.length === 1) begin(e.touches[0].clientX, e.touches[0].clientY);
    },
    onTouchMove: (e: React.TouchEvent) => {
      if (e.touches.length === 1) move(e.touches[0].clientX, e.touches[0].clientY);
    },
    onTouchEnd: end,
    onMouseDown: (e: React.MouseEvent) => begin(e.clientX, e.clientY),
    onMouseMove: (e: React.MouseEvent) => {
      if (e.buttons === 1) move(e.clientX, e.clientY, scale - 0.2);
    },
    onMouseUp: end
  };
}

/* ============================================================ */
/* Fullscreen touchpad — для телефонів: не скролить сайт         */
/* ============================================================ */

const TouchpadFullscreen: React.FC<{ deviceName: string; onClose: () => void }> = React.memo(({ deviceName, onClose }) => {
  const moveHandlers = useTouchpadMove(2.1);
  // Жест по поверхні: тап = клік, два пальці = скрол/щипок (ТЗ 46: зум), тап двома = ПКМ.
  const gest = useRef({ fingers: 0, moved: false, startT: 0, twoFinger: false, scrollLastY: 0, pinchLastDist: 0 });
  // Затиснута кнопка в нижній панелі (drag пальцем + затиснута ЛКМ).
  const heldBtn = useRef<'left' | null>(null);

  useEffect(() => {
    const prior = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => {
      document.body.style.overflow = prior;
      window.removeEventListener('keydown', onKey);
    };
  }, [onClose]);

  const markMoved = () => { gest.current.moved = true; };

  const surfaceTouchStart = (e: React.TouchEvent) => {
    const t = e.touches;
    gest.current.fingers = t.length;
    gest.current.moved = false;
    gest.current.startT = performance.now();
    if (t.length === 1) {
      gest.current.twoFinger = false;
      moveHandlers.onTouchStart(e);
    } else if (t.length >= 2) {
      gest.current.twoFinger = true;
      gest.current.scrollLastY = (t[0].clientY + t[1].clientY) / 2;
      gest.current.pinchLastDist = Math.hypot(t[0].clientX - t[1].clientX, t[0].clientY - t[1].clientY);
    }
  };

  const surfaceTouchMove = (e: React.TouchEvent) => {
    const t = e.touches;
    if (t.length >= 2 && gest.current.twoFinger) {
      const y = (t[0].clientY + t[1].clientY) / 2;
      const dy = y - gest.current.scrollLastY;
      gest.current.scrollLastY = y;
      // ТЗ 46: щипок двома пальцями = зум (Ctrl+скрол на ПК).
      const dist = Math.hypot(t[0].clientX - t[1].clientX, t[0].clientY - t[1].clientY);
      const dDist = dist - gest.current.pinchLastDist;
      gest.current.pinchLastDist = dist;
      if (Math.abs(dDist) > Math.abs(dy) * 1.4 && Math.abs(dDist) >= 2) {
        // Домінує зміна відстані → це щипок: назустріч = збільшити.
        deviceClient.sendMouseScrollEx(0, Math.round(-dDist * 4), true);
        markMoved();
      } else if (Math.abs(dy) >= 2) {
        deviceClient.sendMouseScroll(0, Math.round(-dy * 2.6));
        markMoved();
      }
    } else if (t.length === 1) {
      moveHandlers.onTouchMove(e);
    }
  };

  const surfaceTouchEnd = (e: React.TouchEvent) => {
    const remaining = e.touches.length;
    if (remaining === 0) {
      const g = gest.current;
      const dur = performance.now() - g.startT;
      if (!g.moved && dur < 280) {
        // Тап без руху: один палець — ЛКМ, два пальці — ПКМ.
        deviceClient.sendMouseClick(g.twoFinger ? 'right' : 'left');
      }
      moveHandlers.onTouchEnd();
      gest.current.fingers = 0;
    } else if (remaining === 1) {
      // Другий палець підняли — перезапускаємо трекінг руху чисто.
      gest.current.twoFinger = false;
      moveHandlers.onTouchEnd();
      moveHandlers.onTouchStart({ touches: e.touches } as React.TouchEvent);
    }
  };

  const holdLeftDown = () => {
    heldBtn.current = 'left';
    deviceClient.sendMouseDown('left');
  };
  const holdLeftUp = () => {
    if (heldBtn.current === 'left') {
      heldBtn.current = null;
      deviceClient.sendMouseUp('left');
    }
  };

  return (
    <div className="tp-fs" role="dialog" aria-modal="true" aria-label="Тачпад на весь екран">
      <div className="tp-fs-bar" style={{ paddingTop: '.8rem', paddingBottom: 0 }}>
        <div className="flex min-w-0 items-center gap-2.5">
          <span className="grid h-9 w-9 flex-none place-items-center rounded-xl border border-indigo-400/30 bg-indigo-500/20 text-indigo-300">
            <Touchpad className="h-4.5 w-4.5" />
          </span>
          <div className="min-w-0">
            <p className="truncate text-xs font-extrabold text-white">Тачпад — {deviceName}</p>
            <p className="text-[10px] text-zinc-400">сайт не скролиться, поки тачпад відкритий</p>
          </div>
        </div>
        <button onClick={onClose} className="tp-fs-btn tp-fs-close ml-auto" aria-label="Закрити тачпад">
          <X className="h-5 w-5" />
        </button>
      </div>

      <div
        className="tp-fs-surface"
        {...moveHandlers}
        onTouchStart={surfaceTouchStart}
        onTouchMove={surfaceTouchMove}
        onTouchEnd={surfaceTouchEnd}
      >
        <div className="tp-fs-dots" />
        <div className="tp-fs-hint">
          <Move className="h-8 w-8" />
          <b>Водіть пальцем — мишка на ПК рухається</b>
          <small>
            тап — лівий клік &nbsp;·&nbsp; тап двома пальцями — правий клік<br />
            рух двома пальцями — прокрутка &nbsp;·&nbsp; щипок двома — зум (ТЗ 46)<br />
            затиснута «ЛКМ» знизу — перетягування
          </small>
        </div>
      </div>

      <div className="tp-fs-bar">
        <button
          className={`tp-fs-btn ${heldBtn.current === 'left' ? 'held' : ''}`}
          onPointerDown={holdLeftDown}
          onPointerUp={holdLeftUp}
          onPointerLeave={holdLeftUp}
          onPointerCancel={holdLeftUp}
        >
          <MousePointerClick className="h-4 w-4" />
          <span>ЛКМ (тримати = drag)</span>
        </button>
        <button className="tp-fs-btn" onClick={() => deviceClient.sendMouseClick('left', true)}>
          <span>2×</span>
        </button>
        <button className="tp-fs-btn" onClick={() => deviceClient.sendMouseClick('right')}>
          <MousePointer className="h-4 w-4" />
          <span>ПКМ</span>
        </button>
      </div>
    </div>
  );
});
TouchpadFullscreen.displayName = 'TouchpadFullscreen';

/* ============================================================ */
/* Мишка-пристрій: натискабельна форма з ЛКМ / ПКМ / коліщатком  */
/* ============================================================ */

const CLICK_DELAY_MS = 240;

const MouseCard: React.FC<{ deviceName: string }> = React.memo(({ deviceName }) => {
  const inlinePad = useTouchpadMove(1.8);
  const [fsOpen, setFsOpen] = useState(false);
  const [held, setHeld] = useState<string | null>(null);
  // Ліва кнопка: перший тап чекає CLICK_DELAY — якщо прийде другий,
  // надсилаємо подвійний клік замість двох одиночних.
  const singleClickTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const dragMoved = useRef(false);

  const clearSingleTimer = () => {
    if (singleClickTimer.current) {
      clearTimeout(singleClickTimer.current);
      singleClickTimer.current = null;
    }
  };

  useEffect(() => clearSingleTimer, []);

  /** Спільна обробка зони: затиснення = press-hold (drag), короткий тап = клік. */
  const zoneHandlers = (id: string, button: 'left' | 'right' | 'middle') => ({
    onPointerDown: () => {
      dragMoved.current = false;
      setHeld(id);
      if (button !== 'middle') deviceClient.sendMouseDown(button);
    },
    onPointerMove: () => {
      dragMoved.current = true;
    },
    onPointerUp: () => {
      setHeld(null);
      if (button === 'middle') return; // коліщатко: тільки клік нижче
      deviceClient.sendMouseUp(button);
      if (!dragMoved.current) {
        if (button === 'left') {
          if (singleClickTimer.current) {
            clearTimeout(singleClickTimer.current);
            singleClickTimer.current = null;
            deviceClient.sendMouseClick('left', true);
          } else {
            singleClickTimer.current = setTimeout(() => {
              singleClickTimer.current = null;
              deviceClient.sendMouseClick('left');
            }, CLICK_DELAY_MS);
          }
        } else {
          deviceClient.sendMouseClick('right');
        }
      }
    },
    onPointerLeave: () => {
      if (held !== id) return;
      setHeld(null);
      if (button !== 'middle') deviceClient.sendMouseUp(button);
      clearSingleTimer();
    }
  });

  // Коліщатко на формі більше не є окремою кнопкою (ТЗ) — скрол працює
  // бічними кнопками ▲/▼ і двома пальцями на тачпаді.

  return (
    <section className="fc-card p-5">
      <div className="fc-section-head mb-4">
        <div className="fc-section-icon"><Mouse className="h-5 w-5" /></div>
        <div>
          <h3>Віртуальна мишка</h3>
          <p>Тап по корпусу — клік, затисни і веди — перетягування</p>
        </div>
      </div>

      <div className="grid items-center gap-5 sm:grid-cols-[auto,1fr]">
        {/* Корпус мишки: форма декоративна (ТЗ: нічого не «нажимається» окремо),
            весь корпус — одна велика тач-зона. Бічні кнопки — поруч. */}
        <div className="flex items-center gap-3">
          <div className="mouse-device">
            {/* Декоративні зони — без обробників */}
            <span className="mouse-zone mouse-l !cursor-default" />
            <span className="mouse-zone mouse-r !cursor-default" />
            <span className="mouse-wheel !cursor-default" />
            <span className="mouse-sep" />
            <span className="mouse-hline" />
            <span className="mouse-zone-tag" style={{ left: '.9rem', top: '1.1rem' }}>ЛКМ</span>
            <span className="mouse-zone-tag" style={{ right: '.9rem', top: '1.1rem' }}>ПКМ</span>
            {/* Весь корпус = тач-зона: тап — лівий клік, затиснення+рух — drag */}
            <div className={`mouse-zone mouse-palm ${held === 'body' ? 'held' : ''}`} {...zoneHandlers('body', 'left')}>
              <div className="mouse-palm-inner">
                <MousePointer />
                <b>Тап — клік</b>
                <small>Затисни і веди — перетягування. Два тапи — подвійний клік.</small>
              </div>
            </div>
          </div>

          {/* Бічні кнопки (ТЗ: маленькі, красиві, збоку) — lucide-іконки замість emoji-символів */}
          <div className="flex flex-col gap-1.5">
            {([
              { id: 'back', Icon: ChevronLeft, title: 'Назад (браузер/папки)' },
              { id: 'forward', Icon: ChevronRight, title: 'Вперед (браузер/папки)' },
              { id: 'middle', Icon: Circle, title: 'Середній клік (коліщатко)' },
            ] as const).map(({ id, Icon, title }) => (
              <button
                key={id}
                title={title}
                aria-label={title}
                onClick={() => deviceClient.sendMouseClick(id)}
                className="grid h-9 w-9 cursor-pointer place-items-center rounded-xl border border-white/10 bg-white/[.04] text-zinc-300 transition-all hover:border-violet-400/50 hover:bg-violet-500/15 hover:text-white active:scale-95"
              >
                <Icon className="h-4 w-4" />
              </button>
            ))}
            <span className="mx-auto my-0.5 h-px w-5 bg-white/10" />
            {([
              { dy: 120, Icon: ChevronUp, title: 'Скрол вгору' },
              { dy: -120, Icon: ChevronDown, title: 'Скрол вниз' },
            ] as const).map(({ dy, Icon, title }) => (
              <button
                key={title}
                title={title}
                aria-label={title}
                onClick={() => deviceClient.sendMouseScroll(0, dy)}
                className="grid h-9 w-9 cursor-pointer place-items-center rounded-xl border border-white/10 bg-white/[.04] text-zinc-300 transition-all hover:border-indigo-400/50 hover:bg-indigo-500/15 hover:text-white active:scale-95"
              >
                <Icon className="h-4 w-4" />
              </button>
            ))}
          </div>
        </div>

        {/* Компактний тачпад + кнопка на весь екран (ТЗ: не чіпати) */}
        <div className="flex flex-col gap-3">
          <div
            {...inlinePad}
            className="group relative flex h-36 w-full select-none flex-col items-center justify-center overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-br from-black/70 via-indigo-950/20 to-black/70 shadow-inner touch-none cursor-crosshair hover:border-indigo-500/30"
          >
            <div className="absolute inset-0 bg-[radial-gradient(#6366f1_1px,transparent_1px)] [background-size:16px_16px] opacity-10" />
            <p className="text-xs font-medium text-indigo-300/60">Швидкий тачпад</p>
            <p className="mt-0.5 text-[10px] text-zinc-500">водіть пальцем — мишка рухається</p>
          </div>
          <button onClick={() => setFsOpen(true)} className="fc-btn fc-btn-primary fc-shine w-full">
            <Maximize2 className="h-4 w-4" />
            <span>Тачпад на весь екран</span>
          </button>
          <p className="text-center text-[10px] leading-relaxed text-zinc-500 sm:text-left">
            На телефоні відкривається на весь екран: сайт не скролиться,
            тап — клік, два пальці — скрол і ПКМ.
          </p>
        </div>
      </div>

      {/* Virtual keyboard launcher */}
      <div className="fc-card-static mt-4 flex items-center justify-between gap-3 px-4 py-3">
        <div className="flex items-center gap-2.5">
          <div className="grid h-9 w-9 flex-none place-items-center rounded-xl border border-indigo-400/25 bg-indigo-500/15 text-indigo-300">
            <Keyboard className="h-4 w-4" />
          </div>
          <div>
            <p className="text-xs font-bold text-white">Керування введенням</p>
            <p className="mt-0.5 text-[10px] text-zinc-400">Повна віртуальна клавіатура з комбінаціями</p>
          </div>
        </div>
        <VirtualKeyboardLauncher />
      </div>

      {fsOpen && <TouchpadFullscreen deviceName={deviceName} onClose={() => setFsOpen(false)} />}
    </section>
  );
});
MouseCard.displayName = 'MouseCard';

/* ============================================================ */
/* Text & link printing                                          */
/* ============================================================ */

const TextLinkCard: React.FC = React.memo(() => {
  const [textInput, setTextInput] = useState('');
  const [urlInput, setUrlInput] = useState('');

  const handleSendText = (e: React.FormEvent) => {
    e.preventDefault();
    if (!textInput.trim()) return;
    deviceClient.sendText(textInput.trim());
    toast.success('Текст надруковано у активному вікні ПК');
    setTextInput('');
  };

  const handleOpenUrl = (e: React.FormEvent) => {
    e.preventDefault();
    if (!urlInput.trim()) return;
    let url = urlInput.trim();
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      url = 'https://' + url;
    }
    deviceClient.openUrl(url);
    toast.info(`Відкриття посилання на ПК: ${url}`);
    setUrlInput('');
  };

  return (
    <section className="fc-card p-5">
      <div className="fc-section-head mb-4">
        <div className="fc-section-icon"><Type className="h-5 w-5" /></div>
        <div>
          <h3>Друк тексту та посилання</h3>
          <p>Надішліть текст або URL прямо на екран ПК</p>
        </div>
      </div>

      <div className="space-y-4">
        {/* Багаторядковий друк тексту: Ctrl+Enter швидко надсилає (ТЗ: зробити краще) */}
        <form onSubmit={handleSendText}>
          <div className="relative">
            <textarea
              value={textInput}
              onChange={(e) => setTextInput(e.target.value)}
              onKeyDown={(e) => {
                if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
                  e.preventDefault();
                  handleSendText(e as unknown as React.FormEvent);
                }
              }}
              rows={3}
              placeholder="Текст, який треба надрукувати на ПК… (Ctrl+Enter — надіслати)"
              className="fc-input w-full resize-none pb-8 leading-relaxed"
            />
            <span className="pointer-events-none absolute bottom-2.5 right-3 font-mono text-[10px] text-zinc-500">
              {textInput.length ? `${textInput.length}` : ''}
            </span>
          </div>
          <div className="mt-2 flex items-center justify-end">
            <button type="submit" className="fc-btn fc-btn-primary" disabled={!textInput.trim()}>
              <Keyboard className="h-3.5 w-3.5" />
              <span>Надрукувати</span>
            </button>
          </div>
        </form>

        <form onSubmit={handleOpenUrl} className="flex flex-col items-stretch gap-2 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Globe className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-zinc-500" />
            <input
              type="text"
              value={urlInput}
              onChange={(e) => setUrlInput(e.target.value)}
              placeholder="youtube.com або будь-яке посилання…"
              className="fc-input w-full pl-9"
            />
          </div>
          <button type="submit" className="fc-btn fc-btn-primary">
            <Globe className="h-3.5 w-3.5" />
            <span>Відкрити на ПК</span>
          </button>
        </form>
      </div>
    </section>
  );
});
TextLinkCard.displayName = 'TextLinkCard';

/* ============================================================ */
/* Media player + volume                                         */
/* ============================================================ */

const RoundMediaButton: React.FC<{
  label: string;
  onClick: () => void;
  children: React.ReactNode;
}> = React.memo(({ label, onClick, children }) => (
  <button
    onClick={onClick}
    title={label}
    aria-label={label}
    className="grid h-11 w-11 flex-none place-items-center rounded-full border border-white/10 bg-white/[.06] text-zinc-200 transition hover:border-indigo-400/50 hover:bg-white/[.12] hover:text-white active:scale-95"
  >
    {children}
  </button>
));
RoundMediaButton.displayName = 'RoundMediaButton';

const MediaPlayerCard: React.FC = React.memo(() => {
  const [volume, setVolume] = useState(50);
  const [muted, setMuted] = useState(false);
  const [playing, setPlaying] = useState(false);
  // РЕАЛЬНИЙ статус відтворення (ТЗ): агент шле media_state (пік гучності).
  // null = ще немає даних (старий агент) — тоді працюємо оптимістично як раніше.
  const [realPlaying, setRealPlaying] = useState<boolean | null>(null);
  const VOLUME_STEP = 2; // фикс: ±2% всегда
  const volumeSendRef = useRef({ lastSent: 0, trailing: null as ReturnType<typeof setTimeout> | null });
  const mountedRef = useRef(true);

  useEffect(() => {
    mountedRef.current = true;
    const offState = deviceClient.on('volume_state', (raw: any) => {
      if (!mountedRef.current) return;
      const s = pick<any>(raw);
      if (s && typeof s.value === 'number') {
        setVolume(clampPercent(Math.round(s.value)));
        setMuted(!!s.muted);
      }
    });
    // media_state від агента: { playing, supported, volume, muted }
    const offMedia = deviceClient.on('media_state', (raw: any) => {
      if (!mountedRef.current) return;
      const s = pick<any>(raw);
      if (!s) return;
      if (typeof s.playing === 'boolean') {
        setRealPlaying(!!s.playing);
        setPlaying(!!s.playing); // реальний статус перебиває optimistic (ТЗ)
      }
      if (typeof s.volume === 'number' && !s.muted) setVolume(clampPercent(Math.round(s.volume)));
      if (typeof s.muted === 'boolean') setMuted(!!s.muted);
    });
    const offError = deviceClient.on('media_error', (raw: any) => {
      if (!mountedRef.current) return;
      const s = pick<any>(raw);
      toast.error(s?.message || 'Помилка медіа-керування');
    });
    // Sync with the real volume of the remote PC.
    deviceClient.requestVolumeState();
    // Перший запит реального статусу + легкий опитувач (не тягне CPU: пік знімається на ПК швидко).
    deviceClient.send('get_media_status', {});
    const poll = setInterval(() => {
      if (mountedRef.current) deviceClient.send('get_media_status', {});
    }, 6000);
    return () => {
      mountedRef.current = false;
      offState();
      offMedia();
      offError();
      clearInterval(poll);
      if (volumeSendRef.current.trailing) clearTimeout(volumeSendRef.current.trailing);
    };
  }, []);

  // Throttled exact-set while dragging the slider: at most one message per
  // 150 ms with a trailing flush of the final position.
  const pushSet = (value: number) => {
    const st = volumeSendRef.current;
    const now = Date.now();
    if (st.trailing) clearTimeout(st.trailing);
    if (now - st.lastSent >= 150) {
      st.lastSent = now;
      deviceClient.sendVolumeEx('set', value);
    } else {
      st.trailing = setTimeout(() => {
        st.lastSent = Date.now();
        st.trailing = null;
        deviceClient.sendVolumeEx('set', value);
      }, 150);
    }
  };

  const onSliderChange = (value: number) => {
    setVolume(value);
    if (muted) setMuted(false);
    pushSet(value);
  };

  const stepDown = () => {
    const v = clampPercent(volume - VOLUME_STEP);
    setVolume(v);
    setMuted(false);
    deviceClient.sendVolumeEx('down', undefined, VOLUME_STEP);
  };

  const stepUp = () => {
    const v = clampPercent(volume + VOLUME_STEP);
    setVolume(v);
    setMuted(false);
    deviceClient.sendVolumeEx('up', undefined, VOLUME_STEP);
  };

  const toggleMute = () => {
    setMuted(m => !m);
    deviceClient.sendMediaControl('mute');
  };

  const media = (command: string) => {
    deviceClient.sendMediaControl(command);
    // Короткий локальний стан для миттєвої реакції іконки — через 500 мс
    // агент пришле справжній media_state і все виправиться (ТЗ).
    if (command === 'play_pause') setPlaying(p => !p);
    if (command === 'prev') setPlaying(true);
    if (command === 'next') setPlaying(true);
    if (command === 'stop') setPlaying(false);
  };

  return (
    <section className="fc-card p-5">
      <div className="fc-section-head mb-5 flex-wrap gap-3">
        <div className="fc-section-icon"><Volume2 className="h-5 w-5" /></div>
        <div>
          <h3>Медіа та звук</h3>
          <p>Плеєр і гучність віддаленого ПК</p>
        </div>
        <span className={`ml-auto flex-none rounded-full border px-3 py-1 font-mono text-sm font-black ${muted
          ? 'border-rose-400/40 bg-rose-500/10 text-rose-300'
          : 'border-indigo-400/30 bg-indigo-500/10 text-indigo-200'}`}>
          {muted ? 'MUTE' : `${volume}%`}
        </span>
      </div>

      {/* Гучність: mute · мінус · слайдер · плюс — крок фіксований ±2%,
          у власній підложці (ТЗ: рамка «Медіа та звук» була трохи кривою) */}
      <div className="flex items-center gap-2.5 rounded-2xl border border-white/[.07] bg-black/30 p-3">
        <button
          onClick={toggleMute}
          title={muted ? 'Увімкнути звук' : 'Вимкнути звук (mute)'}
          aria-label={muted ? 'Увімкнути звук' : 'Вимкнути звук'}
          className={`grid h-11 w-11 flex-none place-items-center rounded-xl border transition active:scale-95 ${muted
            ? 'border-rose-400/50 bg-gradient-to-br from-rose-600/55 to-rose-950/70 text-rose-200 shadow-[0_10px_26px_-10px_rgba(225,29,72,.85)]'
            : 'border-white/10 bg-white/[.06] text-zinc-200 hover:border-indigo-400/50 hover:bg-white/[.12] hover:text-white'}`}
        >
          {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
        </button>
        <button onClick={stepDown} title="Тихіше (−2%)" aria-label="Тихіше" className="vol-round">
          <Minus />
        </button>
        <input
          type="range"
          min={0}
          max={100}
          value={muted ? 0 : volume}
          onChange={(e) => onSliderChange(parseInt(e.target.value, 10))}
          aria-label="Гучність на ПК"
          className="fc-range"
          style={{
            background: muted
              ? 'linear-gradient(90deg, #3f3f46 0%, #52525b 100%)'
              : `linear-gradient(90deg, #6366f1 0%, #a78bfa ${volume}%, rgba(0,0,0,.55) ${volume}%)`
          }}
        />
        <button onClick={stepUp} title="Гучніше (+2%)" aria-label="Гучніше" className="vol-round">
          <Plus />
        </button>
      </div>

      {/* Транспорт: скляна підложка, по центру; еквалайзер танцює під час відтворення.
          Відображаємо РЕАЛЬНИЙ статус з ПК (media_state), поки він не прийшов — optimistic.
          ТЗ: кнопку «Стоп» і дрібний текст під паузою прибрано. */}
      <div className="mt-4 rounded-2xl border border-white/10 bg-gradient-to-br from-white/[.055] to-transparent p-4">
        <div className="flex items-center justify-center gap-4">
          <RoundMediaButton label="Попередній трек" onClick={() => media('prev')}>
            <SkipBack className="h-4 w-4" />
          </RoundMediaButton>

          <button
            onClick={() => media('play_pause')}
            title="Відтворення / Пауза"
            aria-label="Відтворення або пауза"
            className="relative grid h-16 w-16 flex-none place-items-center rounded-full bg-gradient-to-br from-violet-500 via-violet-600 to-indigo-700 text-white shadow-[0_14px_34px_-10px_rgba(124,58,237,.9),inset_0_1px_rgba(255,255,255,.35)] transition hover:brightness-110 active:scale-95"
          >
            {playing && <span className="absolute inset-0 animate-ping rounded-full bg-violet-500/40 [animation-duration:2s]" />}
            {playing ? <Pause className="h-6 w-6" /> : <Play className="ml-0.5 h-6 w-6" />}
          </button>

          <RoundMediaButton label="Наступний трек" onClick={() => media('next')}>
            <SkipForward className="h-4 w-4" />
          </RoundMediaButton>
        </div>

        {/* Еквалайзер-індикатор відтворення (ТЗ: краща анімація, не заважає) */}
        <div className="mt-4 flex items-center justify-center gap-[3px]" aria-hidden="true">
          {[0, 1, 2, 3, 4, 5, 6].map(i => (
            <span
              key={i}
              className={`w-[3px] rounded-full bg-gradient-to-t from-violet-600 via-indigo-400 to-indigo-200 ${playing ? 'fc-eq' : ''}`}
              style={{
                height: playing ? undefined : '3px',
                animationDelay: `${i * 0.11}s`,
                opacity: playing ? 1 : 0.3
              }}
            />
          ))}
        </div>
        <p className="mt-1.5 text-center text-[10px] font-bold uppercase tracking-wider text-zinc-500">
          {playing ? 'Відтворення' : 'Пауза'}
        </p>
      </div>
    </section>
  );
});
MediaPlayerCard.displayName = 'MediaPlayerCard';

/* ============================================================ */
/* Запуск програм (ТЗ: «показ повного списку застосунків ПК,    */
/* пошук як Windows+S, клік — програма запускається на ПК»)      */
/* ============================================================ */

interface AppEntry { name: string; path: string }

// ================= ТЗ: кеш иконок лаунчера в localStorage =================
const APP_ICON_CACHE_KEY = 'fc_app_icons_v1';
const APP_ICON_CACHE_SCHEMA = 1;
const APP_ICON_CACHE_MAX = 400;

function loadAppIconCache(): Record<string, string> {
  try {
    const raw = localStorage.getItem(APP_ICON_CACHE_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    if (parsed?.schema === APP_ICON_CACHE_SCHEMA && parsed.icons && typeof parsed.icons === 'object') {
      return parsed.icons;
    }
    localStorage.removeItem(APP_ICON_CACHE_KEY);
  } catch { /* ignore */ }
  return {};
}

function saveAppIconCache(icons: Record<string, string>) {
  try {
    const keys = Object.keys(icons);
    let trimmed = icons;
    if (keys.length > APP_ICON_CACHE_MAX) {
      trimmed = {};
      for (const k of keys.slice(keys.length - APP_ICON_CACHE_MAX)) trimmed[k] = icons[k];
    }
    localStorage.setItem(APP_ICON_CACHE_KEY, JSON.stringify({ schema: APP_ICON_CACHE_SCHEMA, icons: trimmed }));
  } catch { /* ignore */ }
}

// ================= ТЗ: Останні запущені (localStorage) =================
const RECENT_APPS_KEY = 'fc_recent_apps';
const RECENT_APPS_MAX = 8;

function loadRecentApps(): AppEntry[] {
  try {
    const raw = localStorage.getItem(RECENT_APPS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.slice(0, RECENT_APPS_MAX) : [];
  } catch { return []; }
}

function pushRecentApp(app: AppEntry) {
  try {
    const list = loadRecentApps().filter((a) => a.path.toLowerCase() !== app.path.toLowerCase());
    list.unshift({ name: app.name, path: app.path });
    localStorage.setItem(RECENT_APPS_KEY, JSON.stringify(list.slice(0, RECENT_APPS_MAX)));
  } catch { /* ignore */ }
}

// ТЗ «только программы ЗАПУСКА»: страховочный фильтр на стороне панели
// (работает и со старым агентом): деинсталляторы, сетапы, help/readme,
// crash-reporter'ы, git-утилиты, обновлятели.
const JUNK_APP_REGEX = /uninst|деінсталяц|видалити|удалить|\bsetup\b|_setup|setup_|installer\.exe|\bupdate\b|updator|updater|releasenotes|release notes|\breadme\b|\blicense\b|\beula\b|whatsnew|what.s new|crash.?report|crashhandler|maintenance.?tool|\bweb ?site\b|documentation|\bmanual\b|^help(\.|\b| )|\bhelp(\.exe)?$|git (bash|cmd|gui|k)|msiexec|bootstrapper|\.chm$|\.hlp$/i;

function isJunkApp(app: AppEntry): boolean {
  if (JUNK_APP_REGEX.test(app.name)) return true;
  const base = app.path.split(/[\\/]/).pop() || '';
  const baseName = base.replace(/\.(exe|bat|cmd|lnk|url|chm|hlp)$/i, '');
  if (baseName && JUNK_APP_REGEX.test(baseName)) return true;
  if (/^unins/i.test(base)) return true;
  return false;
}

const AppLauncherCard: React.FC = React.memo(() => {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  const [apps, setApps] = useState<AppEntry[]>([]);
  const [launchingPath, setLaunchingPath] = useState<string | null>(null);
  const [recents, setRecents] = useState<AppEntry[]>(() => loadRecentApps());
  // Іконки приходять фоном партіями — ключ: path (lowercase).
  // ТЗ: кеш іконок тепер ПЕРЕЖИВАЄ F5 (localStorage + дебаунс-збереження).
  const iconsRef = useRef<Record<string, string>>(loadAppIconCache());
  const [iconsBump, setIconsBump] = useState(0);
  const searchRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const offList = deviceClient.on('apps_list_result', (raw: any) => {
      const d = raw?.data ?? raw;
      const list: AppEntry[] = Array.isArray(d?.apps) ? d.apps : [];
      setApps(list);
      setLoading(false);
    });
    const offIcons = deviceClient.on('app_icons', (raw: any) => {
      const d = raw?.data ?? raw;
      const icons = d?.icons ?? d;
      if (icons && typeof icons === 'object' && Object.keys(icons).length) {
        Object.assign(iconsRef.current, icons);
        setIconsBump(b => b + 1);
      }
    });
    const offLaunch = deviceClient.on('app_launch_result', (raw: any) => {
      const d = raw?.data ?? raw;
      setLaunchingPath(null);
      if (d?.success) {
        toast.success(`Запущено на ПК: ${d?.name || d?.path || ''}`, { title: 'Запуск програм' });
        // ТЗ: успішний запуск → програма у ТОПІ «Останні».
        const launched = allAppsRef.current.find((a) => a.path === launchingPathRef.current);
        if (launched) {
          pushRecentApp(launched);
          setRecents(loadRecentApps());
        }
      } else {
        toast.error(d?.error || 'Не вдалося запустити програму', { title: 'Запуск програм' });
      }
    });
    return () => { offList(); offIcons(); offLaunch(); };
  }, []);

  // ТЗ: дебаунс-збереження кеша іконок у localStorage.
  useEffect(() => {
    if (!iconsBump) return;
    const t = window.setTimeout(() => saveAppIconCache(iconsRef.current), 1200);
    return () => window.clearTimeout(t);
  }, [iconsBump]);

  const allAppsRef = useRef<AppEntry[]>([]);
  const launchingPathRef = useRef<string | null>(null);
  allAppsRef.current = apps;
  launchingPathRef.current = launchingPath;

  const openModal = () => {
    setOpen(true);
    setSearch('');
    if (apps.length === 0) {
      setLoading(true);
      deviceClient.requestAppsList();
    }
    setTimeout(() => searchRef.current?.focus(), 250);
  };

  const launch = (app: AppEntry) => {
    if (launchingPath) return;
    setLaunchingPath(app.path);
    deviceClient.launchApp(app.path);
  };

  const getIcon = (app: AppEntry): string | undefined => {
    void iconsBump;
    return iconsRef.current[app.path.toLowerCase()];
  };

  // ТЗ: фільтр сміття (uninstall/git-утилити/help…) на стороні панелі.
  const cleanApps = useMemo(() => apps.filter((a) => !isJunkApp(a)), [apps]);
  const q = search.trim().toLowerCase();
  const matchQ = (a: AppEntry) => a.name.toLowerCase().includes(q);
  // Розділення (ТЗ): спочатку «Останні запущені», потім уся решта за алфавітом.
  const recentShown = useMemo(() => {
    if (q) return [];
    return recents.filter((a) => !isJunkApp(a)).slice(0, RECENT_APPS_MAX);
  }, [q, recents]);
  const recentPaths = useMemo(() => new Set(recentShown.map((a) => a.path.toLowerCase())), [recentShown]);
  const filtered = useMemo(() => {
    const list = cleanApps.filter(matchQ).filter((a) => !recentPaths.has(a.path.toLowerCase()));
    list.sort((a, b) => a.name.localeCompare(b.name, 'uk', { numeric: true }));
    return list.slice(0, 60);
  }, [cleanApps, q, recentPaths]);

  return (
    <section className="fc-card p-5">
      <div className="fc-section-head mb-4">
        <div className="fc-section-icon"><Rocket className="h-5 w-5" /></div>
        <div>
          <h3>Запуск програм</h3>
          <p>Усі встановлені програми ПК — запуск одним дотиком</p>
        </div>
      </div>

      <button onClick={openModal} className="fc-btn fc-btn-primary fc-shine w-full">
        <Search className="h-4 w-4" />
        <span>Вибрати програму для запуску</span>
      </button>

      {open && (
        <div className="fc-modal-backdrop" role="dialog" aria-modal="true" onClick={() => setOpen(false)}>
          <div className="fc-modal !w-[min(100%,46rem)]" onClick={(e) => e.stopPropagation()}>
            <div className="mb-3 flex items-center gap-3">
              <div className="fc-section-icon"><Rocket className="h-5 w-5" /></div>
              <div className="min-w-0">
                <h3>Програми на ПК</h3>
                <p className="text-[11px] text-zinc-400">
                  {loading ? 'Отримую список встановлених програм…' : `Знайдено ${cleanApps.length} — клік запускає на ПК`}
                </p>
              </div>
              <button onClick={() => setOpen(false)} className="ml-auto grid h-8 w-8 flex-none cursor-pointer place-items-center rounded-lg border border-white/10 bg-white/5 text-zinc-400 hover:bg-white/10 hover:text-white" aria-label="Закрити">
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500" />
              <input
                ref={searchRef}
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Пошук програми… (напр. chrome, word, Steam)"
                className="fc-input fc-has-icon"
              />
            </div>

            <div className="mt-3 max-h-[70dvh] overflow-y-auto pr-1">
              {loading ? (
                <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2 md:grid-cols-3">
                  {Array.from({ length: 6 }).map((_, i) => (
                    <div key={i} className="h-[72px] animate-pulse rounded-xl border border-white/5 bg-white/[.03]" />
                  ))}
                </div>
              ) : recentShown.length === 0 && filtered.length === 0 ? (
                <p className="py-10 text-center text-xs text-zinc-500">
                  {apps.length === 0 ? 'ПК не повернув список програм — оновіть агент' : `Нічого не знайдено за «${search.trim()}»`}
                </p>
              ) : (
                <>
                  {/* ТЗ: ОСТАННІ ЗАПУЩЕНІ — у самому верху, з розділенням */}
                  {recentShown.length > 0 && (
                    <>
                      <p className="mb-1.5 flex items-center gap-1.5 px-1 text-[9px] font-black uppercase tracking-wider text-indigo-300/80">
                        <History className="h-3 w-3" /> Останні запущені
                      </p>
                      <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2 md:grid-cols-3">
                        {recentShown.map((app) => {
                          const icon = getIcon(app);
                          return (
                            <button
                              key={`r|${app.path}`}
                              onClick={() => launch(app)}
                              disabled={!!launchingPath}
                              className="flex h-[72px] cursor-pointer items-center gap-3 rounded-xl border border-indigo-400/25 bg-indigo-500/[.07] px-3.5 text-left transition-all hover:border-indigo-400/50 hover:bg-indigo-500/15 disabled:opacity-50"
                              title={app.path}
                            >
                              {icon ? (
                                <img src={icon} alt="" loading="lazy" className="h-9 w-9 flex-none rounded-lg bg-black/40 object-contain p-0.5" />
                              ) : (
                                <span className="grid h-9 w-9 flex-none place-items-center rounded-lg border border-white/10 bg-black/40 text-zinc-500">
                                  <AppWindow className="h-4 w-4" />
                                </span>
                              )}
                              <span className="min-w-0">
                                <span className="block truncate text-[13px] font-bold text-white" title={app.name}>{app.name}</span>
                                {launchingPath === app.path
                                  ? <span className="block text-[10px] font-bold text-indigo-300">запуск…</span>
                                  : <span className="block truncate text-[10px] text-indigo-300/70">запущено нещодавно</span>}
                              </span>
                            </button>
                          );
                        })}
                      </div>
                      <div className="my-3 flex items-center gap-2">
                        <span className="h-px flex-1 bg-white/8" />
                        <span className="text-[9px] font-black uppercase tracking-wider text-zinc-500">Усі програми</span>
                        <span className="h-px flex-1 bg-white/8" />
                      </div>
                    </>
                  )}
                  {/* ТЗ 53: макс 3 програми в рядку + ширша модалка (46rem) */}
                  <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2 md:grid-cols-3">
                    {filtered.map((app) => {
                      const icon = getIcon(app);
                      return (
                        <button
                          key={app.path}
                          onClick={() => launch(app)}
                          disabled={!!launchingPath}
                          className="flex h-[72px] cursor-pointer items-center gap-3 rounded-xl border border-white/8 bg-white/[.03] px-3.5 text-left transition-all hover:border-indigo-400/40 hover:bg-indigo-500/10 disabled:opacity-50"
                          title={app.path}
                        >
                          {icon ? (
                            <img src={icon} alt="" loading="lazy" className="h-9 w-9 flex-none rounded-lg bg-black/40 object-contain p-0.5" />
                          ) : (
                            <span className="grid h-9 w-9 flex-none place-items-center rounded-lg border border-white/10 bg-black/40 text-zinc-500">
                              <AppWindow className="h-4 w-4" />
                            </span>
                          )}
                          <span className="min-w-0">
                            <span className="block truncate text-[13px] font-bold text-white" title={app.name}>{app.name}</span>
                            {launchingPath === app.path
                              ? <span className="block text-[10px] font-bold text-indigo-300">запуск…</span>
                              : <span className="block truncate text-[10px] text-zinc-600">запустити на ПК</span>}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </>
              )}
            </div>

            <button
              onClick={() => { setLoading(true); setApps([]); deviceClient.requestAppsList(); }}
              className="fc-btn fc-btn-ghost fc-btn-sm mt-3 w-full"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
              <span>Оновити список</span>
            </button>
          </div>
        </div>
      )}
    </section>
  );
});
AppLauncherCard.displayName = 'AppLauncherCard';

/* ============================================================ */
/* Перегляд вікон ПК (ТЗ: «хтось працює за ПК, а я дивлюсь у     */
/* потрібне вікно (гру) через сайт — воно НЕ виходить на перед») */
/* ============================================================ */

interface WindowEntry { hwnd: number; title: string; process: string; minimized?: boolean }

const WindowViewerCard: React.FC<{ deviceName: string }> = React.memo(({ deviceName }) => {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [windows, setWindows] = useState<WindowEntry[]>([]);
  const [selected, setSelected] = useState<WindowEntry | null>(null);
  const [imgSrc, setImgSrc] = useState<string | null>(null);
  const [capturing, setCapturing] = useState(false);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const selectedRef = useRef<WindowEntry | null>(null);
  selectedRef.current = selected;

  useEffect(() => {
    const offList = deviceClient.on('windows_list_result', (raw: any) => {
      const d = raw?.data ?? raw;
      const list: WindowEntry[] = Array.isArray(d?.windows) ? d.windows : [];
      setWindows(list);
      setLoading(false);
      // Автовибір ПЕРШОГО РОЗГОРНУТОГО вікна (згорнуті — у кінці списку),
      // якщо нічого не вибрано або зникло зі списку.
      setSelected(prev => {
        if (prev && list.some(w => w.hwnd === prev.hwnd)) return prev;
        return list.find(w => !w.minimized) ?? list[0] ?? null;
      });
    });
    const offCapture = deviceClient.on('window_capture_result', (raw: any) => {
      const d = raw?.data ?? raw;
      const sel = selectedRef.current;
      if (!sel || (typeof d?.hwnd === 'number' && d.hwnd !== sel.hwnd)) return;
      setCapturing(false);
      if (d?.error) { setImgSrc(null); return; }
      if (d?.imageBase64) setImgSrc(`data:image/jpeg;base64,${d.imageBase64}`);
    });
    return () => { offList(); offCapture(); };
  }, []);

  const refreshWindows = useCallback(() => {
    setLoading(true);
    deviceClient.requestWindowsList();
  }, []);

  const capture = useCallback((w: WindowEntry | null) => {
    if (!w) return;
    setCapturing(true);
    deviceClient.captureWindow(w.hwnd, 70);
  }, []);

  // Зміна вибору → миттєвий знімок.
  useEffect(() => {
    if (open && selected) capture(selected);
  }, [selected, open, capture]);

  // Автооновлення: «міністрім» потрібного вікна без виведення його на перед.
  useEffect(() => {
    if (!open || !autoRefresh) return;
    const t = setInterval(() => {
      if (selectedRef.current && !capturing) capture(selectedRef.current);
    }, 2500);
    return () => clearInterval(t);
  }, [open, autoRefresh, capturing, capture]);

  const openModal = () => {
    setOpen(true);
    setImgSrc(null);
    refreshWindows();
  };

  return (
    <section className="fc-card p-5">
      <div className="fc-section-head mb-4">
        <div className="fc-section-icon"><AppWindow className="h-5 w-5" /></div>
        <div>
          <h3>Перегляд вікон</h3>
          <p>Скріншот потрібного вікна, не виходячи з нього на передній план</p>
        </div>
      </div>

      <button onClick={openModal} className="fc-btn fc-btn-primary fc-shine w-full">
        <AppWindow className="h-4 w-4" />
        <span>Вибрати вікно для перегляду</span>
      </button>

      {open && (
        <div className="fc-modal-backdrop" role="dialog" aria-modal="true" onClick={() => setOpen(false)}>
          <div className="fc-modal !w-[min(100%,44rem)]" onClick={(e) => e.stopPropagation()}>
            <div className="mb-3 flex items-center gap-3">
              <div className="fc-section-icon"><AppWindow className="h-5 w-5" /></div>
              <div className="min-w-0">
                <h3>Вікна ПК — {deviceName}</h3>
                <p className="text-[11px] text-zinc-400">Вікно залишається на місці — знімок робиться «непомітно»</p>
              </div>
              <button onClick={() => setOpen(false)} className="ml-auto grid h-8 w-8 flex-none cursor-pointer place-items-center rounded-lg border border-white/10 bg-white/5 text-zinc-400 hover:bg-white/10 hover:text-white" aria-label="Закрити">
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="grid gap-3 md:grid-cols-[13rem,1fr]">
              {/* Список вікон */}
              <div className="max-h-[24rem] overflow-y-auto rounded-xl border border-white/8 bg-black/30 p-1.5">
                {loading && windows.length === 0 ? (
                  <p className="p-3 text-[11px] text-zinc-500">Отримую список вікон…</p>
                ) : windows.length === 0 ? (
                  <p className="p-3 text-[11px] text-zinc-500">Вікон не знайдено</p>
                ) : (
                  windows.map(w => (
                    <button
                      key={w.hwnd}
                      onClick={() => setSelected(w)}
                      className={`mb-1 flex w-full cursor-pointer flex-col rounded-lg px-2.5 py-2 text-left transition-colors ${
                        selected?.hwnd === w.hwnd ? 'bg-indigo-600/25 text-white' : 'text-zinc-300 hover:bg-white/5'
                      }`}
                    >
                      <span className="truncate text-[11px] font-bold">{w.title || '(без назви)'}{w.minimized ? ' · згорнуте' : ''}</span>
                      <span className="truncate font-mono text-[9px] text-zinc-500">{w.process}</span>
                    </button>
                  ))
                )}
              </div>

              {/* Знімок вікна */}
              <div className="flex flex-col">
                <div className="relative grid min-h-[15rem] flex-1 place-items-center overflow-hidden rounded-xl border border-white/10 bg-black/60">
                  {imgSrc ? (
                    <img src={imgSrc} alt={selected?.title || 'Вікно'} className="max-h-[24rem] w-auto max-w-full object-contain" />
                  ) : (
                    <div className="flex flex-col items-center gap-2 p-6 text-center text-zinc-500">
                      <AppWindow className="h-8 w-8" />
                      <p className="text-[11px] font-semibold">
                        {capturing ? 'Роблю знімок вікна…' : selected ? 'Знімок недоступний для цього вікна' : 'Виберіть вікно зі списку'}
                      </p>
                    </div>
                  )}
                  {capturing && imgSrc && (
                    <div className="absolute right-2 top-2 flex items-center gap-1.5 rounded-lg border border-white/10 bg-black/80 px-2 py-1 text-[10px] font-bold text-indigo-200">
                      <RefreshCw className="h-3 w-3 animate-spin" /> оновлення…
                    </div>
                  )}
                </div>

                <div className="mt-3 flex items-center gap-2">
                  <button onClick={() => selected && capture(selected)} disabled={!selected || capturing} className="fc-btn fc-btn-primary flex-1">
                    <RefreshCw className={`h-3.5 w-3.5 ${capturing ? 'animate-spin' : ''}`} />
                    <span>Оновити зараз</span>
                  </button>
                  <button
                    onClick={() => setAutoRefresh(v => !v)}
                    aria-pressed={autoRefresh}
                    className={`fc-btn flex-1 ${autoRefresh ? 'fc-btn-success' : 'fc-btn-ghost'}`}
                    title="Автооновлення знімка кожні 2.5 с"
                  >
                    <span className={`h-2 w-2 rounded-full ${autoRefresh ? 'bg-white' : 'bg-zinc-500'}`} />
                    <span>Авто {autoRefresh ? 'увімк' : 'вимк'}</span>
                  </button>
                  <button onClick={refreshWindows} className="fc-btn fc-btn-ghost" title="Оновити список вікон">
                    <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
});
WindowViewerCard.displayName = 'WindowViewerCard';

/* ============================================================ */
/* Power actions + shutdown/restart timer                        */
/* ============================================================ */

type DangerAction = 'shutdown' | 'restart' | 'sleep' | 'hibernate';

const POWER_META: Record<DangerAction, { title: string; toast: string; icon: typeof Power; iconCls: string }> = {
  shutdown: { title: 'Вимкнути комп\'ютер?', toast: 'Вимкнення ПК запущено', icon: Power, iconCls: 'border-rose-400/40 bg-rose-500/15 text-rose-300 shadow-[0_0_44px_-8px_rgba(225,29,72,.75)]' },
  restart: { title: 'Перезавантажити комп\'ютер?', toast: 'Перезавантаження ПК запущено', icon: RotateCcw, iconCls: 'border-amber-400/40 bg-amber-500/15 text-amber-300 shadow-[0_0_44px_-8px_rgba(245,158,11,.65)]' },
  sleep: { title: 'Перевести комп\'ютер у режим сну?', toast: 'ПК перейде в режим сну', icon: Moon, iconCls: 'border-indigo-400/40 bg-indigo-500/15 text-indigo-300 shadow-[0_0_44px_-8px_rgba(99,102,241,.65)]' },
  hibernate: { title: 'Перевести комп\'ютер у гібернацію?', toast: 'Гібернацію запущено', icon: CloudMoon, iconCls: 'border-violet-400/40 bg-violet-500/15 text-violet-300 shadow-[0_0_44px_-8px_rgba(124,58,237,.65)]' }
};

type TimerAction = 'shutdown' | 'restart' | 'sleep' | 'hibernate' | 'lock';

const TIMER_ACTION_META: Record<TimerAction, { label: string; icon: typeof Power }> = {
  shutdown: { label: 'Вимкнення', icon: Power },
  restart: { label: 'Перезавантаження', icon: RotateCcw },
  sleep: { label: 'Сон', icon: Moon },
  hibernate: { label: 'Гібернація', icon: CloudMoon },
  lock: { label: 'Блокування', icon: Lock }
};

const TIMER_MINUTE_CHIPS = [5, 10, 15, 30, 60];

type ActiveTimer = { action: TimerAction; endsAt: number; totalSeconds: number };

const PowerCard: React.FC<{ deviceName: string }> = React.memo(({ deviceName }) => {
  const [pending, setPending] = useState<DangerAction | null>(null);
  // Authoritative timer state comes from the AGENT (timer_state, unix-ms endsAt),
  // so a page refresh or a reconnect restores the real countdown instantly.
  const [timer, setTimer] = useState<ActiveTimer | null>(null);
  const [nowTick, setNowTick] = useState(Date.now());
  // Timer creation modal
  const [timerOpen, setTimerOpen] = useState(false);
  const [timerAction, setTimerAction] = useState<TimerAction>('shutdown');
  const [timerMinutes, setTimerMinutes] = useState<number | null>(10);
  const [customMinutes, setCustomMinutes] = useState('');

  // Ask the agent for the current pending timer on mount (it also pushes
  // timer_state right after every relay reconnect).
  useEffect(() => {
    deviceClient.send('timer_get', {});
  }, []);

  // Live countdown: 1 tick per second and ONLY while a timer is shown.
  useEffect(() => {
    if (!timer) return;
    const t = window.setInterval(() => setNowTick(Date.now()), 1000);
    return () => window.clearInterval(t);
  }, [timer]);

  // Agent-side timer state is the single source of truth.
  useEffect(() => {
    const off = deviceClient.on('timer_state', (raw: any) => {
      const s = pick<any>(raw);
      if (!s || typeof s !== 'object') return;
      if (s.active === true && s.endsAt) {
        setTimer({
          action: (s.action as TimerAction) || 'shutdown',
          endsAt: Number(s.endsAt),
          totalSeconds: Number(s.totalSeconds) || Math.max(1, Math.round((Number(s.endsAt) - Date.now()) / 1000))
        });
        setNowTick(Date.now());
      } else {
        setTimer(null);
      }
    });
    const offAck = deviceClient.on('timer_ack', (raw: any) => {
      const s = pick<any>(raw);
      if (s && s.ok === false) {
        setTimer(null);
        toast.error(s.error || 'Не вдалося запустити таймер');
      }
    });
    return () => {
      off();
      offAck();
    };
  }, []);

  const runPower = (action: DangerAction) => {
    deviceClient.sendPowerAction(action);
    toast.info(POWER_META[action].toast);
    setPending(null);
  };

  const lockScreen = () => {
    deviceClient.sendPowerAction('lock');
    toast.info('Команду блокування екрана надіслано');
  };

  const secondsLeft = timer ? Math.max(0, Math.ceil((timer.endsAt - nowTick) / 1000)) : 0;
  const scheduledAt = timer ? new Date(timer.endsAt).toLocaleTimeString('uk-UA', { hour: '2-digit', minute: '2-digit' }) : '';
  const timerMeta = timer ? TIMER_ACTION_META[timer.action] ?? TIMER_ACTION_META.shutdown : null;

  const confirmStartTimer = () => {
    const minutes = customMinutes.trim() !== '' ? Number(customMinutes.replace(',', '.')) : timerMinutes;
    if (!minutes || !Number.isFinite(minutes) || minutes <= 0 || minutes > 1440) {
      toast.warn('Вкажіть кількість хвилин від 1 до 1440');
      return;
    }
    const seconds = Math.max(5, Math.round(minutes * 60));
    // Optimistic start — the agent's timer_state immediately confirms/corrects.
    setTimer({ action: timerAction, endsAt: Date.now() + seconds * 1000, totalSeconds: seconds });
    setNowTick(Date.now());
    deviceClient.startPowerTimer(timerAction, seconds);
    toast.info(`${TIMER_ACTION_META[timerAction].label} заплановано через ${minutes} хв`);
    setTimerOpen(false);
    setCustomMinutes('');
  };

  const cancelTimer = () => {
    deviceClient.cancelPowerTimer();
    setTimer(null);
    toast.info('Таймер скасовано');
  };

  return (
    <section className="fc-card p-5">
      <div className="fc-section-head mb-4">
        <div className="fc-section-icon fc-icon-rose"><Power className="h-5 w-5" /></div>
        <div>
          <h3>Живлення</h3>
          <p>Вимкнення, перезавантаження, сон і блокування</p>
        </div>
      </div>

      {/* ВЕЛИКІ градієнтні кнопки живлення — найважливіша дія першою. Усі дії
          з підтвердженням, щоб не вимкнути ПК випадковим дотиком. */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <button
          onClick={() => setPending('shutdown')}
          className="pwr-tile pwr-shutdown fc-shine"
        >
          <span className="pwr-ico"><Power /></span>
          <span className="min-w-0">
            <b>Вимкнути ПК</b>
            <small>Повне вимкнення комп&apos;ютера</small>
          </span>
        </button>

        <button
          onClick={() => setPending('restart')}
          className="pwr-tile pwr-restart fc-shine"
        >
          <span className="pwr-ico"><RotateCcw /></span>
          <span className="min-w-0">
            <b>Перезавантажити</b>
            <small>Restart із повним циклом</small>
          </span>
        </button>
      </div>

      <div className="mt-3 grid grid-cols-1 gap-2.5 sm:grid-cols-3">
        <button onClick={() => setPending('sleep')} className="pwr-mini pwr-sleep">
          <Moon className="h-4 w-4" />
          <span>Режим сну</span>
        </button>
        <button onClick={() => setPending('hibernate')} className="pwr-mini pwr-hiber">
          <CloudMoon className="h-4 w-4" />
          <span>Гібернація</span>
        </button>
        <button onClick={lockScreen} className="pwr-mini pwr-lock">
          <Lock className="h-4 w-4" />
          <span>Заблокувати екран</span>
        </button>
      </div>

      {/* Unified power timer: one entry point, the agent executes the action */}
      <div className="mt-4 border-t border-white/10 pt-4">
        {timer === null ? (
          <button onClick={() => setTimerOpen(true)} className="pwr-timer-btn">
            <span className="grid h-10 w-10 flex-none place-items-center rounded-xl border border-amber-400/40 bg-gradient-to-br from-amber-500/35 to-amber-900/50 text-amber-300 shadow-[inset_0_1px_rgba(255,255,255,.2),0_8px_20px_-8px_rgba(245,158,11,.6)]">
              <Timer className="h-[18px] w-[18px]" />
            </span>
            <span className="min-w-0">
              <b className="block text-xs font-extrabold text-white">Таймер живлення</b>
              <small className="block text-[10px] font-semibold text-amber-200/70">вимкнення · перезавантаження · сон · блокування</small>
            </span>
            <span className="pwr-timer-chev"><ChevronRight className="h-4 w-4" /></span>
          </button>
        ) : (
          <div className="pwr-timer-active">
            <div className="flex items-center justify-between gap-3">
              <div className="min-w-0">
                <b className="flex items-center gap-1.5 text-[11px] font-extrabold uppercase tracking-wide text-amber-200/90">
                  {timerMeta && <timerMeta.icon className="h-3.5 w-3.5 flex-none" />}
                  {timerMeta?.label ?? 'Дія'} — ПК «{deviceName}»
                </b>
                <span className="pwr-countdown mt-1 block">{formatSeconds(secondsLeft)}</span>
                <span className="mt-0.5 block text-[10px] text-amber-300/80">Заплановано на {scheduledAt}</span>
              </div>
              <button onClick={cancelTimer} className="fc-btn fc-btn-warn fc-btn-sm flex-none">
                <Ban className="h-3 w-3" />
                <span>Скасувати</span>
              </button>
            </div>
            {timer.totalSeconds > 0 && (
              <div className="fc-progress mt-3">
                <i
                  className="block h-full rounded-[inherit]"
                  style={{
                    width: `${clampPercent((secondsLeft / timer.totalSeconds) * 100)}%`,
                    background: 'linear-gradient(90deg,#f59e0b,#fbbf24)',
                    boxShadow: '0 0 12px rgba(245,158,11,.6)'
                  }}
                />
              </div>
            )}
          </div>
        )}
      </div>

      {/* Unified timer modal */}
      {timerOpen && (
        <div className="fc-modal-backdrop" role="dialog" aria-modal="true" onClick={() => setTimerOpen(false)}>
          <div className="fc-modal" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center gap-3">
              <div className="fc-section-icon fc-icon-amber"><Timer className="h-5 w-5" /></div>
              <div>
                <h3>Таймер дії</h3>
                <p className="text-[11px] text-zinc-400">Дію виконає ПК, навіть якщо сайт закрити</p>
              </div>
            </div>

            <p className="mb-2 mt-4 text-[10px] font-extrabold uppercase tracking-wide text-zinc-500">Тип дії</p>
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
              {(Object.keys(TIMER_ACTION_META) as TimerAction[]).map(action => {
                const meta = TIMER_ACTION_META[action];
                const active = timerAction === action;
                return (
                  <button
                    key={action}
                    onClick={() => setTimerAction(action)}
                    aria-pressed={active}
                    className={`fc-radio-card ${active ? 'active' : ''}`}
                  >
                    <span className="flex items-center gap-2.5">
                      <meta.icon className={`h-4 w-4 flex-none ${active ? 'text-indigo-300' : 'text-zinc-500'}`} />
                      <span className="flex-1 truncate text-xs font-extrabold text-white">{meta.label}</span>
                      <span className={`fc-radio-dot ${active ? 'on' : ''}`} />
                    </span>
                  </button>
                );
              })}
            </div>

            <p className="mb-2 mt-4 text-[10px] font-extrabold uppercase tracking-wide text-zinc-500">Через скільки хвилин</p>
            <div className="flex flex-wrap gap-1.5">
              {TIMER_MINUTE_CHIPS.map(m => (
                <button
                  key={m}
                  onClick={() => { setTimerMinutes(m); setCustomMinutes(''); }}
                  aria-pressed={timerMinutes === m && customMinutes.trim() === ''}
                  className={`fc-btn fc-btn-sm flex-1 ${
                    timerMinutes === m && customMinutes.trim() === '' ? 'fc-btn-primary' : 'fc-btn-ghost'
                  }`}
                >
                  {m < 60 ? `${m} хв` : '1 год'}
                </button>
              ))}
            </div>
            <div className="mt-2 flex items-center gap-2">
              <input
                type="number"
                min={1}
                max={1440}
                inputMode="decimal"
                value={customMinutes}
                onChange={(e) => setCustomMinutes(e.target.value)}
                placeholder="Свій час, хв (напр. 45)"
                className="fc-input flex-1"
                aria-label="Свій час у хвилинах"
              />
              <span className="text-[10px] text-zinc-500">хв</span>
            </div>

            <div className="mt-5 flex items-center gap-3">
              <button onClick={() => setTimerOpen(false)} className="fc-btn fc-btn-ghost flex-1">Скасувати</button>
              <button onClick={confirmStartTimer} className="fc-btn fc-btn-primary fc-shine flex-1">
                <Clock className="h-3.5 w-3.5" />
                <span>Запустити</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Confirmation modal for dangerous actions */}
      {pending && (() => {
        const meta = POWER_META[pending];
        const PendingIcon = meta.icon;
        return (
          <div className="fc-modal-backdrop" role="dialog" aria-modal="true" onClick={() => setPending(null)}>
            <div className="fc-modal text-center" onClick={(e) => e.stopPropagation()}>
              <div className={`mx-auto grid h-16 w-16 place-items-center rounded-[1.25rem] border ${meta.iconCls}`}>
                <PendingIcon className="h-7 w-7" />
              </div>
              <h3 className="mt-3.5 text-base">{meta.title}</h3>
              <p className="mt-1.5 text-xs leading-relaxed text-zinc-400">
                Дію буде виконано негайно на віддаленому комп&apos;ютері{' '}
                <span className="inline-flex items-center gap-1 rounded-lg border border-indigo-400/30 bg-indigo-500/15 px-2 py-0.5 font-bold text-indigo-300">
                  <Monitor className="h-3 w-3" />
                  {deviceName}
                </span>
              </p>
              <div className="mt-5 flex items-center gap-2.5">
                <button onClick={() => setPending(null)} className="fc-btn fc-btn-ghost flex-1">Скасувати</button>
                <button onClick={() => runPower(pending)} className="fc-btn fc-btn-danger fc-shine flex-1">
                  <PendingIcon className="h-3.5 w-3.5" />
                  <span>Так, виконати</span>
                </button>
              </div>
            </div>
          </div>
        );
      })()}
    </section>
  );
});
PowerCard.displayName = 'PowerCard';

/* ============================================================ */
/* Control tab root: screen stream + layout                      */
/* ============================================================ */

// ТЗ 49 (економія трафіку): профілі стриму. Колишній фіксований запит
// 30 FPS / q72 / 1280w через релей — це ~10-20 ГБ/год (ліміт Render 5 ГБ
// згорав за 15-20 хвилин). «Звичайний» — у ~6 разів менше байт.
// ТЗ 53: «макс» — 30 FPS / q80 / 1600w (верхні межі агента) — автоматично
// вмикається, коли панель підключена через ПРЯМИЙ тунель (потужний канал).
const STREAM_PRESETS = {
  eco: { fps: 8, q: 40, w: 854, label: 'Економний' },
  std: { fps: 12, q: 60, w: 1100, label: 'Звичайний' },
  hi: { fps: 20, q: 72, w: 1440, label: 'Якість' },
  max: { fps: 30, q: 80, w: 1600, label: 'Максимум' },
} as const;
type StreamPresetKey = keyof typeof STREAM_PRESETS;

export const ControlTab: React.FC<ControlTabProps> = React.memo(({ device }) => {
  const [screenOpen, setScreenOpen] = useState(false);
  const [streamFps, setStreamFps] = useState(0);
  const [streamStatus, setStreamStatus] = useState<'idle' | 'starting' | 'live' | 'error'>('idle');
  // ТЗ 49: профіль якості/трафіку стриму (persist у localStorage).
  const [preset, setPreset] = useState<StreamPresetKey>(() => {
    try {
      const saved = localStorage.getItem('fc_stream_preset');
      return saved === 'eco' || saved === 'std' || saved === 'hi' || saved === 'max' ? saved : 'std';
    } catch { return 'std'; }
  });
  // ТЗ 53: «пресет вибраний вручну» — якщо користувач сам не тикав профіль,
  // при прямому тунелі якість автоматично піднімається до «Максимум».
  const manualPresetRef = useRef(false);
  const [streamMb, setStreamMb] = useState(0);
  const [hiddenPaused, setHiddenPaused] = useState(false);
  // ТЗ 46: трансляція ЕКРАНА З ЗВУКОМ ПК (WASAPI loopback з агента).
  const [audioOn, setAudioOn] = useState(false);
  const [audioVolume, setAudioVolume] = useState(100);

  const streamImageRef = useRef<HTMLImageElement>(null);
  const frameStatsRef = useRef({ count: 0, since: performance.now() });
  const startTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const audioGainRef = useRef<GainNode | null>(null);
  const audioNextRef = useRef(0);
  const audioOnRef = useRef(false);
  // ТЗ 49: blob-URL кадру, статус для авто-паузи, стан до приховання вкладки.
  const frameUrlRef = useRef<string | null>(null);
  const streamStatusRef = useRef(streamStatus);
  const wasStreamingRef = useRef(false);
  const audioWasOnRef = useRef(false);
  const startScreenStreamRef = useRef<(presetOverride?: StreamPresetKey) => void>(() => {});
  useEffect(() => { streamStatusRef.current = streamStatus; }, [streamStatus]);

  useEffect(() => { audioOnRef.current = audioOn; }, [audioOn]);

  // ТЗ 53: пряме з'єднання (тунель) → автоматично максимальна якість стриму,
  // якщо користувач не обрав профіль вручну. Релей → звичайний/збережений.
  useEffect(() => {
    const off = deviceClient.on('connected', (info: any) => {
      if (info?.direct && !manualPresetRef.current) {
        setPreset(prev => {
          if (prev !== 'max') toast.info('Пряме з\'єднання — максимальна якість трансляції', { title: 'Трансляція' });
          return 'max';
        });
      }
    });
    // якщо сокет уже підключений на момент монтування вкладки
    if (deviceClient.isDirectActive && !manualPresetRef.current) setPreset('max');
    return off;
  }, []);
  useEffect(() => {
    if (audioGainRef.current) audioGainRef.current.gain.value = audioVolume / 100;
  }, [audioVolume]);

  /** Черга відтворення: int16 mono 24кГц chunk → AudioBuffer → планування по часу.
   * ТЗ 49: приймає СИРІ байти (Int16Array з бінарного кадру релея) або base64
   * (старий агент) — мінус 25% трафіку на звук без втрати якості. */
  const feedAudioChunk = useCallback((chunk: Int16Array | string) => {
    try {
      let ctx = audioCtxRef.current;
      if (!ctx) {
        const Ctx = window.AudioContext || (window as any).webkitAudioContext;
        if (!Ctx) return;
        ctx = new Ctx();
        const gain = ctx.createGain();
        gain.gain.value = audioVolume / 100;
        gain.connect(ctx.destination);
        audioCtxRef.current = ctx;
        audioGainRef.current = gain;
        audioNextRef.current = 0;
      }
      if (ctx.state === 'suspended') void ctx.resume();
      let len: number;
      let samples: Float32Array<ArrayBuffer>;
      if (typeof chunk === 'string') {
        const bin = atob(chunk);
        len = bin.length >> 1;
        if (!len) return;
        samples = new Float32Array(len);
        for (let i = 0; i < len; i++) {
          const v = ((bin.charCodeAt(2 * i) | (bin.charCodeAt(2 * i + 1) << 8)) << 16) >> 16;
          samples[i] = v / 32768;
        }
      } else {
        len = chunk.length;
        if (!len) return;
        samples = new Float32Array(len);
        for (let i = 0; i < len; i++) samples[i] = chunk[i] / 32768;
      }
      const buffer = ctx.createBuffer(1, len, 24000);
      buffer.copyToChannel(samples, 0);
      const src = ctx.createBufferSource();
      src.buffer = buffer;
      src.connect(audioGainRef.current!);
      const now = ctx.currentTime;
      if (audioNextRef.current < now + 0.05) audioNextRef.current = now + 0.05;
      src.start(audioNextRef.current);
      audioNextRef.current += buffer.duration;
      // Запас > 0.6с (підлагували чанки) — підстрибуємо вперед, щоб не відставати.
      if (audioNextRef.current > now + 0.6) audioNextRef.current = now + 0.1;
    } catch { }
  }, [audioVolume]);

  const toggleAudio = useCallback(() => {
    if (audioOnRef.current) {
      deviceClient.stopAudioStream();
      setAudioOn(false);
    } else {
      try { audioCtxRef.current?.resume(); } catch { }
      deviceClient.startAudioStream();
    }
  }, [feedAudioChunk]);

  /** Спільний хвіст обробки кадру (JSON і бінарного): статус + FPS-статистика. */
  const onFrameRendered = useCallback(() => {
    if (startTimeoutRef.current) clearTimeout(startTimeoutRef.current);
    setStreamStatus('live');
    const stats = frameStatsRef.current;
    stats.count += 1;
    const elapsed = performance.now() - stats.since;
    if (elapsed >= 500) {
      const fps = Math.round((stats.count * 1000) / elapsed);
      setStreamFps(fps);
      deviceClient.sendScreenStreamFeedback(fps);
      stats.count = 0;
      stats.since = performance.now();
    }
  }, []);

  useEffect(() => {
    const unFrame = deviceClient.on('screen_frame', (frame: any) => {
      const data = frame?.data ?? frame;
      if (!data?.imageBase64 || !streamImageRef.current) return;
      streamImageRef.current.src = `data:image/jpeg;base64,${data.imageBase64}`;
      onFrameRendered();
    });
    // ТЗ 49: бінарний кадр (новий агент) — без base64, рендер через blob-URL.
    const unFrameBin = deviceClient.on('screen_frame_bin', (frame: any) => {
      const bytes: Uint8Array | undefined = frame?.bytes;
      if (!bytes || !streamImageRef.current) return;
      try {
        const url = URL.createObjectURL(new Blob([bytes as BlobPart], { type: 'image/jpeg' }));
        if (frameUrlRef.current) URL.revokeObjectURL(frameUrlRef.current);
        frameUrlRef.current = url;
        streamImageRef.current.src = url;
      } catch { return; }
      onFrameRendered();
    });
    const unError = deviceClient.on('screen_stream_error', (error: any) => {
      toast.error(error?.message || 'Трансляцію екрана перервано');
      setScreenOpen(false);
      setStreamStatus('idle');
    });
    const unStarted = deviceClient.on('screen_stream_started', () => {
      setStreamStatus('live');
      if (startTimeoutRef.current) clearTimeout(startTimeoutRef.current);
    });
    // ТЗ 46: чанки звука ПК + підтвердження запуску аудіо-стриму.
    const unAudioChunk = deviceClient.on('audio_chunk', (p: any) => {
      const b64 = typeof p === 'string' ? p : p?.base64;
      if (b64 && audioOnRef.current) feedAudioChunk(b64);
    });
    // ТЗ 49: бінарні чанки звука — сирі s16le семпли без base64.
    const unAudioBin = deviceClient.on('audio_chunk_bin', (p: any) => {
      const bytes: Uint8Array | undefined = p?.bytes;
      if (bytes && audioOnRef.current) {
        feedAudioChunk(new Int16Array(bytes.buffer, bytes.byteOffset, bytes.byteLength >> 1));
      }
    });
    // ТЗ 49: лічильник медіа-байт для показу в оверлеї.
    const unBytes = deviceClient.on('stream_bytes', (total: any) => {
      setStreamMb((Number(total) || 0) / 1048576);
    });
    const unAudioStarted = deviceClient.on('stream_audio_started', (p: any) => {
      if (p?.success) {
        setAudioOn(true);
        toast.success('Звук ПК у стримі увімкнено', { title: 'Аудіо' });
      } else {
        setAudioOn(false);
        toast.warn(p?.error || 'ПК не зміг почати стрим звука — оновіть агент', { title: 'Аудіо' });
      }
    });
    return () => {
      if (startTimeoutRef.current) clearTimeout(startTimeoutRef.current);
      unFrame();
      unFrameBin();
      unError();
      unStarted();
      unAudioChunk();
      unAudioBin();
      unBytes();
      unAudioStarted();
      deviceClient.stopScreenStream();
      deviceClient.stopAudioStream();
      if (frameUrlRef.current) { URL.revokeObjectURL(frameUrlRef.current); frameUrlRef.current = null; }
    };
  }, [feedAudioChunk, onFrameRendered]);

  const startScreenStream = (presetOverride?: StreamPresetKey) => {
    frameStatsRef.current = { count: 0, since: performance.now() };
    setStreamFps(0);
    setStreamStatus('starting');
    setScreenOpen(true);
    setHiddenPaused(false);
    deviceClient.resetMediaBytes();
    setStreamMb(0);
    // ТЗ 49: профіль якості замість фіксованих 30 FPS q72 1280w.
    const p = STREAM_PRESETS[presetOverride ?? preset];
    deviceClient.startScreenStream(p.fps, p.q, p.w);
    startTimeoutRef.current = setTimeout(() => {
      setStreamStatus(current => {
        if (current === 'starting') {
          toast.warn('Агент не підтвердив запуск трансляції. Оновіть і перезапустіть FluxControl на віддаленому ПК.');
          return 'error';
        }
        return current;
      });
    }, 8000);
  };
  startScreenStreamRef.current = startScreenStream;

  const stopScreenStream = () => {
    deviceClient.stopScreenStream();
    deviceClient.stopAudioStream();
    setAudioOn(false);
    setScreenOpen(false);
    setStreamFps(0);
    setStreamStatus('idle');
    setHiddenPaused(false);
    if (startTimeoutRef.current) clearTimeout(startTimeoutRef.current);
    if (frameUrlRef.current) { URL.revokeObjectURL(frameUrlRef.current); frameUrlRef.current = null; }
  };

  // ТЗ 49: авто-пауза стриму, коли вкладка прихована (телефон згасив екран,
  // користувач згорнув браузер) — релей не перекачує кадри в нікуди.
  // Повернення до вкладки — автоматичне відновлення трансляції й звука.
  useEffect(() => {
    const onVis = () => {
      if (document.hidden) {
        const st = streamStatusRef.current;
        if (st === 'live' || st === 'starting') {
          wasStreamingRef.current = true;
          audioWasOnRef.current = audioOnRef.current;
          deviceClient.stopScreenStream();
          deviceClient.stopAudioStream();
          setHiddenPaused(true);
        }
      } else if (wasStreamingRef.current) {
        wasStreamingRef.current = false;
        startScreenStreamRef.current();
        if (audioWasOnRef.current) {
          audioWasOnRef.current = false;
          deviceClient.startAudioStream();
        }
      }
    };
    document.addEventListener('visibilitychange', onVis);
    return () => document.removeEventListener('visibilitychange', onVis);
  }, []);

  return (
    <div className="space-y-6">

      {/* 1. ЖИВЛЕННЯ — найперша секція: великі кнопки з підтвердженням */}
      <PowerCard deviceName={device.name} />

      {/* 2. ЗАХОПЛЕННЯ ЕКРАНА ТА ВІДЕО — одна рамка з 4 плитками */}
      <RemoteCaptureTools deviceName={device.name} />

      {/* 3. Трансляція екрана */}
      <section className="fc-card flex flex-col items-start justify-between gap-4 p-5 sm:flex-row sm:items-center">
        <div className="fc-section-head">
          <div className="fc-section-icon"><ScreenShare className="h-5 w-5" /></div>
          <div>
            <h3>Трансляція екрана</h3>
            <p>Профілі трафіку, бінарні кадри, пауза у фоні: статичний екран майже не витрачає байти.</p>
          </div>
        </div>
        <button onClick={() => startScreenStream()} className="fc-btn fc-btn-primary fc-shine w-full flex-none sm:w-auto">
          <ScreenShare className="h-4 w-4" />
          <span>Відкрити трансляцію</span>
        </button>
      </section>

      {/* 4. Медіа, мишка, друк, WinLock + програми/вікна (ТЗ) */}
      <div className="grid grid-cols-1 items-start gap-6 lg:grid-cols-2">
        <div className="space-y-6">
          <MediaPlayerCard />
          <MouseCard deviceName={device.name} />
        </div>
        <div className="space-y-6">
          <TextLinkCard />
          <WinLockCard />
          <AppLauncherCard />
          <WindowViewerCard deviceName={device.name} />
        </div>
      </div>

      {/* Fullscreen screen-stream overlay */}
      {screenOpen && (
        <div className="fixed inset-0 z-[70] flex flex-col bg-[#050508] animate-in fade-in duration-200">
          <div className="flex h-16 shrink-0 items-center justify-between border-b border-white/10 bg-black/70 px-4 backdrop-blur-xl sm:px-6">
            <div className="flex min-w-0 items-center gap-3">
              <div className="grid place-items-center rounded-xl border border-indigo-400/25 bg-indigo-500/15 p-2 text-indigo-300"><ScreenShare className="h-5 w-5" /></div>
              <div className="min-w-0">
                <h3 className="truncate text-sm font-bold text-white">Екран: {device.name}</h3>
                <p className="text-[10px] text-zinc-400">
                  {hiddenPaused
                    ? 'Пауза — вкладка прихована (економія трафіку)'
                    : `Потік активний · ${streamFps || '…'} FPS`}
                  {streamMb > 0.05 && ` · ${streamMb.toFixed(1)} МБ`}
                </p>
              </div>
            </div>
            <div className="flex flex-none items-center gap-2">
              {/* ТЗ 49: профіль якості/трафіку (смугу ховаємо на вузьких екранах) */}
              <div className="hidden items-center gap-1 rounded-xl border border-white/10 bg-white/5 p-1 md:flex">
                {(Object.keys(STREAM_PRESETS) as StreamPresetKey[]).map((k) => (
                  <button
                    key={k}
                    onClick={() => {
                      // ТЗ 53: ручний вибір профілю — відключає авто-«Максимум» на тунелі
                      manualPresetRef.current = true;
                      setPreset(k);
                      try { localStorage.setItem('fc_stream_preset', k); } catch { }
                      const st = streamStatusRef.current;
                      if (st === 'live' || st === 'starting') startScreenStream(k);
                    }}
                    className={`rounded-lg px-2.5 py-1.5 text-[11px] font-bold transition-all ${
                      preset === k ? 'bg-indigo-500/30 text-indigo-200' : 'text-zinc-400 hover:text-zinc-200'
                    }`}
                    title={`${STREAM_PRESETS[k].label}: ${STREAM_PRESETS[k].fps} FPS · JPEG ${STREAM_PRESETS[k].q}% · ширина ${STREAM_PRESETS[k].w}px`}
                  >
                    {STREAM_PRESETS[k].label}
                  </button>
                ))}
              </div>
              {/* ТЗ 46: звук ПК у трансляції */}
              {audioOn && (
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={audioVolume}
                  onChange={(e) => setAudioVolume(Number(e.target.value))}
                  className="hidden h-1 w-24 cursor-pointer accent-violet-500 sm:block"
                  aria-label="Гучність звука ПК"
                  title={`Гучність звука ПК: ${audioVolume}%`}
                />
              )}
              <button
                onClick={toggleAudio}
                className={`flex items-center gap-1.5 rounded-xl border px-3 py-2 text-xs font-bold transition-all ${
                  audioOn
                    ? 'border-emerald-400/40 bg-emerald-500/20 text-emerald-200'
                    : 'border-white/15 bg-white/5 text-zinc-300 hover:bg-white/10'
                }`}
                title={audioOn ? 'Вимкнути звук ПК у стримі' : 'Транслювати також звук з ПК (ТЗ 46)'}
              >
                {audioOn ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
                <span className="hidden sm:inline">{audioOn ? 'Звук ПК: увімк.' : 'Звук ПК'}</span>
              </button>
              <button onClick={stopScreenStream} className="fc-btn fc-btn-danger flex-none">Зупинити</button>
            </div>
          </div>
          <div className="relative grid flex-1 place-items-center overflow-hidden bg-black">
            {/* ТЗ 53: кадр ЗАВЖДИ масштабується на всю площу оверлея (максимальний
                масштаб — «на весь екран сайта»), без стрибків під розмір кадру:
                розмір першого кадру і наступних більше не впливає на геометрію. */}
            <img ref={streamImageRef} alt="Трансляція екрана" className="h-full w-full object-contain" />
            {streamStatus === 'starting' && (
              <div className="pointer-events-none absolute inset-0 grid place-items-center text-center">
                <div className="rounded-2xl border border-white/10 bg-black/60 px-5 py-4 text-sm text-indigo-200">Запуск трансляції…</div>
              </div>
            )}
            {streamStatus === 'error' && (
              <div className="absolute inset-0 grid place-items-center text-center">
                <div className="max-w-sm rounded-2xl border border-rose-500/30 bg-black/75 px-5 py-4 text-sm text-rose-200">Агент не підтримує трансляцію. Оновіть і перезапустіть FluxControl на віддаленому ПК.</div>
              </div>
            )}
          </div>
        </div>
      )}

    </div>
  );
});

ControlTab.displayName = 'ControlTab';
