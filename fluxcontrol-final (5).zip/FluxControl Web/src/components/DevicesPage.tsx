import React, { useState, useLayoutEffect, useRef, useEffect } from 'react';
import { 
  Plus, 
  Monitor, 
  Trash2, 
  Activity, 
  Wifi, 
  WifiOff, 
  Cpu, 
  ArrowRight, 
  X, 
  Check, 
  AlertCircle,
  Clock,
  LogIn,
  ShieldCheck,
  Crown,
  Lock,
  Key,
  Edit3,
  User as UserIcon,
  HardDrive,
  Power,
  Settings,
  Zap,
  Loader2,
  Network,
  Save,
  Wand2 } from 'lucide-react';
import { useDevices } from '../context/DeviceContext';
import { useAuth } from '../context/AuthContext';
import { Device, AppRoute } from '../types';
import { ConfirmDialog } from './ConfirmDialog';
import { toast } from '../utils/toast';
import { relayUrl } from '../services/relayBase';

/**
 * Текст, який САМ зменшує шрифт (11px → 7px), щоб влізти в один рядок —
 * жодних обрізань довгої назви ОС («Windows 11 Pro для слабких ПК…»).
 */
const AutoFitRow: React.FC<{ value: string; tone?: string }> = ({ value, tone = 'text-white' }) => {
  const boxRef = useRef<HTMLSpanElement>(null);
  const textRef = useRef<HTMLSpanElement>(null);
  const [size, setSize] = useState(11);

  useLayoutEffect(() => {
    const box = boxRef.current;
    const el = textRef.current;
    if (!box || !el) return;
    // Спочатку даємо тексту природну ширину (без переносу), потім стискаємо.
    for (const s of [11, 10.5, 10, 9.5, 9, 8.5, 8, 7.5, 7]) {
      el.style.fontSize = `${s}px`;
      if (el.scrollWidth <= box.clientWidth) {
        setSize(s);
        return;
      }
    }
    setSize(7);
  }, [value]);

  return (
    <span ref={boxRef} className="relative block min-w-0 flex-1 overflow-hidden text-right" title={value}>
      <span
        ref={textRef}
        className={`inline-block max-w-full whitespace-nowrap font-semibold leading-tight ${tone}`}
        style={{ fontSize: `${size}px` }}
      >
        {value}
      </span>
    </span>
  );
};

interface DevicesPageProps {
  onSelectDevice: (device: Device) => void;
  onNavigate: (route: AppRoute) => void;
  onDownloadClient: () => void;
}

export const DevicesPage: React.FC<DevicesPageProps> = ({ 
  onSelectDevice, 
  onNavigate,
  onDownloadClient 
}) => {
  const { devices, addDevice, removeDevice, renameDevice, verifyCode, updateDeviceStatus, refreshDevices } = useDevices();
  const { user, loginWithGoogle, isSubscribed, isAdmin } = useAuth();

  const [modalOpen, setModalOpen] = useState(false);
  const [subModalOpen, setSubModalOpen] = useState(false);
  const [step, setStep] = useState<1 | 2>(1);
  const [code, setCode] = useState('');
  const [customName, setCustomName] = useState('');
  const [verifiedSpecs, setVerifiedSpecs] = useState<any>(null);
  const [isVerifying, setIsVerifying] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [checkingDeviceId, setCheckingDeviceId] = useState<string | null>(null);

  const [editingDeviceId, setEditingDeviceId] = useState<string | null>(null);
  const [editingName, setEditingName] = useState<string>('');
  const [deviceToRemove, setDeviceToRemove] = useState<Device | null>(null);

  const handleOpenModal = () => {
    if (!user) {
      loginWithGoogle();
      return;
    }
    if (!isSubscribed) {
      setSubModalOpen(true);
      return;
    }
    setStep(1);
    setCode('');
    setCustomName('');
    setVerifiedSpecs(null);
    setErrorMsg(null);
    setModalOpen(true);
  };

  const handleVerifyCode = async (e: React.FormEvent) => {
    e.preventDefault();
    const clean = code.replace(/[^A-Za-z0-9]/g, '').trim().toUpperCase();
    if (!clean) {
      setErrorMsg('Будь ласка, введіть 16-значний код підключення з програми FluxControl на ПК');
      return;
    }

    setIsVerifying(true);
    setErrorMsg(null);

    try {
      const res = await verifyCode(clean);
      if (res.success && res.data) {
        setVerifiedSpecs(res.data);
        setCustomName(res.data.name || 'Мій ПК');
        setStep(2);
      } else {
        setErrorMsg(res.message || 'Комп\'ютер не знайдено в базі або він офлайн. Переконайтеся, що програма запущена.');
      }
    } catch {
      setErrorMsg("Помилка з'єднання із сервером перевірки");
    } finally {
      setIsVerifying(false);
    }
  };

  const handleSaveDevice = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!code.trim()) return;

    setIsSaving(true);
    setErrorMsg(null);

    try {
      const res = await addDevice(code.trim(), customName.trim() || 'Мій ПК', verifiedSpecs);
      if (res.success) {
        setModalOpen(false);
        toast.success(`Пристрій «${customName.trim() || 'Мій ПК'}» успішно прив'язано до вашого акаунта!`, { title: 'Пристрій додано' });
      } else {
        setErrorMsg(res.error || 'Помилка збереження пристрою');
      }
    } catch {
      setErrorMsg("Помилка з'єднання із сервером");
    } finally {
      setIsSaving(false);
    }
  };

  // Wake-on-LAN: пробудження вимкненого ПК через інший онлайн-пристрій
  // у тій самій локальній мережі (донора вибирає сервер).
  const [wakingDeviceId, setWakingDeviceId] = useState<string | null>(null);
  const handleWake = async (device: Device) => {
    if (wakingDeviceId) return;
    setWakingDeviceId(device.id);
    try {
      let ip: string = '';
      try { ip = localStorage.getItem(`fluxcontrol_wol_ip_${device.id}`) || ''; } catch {}
      const r = await fetch(relayUrl('/api/wol'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ target: device.hwid || device.code || device.id, userId: user?.id, ip: ip || undefined })
      });
      const j = await r.json();
      if (j?.success) {
        toast.success(j.message || 'Команду пробудження надіслано. ПК з’явиться в мережі протягом хвилини.', { title: 'Wake-on-LAN' });
      } else {
        toast.warn(j?.message || 'Не вдалося надіслати команду пробудження', { title: 'Wake-on-LAN' });
      }
    } catch {
      toast.warn('Сервер недоступний. Спробуйте ще раз.', { title: 'Wake-on-LAN' });
    } finally {
      setTimeout(() => setWakingDeviceId(null), 1500);
    }
  };

  // Модалка налаштування Wake-on-LAN на карточці пристрою (ТЗ: «натискаєш
  // налаштувати → вікно з MAC/IP»). Ввімкнено = збережений MAC; вимкнено = MAC очищено.
  const [wolModalDevice, setWolModalDevice] = useState<Device | null>(null);

  // Локальний оверлей стану WoL:MAC (модалка зберігає на сервері → оновлюємо
  // оверлей миттєво і підтягуємо список із сервера, щоб кнопка з'явилась/зникла).
  const [wolOverrides, setWolOverrides] = useState<Record<string, string | null>>({});
  const getWolMac = (device: Device): string | null | undefined =>
    device.id in wolOverrides ? wolOverrides[device.id] : device.wolMac;

  const handleWolSaved = (deviceId: string, mac: string | null) => {
    setWolOverrides(prev => ({ ...prev, [deviceId]: mac }));
    void refreshDevices();
  };

  const handleConnect = async (device: Device) => {
    if (!isSubscribed) {
      setSubModalOpen(true);
      return;
    }
    if (!device.isOnline) {
      setCheckingDeviceId(device.id);
      try {
        const live = await verifyCode(device.code || device.id);
        if (live.success) {
          updateDeviceStatus(device.id, 'online');
          onSelectDevice({ ...device, isOnline: true, lastSeen: Date.now() });
          return;
        }
      } finally { setCheckingDeviceId(null); }
      toast.warn(`Пристрій «${device.name}» не відповідає. Перевірте, що FluxControl запущено на ПК.`, { title: 'ПК недоступний' });
      return;
    }
    onSelectDevice(device);
  };

  const handleStartRename = (device: Device) => {
    setEditingDeviceId(device.id);
    setEditingName(device.name);
  };

  const handleConfirmRename = async (deviceId: string) => {
    const trimmed = editingName.trim();
    if (trimmed) {
      await renameDevice(deviceId, trimmed);
    }
    setEditingDeviceId(null);
  };

  const formatLastActivity = (isOnline: boolean, timestamp?: number | string) => {
    if (isOnline) return 'Зараз в мережі';
    if (!timestamp) return 'Невідомо';
    const ts = typeof timestamp === 'string' ? new Date(timestamp).getTime() : Number(timestamp);
    if (isNaN(ts) || ts <= 0) return 'Невідомо';
    const diff = Date.now() - ts;
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return 'Щойно';
    if (mins < 60) return `${mins} хв тому`;
    const hours = Math.floor(mins / 60);
    if (hours < 24) return `${hours} год тому`;
    const d = new Date(ts);
    const months = ['січ', 'лют', 'бер', 'кві', 'тра', 'чер', 'лип', 'сер', 'вер', 'жов', 'лис', 'гру'];
    return `${d.getDate()} ${months[d.getMonth()]}, ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  };

  // СОРТУВАННЯ: спочатку всі ОНЛАЙН, потім офлайн; всередині груп — за
  // останньою активністю (свіжіші вище: «місяць тому» перед «рік тому»).
  const lastSeenMs = (d: Device): number => {
    if (!d.lastSeen) return 0;
    const ts = typeof d.lastSeen === 'string' ? new Date(d.lastSeen).getTime() : Number(d.lastSeen);
    return isNaN(ts) ? 0 : ts;
  };
  const sortedDevices = [...devices].sort((a, b) => {
    if (a.isOnline !== b.isOnline) return a.isOnline ? -1 : 1;
    return lastSeenMs(b) - lastSeenMs(a);
  });
  const onlineCount = devices.filter(d => d.isOnline).length;
  const offlineCount = devices.length - onlineCount;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-28 pb-20 w-full animate-in fade-in duration-300">
      
      {/* Header Bar — чисто і сучасно: заголовок + живе зведення, БЕЗ
          «прив'язано до акаунта …» під текстом */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-7">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              Мої Пристрої
            </h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-600/20 text-indigo-300 border border-indigo-500/30">
              {devices.length}
            </span>
          </div>
          <div className="mt-1.5 flex flex-wrap items-center gap-2">
            {onlineCount > 0 && (
              <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-2.5 py-1 text-[11px] font-bold text-emerald-300">
                <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" />
                {onlineCount} в мережі
              </span>
            )}
            {offlineCount > 0 && (
              <span className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-2.5 py-1 text-[11px] font-bold text-zinc-400">
                <WifiOff className="h-3 w-3" />
                {offlineCount} офлайн
              </span>
            )}
            {isAdmin && (
              <span className="inline-flex items-center gap-1.5 rounded-full border border-amber-500/30 bg-amber-500/10 px-2.5 py-1 text-[11px] font-bold text-amber-300">
                <Crown className="h-3 w-3" /> Admin
              </span>
            )}
          </div>
        </div>

        <div className="flex items-center gap-3 w-full sm:w-auto">
          {user ? (
            <button
              id="btn-add-device-main"
              onClick={handleOpenModal}
              className="flex-1 sm:flex-initial flex items-center justify-center gap-2 px-5 py-2.5 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 active:scale-95 text-white rounded-2xl font-bold transition-all shadow-lg shadow-indigo-600/30 text-xs cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Додати пристрій</span>
            </button>
          ) : (
            <button
              onClick={loginWithGoogle}
              className="flex-1 sm:flex-initial flex items-center justify-center gap-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white rounded-2xl font-bold transition-all shadow-lg shadow-indigo-600/30 text-xs cursor-pointer"
            >
              <LogIn className="w-4 h-4" />
              <span>Увійти через Google</span>
            </button>
          )}
        </div>
      </div>

      {/* Subscription Required Banner (if user has no subscription) */}
      {user && !isSubscribed && (
        <div className="mb-8 p-5 rounded-3xl bg-gradient-to-r from-indigo-950/60 via-purple-950/40 to-black/80 border border-indigo-500/30 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl">
          <div className="flex items-center gap-3.5">
            <div className="p-3 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
              <Lock className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <span>Для керування ПК потрібна активна підписка</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-semibold">Лише 1 ліцензія</span>
              </h3>
              <p className="text-xs text-gray-400 mt-0.5">
                Активуйте ліцензійний ключ у вкладці «Профіль», щоб розблокувати віддалений доступ, передачу файлів та термінал.
              </p>
            </div>
          </div>
          <button
            onClick={() => onNavigate('/profile')}
            className="px-5 py-2.5 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white rounded-2xl font-bold text-xs shadow-lg shadow-indigo-600/30 whitespace-nowrap cursor-pointer flex items-center gap-1.5"
          >
            <Key className="w-3.5 h-3.5" />
            <span>Активувати ключ у Профілі</span>
          </button>
        </div>
      )}

      {/* Devices Grid List: онлайн зверху, офлайн знизу, за активністю */}
      {devices.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {sortedDevices.map((device) => (
            <div
              key={device.id}
              className={`glass-card rounded-3xl p-5 border transition-all duration-300 relative overflow-hidden flex flex-col justify-between group ${
                device.isOnline
                  ? 'border-indigo-500/30 hover:border-indigo-400/60 bg-gradient-to-b from-[#0e0e1c] to-[#070711] shadow-xl hover:shadow-indigo-600/10'
                  : 'border-white/10 hover:border-white/20 bg-[#080810]/70'
              }`}
            >
              {/* Subtle accent glow */}
              {device.isOnline && (
                <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none group-hover:bg-indigo-500/20 transition-colors" />
              )}

              <div>
                {/* Card Top: Status & Name & Unlink */}
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="flex items-center gap-3 min-w-0 flex-1">
                    <div className={`relative p-2.5 rounded-2xl border flex-shrink-0 transition-colors ${
                      device.isOnline 
                        ? 'bg-indigo-600/20 border-indigo-500/40 text-indigo-300' 
                        : 'bg-white/5 border-white/10 text-gray-500'
                    }`}>
                      <Monitor className="w-5 h-5" />
                      <span className={`absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full ring-2 ring-[#0b0b13] ${
                        device.isOnline ? 'bg-emerald-400' : 'bg-zinc-600'
                      }`} />
                    </div>

                    <div className="min-w-0 flex-1">
                      {editingDeviceId === device.id ? (
                        <div className="flex items-center gap-1.5">
                          <input
                            type="text"
                            value={editingName}
                            onChange={(e) => setEditingName(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleConfirmRename(device.id);
                              if (e.key === 'Escape') setEditingDeviceId(null);
                            }}
                            autoFocus
                            className="bg-black/80 border border-indigo-500/50 rounded-xl px-2.5 py-1 text-xs sm:text-sm font-bold text-white focus:outline-none focus:border-indigo-400 w-full max-w-[180px]"
                          />
                          <button
                            onClick={() => handleConfirmRename(device.id)}
                            className="p-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg transition-colors cursor-pointer"
                            title="Зберегти назву"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setEditingDeviceId(null)}
                            className="p-1.5 bg-white/10 hover:bg-white/15 text-gray-400 hover:text-white rounded-lg transition-colors cursor-pointer"
                            title="Скасувати"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <div className="flex items-center gap-1.5">
                          <h3 className="font-extrabold text-base text-white truncate leading-tight">
                            {device.name}
                          </h3>
                          <button
                            onClick={() => handleStartRename(device)}
                            className="p-1 text-gray-500 hover:text-indigo-300 rounded-lg hover:bg-white/5 transition-colors cursor-pointer flex-shrink-0"
                            title="Перейменувати пристрій"
                          >
                            <Edit3 className="w-3 h-3" />
                          </button>
                        </div>
                      )}

                      <div className="mt-0.5 flex items-center gap-1.5">
                        {device.isOnline ? (
                          <span className="fc-badge fc-badge-ok">
                            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" /> В мережі
                          </span>
                        ) : (
                          <span className="fc-badge fc-badge-muted">
                            <WifiOff className="h-2.5 w-2.5" /> Не запущено
                          </span>
                        )}
                        {!device.isOnline && lastSeenMs(device) > 0 && (
                          <span className="truncate font-mono text-[10px] text-zinc-500">
                            · був {formatLastActivity(device.isOnline, device.lastSeen)}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => setDeviceToRemove(device)}
                    className="p-1.5 text-gray-500 hover:text-red-400 rounded-xl hover:bg-red-500/10 transition-colors flex-shrink-0 cursor-pointer"
                    title="Відв'язати пристрій"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                {/* Specs: ОС (завжди — жива або збережена в БД) + користувач.
                    Компактно: зменшені відступи, без «рядочних» банерів. */}
                <div className="space-y-1.5 rounded-2xl border border-white/5 bg-black/30 px-3 py-2.5 text-[11px]">
                  <div className="flex items-center gap-2">
                    <Cpu className="h-3 w-3 flex-none text-indigo-400" />
                    <span className="flex-none text-zinc-500">ОС:</span>
                    <AutoFitRow value={device.osInfo || device.os || 'Windows'} />
                  </div>
                  <div className="flex items-center gap-2">
                    <UserIcon className="h-3 w-3 flex-none text-indigo-400" />
                    <span className="flex-none text-zinc-500">Користувач:</span>
                    <AutoFitRow value={device.username || 'Адміністратор'} tone="text-indigo-300" />
                  </div>
                </div>
              </div>

              {/* Action: підключення (онлайн) / Wake-on-LAN (офлайн) + налаштування (ТЗ) */}
              <div className="pt-3.5">
                <div className="flex items-center gap-2">
                  {device.isOnline || checkingDeviceId === device.id ? (
                    <button
                      id={`btn-connect-device-${device.id}`}
                      onClick={() => handleConnect(device)}
                      disabled={checkingDeviceId === device.id}
                      className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-2xl font-bold text-xs bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 active:scale-[0.98] text-white shadow-lg shadow-indigo-600/30 transition-all cursor-pointer"
                    >
                      <Wifi className="w-3.5 h-3.5" />
                      <span>Підключитись до ПК</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  ) : getWolMac(device) ? (
                    <button
                      id={`btn-wake-device-${device.id}`}
                      onClick={() => handleWake(device)}
                      disabled={wakingDeviceId === device.id}
                      className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-2xl font-bold text-xs transition-all active:scale-[0.98] ${
                        wakingDeviceId === device.id
                          ? 'bg-white/[.04] text-amber-300 border border-amber-400/20 cursor-wait'
                          : 'bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-white shadow-lg shadow-orange-600/20 cursor-pointer'
                      }`}
                      title="Запустити ПК через Wake-on-LAN (працює в межах локальної мережі)"
                    >
                      {wakingDeviceId === device.id ? (
                        <>
                          <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-amber-300/30 border-t-amber-300" />
                          <span>Надсилаю команду…</span>
                        </>
                      ) : (
                        <>
                          <Power className="w-3.5 h-3.5" />
                          <span>Запустити ПК</span>
                        </>
                      )}
                    </button>
                  ) : (
                    /* ТЗ: WoL вимкнено/не налаштовано → жодної кнопки запуску і
                       ЖОДНОГО тексту-пояснення — просто «ПК оффлайн». */
                    <div
                      className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-2xl font-bold text-xs bg-white/[.03] text-zinc-500 border border-white/5"
                      title="ПК зараз оффлайн"
                    >
                      <Power className="w-3.5 h-3.5 opacity-50" />
                      <span>ПК оффлайн</span>
                    </div>
                  )}

                  {/* Шестерня налаштування WoL — ТЗ: «натискаєш налаштувати → вікно» */}
                  <button
                    onClick={() => setWolModalDevice(device)}
                    className={`flex h-[38px] w-[38px] flex-none items-center justify-center rounded-xl border transition-all cursor-pointer ${
                      device.isOnline
                        ? 'border-white/10 bg-white/5 text-zinc-400 hover:border-indigo-400/40 hover:text-indigo-300'
                        : getWolMac(device)
                          ? 'border-amber-400/25 bg-amber-500/10 text-amber-300 hover:bg-amber-500/20'
                          : 'border-white/10 bg-white/5 text-zinc-500 hover:border-indigo-400/40 hover:text-indigo-300'
                    }`}
                    title="Налаштувати Wake-on-LAN (MAC, IP)"
                    aria-label="Налаштувати Wake-on-LAN"
                  >
                    <Settings className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* Empty State */
        <div className="glass-card rounded-3xl p-12 text-center max-w-xl mx-auto border border-white/10 bg-[#090b14]/80">
          <div className="w-16 h-16 bg-indigo-600/20 border border-indigo-500/30 rounded-3xl flex items-center justify-center text-indigo-400 mx-auto mb-4">
            <Monitor className="w-8 h-8" />
          </div>
          <h2 className="text-xl font-bold text-white mb-2">Немає доданих комп'ютерів</h2>
          <p className="text-xs text-gray-400 max-w-md mx-auto mb-6 leading-relaxed">
            Запустіть <span className="text-indigo-300 font-semibold">«FluxControl.exe»</span> на вашому комп'ютері, візьміть 16-значний код та прив'яжіть його тут.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={handleOpenModal}
              className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white rounded-2xl font-bold text-xs transition-all shadow-lg shadow-indigo-600/30 cursor-pointer"
            >
              Додати перший ПК
            </button>
            <button
              onClick={onDownloadClient}
              className="px-5 py-2.5 bg-white/5 hover:bg-white/10 text-indigo-300 hover:text-white rounded-2xl font-semibold text-xs border border-white/10 hover:border-indigo-500/30 transition-all cursor-pointer"
            >
              Завантажити клієнт (.exe)
            </button>
          </div>
        </div>
      )}

      {/* Add Device Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
          <div className="glass-panel w-full max-w-md rounded-3xl p-6 border border-white/15 shadow-2xl relative bg-[#090b14]">
            
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-5">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-indigo-600/20 text-indigo-400">
                  <Monitor className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Додати новий пристрій</h3>
                  <p className="text-[11px] text-indigo-300/80">Крок {step} з 2</p>
                </div>
              </div>
              <button
                onClick={() => setModalOpen(false)}
                className="p-1.5 text-gray-400 hover:text-white rounded-xl hover:bg-white/5 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Error banner */}
            {errorMsg && (
              <div className="mb-4 p-3 bg-red-500/10 border border-red-500/30 rounded-xl text-red-400 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* Step 1: Input Connection Code */}
            {step === 1 && (
              <form onSubmit={handleVerifyCode} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-300 mb-1.5">
                    16-значний код підключення з програми
                  </label>
                  <input
                    type="text"
                    required
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    placeholder="Наприклад: 59F5PWDG7KEPBW7B"
                    className="w-full bg-black/60 border border-white/10 focus:border-indigo-500 rounded-2xl px-4 py-3 text-sm text-white font-mono placeholder:text-gray-600 focus:outline-none transition-colors uppercase tracking-wider"
                  />
                  <p className="text-[11px] text-gray-400 mt-2 leading-relaxed">
                    Запустіть <span className="text-indigo-300 font-semibold">FluxControl.exe</span> на ПК, і у вікні відобразиться 16-символьний код.
                  </p>
                </div>

                <div className="flex items-center gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setModalOpen(false)}
                    className="flex-1 py-3 bg-white/5 hover:bg-white/10 text-gray-300 rounded-2xl font-bold text-xs transition-colors cursor-pointer"
                  >
                    Скасувати
                  </button>
                  <button
                    type="submit"
                    disabled={isVerifying}
                    className="flex-1 py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl font-bold text-xs transition-all shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                  >
                    {isVerifying ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        <span>Пошук ПК...</span>
                      </>
                    ) : (
                      <>
                        <span>Перевірити</span>
                        <ArrowRight className="w-4 h-4" />
                      </>
                    )}
                  </button>
                </div>
              </form>
            )}

            {/* Step 2: Name Device & Confirm Specs */}
            {step === 2 && (
              <form onSubmit={handleSaveDevice} className="space-y-4">
                {verifiedSpecs && (
                  <div className="p-4 bg-gradient-to-br from-[#0e1022] to-[#080812] border border-indigo-500/30 rounded-2xl space-y-3 text-xs shadow-xl">
                    <div className="flex items-center gap-3 pb-2.5 border-b border-white/10">
                      <div className="p-2.5 rounded-xl bg-indigo-600/20 border border-indigo-500/40 text-indigo-300">
                        <Monitor className="w-5 h-5 text-indigo-300" />
                      </div>
                      <div>
                        <p className="text-[10px] uppercase font-bold text-indigo-300 tracking-wider">Знайдено комп'ютер</p>
                        <h4 className="text-sm font-black text-white">{verifiedSpecs.name || 'Мій ПК'}</h4>
                      </div>
                    </div>

                    <div className="space-y-1.5 text-[11px]">
                      <div className="flex items-center justify-between">
                        <span className="text-gray-400">Операційна система:</span>
                        <span className="font-semibold text-white truncate max-w-[210px] text-right">
                          {verifiedSpecs.os || verifiedSpecs.osInfo || 'Windows 11'}
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-gray-400">Процесор:</span>
                        <span className="font-semibold text-indigo-200 truncate max-w-[210px] text-right" title={verifiedSpecs.cpu || verifiedSpecs.cpuInfo}>
                          {verifiedSpecs.cpu || verifiedSpecs.cpuInfo || 'Процесор'}
                        </span>
                      </div>
                      {(verifiedSpecs.gpu || verifiedSpecs.gpuInfo) && (
                        <div className="flex items-center justify-between">
                          <span className="text-gray-400">Відеокарта:</span>
                          <span className="font-semibold text-emerald-400 truncate max-w-[210px] text-right" title={verifiedSpecs.gpu || verifiedSpecs.gpuInfo}>
                            {verifiedSpecs.gpu || verifiedSpecs.gpuInfo}
                          </span>
                        </div>
                      )}
                      {verifiedSpecs.username && (
                        <div className="flex items-center justify-between">
                          <span className="text-gray-400">Користувач ОС:</span>
                          <span className="font-semibold text-gray-300">{verifiedSpecs.username}</span>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                <div>
                  <label className="block text-xs font-semibold text-gray-300 mb-1.5">
                    Власна назва для пристрою
                  </label>
                  <input
                    type="text"
                    required
                    value={customName}
                    onChange={(e) => setCustomName(e.target.value)}
                    placeholder="Наприклад: Мій Ноутбук, Робочий ПК..."
                    className="w-full bg-black/60 border border-white/10 focus:border-indigo-500 rounded-2xl px-4 py-3 text-sm text-white focus:outline-none transition-colors"
                  />
                </div>

                <div className="flex items-center gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setStep(1)}
                    className="flex-1 py-3 bg-white/5 hover:bg-white/10 text-gray-300 rounded-2xl font-bold text-xs transition-colors cursor-pointer"
                  >
                    Назад
                  </button>
                  <button
                    type="submit"
                    disabled={isSaving}
                    className="flex-1 py-3 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white rounded-2xl font-bold text-xs transition-all shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                  >
                    {isSaving ? 'Збереження...' : 'Зберегти та прив\'язати'}
                  </button>
                </div>
              </form>
            )}

          </div>
        </div>
      )}

      {/* Subscription Guard Modal */}
      {subModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
          <div className="glass-panel w-full max-w-md rounded-3xl p-6 sm:p-8 border border-white/15 shadow-2xl relative bg-[#090b14] text-center">
            <button
              onClick={() => setSubModalOpen(false)}
              className="absolute top-5 right-5 p-1.5 text-gray-400 hover:text-white rounded-xl hover:bg-white/5"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="w-16 h-16 rounded-3xl bg-amber-500/20 border border-amber-500/30 text-amber-400 flex items-center justify-center mx-auto mb-4">
              <Crown className="w-8 h-8" />
            </div>

            <h3 className="text-xl font-bold text-white mb-2">Потрібна підписка PRO</h3>
            <p className="text-xs text-gray-400 leading-relaxed mb-6">
              Для додавання та підключення комп'ютерів необхідно мати активну підписку. Ви можете активувати ліцензійний ключ у вкладці «Профіль».
            </p>

            <div className="space-y-3">
              <button
                onClick={() => {
                  setSubModalOpen(false);
                  onNavigate('/profile');
                }}
                className="w-full py-3.5 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white rounded-2xl font-bold text-xs sm:text-sm shadow-lg shadow-indigo-600/30 cursor-pointer flex items-center justify-center gap-2"
              >
                <Key className="w-4 h-4" />
                <span>Перейти до активації ключа</span>
              </button>
              <button
                onClick={() => setSubModalOpen(false)}
                className="w-full py-2.5 text-gray-400 hover:text-white text-xs font-semibold"
              >
                Закрити
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Unlink Device Confirmation (styled, replaces native confirm) */}
      <ConfirmDialog
        isOpen={Boolean(deviceToRemove)}
        title="Відв'язати пристрій?"
        message={`Ви дійсно бажаєте відв'язати «${deviceToRemove?.name ?? ''}»? Пристрій зникне зі списку, але його можна додати знову за кодом підключення.`}
        confirmLabel="Відв'язати"
        onCancel={() => setDeviceToRemove(null)}
        onConfirm={() => {
          if (deviceToRemove) removeDevice(deviceToRemove.id);
          setDeviceToRemove(null);
        }}
      />

      {/* Wake-on-LAN settings modal (ТЗ: налаштування прямо з карточки) */}
      <WolSettingsModal
        device={wolModalDevice}
        onClose={() => setWolModalDevice(null)}
        onSaved={handleWolSaved}
      />

    </div>
  );
};

/** Нормалізує введений MAC до A4:BB:6D:11:22:33 (null — якщо некоректний). */
const normalizeMacInput = (raw: string): string | null => {
  const hex = raw.replace(/[^0-9a-fA-F]/g, '').toUpperCase();
  if (hex.length !== 12 || hex === '000000000000') return null;
  return hex.match(/.{2}/g)!.join(':');
};

/**
 * Модалка налаштування Wake-on-LAN на карточці пристрою (ТЗ):
 *  • перемикач «Увімкнено/Вимкнено» (увімкнено = збережений MAC);
 *  • вибір адаптера зі списку (якщо ПК онлайн і адаптери відомі серверу);
 *  • ручне введення MAC і опційної IP-адреси для спрямованого бродкасту;
 *  • вимкнено → на офлайн-карточці просто «ПК оффлайн» без кнопки запуску.
 */
const WolSettingsModal: React.FC<{
  device: Device | null;
  onClose: () => void;
  onSaved: (deviceId: string, mac: string | null) => void;
}> = ({ device, onClose, onSaved }) => {
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [enabled, setEnabled] = useState(false);
  const [macInput, setMacInput] = useState('');
  const [ipInput, setIpInput] = useState('');
  const [savedMac, setSavedMac] = useState<string | null>(null);
  const [adapters, setAdapters] = useState<{ mac: string; name: string; ip?: string; broadcast?: string; type?: string; hasGateway?: boolean }[]>([]);
  const [autoOpen, setAutoOpen] = useState(false);

  useEffect(() => {
    if (!device) return;
    let alive = true;
    // ТЗ 45: у кожного ПК СВОИ адаптеры — при открытии модалки другого
    // устройства сбрасываем список, auto-панель и поля, иначе в модалке
    // устройства B показывались адаптеры устройства A.
    setAdapters([]);
    setAutoOpen(false);
    setMacInput('');
    setIpInput('');
    setLoading(true);
    setEnabled(Boolean(device.wolMac));
    try { setIpInput(localStorage.getItem(`fluxcontrol_wol_ip_${device.id}`) || ''); } catch {}

    (async () => {
      try {
        const r = await fetch(`${relayUrl('/api/wol/config')}?target=${encodeURIComponent(device.hwid || device.code || device.id)}`);
        const j = await r.json();
        if (!alive) return;
        if (j?.success) {
          const mac: string | null = j.wolMac || null;
          setSavedMac(mac);
          setEnabled(Boolean(mac));
          // ТЗ: «коли наступного разу заходиш — у полях вже стоїть збережене».
          setMacInput(mac || '');
          if (Array.isArray(j.adapters)) {
            setAdapters(j.adapters.filter((a: any) => a?.mac));
          }
        }
      } catch { /* сервер недоступний — працюємо з локальним станом */ }
      finally { if (alive) setLoading(false); }
    })();

    return () => { alive = false; };
  }, [device]);

  if (!device) return null;

  const persist = async (mac: string | null) => {
    setSaving(true);
    try {
      const r = await fetch(relayUrl('/api/wol/config'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ target: device.hwid || device.code || device.id, mac: mac || '' })
      });
      const j = await r.json();
      if (j?.success) {
        setSavedMac(j.wolMac || null);
        setEnabled(Boolean(j.wolMac));
        try {
          if (ipInput.trim()) localStorage.setItem(`fluxcontrol_wol_ip_${device.id}`, ipInput.trim());
          else localStorage.removeItem(`fluxcontrol_wol_ip_${device.id}`);
        } catch {}
        onSaved(device.id, j.wolMac || null);
        toast.success(
          j.wolMac ? `Wake-on-LAN увімкнено · MAC ${j.wolMac}` : 'Wake-on-LAN вимкнено',
          { title: 'Wake-on-LAN' }
        );
      } else {
        toast.warn(j?.message || 'Не вдалося зберегти MAC', { title: 'Wake-on-LAN' });
      }
    } catch {
      toast.warn('Сервер недоступний', { title: 'Wake-on-LAN' });
    } finally { setSaving(false); }
  };

  const toggleEnabled = () => {
    if (!enabled && savedMac) {
      void persist(savedMac); // повторне увімкнення — відома адреса
      return;
    }
    if (!enabled) {
      // Увімкнення без MAC: спробуємо вибрати адаптер зі шлюзом або перший.
      const gw = adapters.find(a => a.hasGateway) || adapters[0];
      if (gw?.mac) { setMacInput(gw.mac); void persist(gw.mac); return; }
      toast.warn('Введіть MAC-адресу ПК, щоб увімкнути пробудження', { title: 'Wake-on-LAN' });
      return;
    }
    void persist(null); // вимкнення — очищуємо MAC
  };

  const saveManual = () => {
    const mac = normalizeMacInput(macInput);
    if (!mac) {
      toast.warn('Введіть MAC у форматі A4:BB:6D:11:22:33', { title: 'Wake-on-LAN' });
      return;
    }
    if (ipInput.trim() && !/^\d{1,3}(\.\d{1,3}){3}$/.test(ipInput.trim())) {
      toast.warn('IP має бути у форматі 192.168.1.255 (або очистіть поле)', { title: 'Wake-on-LAN' });
      return;
    }
    void persist(mac);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in" onClick={onClose}>
      <div
        className="glass-panel w-full max-w-md rounded-3xl p-6 border border-white/15 shadow-2xl relative bg-[#090b14]"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-1.5 text-gray-400 hover:text-white rounded-xl hover:bg-white/5"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 pb-4 border-b border-white/10">
          <div className="p-2.5 rounded-xl bg-amber-500/15 border border-amber-500/25 text-amber-300">
            <Zap className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">Wake-on-LAN</h3>
            <p className="text-[11px] text-amber-300/80 truncate max-w-[260px]">{device.name}</p>
          </div>
        </div>

        {/* Перемикач Увімкнено/Вимкнено */}
        <div className="mt-4 flex items-center justify-between rounded-2xl border border-white/10 bg-black/30 px-4 py-3">
          <div>
            <p className="text-sm font-bold text-white">{enabled ? 'Увімкнено' : 'Вимкнено'}</p>
            <p className="mt-0.5 text-[11px] text-zinc-500">
              {enabled ? 'На офлайн-карточці буде кнопка «Запустити ПК»' : 'Кнопки запуску на карточці не буде'}
            </p>
          </div>
          <button
            type="button"
            role="switch"
            aria-checked={enabled}
            onClick={toggleEnabled}
            disabled={loading || saving}
            className={`relative h-7 w-12 flex-none rounded-full transition-colors cursor-pointer disabled:opacity-50 ${enabled ? 'bg-emerald-500/80' : 'bg-white/10'}`}
          >
            <span className={`absolute top-1 h-5 w-5 rounded-full bg-white shadow transition-all ${enabled ? 'left-6' : 'left-1'}`} />
          </button>
        </div>

        {/* ТЗ: кнопка «Налаштувати автоматично» — показує список адаптерів ПК */}
        <button
          type="button"
          onClick={() => {
            setAutoOpen(v => !v);
            if (!autoOpen && adapters.length === 0) {
              // Адаптери ще не прийшли з реєстрації — перезапитуємо конфіг.
              (async () => {
                try {
                  const r = await fetch(`${relayUrl('/api/wol/config')}?target=${encodeURIComponent(device.hwid || device.code || device.id)}`);
                  const j = await r.json();
                  if (j?.success && Array.isArray(j.adapters)) setAdapters(j.adapters.filter((a: any) => a?.mac));
                  else toast.warn('Список адаптерів ПК ще не готовий — спробуйте за хвилину', { title: 'Wake-on-LAN' });
                } catch { toast.warn('Сервер недоступний', { title: 'Wake-on-LAN' }); }
              })();
            }
          }}
          className={`mt-4 flex w-full cursor-pointer items-center justify-center gap-2 rounded-2xl border py-2.5 text-xs font-bold transition-all ${
            autoOpen
              ? 'border-indigo-400/40 bg-indigo-500/15 text-indigo-200'
              : 'border-white/10 bg-white/5 text-zinc-300 hover:border-indigo-400/40 hover:text-white'
          }`}
        >
          <Wand2 className="h-4 w-4" />
          {autoOpen ? 'Приховати список адаптерів' : 'Налаштувати автоматично'}
        </button>

        {/* Адаптери (якщо сервер їх знає) */}
        {autoOpen && adapters.length > 0 && (
          <div className="mt-3">
            <p className="mb-2 flex items-center gap-1.5 text-[10px] font-extrabold uppercase tracking-wider text-zinc-500">
              <Network className="h-3 w-3" /> Адаптери ПК — вибери той, через який ПК в мережі
            </p>
            <div className="max-h-36 space-y-1.5 overflow-y-auto pr-1">
              {adapters.map((a) => (
                <button
                  key={a.mac}
                  type="button"
                  onClick={() => {
                    // ТЗ «налаштувати автоматично»: вибрав адаптер — у поля
                    // підставляються MAC і IP спрямованого бродкасту.
                    setMacInput(a.mac);
                    const bcast = a.broadcast || (a.ip ? a.ip.replace(/\d+$/, '255') : '');
                    if (bcast) setIpInput(bcast);
                  }}
                  className={`flex w-full items-center gap-2.5 rounded-xl border px-3 py-2 text-left transition-all cursor-pointer ${
                    macInput.toUpperCase() === a.mac.toUpperCase()
                      ? 'border-indigo-500/50 bg-indigo-500/10'
                      : 'border-white/5 bg-white/[.02] hover:border-white/15'
                  }`}
                >
                  <Wifi className="h-3.5 w-3.5 flex-none text-indigo-300" />
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-xs font-bold text-white">{a.name || 'Адаптер'}</span>
                    <span className="block truncate font-mono text-[10px] text-zinc-500">{a.mac}{a.ip ? ` · ${a.ip}` : ''}</span>
                  </span>
                  {savedMac === a.mac && (
                    <span className="flex-none rounded-full bg-amber-500/10 px-1.5 py-0.5 text-[9px] font-bold text-amber-400">для пробудження</span>
                  )}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Ручне введення */}
        <div className="mt-4 space-y-2.5">
          <div>
            <label className="mb-1.5 block text-[11px] font-semibold text-gray-300">MAC-адреса</label>
            <input
              value={macInput}
              onChange={(e) => setMacInput(e.target.value)}
              placeholder="A4:BB:6D:11:22:33"
              className="w-full bg-black/60 border border-white/10 focus:border-indigo-500 rounded-2xl px-4 py-2.5 text-sm text-white font-mono placeholder:text-gray-600 focus:outline-none transition-colors"
            />
          </div>
          <div>
            <label className="mb-1.5 block text-[11px] font-semibold text-gray-300">
              IP для спрямованого бродкасту <span className="text-zinc-600">(опційно)</span>
            </label>
            <input
              value={ipInput}
              onChange={(e) => setIpInput(e.target.value)}
              placeholder="192.168.1.255"
              className="w-full bg-black/60 border border-white/10 focus:border-indigo-500 rounded-2xl px-4 py-2.5 text-sm text-white font-mono placeholder:text-gray-600 focus:outline-none transition-colors"
            />
          </div>
        </div>

        {savedMac && (
          <p className="mt-3 text-[11px] text-zinc-500">
            Зараз збережено: <span className="font-mono text-amber-300">{savedMac}</span>
          </p>
        )}

        <div className="mt-5 flex items-center gap-3">
          <button
            onClick={onClose}
            className="flex-1 py-3 bg-white/5 hover:bg-white/10 text-gray-300 rounded-2xl font-bold text-xs transition-colors cursor-pointer"
          >
            Закрити
          </button>
          <button
            onClick={saveManual}
            disabled={loading || saving}
            className="flex-1 py-3 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white rounded-2xl font-bold text-xs transition-all shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
          >
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            <span>Зберегти</span>
          </button>
        </div>

        <p className="mt-3 text-center text-[10px] leading-relaxed text-zinc-600">
          Пробудження працює в межах однієї локальної мережі: інший ваш онлайн-пристрій надішле магічний пакет.
        </p>
      </div>
    </div>
  );
};
