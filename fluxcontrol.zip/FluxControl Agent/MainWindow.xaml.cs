using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Forms;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Threading;
using FluxControl.Agent.Services;

namespace FluxControl.Agent;

public class UserSessionData
{
    public string id { get; set; } = string.Empty;
    public string name { get; set; } = string.Empty;
    public string email { get; set; } = string.Empty;
    public string picture { get; set; } = string.Empty;
    public string role { get; set; } = "user";
    public long? subscriptionExpiresAt { get; set; } = null;
}

public partial class MainWindow : Window
{
    [DllImport("user32.dll")]
    public static extern bool ReleaseCapture();

    [DllImport("user32.dll")]
    public static extern IntPtr SendMessage(IntPtr hWnd, int Msg, IntPtr wParam, IntPtr lParam);

    private const int WM_NCLBUTTONDOWN = 0xA1;
    private const int HTCAPTION = 0x2;

    // ---- Window corner rounding (opaque window; OS draws the corners) ----
    [DllImport("dwmapi.dll")]
    private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int value, int size);

    private const int DWMWA_USE_IMMERSIVE_DARK_MODE = 20;
    private const int DWMWA_BORDER_COLOR = 34;
    private const int DWMWA_WINDOW_CORNER_PREFERENCE = 33;
    private const int DWMWCP_ROUND = 2;          // preference value, not attribute
    private const int DWMWA_COLOR_NONE = unchecked((int)0xFFFFFFFE); // default system border

    [DllImport("gdi32.dll")]
    private static extern IntPtr CreateRoundRectRgn(int x1, int y1, int x2, int y2, int w, int h);

    [DllImport("user32.dll")]
    private static extern int SetWindowRgn(IntPtr hWnd, IntPtr hRgn, bool bRedraw);

    private bool _regionApplied;                 // Win10 fallback state
    private static readonly bool IsWin11OrNewer = Environment.OSVersion.Version.Build >= 22000;

    private readonly SystemService _systemService;
    private readonly InputService _inputService;
    private readonly ProcessManagerService _processService;
    private readonly FileManagerService _fileService;
    private readonly MediaService _mediaService;
    private readonly PairingService _pairingService;
    private readonly WebSocketServerService _serverService;
    private readonly RelayClientService _relayService;
    // «Пряме з'єднання» (ТЗ 49): канал повз релей — стрим/файли/звук не їдять
    // трафік хмарного сервера. Реєструється і запускається у конструкторі нижче.
    private readonly DirectLinkService _directLink = new();
    private readonly WinLockService _winLockService;

    private readonly NotifyIcon _notifyIcon;
    private System.Drawing.Icon? _appIcon;
    private bool _minimizeToTray = true;
    private bool _isExplicitExit = false;
    private bool _startedMinimized;   // запуск із --minimized (автозапуск Windows)
    private bool _headless;           // запуск із --hidden (сторож): без трея і вікон взагалі
    private bool _forcedLaunch;       // «Примусовий запуск програми» (ТЗ 46)
    private bool _startupHideDone;    // невидима фаза запуску завершена
    private readonly Dictionary<string, PairingRequest> _pendingRequests = new();

    // Єдине джерело правди про налаштування (settings.json у %AppData%\FluxControl):
    // без нього вимкнений автозапуск вмикався знову при кожному старті,
    // а «згортати в трей» взагалі не зберігався (лише в пам'яті).
    private readonly Services.SettingsService _settings = new();

    private readonly string _userSessionFilePath;
    private UserSessionData? _currentUser;
    private static readonly HttpClient _authHttpClient = new() { Timeout = TimeSpan.FromSeconds(5) };
    private DispatcherTimer? _metricsTimer;
    private DispatcherTimer? _subscriptionTimer;

    // Startup dependency + speedtest state surfaced to the embedded UI
    private string _ffmpegStatus = "checking"; // checking | ready | missing | installing | error
    private string _ffmpegStage = "перевірка…";
    private int _ffmpegPercent;
    private long _ffmpegReceived;   // живі байти завантаження (для UI установщика)
    private long? _ffmpegTotal;     // загальний розмір архіву, якщо сервер віддав
    private string? _ffmpegError;
    private bool _dependencyPipelineStarted;
    private bool _overlayHidden;

    // Кэш метрик (ТЗ «загрузка без лагов»): GetMetrics — тяжёлый (счётчики,
    // WMI-запросы, перебор дисков), его нельзя звать на UI-потоке каждый тик.
    // Фоновый цикл считает метрики, UI-поток лишь берёт готовый снапшот.
    private SystemMetricsDto? _lastMetrics;
    private int _metricsBusy;
    // QR generation is expensive (bitmap render + base64). It only depends on
    // the connect URL, so cache it instead of rebuilding every state tick.
    private string _cachedQrBase64 = string.Empty;
    private string _cachedQrUrl = string.Empty;

    public MainWindow()
    {
        App.Log("MainWindow constructor entering...");
        InitializeComponent();
        App.Log("InitializeComponent passed.");

        _systemService = new SystemService();
        _inputService = new InputService();
        _processService = new ProcessManagerService();
        _fileService = new FileManagerService();
        _mediaService = new MediaService();
        _pairingService = new PairingService();
        App.Log("Services instantiated.");

        var appData = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FluxControl");
        Directory.CreateDirectory(appData);
        _userSessionFilePath = Path.Combine(appData, "user_session.json");
        LoadUserSession();

        _serverService = new WebSocketServerService(
            _pairingService,
            _systemService,
            _inputService,
            _processService,
            _fileService,
            _mediaService,
            5080
        );

        _relayService = new RelayClientService(
            _pairingService,
            _systemService,
            _inputService,
            _processService,
            _fileService,
            _mediaService,
            "https://fluxcontrol-backend-bl3u.onrender.com"
        );
        _relayService.OnConnectionStatusChanged += (isConnected) =>
        {
            Dispatcher.Invoke(SendStateToWebView);
        };
        _relayService.OnStateChanged += (status, err) =>
        {
            try
            {
                var s = status?.ToLowerInvariant() ?? "";
                if (s.Contains("connect") && !s.Contains("error")) ActivityLogger.Log("RELAY", "Хмарну службу підключено");
                else if (s.Contains("error")) ActivityLogger.Log("RELAY", "З'єднання з хмарною службою втрачено", err);
            }
            catch { }
            Dispatcher.Invoke(SendStateToWebView);
        };
        _relayService.SpeedTest.OnResult += (result) =>
        {
            try { Dispatcher.Invoke(SendStateToWebView); } catch { }
        };

        // «Пряме з'єднання» (ТЗ 49): шлюз віддає панельні сокети релей-клієнту
        // (той перевіряє code+key), релей-клієнт отримує посилання на сервіс —
        // щоб реєструвати публічний URL на сервері після кожного реконекту.
        _directLink.PanelAttach = (ws, code, key) => _relayService.AttachDirectPanelAsync(ws, code, key);
        _relayService.DirectLink = _directLink;
        _directLink.Start();
        _winLockService = new WinLockService();
        _relayService.SetWinLockService(_winLockService);
        _relayService.Start();

        // System tray setup — фирменная иконка из внедрённого ресурса logo.ico
        _appIcon = LoadAppIcon();
        _notifyIcon = new NotifyIcon
        {
            Icon = _appIcon ?? SystemIcons.Shield,
            Text = "FluxControl",
            // --hidden (сторож перезапустив агента після «закриття»): програма
            // ПОВИННА працювати невидимо — без іконки в треї (ТЗ 46).
            Visible = !_headless
        };

        // Фірмове меню трея v2 (ТЗ): мінімалізм — лише Відкрити, Скопіювати
        // код підключення та Вихід; БЕЗ «Перевірити оновлення», БЕЗ автозапуску
        // (він у Налаштуваннях) і БЕЗ рядка версії. Скруглення + fade-анимація
        // + іконки + фірмовий шрифт — усе в Services/TrayTheme.cs.
        var contextMenu = new TrayDropDown
        {
            Font = TrayTheme.MenuFont
        };
        contextMenu.Items.Add(new TrayBrandItem());
        contextMenu.Items.Add(new ToolStripSeparator());
        contextMenu.Items.Add(new ToolStripMenuItem("Відкрити", TrayIcons.Open(), (s, e) => ShowAndActivate()));
        contextMenu.Items.Add(new ToolStripMenuItem("Скопіювати код підключення", TrayIcons.Copy(), (s, e) => CopyConnectCode()));
        contextMenu.Items.Add(new ToolStripSeparator());
        var exitItem = new ToolStripMenuItem("Вихід", TrayIcons.Exit(), (s, e) => ExitFromTray())
        {
            Tag = "danger"
        };
        contextMenu.Items.Add(exitItem);
        _notifyIcon.ContextMenuStrip = contextMenu;
        _notifyIcon.DoubleClick += (s, e) => ShowAndActivate();

        // Запуск з --minimized (автозапуск Windows або інсталятор): вікно має
        // бути ПОВНІСТЮ невидимим — тільки іконка в треї, нічого на панелі
        // завдань, без перехоплення фокуса. StartupUri більше немає, тож нічого
        // не покаже вікно поверх цього. Одноразовий "показ" із Opacity=0 потрібен,
        // бо весь стартовий пайплайн (WebView2, WebSocket 5080, релей) живе в
        // Loaded — він відпрацює, поки вікно прозоре.
        var args = Environment.GetCommandLineArgs();
        _startedMinimized = args.Any(a =>
            a.Equals("--minimized", StringComparison.OrdinalIgnoreCase) ||
            a.Equals("--hidden", StringComparison.OrdinalIgnoreCase) ||
            a.Equals("--background", StringComparison.OrdinalIgnoreCase) ||
            a.Equals("--silent", StringComparison.OrdinalIgnoreCase) ||
            a.Equals("/minimized", StringComparison.OrdinalIgnoreCase));
        // --hidden = ПОВНИЙ НЕВИДИМИЙ режим (сторож перезапустив програму):
        // жодного трея/кульок/вікон — тільки робочий процес із релеєм (ТЗ 46).
        _headless = args.Any(a => a.Equals("--hidden", StringComparison.OrdinalIgnoreCase));
        if (_startedMinimized)
        {
            ShowActivated = false;          // не крадемо фокус при вході в Windows
            ShowInTaskbar = false;          // жодної кнопки на панелі завдань
            Opacity = 0d;                   // невидимо навіть один кадр
            WindowState = WindowState.Minimized;
        }

        // Налаштування (settings.json) — джерело правди: синхронізуємо реєстр
        // зі ЗБЕРЕЖЕНИМ вибором користувача. EnsureFirstRunAutoRun (вмикав
        // автозапуск заново, бо реєстр порожній) — лише на САМОМУ першому
        // запуску, поки файлу налаштувань ще не існує.
        if (_settings.LoadedFromFile)
        {
            AutoRunService.SetAutoRun(_settings.Settings.AutoRun);
            _minimizeToTray = _settings.Settings.MinimizeToTray;
            _forcedLaunch = _settings.Settings.ForcedLaunch;
            _autoUpdate = _settings.Settings.AutoUpdate;
            App.Log($"Settings loaded from file: AutoRun={_settings.Settings.AutoRun}, MinimizeToTray={_settings.Settings.MinimizeToTray}, ForcedLaunch={_settings.Settings.ForcedLaunch}, AutoUpdate={_settings.Settings.AutoUpdate}");
        }
        else
        {
            AutoRunService.EnsureFirstRunAutoRun();
            PersistSettings(); // одразу створюємо settings.json з поточним станом
        }

        // Сторож «примусового запуску» (ТЗ 46): свіжий старт — stop-файл
        // неактуальний; функція увімкнена → тримаємо живого сторожа.
        try
        {
            Services.WatchdogService.ClearStopFile();
            if (_forcedLaunch)
                Services.WatchdogService.EnsureStarted(Environment.ProcessId);
        }
        catch { }

        // Релей вмикає/вимикає «примусовий запуск» з сайту: зберігаємо
        // налаштування і керуємо сторожем тут, у UI-потоку.
        _relayService.ForcedLaunchChanged = enabled =>
        {
            _forcedLaunch = enabled;
            try
            {
                if (enabled) Services.WatchdogService.EnsureStarted(Environment.ProcessId);
                else Services.WatchdogService.Stop();
            }
            catch { }
            PersistSettings();
            ActivityLogger.Log("SETTINGS", enabled ? "Примусовий запуск програми УВІМКНЕНО" : "Примусовий запуск програми вимкнено");
        };

        // Re-engage WinLock if the PC rebooted while locked (also fires with --minimized).
        _winLockService.TryRestoreOnStartup();

        // Re-arm (or execute) a power timer that was pending before the app exited.
        _relayService.ScheduledActions.TryRestore();

        // OS-level window chrome. The window is OPAQUE (#05050A); its corners
        // are rounded by the operating system: DWMWCP_ROUND on Windows 11
        // (anti-aliased, with the native shadow) or a GDI round region as the
        // Windows 10 fallback. No transparency is involved anywhere, so the
        // WebView2 HWND keeps normal mouse input and no «острые прозрачные
        // штуки» can appear — the page never draws window chrome itself.
        SourceInitialized += (s, e) =>
        {
            try
            {
                ApplyOsWindowRounding();
                CenterWindowOnScreen();
                PostChromeState();
            }
            catch { }
        };

        // ФІКС чорного екрана: після відновлення вікна з трея (IsVisible
        // false → true) WebView2 може лишитися неперемальованим. «Блим»
        // видимістю контрола змушує HwndHost перерендеритись.
        IsVisibleChanged += (s, e) =>
        {
            try
            {
                if (e.NewValue is bool v && v) NudgeWebViewAfterShow();
            }
            catch { }
        };

        // Maximized state changes corner handling: DWM un-rounds maximized
        // windows by itself; the Win10 region must be removed/re-applied here.
        StateChanged += (s, e) =>
        {
            if (!IsWin11OrNewer) ApplyOrClearWin10Region();
            PostChromeState();
        };
        // One precise re-center once the real content size is known — fixes the
        // «окно чуть правее центра» на масштабах DPI, где встроенное центрирование
        // WPF считает позицию по устаревшим значениям.
        bool centeredOnce = false;
        ContentRendered += (s, e) =>
        {
            if (!centeredOnce)
            {
                centeredOnce = true;
                CenterWindowOnScreen();
            }
        };

        // Pairing events
        _pairingService.OnPairingRequested += (request) =>
        {
            Dispatcher.Invoke(() =>
            {
                _pendingRequests[request.RequestId] = request;
                if (!IsVisible)
                {
                    _notifyIcon.ShowBalloonTip(5000, "FluxControl", $"Запит на підключення від {request.DeviceName}", ToolTipIcon.Info);
                }
                PostJsonToWebView(new
                {
                    type = "pairing_request",
                    requestId = request.RequestId,
                    deviceName = request.DeviceName,
                    ip = request.IpAddress
                });
            });
        };

        _pairingService.OnClientsChanged += () =>
        {
            Dispatcher.Invoke(SendStateToWebView);
        };

        Loaded += MainWindow_Loaded;
    }

    /// <summary>
    /// Windows notification policy: ЛИБО всплывашка внутри программы (когда
    /// окно видно и активно — рисует WebView-тост), ЛИБО уведомление Windows
    /// (когда окно скрыто/свёрнуто/неактивно). Никогда оба сразу.
    /// </summary>
    private bool UserCanSeeWindow()
    {
        return IsVisible && WindowState != WindowState.Minimized && IsActive;
    }

    private void NotifyWindowsOnly(string title, string message)
    {
        try { _notifyIcon.ShowBalloonTip(2600, title, message, ToolTipIcon.Info); } catch { }
    }

    /// <summary>Балун только если пользователь сейчас НЕ смотрит на окно.
    /// ПОТОКОБЕЗОПАСНО (ТЗ-фікс хибної помилки «The calling thread cannot access
    /// this object»): викликається з фонових потоків (установка FFmpeg тощо),
    /// тому читання IsVisible/IsActive та балун трея мусять іти через диспетчер.
    /// Ніколи не кидає винятків — сповіщення не може зламати бізнес-потік.</summary>
    private void NotifySmart(string title, string message)
    {
        try
        {
            if (!Dispatcher.CheckAccess())
            {
                _ = Dispatcher.InvokeAsync(() => NotifySmart(title, message));
                return;
            }
            if (!UserCanSeeWindow()) NotifyWindowsOnly(title, message);
        }
        catch { }
    }

    private System.Drawing.Icon? LoadAppIcon()
    {
        try
        {
            var sri = System.Windows.Application.GetResourceStream(new Uri("pack://application:,,,/logo.ico"));
            if (sri != null) return new System.Drawing.Icon(sri.Stream);
        }
        catch { }
        return null;
    }

    /// <summary>
    /// Round the window corners using the OS. Win11+: DWM native rounding
    /// (anti-aliased, no artifacts, native shadow). Win10: GDI round region
    /// with a DPI-scaled radius. The window stays opaque in both cases.
    /// </summary>
    private void ApplyOsWindowRounding()
    {
        var hwnd = new WindowInteropHelper(this).Handle;
        if (hwnd == IntPtr.Zero) return;

        try
        {
            int dark = 1;
            DwmSetWindowAttribute(hwnd, DWMWA_USE_IMMERSIVE_DARK_MODE, ref dark, sizeof(int));
        }
        catch { }

        if (IsWin11OrNewer)
        {
            try
            {
                int pref = DWMWCP_ROUND;
                DwmSetWindowAttribute(hwnd, DWMWA_WINDOW_CORNER_PREFERENCE, ref pref, sizeof(int));
                // Subtle dark violet border (COLORREF 0x00BBGGRR = #251A38 RGB).
                int borderColor = 0x00381A25;
                DwmSetWindowAttribute(hwnd, DWMWA_BORDER_COLOR, ref borderColor, sizeof(int));
            }
            catch { }
        }
        else
        {
            ApplyOrClearWin10Region();
        }
    }

    /// <summary>Win10 fallback: GDI rounded region, re-applied on size changes.
    /// Removed while maximized/minimized so the full screen area is used.</summary>
    private void ApplyOrClearWin10Region()
    {
        try
        {
            var hwnd = new WindowInteropHelper(this).Handle;
            if (hwnd == IntPtr.Zero) return;

            if (WindowState != WindowState.Normal)
            {
                if (_regionApplied)
                {
                    SetWindowRgn(hwnd, IntPtr.Zero, true);
                    _regionApplied = false;
                }
                return;
            }

            var source = PresentationSource.FromVisual(this);
            double dpi = source?.CompositionTarget?.TransformToDevice.M11 ?? 1.0;
            if (double.IsNaN(dpi) || dpi <= 0) dpi = 1.0;

            int w = (int)Math.Ceiling(ActualWidth > 0 ? ActualWidth * dpi : Width * dpi);
            int h = (int)Math.Ceiling(ActualHeight > 0 ? ActualHeight * dpi : Height * dpi);
            if (w <= 0 || h <= 0) return;

            int r = (int)Math.Round(14 * dpi);
            var rgn = CreateRoundRectRgn(0, 0, w + 1, h + 1, r, r);
            SetWindowRgn(hwnd, rgn, true);
            _regionApplied = true;
        }
        catch { }
    }

    /// <summary>DPI-точное центрирование окна на рабочей области монитора.</summary>
    private void CenterWindowOnScreen()
    {
        try
        {
            if (WindowState != WindowState.Normal) return;
            var hwnd = new WindowInteropHelper(this).Handle;
            if (hwnd == IntPtr.Zero) return;

            var source = PresentationSource.FromVisual(this);
            double dpi = source?.CompositionTarget?.TransformToDevice.M11 ?? 1.0;
            if (double.IsNaN(dpi) || dpi <= 0) dpi = 1.0;

            var area = System.Windows.Forms.Screen.FromHandle(hwnd).WorkingArea; // device px
            double w = ActualWidth > 0 ? ActualWidth : Width;
            double h = ActualHeight > 0 ? ActualHeight : Height;
            if (w <= 0 || h <= 0) return;

            double devW = w * dpi, devH = h * dpi;
            double devLeft = area.Left + (area.Width - devW) / 2.0;
            double devTop = area.Top + (area.Height - devH) / 2.0;

            Left = devLeft / dpi;
            Top = devTop / dpi;
        }
        catch { }
    }

    private void LoadUserSession()
    {
        try
        {
            string? json = null;
            if (File.Exists(_userSessionFilePath))
            {
                json = File.ReadAllText(_userSessionFilePath);
            }

            if (string.IsNullOrWhiteSpace(json))
            {
                try
                {
                    using var reg = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(@"Software\FluxControl");
                    json = reg?.GetValue("UserSession")?.ToString();
                    if (!string.IsNullOrWhiteSpace(json))
                    {
                        File.WriteAllText(_userSessionFilePath, json);
                    }
                }
                catch { }
            }

            if (!string.IsNullOrWhiteSpace(json))
            {
                _currentUser = JsonSerializer.Deserialize<UserSessionData>(json);
            }
        }
        catch { }
    }

    private void SaveUserSession(UserSessionData user)
    {
        try
        {
            _currentUser = user;
            var json = JsonSerializer.Serialize(user, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(_userSessionFilePath, json);
            try
            {
                using var reg = Microsoft.Win32.Registry.CurrentUser.CreateSubKey(@"Software\FluxControl");
                reg?.SetValue("UserSession", json);
            }
            catch { }
        }
        catch { }
    }

    private static string? FindEdgeWebViewRuntimePath()
    {
        try
        {
            var localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            var userEdgeDir = Path.Combine(localAppData, "Microsoft", "EdgeWebView", "Application");
            if (Directory.Exists(userEdgeDir))
            {
                var versionDirs = Directory.GetDirectories(userEdgeDir)
                    .Where(d => File.Exists(Path.Combine(d, "msedgewebview2.exe")))
                    .OrderByDescending(d => Path.GetFileName(d))
                    .ToList();
                if (versionDirs.Count > 0)
                {
                    return versionDirs[0];
                }
            }
        }
        catch { }
        return null;
    }

    private async void MainWindow_Loaded(object sender, RoutedEventArgs e)
    {
        App.Log("MainWindow_Loaded triggered.");

        // ПЕРШИЙ крок прогресу — запускає плавний безперервний хід відсотків
        // (ТЗ: «щоб доходило до 100% плавно, без застрягання і стрибків»).
        SetLoadingStep("Запуск програми…", 6);

        // ТЗ: «після того, як екран загрузки зникає, все має бути вже загружено».
        // Preflight рахує перші метрики у фоновому потоці та підтверджує сесію
        // акаунта — сплеш не зникне, поки це не завершиться (з таймаутами).
        _startupPreflight = RunStartupPreflightAsync();

        if (_startedMinimized)
        {
            // Усі сервіси ініціалізуються в цьому обробнику; коли пайплайн
            // рендера добіг кінця (пріоритет ApplicationIdle) — ховаємо вікно
            // в трей назавжди, користувач нічого не побачив.
            // DispatcherOperation в .NET 8 awaitable — без явного discard це CS4014
            _ = Dispatcher.BeginInvoke(DispatcherPriority.ApplicationIdle, new Action(FinishStartupToTray));
        }
        try
        {
            App.Log("Initializing WebView2...");
            string? browserPath = FindEdgeWebViewRuntimePath();

            // Graceful-перевірка (bootstrap зазвичай встановлює WebView2 заздалегідь,
            // але якщо його знесли/блокує адмін — показуємо діалог з посиланням,
            // замість тихої аварії при CreateAsync).
            if (browserPath == null)
            {
                try { Microsoft.Web.WebView2.Core.CoreWebView2Environment.GetAvailableBrowserVersionString(); }
                catch (Exception notFound)
                {
                    App.Log($"WebView2 runtime missing: {notFound.Message}");
                    var choice = System.Windows.MessageBox.Show(
                        this,
                        "На цьому комп'ютері не знайдено Microsoft WebView2 Runtime — він потрібен для інтерфейсу FluxControl.\r\n\r\n" +
                        "Завантажити та встановити його зараз з офіційного сайту Microsoft?",
                        "FluxControl — WebView2", System.Windows.MessageBoxButton.YesNo, System.Windows.MessageBoxImage.Warning);
                    if (choice == System.Windows.MessageBoxResult.Yes)
                    {
                        try
                        {
                            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(
                                "https://go.microsoft.com/fwlink/?linkid=2099617") { UseShellExecute = true });
                        }
                        catch { }
                        System.Windows.MessageBox.Show(
                            this,
                            "Після встановлення WebView2 запусти FluxControl ще раз.",
                            "FluxControl", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Information);
                    }
                    System.Windows.Application.Current.Shutdown();
                    return;
                }
            }

            string userDataDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "FluxControl", "WebView2");
            Directory.CreateDirectory(userDataDir);
            App.Log($"Using WebView2 runtime: {browserPath ?? "Default"}, UserData: {userDataDir}");
            var env = await Microsoft.Web.WebView2.Core.CoreWebView2Environment.CreateAsync(browserPath, userDataDir);
            await webView.EnsureCoreWebView2Async(env);
            // Непрозорий фон, точно в колір вікна: сторінка малює контент
            // edge-to-edge, а кути скруглює сама ОС (DWM/регіон).
            // Transparent here is FORBIDDEN: layered-window composition
            // breaks WebView2 input and shows «sharp transparent» artifacts.
            webView.DefaultBackgroundColor = System.Drawing.Color.FromArgb(0xFF, 0x05, 0x05, 0x0A);
            App.Log("WebView2 initialized successfully.");
            SetLoadingStep("Інтерфейс завантажено", 28);

            webView.CoreWebView2.Settings.IsZoomControlEnabled = false;
            webView.CoreWebView2.Settings.AreDevToolsEnabled = false;

            // Іконка вікна (панель задач / Alt-Tab) — той самий бренд-знак.
            try
            {
                var wicSri = System.Windows.Application.GetResourceStream(new Uri("pack://application:,,,/logo.ico"));
                if (wicSri != null) Icon = System.Windows.Media.Imaging.BitmapFrame.Create(wicSri.Stream);
            }
            catch { }

            webView.CoreWebView2.WebMessageReceived += CoreWebView2_WebMessageReceived;

            var hostedUrl = "https://fluxcontrol.pages.dev/agent-ui";
            // Локальний agent_ui.html — ОСНОВНЕ ДЖЕРЕЛО інтерфейсу (архітектура v4):
            // він вбудований в exe, витягується у %AppData%\FluxControl і оновлюється
            // по манифесту version.json (sha256). Лише він вміє показувати блокуючий
            // екран оновлення і приймати всі state-повідомлення хоста — хостед-сторінка
            // pages.dev обробляє лише pairing/chrome, через що з нею перевірка
            // оновлень виглядала «непрацюючою». Хостед лишається фолбеком.
            var localHtmlPath = Services.RuntimeFiles.UiHtmlPath;
            var uiFallbackTried = false;

            webView.NavigationCompleted += (s, ev) =>
            {
                App.Log($"WebView2 navigation completed: {ev.IsSuccess} -> {webView.Source}");
                if (!ev.IsSuccess && !uiFallbackTried)
                {
                    // один фолбек у будь-який бік: локальний не відкрився -> хостед,
                    // хостед не відкрився -> локальний. Другого фолбеку немає (без циклів).
                    uiFallbackTried = true;
                    var isLocal = string.Equals(webView.Source?.LocalPath, localHtmlPath, StringComparison.OrdinalIgnoreCase);
                    App.Log(isLocal ? "Local agent_ui.html failed — falling back to hosted UI" : "Hosted UI failed — falling back to local agent_ui.html");
                    webView.CoreWebView2.Navigate(isLocal ? hostedUrl : localHtmlPath);
                    return;
                }
                Dispatcher.Invoke(SendStateToWebView);
                SetLoadingStep("Інтерфейс готовий", 62);
                _ = Task.Delay(350).ContinueWith(_ => Dispatcher.Invoke(SendStateToWebView));
                _ = Task.Delay(120).ContinueWith(_ => Dispatcher.Invoke(PostChromeState));
                // The embedded browser finished rendering — the loading screen
                // can step aside AFTER the preflight (metrics + auth) finishes,
                // so the user never sees the UI «догружающимся».
                _ = Task.Delay(400).ContinueWith(_ => Dispatcher.Invoke(HideLoadingOverlayWhenReady));
            };

            // Navigate to the local UI (primary) with hosted fallback
            try
            {
                webView.CoreWebView2.Navigate(localHtmlPath);
            }
            catch
            {
                webView.CoreWebView2.Navigate(hostedUrl);
            }

            // Absolute safety: never trap the user behind the splash.
            // 30с: гейт підключень (релей до 20с + тунель до 9с) має встигнути
            // відпрацювати ще НА сплеші; далі — у будь-якому разі показуємо UI,
            // а залишкові підключення завершуються у фоні.
            var overlaySafety = new DispatcherTimer { Interval = TimeSpan.FromSeconds(30) };
            overlaySafety.Tick += (s, ev) => { HideLoadingOverlay(); overlaySafety.Stop(); };
            overlaySafety.Start();

            // Startup pipeline: dependency checks (FFmpeg) then the automatic
            // internet speed measurement requested for every program start.
            _ = RunStartupPipelineAsync();

            // ТЗ: перевірка оновлень ЩЕ на екрані завантаження — паралельно з
            // ініціалізацією WebView2, ДО появи головного GUI. Якщо є нова
            // версія — блокуючий екран з'явиться одразу після загрузки.
            try { LoadingVersionText.Text = "v" + UpdateService.GetLocalVersion(); } catch { }
            _ = CheckForUpdatesOnStartupAsync();

            // ТЗ: оновлення має помітитися ОДРАЗУ, а не «спустя 5 мин» —
            // манифест читається з офіційного сайту (без кеша), тихий опитувач
            // кожні 60 секунд поки програма працює.
            _updatePollTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(60) };
            _updatePollTimer.Tick += (s, ev) => { _ = PollForUpdatesAsync(); };
            _updatePollTimer.Start();

            // Периодические живые телеметрические обновления. Сам расчёт метрик
            // идёт в фоне (Task.Run) — UI-поток только отправляет готовый снапшот:
            // тяжёлые счётчики/WMI больше не «дёргают» загрузку и анимации.
            _metricsTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
            _metricsTimer.Tick += (s, ev) => RefreshMetricsInBackground();
            _metricsTimer.Start();

            // Auto-refresh account / subscription status from the server every 20s
            _subscriptionTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(20) };
            _subscriptionTimer.Tick += (s, ev) => { _ = CheckUserSubscriptionAsync(silent: true); };
            _subscriptionTimer.Start();
            if (_currentUser != null) _ = CheckUserSubscriptionAsync(silent: true);

            App.Log("Starting WebSocket server in background...");
            _ = Task.Run(async () =>
            {
                try
                {
                    await _serverService.StartAsync();
                    App.Log("WebSocket server started on port 5080.");
                    SetLoadingStep("Служба запущена", 72);
                }
                catch (Exception ex)
                {
                    App.Log($"[WARN] WebSocket server start error: {ex.Message}");
                }
            });
        }
        catch (Exception ex)
        {
            App.Log($"[ERROR] in MainWindow_Loaded: {ex}");
            System.Windows.MessageBox.Show($"Помилка запуску: {ex.Message}", "FluxControl", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void CoreWebView2_WebMessageReceived(object? sender, Microsoft.Web.WebView2.Core.CoreWebView2WebMessageReceivedEventArgs e)
    {
        try
        {
            var jsonStr = e.WebMessageAsJson;
            var msg = JsonSerializer.Deserialize<JsonObject>(jsonStr);
            if (msg == null) return;

            var type = msg["type"]?.GetValue<string>() ?? "";

            switch (type)
            {
                case "ready":
                    SendStateToWebView();
                    // Сторінка надіслала ready ПІСЛЯ першої відрисовки (подвійний
                    // rAF у UI) — можна плавно прибрати екран завантаження без
                    // «сірого» проміжку, але ЛИШЕ після preflight (метрики+акаунт).
                    if (!_overlayHidden)
                        _ = Task.Delay(250).ContinueWith(_ => Dispatcher.Invoke(HideLoadingOverlayWhenReady));
                    // після перезавантаження сторінки блокуючий екран оновлення
                    // має з'явитися знову, якщо оновлення ще не встановлене
                    if (_pendingUpdate != null) SendUpdateAvailableToWebView();
                    break;

                case "install_update":
                    ActivityLogger.Log("UPDATE", "Встановлення оновлення розпочато (з UI)");
                    _ = InstallUpdateFromUiAsync();
                    break;

                // ТЗ: «вкладка Оновлення» — встановлення КОНКРЕТНОЇ версії з архіву
                // versions/<v>/FluxControl.exe на сайті (відкат у т.ч.).
                case "install_version":
                    {
                        var ver = UpdateService.NormalizeVersion(msg["version"]?.GetValue<string>() ?? "");
                        ActivityLogger.Log("UPDATE", $"Встановлення версії {ver} з архіву версій (з UI)");
                        _ = InstallSpecificVersionFromUiAsync(ver);
                    }
                    break;

                case "check_updates":
                    ActivityLogger.Log("UI", "Перевірка оновлень (вручну)");
                    _ = CheckUpdatesFromUiAsync();
                    break;

                case "retry_connection":
                    ActivityLogger.Log("UI", "Повторне підключення до хмарної служби (з UI)");
                    _relayService?.ForceReconnect();
                    SendStateToWebView();
                    break;

                case "login_via_browser":
                    ActivityLogger.Log("UI", "Вхід через браузер розпочато");
                    _ = HandleLoginViaBrowserAsync();
                    break;

                case "logout":
                    ActivityLogger.Log("UI", "Вихід з акаунта", _currentUser?.email);
                    _currentUser = null;
                    try
                    {
                        if (File.Exists(_userSessionFilePath)) File.Delete(_userSessionFilePath);
                        using var reg = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(@"Software\FluxControl", true);
                        reg?.DeleteValue("UserSession", false);
                    }
                    catch { }
                    Dispatcher.Invoke(SendStateToWebView);
                    break;

                case "check_subscription":
                    _ = CheckUserSubscriptionAsync();
                    break;

                case "window_drag":
                    Dispatcher.Invoke(() =>
                    {
                        try
                        {
                            var handle = new WindowInteropHelper(this).Handle;
                            if (handle != IntPtr.Zero)
                            {
                                ReleaseCapture();
                                SendMessage(handle, WM_NCLBUTTONDOWN, (IntPtr)HTCAPTION, IntPtr.Zero);
                            }
                        }
                        catch { }
                    });
                    break;

                case "window_maximize":
                    Dispatcher.Invoke(ToggleMaximize);
                    break;

                case "window_minimize":
                    Dispatcher.Invoke(() => WindowState = WindowState.Minimized);
                    break;

                case "window_close":
                    Dispatcher.Invoke(ApplyCloseAction);
                    break;

                case "regenerate_code":
                    ActivityLogger.Log("UI", "Код підключення оновлено (старий код/QR недійсні)");
                    _pairingService.RegenerateCode();
                    Dispatcher.Invoke(SendStateToWebView);
                    break;

                case "copy_link":
                    CopyWebLink();
                    break;

                case "respond_pairing":
                    var reqId = msg["requestId"]?.GetValue<string>() ?? "";
                    var allow = msg["allow"]?.GetValue<bool>() ?? false;
                    ActivityLogger.Log("REMOTE", allow ? "Запит підключення пристрою ДОЗВОЛЕНО" : "Запит підключення пристрою відхилено", reqId);
                    if (_pendingRequests.Remove(reqId, out var req))
                    {
                        req.CompletionSource.TrySetResult(allow);
                    }
                    break;

                case "set_autorun":
                    var auto = msg["enable"]?.GetValue<bool>() ?? false;
                    AutoRunService.SetAutoRun(auto);
                    PersistSettings();
                    ActivityLogger.Log("SETTINGS", auto ? "Автозапуск із Windows увімкнено" : "Автозапуск із Windows вимкнено");
                    SendStateToWebView();
                    break;

                case "set_tray":
                    _minimizeToTray = msg["enable"]?.GetValue<bool>() ?? true;
                    PersistSettings();
                    ActivityLogger.Log("SETTINGS", _minimizeToTray ? "Згортання в системний трей увімкнено" : "Згортання в системний трей вимкнено");
                    break;

                case "set_autoupdate":
                    _autoUpdate = msg["enable"]?.GetValue<bool>() ?? true;
                    PersistSettings();
                    SendStateToWebView();
                    ActivityLogger.Log("SETTINGS", _autoUpdate ? "Автооновлення увімкнено" : "Автооновлення вимкнено");
                    break;

                case "revoke_client":
                    var connId = msg["connectionId"]?.GetValue<string>();
                    if (!string.IsNullOrEmpty(connId))
                    {
                        ActivityLogger.Log("REMOTE", "Пристрій відключено (revoke)", connId);
                        _pairingService.RegisterClientDisconnected(connId);
                    }
                    break;

                case "install_ffmpeg":
                    ActivityLogger.Log("UI", "Встановлення FFmpeg розпочато");
                    _ = InstallFfmpegAsync();
                    break;

                case "retry_dependency_check":
                    CheckFfmpegDependency();
                    Dispatcher.Invoke(SendStateToWebView);
                    break;

                case "run_speedtest":
                    ActivityLogger.Log("UI", "Перевірка швидкості інтернету запущена");
                    _ = Task.Run(() => _relayService.SpeedTest.RunAsync());
                    break;
            }
        }
        catch (Exception ex)
        {
            Debug.WriteLine($"WebMessage error: {ex.Message}");
        }
    }

    private async Task CheckUserSubscriptionAsync(bool silent = false)
    {
        if (_currentUser == null || string.IsNullOrEmpty(_currentUser.id)) return;
        var prevExpiry = _currentUser.subscriptionExpiresAt;
        var prevRole = _currentUser.role;
        try
        {
            var payload = new { user = new { id = _currentUser.id, email = _currentUser.email } };
            var json = JsonSerializer.Serialize(payload);
            using var content = new StringContent(json, Encoding.UTF8, "application/json");

            HttpResponseMessage? res = null;
            try
            {
                res = await _authHttpClient.PostAsync("https://fluxcontrol.pages.dev/api/auth/profile", content);
            }
            catch { }

            if (res == null || !res.IsSuccessStatusCode)
            {
                res = await _authHttpClient.PostAsync("https://fluxcontrol-backend-bl3u.onrender.com/api/auth/profile", content);
            }

            if (res != null && res.IsSuccessStatusCode)
            {
                var respStr = await res.Content.ReadAsStringAsync();
                var doc = JsonDocument.Parse(respStr);
                if (doc.RootElement.TryGetProperty("user", out var userEl))
                {
                    var updatedUser = JsonSerializer.Deserialize<UserSessionData>(userEl.GetRawText());
                    if (updatedUser != null)
                    {
                        SaveUserSession(updatedUser);
                        Dispatcher.Invoke(SendStateToWebView);
                        if (!silent || updatedUser.subscriptionExpiresAt != prevExpiry || updatedUser.role != prevRole)
                        {
                            // Дубля немає: якщо окно видно — вбудований тост малює сторінка;
                            // балун летит только когда окно скрыто/свёрнуто/неактивно.
                            NotifySmart("FluxControl", "Статус підписки оновлено!");
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            App.Log($"[SUB] Check error: {ex.Message}");
        }
    }

    private async Task HandleLoginViaBrowserAsync()
    {
        try
        {
            var payload = new
            {
                computerName = Environment.MachineName,
                hwid = _pairingService.HardwareId,
                code = _pairingService.DeviceCode
            };
            var json = JsonSerializer.Serialize(payload);
            using var content = new StringContent(json, Encoding.UTF8, "application/json");

            HttpResponseMessage? res = null;
            try
            {
                res = await _authHttpClient.PostAsync("https://fluxcontrol.pages.dev/api/auth/device-session/create", content);
            }
            catch { }

            if (res == null || !res.IsSuccessStatusCode)
            {
                res = await _authHttpClient.PostAsync("https://fluxcontrol-backend-bl3u.onrender.com/api/auth/device-session/create", content);
            }

            if (res != null && res.IsSuccessStatusCode)
            {
                var respStr = await res.Content.ReadAsStringAsync();
                var doc = JsonDocument.Parse(respStr);
                if (doc.RootElement.TryGetProperty("token", out var tokenProp) &&
                    doc.RootElement.TryGetProperty("authUrl", out var authUrlProp))
                {
                    string token = tokenProp.GetString() ?? "";
                    string authUrl = authUrlProp.GetString() ?? "";

                    if (!string.IsNullOrEmpty(authUrl))
                    {
                        Process.Start(new ProcessStartInfo(authUrl) { UseShellExecute = true });
                        _ = PollAuthSessionAsync(token);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            App.Log($"[AUTH] HandleLoginViaBrowser error: {ex.Message}");
        }
    }

    private async Task PollAuthSessionAsync(string token)
    {
        var startTime = DateTime.UtcNow;
        while (DateTime.UtcNow - startTime < TimeSpan.FromMinutes(5))
        {
            await Task.Delay(1500);
            try
            {
                HttpResponseMessage? res = null;
                try
                {
                    res = await _authHttpClient.GetAsync($"https://fluxcontrol.pages.dev/api/auth/device-session/status?token={token}");
                }
                catch { }

                if (res == null || !res.IsSuccessStatusCode)
                {
                    res = await _authHttpClient.GetAsync($"https://fluxcontrol-backend-bl3u.onrender.com/api/auth/device-session/status?token={token}");
                }

                if (res != null && res.IsSuccessStatusCode)
                {
                    var respStr = await res.Content.ReadAsStringAsync();
                    var doc = JsonDocument.Parse(respStr);
                    var status = doc.RootElement.GetProperty("status").GetString();

                    if (status == "approved" && doc.RootElement.TryGetProperty("user", out var userEl))
                    {
                        var user = JsonSerializer.Deserialize<UserSessionData>(userEl.GetRawText());
                        if (user != null)
                        {
                            SaveUserSession(user);
                            Dispatcher.Invoke(SendStateToWebView);
                            NotifySmart("FluxControl", $"Успішний вхід: {user.name} ({user.email})");
                            break;
                        }
                    }
                    else if (status == "rejected")
                    {
                        break;
                    }
                }
            }
            catch { }
        }
    }

    private string GetWebConnectUrl()
    {
        return $"https://fluxcontrol.pages.dev/device/{_pairingService.DeviceCode}";
    }

    // ================================================================
    // Startup dependency pipeline (FFmpeg) + auto speedtest
    // ================================================================

    private async Task RunStartupPipelineAsync()
    {
        if (_dependencyPipelineStarted) return;
        _dependencyPipelineStarted = true;

        SetLoadingStep("Перевірка компонентів…", 40);

        // FFmpeg-проверка может ходить по диску/PATH — выполняем её вне
        // UI-потока, чтобы загрузочный экран не «замирал» на этом шаге.
        _ = Task.Run(() =>
        {
            try { CheckFfmpegDependency(); }
            catch (Exception ex) { App.Log($"FFmpeg check failed: {ex.Message}"); }
            try { Dispatcher.Invoke(SendStateToWebView); } catch { }
        });

        // The automatic speed measurement from the task description:
        // it runs once per program start and the result is stored.
        // The relay connection already triggers one as soon as it is up —
        // only run here as a fallback when that has not produced a result.
        await Task.Delay(TimeSpan.FromSeconds(10));
        if (_relayService.SpeedTest.Last == null)
        {
            await _relayService.SpeedTest.RunAsync(auto: true);
        }
    }

    private void CheckFfmpegDependency()
    {
        // Скример-ассети: прогрів кеша у фоні (звук+фото з GitHub assets/),
        // щоб скример потім стартував миттєво і синхронно.
        ScreamerAssetsService.WarmCacheInBackground();

        if (DependencyService.IsFfmpegAvailable())
        {
            _ffmpegStatus = "ready";
            _ffmpegStage = string.Empty;
            _ffmpegPercent = 0;
            _ffmpegError = null;
            return;
        }

        _ffmpegStatus = "missing";
        _ffmpegError = null;
        // Auto-install attempt right away, exactly as requested: the program
        // downloads FFmpeg by itself, and only falls back to the manual
        // installer screen when the download is impossible.
        _ = InstallFfmpegAsync();
    }

    private async Task InstallFfmpegAsync()
    {
        if (_ffmpegStatus is "installing" or "ready") return;
        _ffmpegStatus = "installing";
        _ffmpegStage = "завантаження…";
        _ffmpegPercent = 0;
        _ffmpegReceived = 0;
        _ffmpegTotal = null;
        _ffmpegError = null;
        Dispatcher.Invoke(SendStateToWebView);

        // ТЗ-фікс хибної помилки: статус «error» ставимо ЛИШЕ коли завантаження
        // реально провалилося. Раніше NotifySmart із фонового потоку кидав
        // «The calling thread cannot access this object» — catch перезаписував
        // успішний ready на error, і юзер бачив помилку хоча FFmpeg уже стояв.
        bool success = false;
        string? installError = null;
        try
        {
            await DependencyService.EnsureFfmpegAsync(progress =>
            {
                _ffmpegStage = progress.Stage;
                _ffmpegPercent = progress.Percent;
                _ffmpegReceived = progress.BytesReceived;
                _ffmpegTotal = progress.TotalBytes;
                Dispatcher.Invoke(SendStateToWebView);
            });
            success = true;
        }
        catch (Exception ex)
        {
            installError = ex.Message;
            App.Log($"[DEPS] FFmpeg install failed: {ex.Message}");
        }

        if (success)
        {
            _ffmpegStatus = "ready";
            _ffmpegStage = string.Empty;
            _ffmpegPercent = 0;
            _ffmpegReceived = 0;
            _ffmpegTotal = null;
            _ffmpegError = null;
            NotifySmart("FluxControl", "FFmpeg встановлено — запис екрана й камери готові до роботи");
        }
        else
        {
            _ffmpegStatus = "error";
            _ffmpegStage = string.Empty;
            _ffmpegReceived = 0;
            _ffmpegTotal = null;
            _ffmpegError = $"Автоматичне встановлення не вдалося: {installError}. Повна інструкція з ручного встановлення — на сайті (кнопка нижче). Після встановлення натисніть «Перевірити ще раз».";
        }
        Dispatcher.Invoke(SendStateToWebView);
    }

    // ================================================================
    // Window chrome: loading overlay + native-style maximize
    // ================================================================

    /// <summary>Preflight-задача старту: метрики + перевірка акаунта + релей.</summary>
    private Task? _startupPreflight;

    /// <summary>
    /// ТЗ: «все, що програма загружає, має загружатися ПІД ЧАС екрана загрузки;
    /// після того, як екран зникає — все вже загружено». Рахуємо перший снапшот
    /// метрик У ФОНІ (важкий WMI/nvidia-smi), підтверджуємо сесію акаунта
    /// (інакше UI блимав «не залогінений → залогінений»), даємо релею час
    /// підключитися. З таймаутами, щоб ніколи не замкнути користувача.
    /// </summary>
    private async Task RunStartupPreflightAsync()
    {
        try { RefreshMetricsInBackground(); } catch { }
        try
        {
            if (_currentUser != null)
                await CheckUserSubscriptionAsync(silent: true);
        }
        catch { }
        // чекаємо перший снапшот метрик (макс ~6с)
        for (int i = 0; i < 60 && _lastMetrics == null; i++)
            await Task.Delay(100);

        // ТЗ: УСІ підключення виконуються ЩЕ НА ЕКРАНІ ЗАВАНТАЖЕННЯ —
        // головний екран з'являється вже з підключеною хмарною службою
        // та зареєстрованим прямим каналом, а не «інтерфейс є, а зв'язок
        // догружається». Таймаути захищають від зависання сплеша, коли
        // інтернету немає взагалі або Render «холодний» (пробудження ~30с).
        try
        {
            // Фаза 1: хмарний релей. З живих логів — зазвичай 1-3с; даємо
            // до 20с (холодний старт Render + повторні спроби).
            if (_relayService != null && !_relayService.IsConnected)
            {
                SetLoadingStep("Підключення до хмарної служби…", 80);
                SetSplashStatus("Підключення до хмарної служби…");
                for (int i = 0; i < 200 && !_relayService.IsConnected &&
                     !string.Equals(_relayService.Status, "error", StringComparison.OrdinalIgnoreCase); i++)
                    await Task.Delay(100);
            }
            SetSplashStatus(_relayService?.IsConnected == true
                ? "Хмарну службу підключено"
                : "Хмарна служба ще підключається у фоні…");
        }
        catch { }

        try
        {
            // Фаза 2: прямий тунель (cloudflared). З живих логів — ~7с;
            // чекаємо до 9с після релея.
            if (_directLink != null && !_directLink.IsAvailable)
            {
                SetLoadingStep("Налаштування прямого з'єднання…", 88);
                SetSplashStatus("Налаштування прямого з'єднання…");
                for (int i = 0; i < 90 && !_directLink.IsAvailable; i++)
                    await Task.Delay(100);
            }
            SetSplashStatus(_directLink?.IsAvailable == true
                ? "Пряме з'єднання готове"
                : "Пряме з'єднання налаштовується у фоні…");
        }
        catch { }
    }

    /// <summary>Статусний рядок унизу сплеша (без зміни кроку/відсотків).
    /// Дозволено звати з фонових потоків.</summary>
    private void SetSplashStatus(string text)
    {
        try
        {
            if (!Dispatcher.CheckAccess()) { Dispatcher.Invoke(() => SetSplashStatus(text)); return; }
            if (LoadingOverlay.Visibility == System.Windows.Visibility.Visible)
                LoadingStatusText.Text = text;
        }
        catch { }
    }

    /// <summary>Сховати сплеш тільки коли preflight завершився (ТЗ «після зникнення
    /// екрана все вже загружено»). Викликається з 'ready' та NavigationCompleted.</summary>
    private void HideLoadingOverlayWhenReady()
    {
        _ = WaitPreflightThenHideAsync();
    }

    private async Task WaitPreflightThenHideAsync()
    {
        if (_overlayHidden) return;
        try { if (_startupPreflight != null) await _startupPreflight.ConfigureAwait(false); } catch { }
        if (_overlayHidden) return;
        try { await Dispatcher.InvokeAsync(HideLoadingOverlay); } catch { }
    }

    private void HideLoadingOverlay()
    {
        if (_overlayHidden) return;
        _overlayHidden = true;
        try
        {
            // ФІКС блимання «не авторизований → авторизований» (ТЗ): перед самим
            // зникненням сплеша шлемо СВІЖИЙ стан — сторінка застосує юзера/код
            // ще ПІД сплешем, і користувач ніколи не побачить проміжний «гість».
            SendStateToWebView();
            // Плавне завершення (ТЗ: «завершилось — плавненько з анімацією»):
            // спочатку 100% + «Готово», ЧЕКАЄМО, поки відсотки плавно доїдуть
            // до 100 (щоб юзер реально побачив 100%), коротка пауза — і тільки
            // потім fade + легкий zoom оверлея.
            SetLoadingStep("Готово", 100);
            LoadingOverlay.IsHitTestVisible = false;
            _ = WaitPercentDoneThenFadeAsync();
        }
        catch
        {
            LoadingOverlay.Visibility = Visibility.Collapsed;
        }
    }

    /// <summary>Чекає, поки видимі відсотки плавно досягнуть 100 (макс ~1.5с),
    /// тримає «Готово» пів секунди і лише тоді запускає fade оверлея.</summary>
    private async Task WaitPercentDoneThenFadeAsync()
    {
        for (int i = 0; i < 75 && _percentShown < 99.5; i++)
            await Task.Delay(20);
        try { await Task.Delay(430).ConfigureAwait(false); } catch { }
        try { await Dispatcher.InvokeAsync(FadeOutLoadingOverlay); } catch { }
    }

    private bool _overlayFaded;

    private void FadeOutLoadingOverlay()
    {
        if (_overlayFaded) return;
        _overlayFaded = true;
        try
        {
            var ease = new System.Windows.Media.Animation.CubicEase { EasingMode = System.Windows.Media.Animation.EasingMode.EaseOut };
            var fade = new System.Windows.Media.Animation.DoubleAnimation(0, TimeSpan.FromMilliseconds(430)) { EasingFunction = ease };
            var zoom = new System.Windows.Media.Animation.DoubleAnimation(1, 1.02, TimeSpan.FromMilliseconds(430)) { EasingFunction = ease };
            var st = new System.Windows.Media.ScaleTransform(1, 1);
            LoadingOverlay.RenderTransform = st;
            LoadingOverlay.RenderTransformOrigin = new System.Windows.Point(0.5, 0.5);
            st.BeginAnimation(System.Windows.Media.ScaleTransform.ScaleXProperty, zoom);
            st.BeginAnimation(System.Windows.Media.ScaleTransform.ScaleYProperty, zoom);
            fade.Completed += (s, e) =>
            {
                try { _percentTimer?.Stop(); } catch { }
                LoadingOverlay.Visibility = Visibility.Collapsed;
            };
            LoadingOverlay.BeginAnimation(OpacityProperty, fade);
        }
        catch
        {
            LoadingOverlay.Visibility = Visibility.Collapsed;
        }
    }

    /// <summary>Кнопка «згорнути» на екрані завантаження (ТЗ: справа зверху
    /// лише закриття/згортання). Поведінка ідентична titlebar-кнопці UI.</summary>
    private void BtnLoadingMinimize_Click(object sender, RoutedEventArgs e)
    {
        WindowState = WindowState.Minimized;
    }

    /// <summary>Кнопка «закрити» на екрані завантаження — та сама логіка,
    /// що й window_close з HTML-інтерфейсу (трей або вихід).</summary>
    private void BtnLoadingClose_Click(object sender, RoutedEventArgs e) => ApplyCloseAction();

    /// <summary>Єдина точка закриття вікна (titlebar UI + екран завантаження).</summary>
    private void ApplyCloseAction()
    {
        ActivityLogger.Log("UI", _minimizeToTray ? "Вікно приховано в трей (закриття)" : "Програму закрито з вікна");
        if (_minimizeToTray)
        {
            WindowState = WindowState.Minimized;
            Hide();
        }
        else
        {
            _isExplicitExit = true;
            _notifyIcon.Visible = false;
            try { Services.WatchdogService.Stop(); } catch { }
            System.Windows.Application.Current.Shutdown();
        }
    }

    /// <summary>Запис налаштувань у %AppData%\FluxControl\settings.json (ТЗ:
    /// «вимкнув автозапуск — перезапустив — він вимкнений»). Викликається
    /// після кожної зміни (автозапуск / трей); SaveSettings синхронно
    /// підтримує запис у реєстрі в актуальному стані.</summary>
    private void PersistSettings()
    {
        try
        {
            _settings.SaveSettings(new Services.AppSettings
            {
                AutoRun = AutoRunService.IsAutoRunEnabled(),
                MinimizeToTray = _minimizeToTray,
                StartMinimized = _startedMinimized,
                ForcedLaunch = _forcedLaunch,
                AutoUpdate = _autoUpdate
            });
        }
        catch (Exception ex)
        {
            try { App.Log($"PersistSettings failed: {ex.Message}"); } catch { }
        }
    }

    private void ToggleMaximize()
    {
        if (_windowRectAnimating) return;
        if (WindowState == WindowState.Maximized) AnimateWindowRestore();
        else AnimateWindowMaximize();
    }

    private bool _windowRectAnimating;

    /// <summary>Цільовий прямокутник робочої області монітора (у DIP WPF).</summary>
    private Rect GetWorkAreaRect()
    {
        var wa = SystemParameters.WorkArea;
        return new Rect(wa.Left, wa.Top, wa.Width, wa.Height);
    }

    /// <summary>
    /// Анімація розгортання (ТЗ: «вікно наче стоїть по центру маленьке і як
    /// красиво збільшується»): легкий «відскок» — 80мс зжимання до 96% у центрі,
    /// потім плавне зростання до робочої області; у кінці — справжній Maximized.
    /// </summary>
    private void AnimateWindowMaximize()
    {
        try
        {
            _windowRectAnimating = true;
            var target = GetWorkAreaRect();
            double curW = ActualWidth > 0 ? ActualWidth : Width;
            double curH = ActualHeight > 0 ? ActualHeight : Height;
            double curL = Left, curT = Top;

            double dipW = curW * 0.96, dipH = curH * 0.96;
            double dipL = curL + (curW - dipW) / 2, dipT = curT + (curH - dipH) / 2;

            var easeOut = new System.Windows.Media.Animation.CubicEase { EasingMode = System.Windows.Media.Animation.EasingMode.EaseOut };
            var easeInOut = new System.Windows.Media.Animation.CubicEase { EasingMode = System.Windows.Media.Animation.EasingMode.EaseInOut };

            var animL = new System.Windows.Media.Animation.DoubleAnimationUsingKeyFrames();
            animL.KeyFrames.Add(new System.Windows.Media.Animation.LinearDoubleKeyFrame(dipL, TimeSpan.FromMilliseconds(80)));
            animL.KeyFrames.Add(new System.Windows.Media.Animation.EasingDoubleKeyFrame(target.Left, TimeSpan.FromMilliseconds(340)) { EasingFunction = easeOut });
            var animT = new System.Windows.Media.Animation.DoubleAnimationUsingKeyFrames();
            animT.KeyFrames.Add(new System.Windows.Media.Animation.LinearDoubleKeyFrame(dipT, TimeSpan.FromMilliseconds(80)));
            animT.KeyFrames.Add(new System.Windows.Media.Animation.EasingDoubleKeyFrame(target.Top, TimeSpan.FromMilliseconds(340)) { EasingFunction = easeOut });
            var animW = new System.Windows.Media.Animation.DoubleAnimationUsingKeyFrames();
            animW.KeyFrames.Add(new System.Windows.Media.Animation.LinearDoubleKeyFrame(dipW, TimeSpan.FromMilliseconds(80)));
            animW.KeyFrames.Add(new System.Windows.Media.Animation.EasingDoubleKeyFrame(target.Width, TimeSpan.FromMilliseconds(340)) { EasingFunction = easeInOut });
            var animH = new System.Windows.Media.Animation.DoubleAnimationUsingKeyFrames();
            animH.KeyFrames.Add(new System.Windows.Media.Animation.LinearDoubleKeyFrame(dipH, TimeSpan.FromMilliseconds(80)));
            animH.KeyFrames.Add(new System.Windows.Media.Animation.EasingDoubleKeyFrame(target.Height, TimeSpan.FromMilliseconds(340)) { EasingFunction = easeInOut });

            animW.Completed += (s, e) =>
            {
                try
                {
                    // Снимаем удержание анимаций (HoldEnd), зафиксировав финальные
                    // значения как локальные — иначе окно «залипнет» и его нельзя
                    // будет менять мышью, а явные Width/Height будут игнорироваться.
                    BeginAnimation(LeftProperty, null); Left = target.Left;
                    BeginAnimation(TopProperty, null); Top = target.Top;
                    BeginAnimation(WidthProperty, null); Width = target.Width;
                    BeginAnimation(HeightProperty, null); Height = target.Height;
                    MaxHeight = SystemParameters.WorkArea.Height;
                    WindowState = WindowState.Maximized;
                }
                catch { }
                _windowRectAnimating = false;
                SendStateToWebView();
            };

            // На Win10 GDI-регион старого размера обрезал бы растущее окно —
            // на время анимации снимаем его (вернём по StateChanged/завершению).
            if (!IsWin11OrNewer)
            {
                try
                {
                    var hwnd = new WindowInteropHelper(this).Handle;
                    if (hwnd != IntPtr.Zero) { SetWindowRgn(hwnd, IntPtr.Zero, true); _regionApplied = false; }
                }
                catch { }
            }

            BeginAnimation(LeftProperty, animL);
            BeginAnimation(TopProperty, animT);
            BeginAnimation(WidthProperty, animW);
            BeginAnimation(HeightProperty, animH);
        }
        catch
        {
            _windowRectAnimating = false;
            MaxHeight = SystemParameters.WorkArea.Height;
            WindowState = WindowState.Maximized;
            SendStateToWebView();
        }
        PostChromeState();
    }

    /// <summary>Зворотна анімація: із максимізованого стану плавно «з'їжджаємось»
    /// до звичайного прямокутника вікна.</summary>
    private void AnimateWindowRestore()
    {
        try
        {
            _windowRectAnimating = true;
            var max = GetWorkAreaRect();
            var rb = RestoreBounds;
            double targetW = rb.Width > 0 ? rb.Width : 1000;
            double targetH = rb.Height > 0 ? rb.Height : 640;
            if (targetW > max.Width) targetW = max.Width;
            if (targetH > max.Height) targetH = max.Height;
            double targetL = rb.Left, targetT = rb.Top;
            if (targetL < max.Left || targetL + targetW > max.Right) targetL = max.Left + (max.Width - targetW) / 2;
            if (targetT < max.Top || targetT + targetH > max.Bottom) targetT = max.Top + (max.Height - targetH) / 2;

            // миттєво переносимо вікно в maximize-прямокутник (поки воно ще
            // максимізоване) і знімаємо максимізацію — анімація йде з видимого положення
            MaxHeight = double.PositiveInfinity;
            WindowState = WindowState.Normal;
            Left = max.Left; Top = max.Top; Width = max.Width; Height = max.Height;

            var ease = new System.Windows.Media.Animation.CubicEase { EasingMode = System.Windows.Media.Animation.EasingMode.EaseInOut };
            var animL = new System.Windows.Media.Animation.DoubleAnimation(targetL, TimeSpan.FromMilliseconds(230)) { EasingFunction = ease };
            var animT = new System.Windows.Media.Animation.DoubleAnimation(targetT, TimeSpan.FromMilliseconds(230)) { EasingFunction = ease };
            var animW = new System.Windows.Media.Animation.DoubleAnimation(targetW, TimeSpan.FromMilliseconds(230)) { EasingFunction = ease };
            var animH = new System.Windows.Media.Animation.DoubleAnimation(targetH, TimeSpan.FromMilliseconds(230)) { EasingFunction = ease };

            animW.Completed += (s, e) =>
            {
                try
                {
                    // Снимаем удержание анимаций, зафиксировав нормальный прямоугольник
                    BeginAnimation(LeftProperty, null); Left = targetL;
                    BeginAnimation(TopProperty, null); Top = targetT;
                    BeginAnimation(WidthProperty, null); Width = targetW;
                    BeginAnimation(HeightProperty, null); Height = targetH;
                }
                catch { }
                _windowRectAnimating = false;
                if (!IsWin11OrNewer) ApplyOrClearWin10Region();
                SendStateToWebView();
            };

            BeginAnimation(LeftProperty, animL);
            BeginAnimation(TopProperty, animT);
            BeginAnimation(WidthProperty, animW);
            BeginAnimation(HeightProperty, animH);
        }
        catch
        {
            _windowRectAnimating = false;
            MaxHeight = double.PositiveInfinity;
            WindowState = WindowState.Normal;
            SendStateToWebView();
        }
        PostChromeState();
    }

    private void CopyWebLink()
    {
        try
        {
            var url = GetWebConnectUrl();
            System.Windows.Clipboard.SetText(url);
            // Копіювання зазвичай ініціюють кнопкою у вікні — там тост малює
            // сторінка; балун потрібен лише при виклику з трею, коли окно сховано.
            NotifySmart("FluxControl", "Посилання скопійовано у буфер обміну!");
        }
        catch { }
    }

    /// <summary>Пункт трея «Скопіювати код підключення» (ТЗ): у буфер потрапляє
    /// ЛИШЕ 16-символьний код пристрою — його вставляють на сайті в поле коду.</summary>
    private void CopyConnectCode()
    {
        try
        {
            var code = _pairingService.DeviceCode;
            if (string.IsNullOrWhiteSpace(code))
            {
                NotifySmart("FluxControl", "Код підключення ще не готовий — спробуйте за секунду");
                return;
            }
            System.Windows.Clipboard.SetText(code);
            NotifySmart("FluxControl", $"Код підключення скопійовано: {code}");
        }
        catch { }
    }

    /// <summary>Штатний вихід із трея: прибрати іконку, зупинити сторож
    /// «примусового запуску» (інакше через 10с підніме програму знову) і закритись.</summary>
    private void ExitFromTray()
    {
        _isExplicitExit = true;
        _notifyIcon.Visible = false;
        try { Services.WatchdogService.Stop(); } catch { }
        System.Windows.Application.Current.Shutdown();
    }

    /// <summary>ФІКС чорного екрана після показу вікна з трея: у WPF-обгортці
    /// WebView2 немає NotifyParentWindowPositionChanged, тому після відновлення
    /// вікна контрол може лишитись неперемальованим («чорний прямокутник»,
    /// вміст з'являється лише після кліку/ресайзу). Короткий «блим» видимістю
    /// контрола на DispatcherPriority.Loaded змушує HwndHost перемалюватись.</summary>
    private void NudgeWebViewAfterShow()
    {
        try
        {
            _ = Dispatcher.BeginInvoke(DispatcherPriority.Loaded, new Action(() =>
            {
                try
                {
                    webView.Visibility = Visibility.Hidden;
                    webView.Visibility = Visibility.Visible;
                }
                catch { }
            }));
        }
        catch { }
    }

    /// <summary>
    /// ТЗ «загрузка без лагов»: тяжёлый GetMetrics (счётчики производительности,
    /// WMI, перебор дисков) выполняется в фоновом потоке; результат кладётся
    /// в кэш и UI-поток лишь отправляет готовый снапшот в WebView.
    /// </summary>
    private void RefreshMetricsInBackground()
    {
        if (Interlocked.Exchange(ref _metricsBusy, 1) == 1) return; // предыдущий расчёт ещё идёт
        _ = Task.Run(async () =>
        {
            try
            {
                var metrics = _systemService.GetMetrics();
                await Dispatcher.InvokeAsync(() =>
                {
                    _lastMetrics = metrics;
                    SendStateToWebView();
                });
            }
            catch { }
            finally { Interlocked.Exchange(ref _metricsBusy, 0); }
        });
    }

    private void SendStateToWebView()
    {
        try
        {
            var webUrl = GetWebConnectUrl();
            if (_cachedQrUrl != webUrl || string.IsNullOrEmpty(_cachedQrBase64))
            {
                try
                {
                    _cachedQrBase64 = _pairingService.GenerateQrCodeDataUrl(webUrl);
                    _cachedQrUrl = webUrl;
                }
                catch (Exception qrx)
                {
                    App.Log($"[WARN] QR generation failed: {qrx.Message}");
                }
            }
            string qrBase64 = _cachedQrBase64;

            var isRelayConnected = _relayService?.IsConnected ?? false;
            var relayStatus = _relayService?.Status ?? (isRelayConnected ? "connected" : "connecting");
            var relayError = _relayService?.LastError;

            // ГОТОВИЙ снапшот із фонового розрахунку. Важкий GetMetrics() НА
            // UI-ПОТОЦІ заборонено: перший виклик (WMI-диски, nvidia-smi, лічильники)
            // триває секунди — саме через це сплеш зникав, а дані «догружались»
            // після, і екран блимав «не залогінений → залогінений». Якщо снапшота
            // ще немає — просимо фоновий розрахунок і шлемо стан без метрик
            // (наступний тик доставить цифри).
            var metrics = _lastMetrics;
            if (metrics == null) RefreshMetricsInBackground();

            var state = new
            {
                type = "state",
                computerName = Environment.MachineName,
                userName = Environment.UserName,
                // версія, зашита в exe (-p:Version при деплої) — для секції «Про програму»
                appVersion = Services.UpdateService.GetLocalVersion(),
                // ТЗ v2 «Про програму»: реальне лого (PNG data-URL з вбудованої logo.ico).
                logo = GetLogoDataUrl(),
                code = _pairingService.DeviceCode,
                deviceCode = _pairingService.DeviceCode,
                formattedCode = _pairingService.GetFormattedCode(),
                hwid = _pairingService.HardwareId,
                pin = _pairingService.CurrentPin,
                qrCode = qrBase64,
                qrBase64 = qrBase64,
                webUrl = webUrl,
                relayConnected = isRelayConnected,
                relayStatus = relayStatus,
                relayError = relayError,
                isAutoRun = AutoRunService.IsAutoRunEnabled(),
                autoRun = AutoRunService.IsAutoRunEnabled(),
                autoUpdate = _autoUpdate,
                minimizeToTray = _minimizeToTray,
                activeClients = _pairingService.GetActiveClients().Count,
                user = _currentUser,
                ffmpeg = new { status = _ffmpegStatus, stage = _ffmpegStage, percent = _ffmpegPercent, error = _ffmpegError, receivedBytes = _ffmpegReceived, totalBytes = _ffmpegTotal },
                dependencies = new { ffmpeg = new { status = _ffmpegStatus, stage = _ffmpegStage, percent = _ffmpegPercent, error = _ffmpegError, receivedBytes = _ffmpegReceived, totalBytes = _ffmpegTotal } },
                speedTest = _relayService?.SpeedTest.Last,
                cpuName = metrics?.CpuName ?? string.Empty,
                cpuPercent = Math.Round(metrics?.CpuPercent ?? 0, 1),
                gpuName = metrics?.GpuName ?? string.Empty,
                gpuPercent = Math.Round(metrics?.GpuUsage ?? 0, 1),
                ramUsedGb = Math.Round(metrics?.RamUsedGb ?? 0, 1),
                ramTotalGb = Math.Round(metrics?.RamTotalGb ?? 0, 1),
                ramPercent = Math.Round(metrics?.RamPercent ?? 0, 0),
                osName = metrics?.OsVersion ?? string.Empty,
                uptime = metrics?.Uptime ?? string.Empty,
                batteryPercent = metrics?.BatteryPercent ?? 0,
                batteryCharging = metrics?.BatteryCharging ?? false,
                batteryPresent = metrics?.BatteryPresent ?? false,
                motherboard = metrics?.Motherboard ?? string.Empty,
                data = new
                {
                    code = _pairingService.DeviceCode,
                    deviceCode = _pairingService.DeviceCode,
                    formattedCode = _pairingService.GetFormattedCode(),
                    pin = _pairingService.CurrentPin,
                    qrCode = qrBase64,
                    webUrl = webUrl,
                    relayConnected = isRelayConnected,
                    relayStatus = relayStatus,
                    relayError = relayError,
                    isAutoRun = AutoRunService.IsAutoRunEnabled(),
                    autoUpdate = _autoUpdate,
                    minimizeToTray = _minimizeToTray,
                    activeClients = _pairingService.GetActiveClients().Count,
                    user = _currentUser,
                    ffmpeg = new { status = _ffmpegStatus, stage = _ffmpegStage, percent = _ffmpegPercent, error = _ffmpegError },
                    speedTest = _relayService?.SpeedTest.Last
                }
            };

            PostJsonToWebView(state);
        }
        catch (Exception ex)
        {
            App.Log($"[ERROR] SendStateToWebView failed: {ex}");
        }
    }

    private void PostChromeState()
    {
        PostJsonToWebView(new { type = "chrome", maximized = WindowState == WindowState.Maximized });
    }

    private string? _logoDataUrl;

    /// <summary>
    /// ТЗ v2 «Про програму»: реальний логотип у картці. Конвертуємо вбудований
    /// pack://application:,,,/logo.ico у PNG (96px, найбільший кадр .ico) та
    /// віддаємо як data-URL для WebView. Результат кешується — конвертація
    /// виконується один раз за сесію; будь-яка помилка → null (UI покаже
    /// фолбек-блискавку). Виклик ЛИШЕ з UI-потоку.
    /// </summary>
    private string? GetLogoDataUrl()
    {
        if (_logoDataUrl != null) return _logoDataUrl;
        try
        {
            var sri = System.Windows.Application.GetResourceStream(new Uri("pack://application:,,,/logo.ico"));
            if (sri?.Stream == null) return null;
            using (var icoMs = new MemoryStream())
            {
                sri.Stream.CopyTo(icoMs);
                icoMs.Position = 0;
                var decoder = System.Windows.Media.Imaging.BitmapDecoder.Create(
                    icoMs, System.Windows.Media.Imaging.BitmapCreateOptions.None,
                    System.Windows.Media.Imaging.BitmapCacheOption.OnLoad);
                var frame = decoder.Frames
                    .OrderByDescending(f => (long)f.PixelWidth * f.PixelHeight)
                    .FirstOrDefault();
                if (frame == null) return null;
                // 96px — вдосталь для бейджа 46px з запасом на HiDPI.
                double target = 96;
                double scale = target / Math.Max(frame.PixelWidth, frame.PixelHeight);
                var scaled = new System.Windows.Media.Imaging.TransformedBitmap(
                    frame, new System.Windows.Media.ScaleTransform(scale, scale));
                // Заморожуємо — робить бітмапу безпечним для будь-якого потоку.
                if (scaled.CanFreeze) scaled.Freeze();
                var encoder = new System.Windows.Media.Imaging.PngBitmapEncoder();
                encoder.Frames.Add(System.Windows.Media.Imaging.BitmapFrame.Create(scaled));
                using var pngMs = new MemoryStream();
                encoder.Save(pngMs);
                _logoDataUrl = "data:image/png;base64," + Convert.ToBase64String(pngMs.ToArray());
            }
        }
        catch (Exception ex)
        {
            App.Log($"[UI] Logo conversion failed (fallback lightning will be used): {ex.Message}");
            _logoDataUrl = null;
        }
        return _logoDataUrl;
    }

    private void PostJsonToWebView(object payload)
    {
        try
        {
            var json = JsonSerializer.Serialize(payload);
            webView.CoreWebView2?.PostWebMessageAsJson(json);
        }
        catch { }
    }

    /// <summary>
    /// ТЗ: перевірка оновлень при кожному запуску — ЩЕ НА ЕКРАНІ ЗАВАНТАЖЕННЯ.
    /// ТЗ 53 (нова логіка):
    ///  • автооновлення УВІМКНЕНО → нова версія завантажується тихо; GUI після
    ///    рестарту лише якщо вікно відкрито користувачем, автозапуск → трей;
    ///  • автооновлення вимкнено + автозапуск (--minimized) → ВІКНО НЕ
    ///    ПІДНІМАЄМО: тільки балун «є оновлення», блокуючий екран покажеться,
    ///    коли користувач сам відкриє програму з трея;
    ///  • вимкнено + звичайний запуск → колишня поведінка (блокуючий екран).
    /// </summary>
    private async Task CheckForUpdatesOnStartupAsync()
    {
        try
        {
            var update = await UpdateService.CheckForUpdateAsync();
            if (update == null)
            {
                // мережа ще не піднялась (автозапуск Windows) — одна повторна спроба за 15 секунд
                App.Log("Startup update check: мережа недоступна, повторна спроба за 15с");
                await Task.Delay(15000);
                update = await UpdateService.CheckForUpdateAsync();
            }
            if (update == null || !update.UpdateAvailable) return;

            App.Log($"Startup update check: знайдено нову версію {update.LatestVersion} (локальна {update.LocalVersion}), autoUpdate={_autoUpdate}, minimized={_startedMinimized}");
            _pendingUpdate = update;

            if (_autoUpdate)
            {
                // Тиха автоустановка: ніякого GUI, балун лише коли вікно приховане.
                await InstallUpdateSilentlyAsync(update);
                return;
            }

            await Dispatcher.InvokeAsync(() =>
            {
                SendUpdateAvailableToWebView();
                // ТЗ 53 + ФІКС самовистрибу: стартова перевірка оновлень
                // НІКОЛИ не піднімає вікно — лише балун. Автозапуск — старт у трей.
                if (_startedMinimized || _headless || !IsVisible)
                {
                    try
                    {
                        _notifyIcon.ShowBalloonTip(6000, "FluxControl",
                            $"Доступне оновлення v{update.LatestVersion} — відкрийте програму, щоб встановити", ToolTipIcon.Info);
                    }
                    catch { }
                }
            });
        }
        catch (Exception ex)
        {
            App.Log($"Startup update check failed: {ex.Message}");
        }
    }

    /// <summary>Тихий періодичний опит манифесту поки програма працює: нова
    /// версія помічається одразу (ТЗ «не спустя 5 мин»). ТЗ 53: при увімкненому
    /// автооновленні — тиха установка; у трей-режимі вікно не піднімаємо.</summary>
    private async Task PollForUpdatesAsync()
    {
        try
        {
            if (_updateInstalling) return;
            var update = await UpdateService.CheckForUpdateAsync();
            if (update == null || !update.UpdateAvailable) return;
            bool alreadyShown = _pendingUpdate != null &&
                string.Equals(_pendingUpdate.LatestVersion, update.LatestVersion, StringComparison.OrdinalIgnoreCase);
            _pendingUpdate = update;

            if (_autoUpdate)
            {
                await InstallUpdateSilentlyAsync(update);
                return;
            }

            await Dispatcher.InvokeAsync(() =>
            {
                SendUpdateAvailableToWebView();
                // ФІКС самовистрибу вікна: фоновий опитувач НІКОЛИ не викликає
                // ShowAndActivate. Колишня умова (!_startedMinimized||IsVisible)
                // пропускала випадок «закрито в трей після звичайного старту» і
                // висмикувала вікно на передній план серед роботи. Балун достатньо.
                if (!alreadyShown && !_headless)
                {
                    try
                    {
                        _notifyIcon.ShowBalloonTip(6000, "FluxControl",
                            $"Доступне оновлення v{update.LatestVersion} — відкрийте програму, щоб встановити", ToolTipIcon.Info);
                    }
                    catch { }
                }
            });
        }
        catch { }
    }

    /// <summary>
    /// ТЗ 53: тиха автоустановка без блокуючого екрана. Видимість програми
    /// після рестарту успадковується: вікно відкрите → GUI; сховане в трей /
    /// автозапуск із Windows → старт у трей (--minimized); --hidden сторожа
    /// теж успадковується. Прогрес у балуні НЕ спамимо — лише початок/фінал.
    /// </summary>
    private async Task InstallUpdateSilentlyAsync(UpdateInfo update)
    {
        if (_updateInstalling) return;
        _updateInstalling = true;
        try
        {
            // IsVisible / _headless читаємо ЛИШЕ в UI-потоці (WPF-властивості).
            string relaunchArgs = string.Empty;
            await Dispatcher.InvokeAsync(() => relaunchArgs = RelaunchVisibilityArgs());
            App.Log($"Auto-update: silent install v{update.LatestVersion} starts (relaunchArgs=\"{relaunchArgs}\")");
            var newExePath = await UpdateService.DownloadReleaseZipAsync(
                update.DownloadUrl, update.LatestVersion, progress: null, System.Threading.CancellationToken.None);

            if (newExePath.EndsWith(".zip", StringComparison.OrdinalIgnoreCase))
                newExePath = await UpdateInstaller.ExtractExeFromZipAsync(newExePath);

            UpdateInstaller.Launch(newExePath, RelaunchVisibilityArgs());
            App.Log($"Auto-update: relaunching into v{update.LatestVersion}");
            await Task.Delay(600);
            System.Windows.Application.Current.Shutdown();
        }
        catch (Exception ex)
        {
            App.Log($"Auto-update silent install failed: {ex.Message}");
            _updateInstalling = false;
            try
            {
                _notifyIcon.ShowBalloonTip(5000, "FluxControl",
                    "Автооновлення не вдалося: " + ex.Message, ToolTipIcon.Warning);
            }
            catch { }
        }
    }

    /// <summary>
    /// Аргументи рестарту після оновлення (ТЗ 53): сторож — --hidden;
    /// вікно приховане в трей або автозапуск — --minimized (GUI НЕ показуємо);
    /// вікно відкрите — порожньо (новий процес покаже GUI як завжди).
    /// </summary>
    private string RelaunchVisibilityArgs()
    {
        if (_headless) return "--hidden";
        if (_startedMinimized && !IsVisible) return "--minimized";
        return string.Empty;
    }

    /// <summary>Статус кроку завантаження на нативному лоадинг-екрані
    /// (зникає разом з оверлеєм, після загрузки не чіпаємо).</summary>
    private void SetLoadingStep(string text, int percent = -1)
    {
        try
        {
            if (!Dispatcher.CheckAccess()) { Dispatcher.Invoke(() => SetLoadingStep(text, percent)); return; }
            if (LoadingOverlay.Visibility == System.Windows.Visibility.Visible) LoadingStepText.Text = text;
            if (percent >= 0) SetLoadingPercent(percent);
        }
        catch { }
    }

    // Плавні відсотки (ТЗ: «анімація завантаження з відсотками», «щоб плавно
    // доходило до 100% — без застрягання на 15% і стрибка на 30%»): кроки
    // пайплайна задають ціль, а ПОКИ ціль не оновлюється — вона повільно
    // повзе вгору сама (експонента до 92%), тож відсотки рухаються ПОСТІЙНО.
    private double _percentShown;
    private double _percentTarget;
    private DispatcherTimer? _percentTimer;
    private DateTime _percentStart = DateTime.MinValue;

    private void SetLoadingPercent(int percent)
    {
        try
        {
            if (!Dispatcher.CheckAccess()) { Dispatcher.Invoke(() => SetLoadingPercent(percent)); return; }
            var p = Math.Max(0, Math.Min(100, percent));
            if (p <= _percentTarget && _percentTarget > 0 && p < 100) return; // назад не відкочуємо
            _percentTarget = p;
            if (_percentTimer != null) return;
            _percentStart = DateTime.UtcNow;
            _percentTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(16) };
            _percentTimer.Tick += (s, e) =>
            {
                try
                {
                    // Безперервний хід: поки пайплайн не задав нову ціль,
                    // цільова відмітка повзе сама (6 → 92% за ~12с, експонента).
                    var elapsed = (DateTime.UtcNow - _percentStart).TotalSeconds;
                    var creep = 6 + 86 * (1 - Math.Exp(-elapsed / 4.2));
                    if (_percentTarget < creep) _percentTarget = Math.Min(creep, 92);

                    var diff = _percentTarget - _percentShown;
                    if (diff <= 0.05)
                    {
                        _percentShown = _percentTarget;
                    }
                    else
                    {
                        _percentShown += diff * 0.10;
                        if (_percentTarget >= 100 && _percentTarget - _percentShown < 0.4)
                            _percentShown = _percentTarget;
                    }
                    LoadingPercentText.Text = Math.Round(_percentShown) + "%";
                    // Лінійний бар під кільцем — рухається синхронно з відсотками
                    try { LoadingBarFill.ScaleX = Math.Max(0, Math.Min(1, _percentShown / 100.0)); } catch { }
                }
                catch { }
            };
            _percentTimer.Start();
        }
        catch { }
    }

    /// <summary>Захист від паралельних фонових перевірок оновлень.</summary>
    private int _updateCheckInFlight;

    /// <summary>Періодичний опитувач манифесту (кожні 60 секунд).</summary>
    private DispatcherTimer? _updatePollTimer;

    /// <summary>Пункт трея «Перевірити оновлення»: з балунами-статусами.</summary>
    private async void CheckUpdatesManually()
    {
        try
        {
            _notifyIcon.ShowBalloonTip(1500, "FluxControl", "Перевіряю оновлення…", ToolTipIcon.Info);
            var update = await UpdateService.CheckForUpdateAsync();
            if (update == null)
            {
                _notifyIcon.ShowBalloonTip(3500, "FluxControl",
                    "Не вдалося перевірити оновлення — немає зв'язку з сайтом оновлень", ToolTipIcon.Warning);
                return;
            }
            if (!update.UpdateAvailable)
            {
                _notifyIcon.ShowBalloonTip(3500, "FluxControl",
                    $"У вас остання версія {update.LocalVersion}", ToolTipIcon.Info);
                return;
            }
            // Є нова версія — показуємо блокуючий екран оновлення в інтерфейсі
            _pendingUpdate = update;
            SendUpdateAvailableToWebView();
            ShowAndActivate();
        }
        catch (Exception ex)
        {
            App.Log($"Manual update check failed: {ex.Message}");
        }
    }

    // ------------------------------------------------ обновление через UI ---

    /// <summary>
    /// Перевірка оновлень на запит з інтерфейсу (кнопка «Перевірити оновлення»
    /// у секції «Про програму»). Завжди відповідає повідомленням
    /// update_check_result, щоб користувач бачив результат очима.
    /// </summary>
    private async Task CheckUpdatesFromUiAsync()
    {
        try
        {
            PostJsonToWebView(new { type = "update_check_result", state = "checking" });
            var update = await UpdateService.CheckForUpdateAsync();
            if (update == null)
            {
                PostJsonToWebView(new
                {
                    type = "update_check_result",
                    state = "error",
                    message = "Немає зв'язку з сайтом оновлень — перевірте інтернет"
                });
                return;
            }
            if (!update.UpdateAvailable)
            {
                PostJsonToWebView(new
                {
                    type = "update_check_result",
                    state = "latest",
                    localVersion = update.LocalVersion,
                    latestVersion = update.LatestVersion,
                    message = $"У вас остання версія v{update.LocalVersion}"
                });
                return;
            }
            // Є нова версія — показуємо блокуючий екран оновлення
            _pendingUpdate = update;
            PostJsonToWebView(new
            {
                type = "update_check_result",
                state = "available",
                localVersion = update.LocalVersion,
                latestVersion = update.LatestVersion,
                message = $"Доступна нова версія v{update.LatestVersion}"
            });
            SendUpdateAvailableToWebView();
        }
        catch (Exception ex)
        {
            App.Log($"UI update check failed: {ex.Message}");
            PostJsonToWebView(new { type = "update_check_result", state = "error", message = "Помилка перевірки: " + ex.Message });
        }
    }

    /// <summary>Оновлення, яке очікує на згоду користувача в інтерфейсі.</summary>
    private UpdateInfo? _pendingUpdate;

    /// <summary>ТЗ 53: автооновлення у фоні (налаштування в UI). true — нова
    /// версія завантажується й установлюється тихо; GUI після рестарту — лише
    /// якщо вікно було відкритим, автозапуск із Windows → старт у трей.</summary>
    private bool _autoUpdate = true;

    /// <summary>Захист від подвійного запуску завантаження оновлення.</summary>
    private bool _updateInstalling;

    /// <summary>Досипає інтерфейсу інформацію про доступне оновлення (блокуючий екран).</summary>
    private void SendUpdateAvailableToWebView()
    {
        if (_pendingUpdate == null) return;
        PostJsonToWebView(new
        {
            type = "update_available",
            localVersion = _pendingUpdate.LocalVersion,
            latestVersion = _pendingUpdate.LatestVersion,
            installing = _updateInstalling
        });
    }

    private void SendUpdateProgressToWebView(double percent, long received, long total, string status)
    {
        PostJsonToWebView(new
        {
            type = "update_progress",
            percent = Math.Round(percent, 1),
            received,
            total,
            status
        });
    }

    /// <summary>
    /// Команда «install_update» з інтерфейсу: завантажує останній exe,
    /// показує прогрес прямо в блокуючому екрані, запускає оновлювач
    /// (exe-swap) і коректно завершує програму.
    /// </summary>
    private async Task InstallUpdateFromUiAsync()
    {
        if (_pendingUpdate == null || _updateInstalling) return;
        _updateInstalling = true;
        try
        {
            var progress = new Progress<DownloadProgress>(p =>
                SendUpdateProgressToWebView(p.Percent, p.ReceivedBytes, p.TotalBytes,
                    p.TotalBytes > 0
                        ? $"Завантажено {p.ReceivedBytes / 1048576.0:0.0} з {p.TotalBytes / 1048576.0:0.0} МБ"
                        : $"Завантажено {p.ReceivedBytes / 1048576.0:0.0} МБ"));

            SendUpdateProgressToWebView(0, 0, 0, "Завантаження оновлення…");
            var newExePath = await UpdateService.DownloadReleaseZipAsync(
                _pendingUpdate.DownloadUrl, _pendingUpdate.LatestVersion, progress, System.Threading.CancellationToken.None);

            // Легасі-релізи: zip із exe всередині — витягуємо; голий .exe — як є.
            if (newExePath.EndsWith(".zip", StringComparison.OrdinalIgnoreCase))
            {
                SendUpdateProgressToWebView(100, 1, 1, "Розпакування оновлення…");
                newExePath = await UpdateInstaller.ExtractExeFromZipAsync(newExePath);
            }

            SendUpdateProgressToWebView(100, 1, 1, "Запускаю оновлювач… програма перезапуститься");
            await Task.Delay(800);
            // ТЗ 53: вікно відкрите (кнопка натиснута в GUI) → після оновлення
            // GUI показується; автозапуск/трей успадковує --minimized.
            UpdateInstaller.Launch(newExePath, RelaunchVisibilityArgs());
            await Task.Delay(600);
            System.Windows.Application.Current.Shutdown(); // updater чекає PID
        }
        catch (Exception ex)
        {
            App.Log($"UI update install failed: {ex}");
            _updateInstalling = false;
            SendUpdateProgressToWebView(0, 0, 0, "Помилка: " + ex.Message + " — спробуйте ще раз");
            SendUpdateAvailableToWebView();
        }
    }

    /// <summary>
    /// Встановлення конкретної версії з архіву на сайті (ТЗ «відкат на стару»):
    /// той самий блокуючий екран + прогрес, що й у звичайного оновлення, але
    /// джерело — versions/<version>/FluxControl.exe. Працює і ДЛЯ ВІДКАТУ.
    /// </summary>
    private async Task InstallSpecificVersionFromUiAsync(string version)
    {
        if (_updateInstalling) return;
        _updateInstalling = true;
        try
        {
            var progress = new Progress<DownloadProgress>(p =>
                SendUpdateProgressToWebView(p.Percent, p.ReceivedBytes, p.TotalBytes,
                    p.TotalBytes > 0
                        ? $"Завантаження v{version}: {p.ReceivedBytes / 1048576.0:0.0} з {p.TotalBytes / 1048576.0:0.0} МБ"
                        : $"Завантаження v{version}: {p.ReceivedBytes / 1048576.0:0.0} МБ"));

            SendUpdateProgressToWebView(0, 0, 0, $"Завантаження версії {version} з архіву…");
            var newExePath = await UpdateService.InstallSpecificVersionAsync(version, progress, System.Threading.CancellationToken.None);

            if (newExePath.EndsWith(".zip", StringComparison.OrdinalIgnoreCase))
            {
                SendUpdateProgressToWebView(100, 1, 1, "Розпакування…");
                newExePath = await UpdateInstaller.ExtractExeFromZipAsync(newExePath);
            }

            SendUpdateProgressToWebView(100, 1, 1, $"Запускаю версію {version}… програма перезапуститься");
            await Task.Delay(800);
            UpdateInstaller.Launch(newExePath, RelaunchVisibilityArgs());
            await Task.Delay(600);
            System.Windows.Application.Current.Shutdown();
        }
        catch (Exception ex)
        {
            App.Log($"UI specific-version install failed: {ex}");
            _updateInstalling = false;
            SendUpdateProgressToWebView(0, 0, 0, $"Помилка встановлення v{version}: {ex.Message}");
            await Task.Delay(4000);
            SendUpdateProgressToWebView(0, 0, 0, "");
        }
    }

    /// <summary>
    /// Завершення запуску з --minimized: вікно виконало свій один невидимий
    /// показ (Loaded-пайплайн відпрацював) — тепер ховаємо його повністю.
    /// Користувач бачить: нічого на екрані, нічого на панелі завдань,
    /// лише іконка в треї + балун «працює у фоновому режимі».
    /// </summary>
    private void FinishStartupToTray()
    {
        if (_startupHideDone) return;
        _startupHideDone = true;
        try
        {
            Hide();
            Opacity = 1d;
            ShowInTaskbar = true;
            ShowActivated = true;
            _notifyIcon.ShowBalloonTip(2500, "FluxControl",
                "Програма запущена у фоновому режимі — іконка в треї біля годинника", ToolTipIcon.Info);
        }
        catch { }
    }

    // public: викликається з App.xaml.cs (сигнал «покажи вікно» від повторного
    // запуску ярлика) та з власних обробників трею й оновлень.
    public void ShowAndActivate()
    {
        // Скасовуємо невидиму фазу автозапуску — користувач попросив вікно,
        // воно має бути повністю видимим, навіть якщо клікнув у трей дуже рано.
        _startupHideDone = true;
        try
        {
            Opacity = 1d;
            ShowInTaskbar = true;
            ShowActivated = true;
        }
        catch { }
        Show();
        WindowState = WindowState.Normal;
        Activate();

        // ФІКС чорного екрана після показу вікна з трея: у WPF-обгортці WebView2
        // немає NotifyParentWindowPositionChanged, тому після відновлення вікна
        // контрол може лишитись неперемальованим («чорний прямокутник», вміст
        // з'являється лише після кліку/ресайзу). Короткий «блим» видимістю
        // контрола на DispatcherPriority.Loaded змушує HwndHost перемалюватись.
        NudgeWebViewAfterShow();

        // ТЗ 53: якщо оновлення знайдено раніше (автозапуск не піднімав вікно),
        // блокуючий екран має з'явитися саме ТЕПЕР — користувач відкрив GUI.
        if (_pendingUpdate != null) SendUpdateAvailableToWebView();

        // ТЗ: перевірка оновлень при кожному запуску програми. Відкриття вікна
        // з трею — це теж «запуск» для користувача: тихо перепитуємо манифест,
        // якщо оновлення ще не знайдено і фонова перевірка не триває.
        if (_pendingUpdate == null && Interlocked.Exchange(ref _updateCheckInFlight, 1) == 0)
        {
            _ = Task.Run(async () =>
            {
                try
                {
                    var upd = await UpdateService.CheckForUpdateAsync();
                    if (upd != null && upd.UpdateAvailable)
                    {
                        await Dispatcher.InvokeAsync(() =>
                        {
                            _pendingUpdate = upd;
                            SendUpdateAvailableToWebView();
                        });
                    }
                }
                catch { }
                finally { Interlocked.Exchange(ref _updateCheckInFlight, 0); }
            });
        }
    }

    protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
    {
        if (!_isExplicitExit && _minimizeToTray)
        {
            e.Cancel = true;
            WindowState = WindowState.Minimized;
            Hide();
            if (!_headless)
                _notifyIcon.ShowBalloonTip(2000, "FluxControl", "Додаток згорнуто в трей і продовжує працювати", ToolTipIcon.Info);
        }
        else
        {
            // Штатний вихід: зупиняємо сторожа і розморожуємо все, що було
            // заморожено з сайту (щоб ПК не лишився з «звисаючими» програмами).
            try { Services.WatchdogService.Stop(); } catch { }
            try { _processService.ResumeAllFrozen(); } catch { }
            try { _directLink.Stop(); } catch { }
            _notifyIcon.Visible = false;
            _notifyIcon.Dispose();
            base.OnClosing(e);
        }
    }
}
