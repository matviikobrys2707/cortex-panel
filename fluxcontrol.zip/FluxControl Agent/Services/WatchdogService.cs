using System;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace FluxControl.Agent.Services;

/// <summary>
/// «Примусовий запуск програми» (ТЗ 46): якщо хтось (гість) закрив агент у
/// трее — сторожовий процес-свидетель перезапускає його ЧЕРЕ ~10 СЕКУНД у
/// прихованому режимі (--hidden: без вікна і без іконки в треї, але з
/// повноцінним підключенням до релея). Власник у будь-який момент керує ПК.
///
/// Як це працює:
///  • основний процес при старті (коли функція увімкнена) запускає
///    FluxControl.exe --watchdog &lt;свій pid&gt; — окремий прихований процес;
///  • сторож чекає виходу основного процесу;
///  • якщо вихід «мимовільний» (немає stop-файла) — через 10 с перевіряє,
///    чи не запустився хтось інший (оновлення), і за потреби стартує новий
///    прихований екземпляр і стереже вже його;
///  • «штатний» вихід (трей «Вихід», деплой/оновлення) пише stop-файл —
///    сторож завершується, нічого не перезапускає;
///  • вимкнення функції з сайту негайно прибирає сторожа.
/// </summary>
public static class WatchdogService
{
    private static readonly object Sync = new();
    private static Process? _watchdogProcess;

    public static string StopFilePath => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
        "FluxControl",
        "watchdog.stop");

    /// <summary>Запустити сторожа для pid (якщо він ще не запущений).</summary>
    public static void EnsureStarted(int pidToWatch)
    {
        lock (Sync)
        {
            try
            {
                if (_watchdogProcess != null && !_watchdogProcess.HasExited) return;
                ClearStopFile();

                var exe = Process.GetCurrentProcess().MainModule?.FileName;
                if (string.IsNullOrEmpty(exe)) return;

                var psi = new ProcessStartInfo
                {
                    FileName = exe,
                    Arguments = $"--watchdog {pidToWatch}",
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    WindowStyle = ProcessWindowStyle.Hidden
                };
                _watchdogProcess = Process.Start(psi);
                App.Log($"Watchdog: started (pid={_watchdogProcess?.Id}) for main pid {pidToWatch}");
            }
            catch (Exception ex)
            {
                try { App.Log($"Watchdog: start failed: {ex.Message}"); } catch { }
            }
        }
    }

    /// <summary>Зупинити сторожа: штатний вихід — стоп-файл + сигнал процесу.</summary>
    public static void Stop()
    {
        lock (Sync)
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(StopFilePath)!);
                File.WriteAllText(StopFilePath, DateTimeOffset.UtcNow.ToUnixTimeMilliseconds().ToString());
            }
            catch { }

            try
            {
                if (_watchdogProcess != null && !_watchdogProcess.HasExited)
                {
                    _watchdogProcess.Kill(entireProcessTree: true);
                }
            }
            catch { }
            _watchdogProcess = null;
        }
    }

    public static void ClearStopFile()
    {
        try { if (File.Exists(StopFilePath)) File.Delete(StopFilePath); } catch { }
    }

    /// <summary>Точка входу режиму --watchdog (викликається з App.OnStartup ДО
    /// м'ютекса/вікна). Блокує потік сторожа; повертає true, якщо це був
    /// сторож-запуск і додаток має просто вийти.</summary>
    public static bool RunWatchdogIfRequested(string[] args)
    {
        int? watchedPid = null;
        for (int i = 0; i < args.Length - 1; i++)
        {
            if (args[i].Equals("--watchdog", StringComparison.OrdinalIgnoreCase) &&
                int.TryParse(args[i + 1], out int pid))
            {
                watchedPid = pid;
                break;
            }
        }
        if (watchedPid == null) return false;

        // Сторож НЕ тримає WPF, не реєструє автозапуск, не створює вікон —
        // просто тихо сидить у пам'яті (пара МБ) і чекає.
        try { App.Log($"Watchdog mode entered for pid {watchedPid}"); } catch { }

        _ = Task.Run(async () =>
        {
            int currentPid = watchedPid.Value;
            for (int generation = 0; generation < 1000; generation++)
            {
                Process? watched = null;
                try { watched = Process.GetProcessById(currentPid); } catch { }

                if (watched != null)
                {
                    // Чекаємо, поки процес живий (полінг — простіше і надійніше за handle-и).
                    while (!watched.HasExited)
                    {
                        try { await Task.Delay(1000); } catch { return; }
                    }
                    try { watched.Dispose(); } catch { }
                }

                // Основний процес зник. Чи це штатний вихід?
                if (IsStopRequested())
                {
                    try { ClearStopFile(); App.Log("Watchdog: stop file present — exiting (intentional shutdown)."); } catch { }
                    Environment.Exit(0);
                    return;
                }

                // ТЗ: «через секунд 10 вона опять открывается».
                for (int wait = 0; wait < 10; wait++)
                {
                    try { await Task.Delay(1000); } catch { return; }
                    if (IsStopRequested())
                    {
                        try { App.Log("Watchdog: stop file appeared during delay — exiting."); } catch { }
                        Environment.Exit(0);
                        return;
                    }
                }

                // Оновлення/деплой могло вже підняти новий екземпляр — тоді
                // просто переходимо на нього.
                var existing = FindAgentProcess(excludePid: 0);
                if (existing != null)
                {
                    currentPid = existing.Id;
                    try { App.Log($"Watchdog: adopting running agent pid {currentPid}."); } catch { }
                    continue;
                }

                // Функція могла бути вимкнена з сайту ДО перезапуску.
                if (!ReadForcedLaunchSetting())
                {
                    try { App.Log("Watchdog: forced-launch disabled in settings — exiting."); } catch { }
                    Environment.Exit(0);
                    return;
                }

                try
                {
                    var exe = Process.GetCurrentProcess().MainModule?.FileName;
                    if (string.IsNullOrEmpty(exe)) { Environment.Exit(0); return; }

                    var psi = new ProcessStartInfo
                    {
                        FileName = exe,
                        // --hidden: повністю невидимий запуск (без трея) — ТЗ
                        // «щоб її не було видно, але вона працювала».
                        Arguments = "--hidden",
                        UseShellExecute = false,
                        CreateNoWindow = true
                    };
                    var fresh = Process.Start(psi);
                    if (fresh == null) { Environment.Exit(0); return; }
                    fresh.WaitForExit(15000); // даємо час піднятись
                    currentPid = !fresh.HasExited ? fresh.Id : (FindAgentProcess(0)?.Id ?? 0);
                    try { App.Log($"Watchdog: relaunched hidden agent (pid={currentPid})."); } catch { }
                    if (currentPid == 0) { Environment.Exit(0); return; }
                }
                catch (Exception ex)
                {
                    try { App.Log($"Watchdog: relaunch failed: {ex.Message}"); } catch { }
                    Environment.Exit(0);
                    return;
                }
            }
        });

        // Головний потік сторожа просто спить вічно (завершення — Environment.Exit вище).
        Thread.Sleep(Timeout.Infinite);
        return true;
    }

    private static bool IsStopRequested()
    {
        try { return File.Exists(StopFilePath); } catch { return false; }
    }

    private static bool ReadForcedLaunchSetting()
    {
        try
        {
            var path = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "FluxControl", "settings.json");
            if (!File.Exists(path)) return false;
            var json = File.ReadAllText(path);
            using var doc = System.Text.Json.JsonDocument.Parse(json);
            return doc.RootElement.TryGetProperty("ForcedLaunch", out var prop) &&
                   prop.ValueKind == System.Text.Json.JsonValueKind.True;
        }
        catch { return false; }
    }

    private static Process? FindAgentProcess(int excludePid)
    {
        try
        {
            var me = Process.GetCurrentProcess().Id;
            foreach (var p in Process.GetProcessesByName("FluxControl"))
            {
                try
                {
                    if (p.Id != me && p.Id != excludePid && !p.HasExited) return p;
                }
                catch { }
            }
        }
        catch { }
        return null;
    }
}
