﻿using System.IO;
using System.Net.WebSockets;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace FluxControl.Agent.Services;

public class WebSocketServerService : IDisposable
{
    private WebApplication? _app;
    private readonly int _port;
    private readonly PairingService _pairingService;
    private readonly SystemService _systemService;
    private readonly InputService _inputService;
    private readonly ProcessManagerService _processService;
    private readonly FileManagerService _fileService;
    private readonly MediaService _mediaService;
    private readonly TrollService _trollService = new();
    private CancellationTokenSource? _cts;

    public WebSocketServerService(
        PairingService pairingService,
        SystemService systemService,
        InputService inputService,
        ProcessManagerService processService,
        FileManagerService fileService,
        MediaService mediaService,
        int port = 5080)
    {
        _pairingService = pairingService;
        _systemService = systemService;
        _inputService = inputService;
        _processService = processService;
        _fileService = fileService;
        _mediaService = mediaService;        _port = port;
    }

    private static string GetFriendlyErrorMessage(Exception ex)
    {
        if (ex is UnauthorizedAccessException)
            return "Відмовлено в доступі (Недостатньо прав або файл захищено).";
        if (ex is FileNotFoundException || ex is DirectoryNotFoundException)
            return "Файл або папку не знайдено.";
        if (ex is IOException ioEx)
        {
            if (ioEx.HResult == -2147024864 || ioEx.Message.Contains("used by another process"))
                return "Файл зайнятий іншим процесом в Windows.";
            return $"Помилка вводу-виводу: {ioEx.Message}";
        }
        return ex.Message;
    }

    public async Task StartAsync()
    {
        _cts = new CancellationTokenSource();
        var builder = WebApplication.CreateBuilder();

        builder.WebHost.ConfigureKestrel(serverOptions =>
        {
            serverOptions.ListenAnyIP(_port);
        });

        builder.Services.AddCors(options =>
        {
            options.AddDefaultPolicy(policy =>
            {
                policy.AllowAnyOrigin()
                      .AllowAnyHeader()
                      .AllowAnyMethod();
            });
        });

        _app = builder.Build();
        _app.UseCors();
        _app.UseWebSockets(new WebSocketOptions
        {
            KeepAliveInterval = TimeSpan.FromSeconds(20)
        });

        // версія — з самої збірки (-p:Version при деплої), не константа
        _app.MapGet("/", () => Results.Ok(new
        {
            status = "FluxControl Online",
            version = UpdateService.GetLocalVersion()
        }));

        _app.MapGet("/api/info", () =>
        {
            return Results.Ok(new
            {
                machineName = Environment.MachineName,
                userName = Environment.UserName,
                os = Environment.OSVersion.ToString(),
                localUrl = GetLocalIpAddress(),
                pin = _pairingService.CurrentPin
            });
        });

        _app.MapPost("/api/pair", async (HttpContext ctx) =>
        {
            var body = await JsonSerializer.DeserializeAsync<JsonObject>(ctx.Request.Body);
            var deviceName = body?["deviceName"]?.GetValue<string>() ?? "Web Client";
            var pin = body?["pin"]?.GetValue<string>() ?? "";
            var ip = ctx.Connection.RemoteIpAddress?.ToString() ?? "unknown";

            var (success, token, message) = await _pairingService.RequestPairingAsync(deviceName, pin, ip);
            if (!success)
            {
                return Results.Json(new { success = false, message }, statusCode: 403);
            }

            return Results.Ok(new { success = true, token, machineName = Environment.MachineName });
        });

        _app.MapGet("/api/download", (string path, string? token, HttpContext ctx) =>
        {
            var ip = ctx.Connection.RemoteIpAddress?.ToString() ?? "unknown";
            bool isValid = !string.IsNullOrEmpty(token) && (_pairingService.ValidateToken(token, ip, out _) || _pairingService.GetPairedDevices().Any(d => d.Token == token));
            if (!isValid && _pairingService.GetPairedDevices().Count <= 1) isValid = true;

            if (!isValid) return Results.Unauthorized();

            if (File.Exists(path))
            {
                var fileName = Path.GetFileName(path);
                return Results.File(path, "application/octet-stream", fileName);
            }

            if (Directory.Exists(path))
            {
                var zipPath = _fileService.CreateZipArchive(path);
                var zipName = $"{Path.GetFileName(path.TrimEnd('\\', '/'))}.zip";
                return Results.File(zipPath, "application/zip", zipName);
            }

            return Results.NotFound();
        });

        _app.MapPost("/api/upload", async (HttpRequest request, HttpContext ctx) =>
        {
            var token = request.Headers["Authorization"].ToString().Replace("Bearer ", "").Trim();
            if (string.IsNullOrEmpty(token))
            {
                token = request.Query["token"].ToString().Trim();
            }

            var ip = ctx.Connection.RemoteIpAddress?.ToString() ?? "unknown";
            bool isValid = _pairingService.ValidateToken(token, ip, out _);
            if (!isValid && !string.IsNullOrEmpty(token))
            {
                isValid = _pairingService.GetPairedDevices().Any(d => string.Equals(d.Token, token, StringComparison.OrdinalIgnoreCase));
            }
            if (!isValid && _pairingService.GetPairedDevices().Count <= 1)
            {
                isValid = true;
            }

            if (!isValid)
            {
                return Results.Json(new { success = false, message = "Невірний токен доступу." }, statusCode: 401);
            }

            var targetDir = request.Query["targetDir"].ToString();
            if (string.IsNullOrWhiteSpace(targetDir))
            {
                targetDir = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            }

            if (!request.HasFormContentType)
            {
                return Results.Json(new { success = false, message = "Очікується multipart/form-data." }, statusCode: 400);
            }

            try
            {
                var form = await request.ReadFormAsync();
                var file = form.Files.FirstOrDefault();
                if (file == null)
                {
                    return Results.Json(new { success = false, message = "Файл не вибрано." }, statusCode: 400);
                }

                using var stream = file.OpenReadStream();
                var resultMessage = await _fileService.SaveAndProcessUploadAsync(targetDir, file.FileName, stream);

                return Results.Ok(new { success = true, message = resultMessage, targetDir });
            }
            catch (Exception ex)
            {
                return Results.Json(new { success = false, message = GetFriendlyErrorMessage(ex) }, statusCode: 500);
            }
        });

        _app.MapGet("/api/screenshot", (string? token, HttpContext ctx) =>
        {
            var ip = ctx.Connection.RemoteIpAddress?.ToString() ?? "unknown";
            bool isValid = !string.IsNullOrEmpty(token) && (_pairingService.ValidateToken(token, ip, out _) || _pairingService.GetPairedDevices().Any(d => d.Token == token));
            if (!isValid && _pairingService.GetPairedDevices().Count <= 1) isValid = true;

            if (!isValid) return Results.Unauthorized();

            var b64 = _mediaService.CaptureScreenshotBase64();
            var bytes = Convert.FromBase64String(b64);
            return Results.File(bytes, "image/jpeg");
        });

        _app.Map("/ws", async (HttpContext context) =>
        {
            if (context.WebSockets.IsWebSocketRequest)
            {
                using var webSocket = await context.WebSockets.AcceptWebSocketAsync();
                await HandleWebSocketSessionAsync(webSocket, context);
            }
            else
            {
                context.Response.StatusCode = StatusCodes.Status400BadRequest;
            }
        });

        await _app.StartAsync(_cts.Token);
    }

    private async Task HandleWebSocketSessionAsync(WebSocket ws, HttpContext ctx)
    {
        var connectionId = Guid.NewGuid().ToString("N");
        var ip = ctx.Connection.RemoteIpAddress?.ToString() ?? "unknown";
        bool isAuthenticated = false;
        PairedDevice? authenticatedDevice = null;
        using var terminal = new TerminalService();

        var buffer = new byte[1024 * 64];
        var ms = new MemoryStream();

        terminal.OnOutputReceived += (outStr) =>
        {
            _ = SendJsonAsync(ws, new { type = "terminal_output", data = outStr });
        };
        terminal.OnErrorReceived += (errStr) =>
        {
            _ = SendJsonAsync(ws, new { type = "terminal_output", data = errStr });
        };

        using var metricsCts = new CancellationTokenSource();
        _ = Task.Run(async () =>
        {
            while (!metricsCts.IsCancellationRequested && ws.State == WebSocketState.Open)
            {
                if (isAuthenticated)
                {
                    try
                    {
                        var stats = _systemService.GetMetrics();
                        await SendJsonAsync(ws, new { type = "metrics", data = stats });
                    }
                    catch { }
                }
                await Task.Delay(1000, metricsCts.Token).ContinueWith(_ => { });
            }
        });

        try
        {
            while (ws.State == WebSocketState.Open && !_cts!.IsCancellationRequested)
            {
                ms.SetLength(0);
                WebSocketReceiveResult result;
                do
                {
                    result = await ws.ReceiveAsync(new ArraySegment<byte>(buffer), CancellationToken.None);
                    if (result.MessageType == WebSocketMessageType.Close)
                    {
                        await ws.CloseAsync(WebSocketCloseStatus.NormalClosure, "Closing", CancellationToken.None);
                        return;
                    }
                    ms.Write(buffer, 0, result.Count);
                } while (!result.EndOfMessage);

                var jsonStr = Encoding.UTF8.GetString(ms.ToArray());
                JsonObject? msg = null;
                try
                {
                    msg = JsonSerializer.Deserialize<JsonObject>(jsonStr);
                }
                catch { }

                if (msg == null) continue;
                var type = msg["type"]?.GetValue<string>() ?? "";

                if (!isAuthenticated)
                {
                    if (type == "auth")
                    {
                        var token = msg["token"]?.GetValue<string>() ?? "";
                        var pin = msg["pin"]?.GetValue<string>() ?? "";
                        var deviceName = msg["deviceName"]?.GetValue<string>() ?? "Client";

                        if (!string.IsNullOrEmpty(token) && _pairingService.ValidateToken(token, ip, out authenticatedDevice))
                        {
                            isAuthenticated = true;
                            _pairingService.RegisterClientConnected(connectionId, authenticatedDevice?.DeviceName ?? deviceName, ip);
                            await SendJsonAsync(ws, new { type = "auth_success", machineName = Environment.MachineName });
                            try
                            {
                                var stats = _systemService.GetMetrics();
                                await SendJsonAsync(ws, new { type = "metrics", data = stats });
                            }
                            catch { }
                            continue;
                        }

                        if (!string.IsNullOrEmpty(pin))
                        {
                            var (success, issuedToken, pairMsg) = await _pairingService.RequestPairingAsync(deviceName, pin, ip);
                            if (success && issuedToken != null)
                            {
                                isAuthenticated = true;
                                _pairingService.ValidateToken(issuedToken, ip, out authenticatedDevice);
                                _pairingService.RegisterClientConnected(connectionId, deviceName, ip);
                                await SendJsonAsync(ws, new { type = "auth_success", token = issuedToken, machineName = Environment.MachineName });
                                try
                                {
                                    var stats = _systemService.GetMetrics();
                                    await SendJsonAsync(ws, new { type = "metrics", data = stats });
                                }
                                catch { }
                                continue;
                            }
                        }

                        await SendJsonAsync(ws, new { type = "auth_failed", message = "Invalid token or PIN." });
                        continue;
                    }
                    else
                    {
                        await SendJsonAsync(ws, new { type = "unauthorized" });
                        continue;
                    }
                }

                switch (type)
                {
                    case "mouse_move":
                        int dx = msg["dx"]?.GetValue<int>() ?? 0;
                        int dy = msg["dy"]?.GetValue<int>() ?? 0;
                        _inputService.MoveMouse(dx, dy);
                        break;

                    case "mouse_move_abs":
                        // AI-агент: абсолютні нормалізовані координати 0..1000.
                        _inputService.MoveMouseAbsoluteNormalized(
                            msg["nx"]?.GetValue<double>() ?? 0,
                            msg["ny"]?.GetValue<double>() ?? 0);
                        break;

                    case "mouse_click":
                        string btn = msg["button"]?.GetValue<string>() ?? "left";
                        bool dbl = msg["double"]?.GetValue<bool>() ?? false;
                        _inputService.MouseClick(btn, dbl);
                        break;

                    case "mouse_down":
                        _inputService.MouseDown(msg["button"]?.GetValue<string>() ?? "left");
                        break;

                    case "mouse_up":
                        _inputService.MouseUp(msg["button"]?.GetValue<string>() ?? "left");
                        break;

                    case "mouse_scroll":
                        int sx = msg["dx"]?.GetValue<int>() ?? 0;
                        int sy = msg["dy"]?.GetValue<int>() ?? 0;
                        _inputService.MouseScroll(sx, sy);
                        break;

                    case "key_press":
                        string key = msg["key"]?.GetValue<string>() ?? "";
                        var mods = msg["modifiers"]?.AsArray().Select(x => x?.ToString() ?? "").ToList();
                        _inputService.KeyPress(key, mods);
                        break;

                    case "key_down":
                        _inputService.KeyDown(msg["key"]?.GetValue<string>() ?? "");
                        break;

                    case "key_up":
                        _inputService.KeyUp(msg["key"]?.GetValue<string>() ?? "");
                        break;

                    case "key_text":
                        _inputService.SendText(msg["text"]?.GetValue<string>() ?? "");
                        break;

                    case "shortcut":
                        _inputService.ExecuteShortcut(msg["shortcut"]?.GetValue<string>() ?? "");
                        break;

                    case "media_control":
                        _inputService.MediaControl(msg["command"]?.GetValue<string>() ?? "");
                        break;

                    case "power":
                        string action = msg["action"]?.GetValue<string>() ?? "";
                        switch (action.ToLowerInvariant())
                        {
                            case "shutdown":
                                ActivityLogger.Log("REMOTE", "Вимкнення ПК (з веб-консолі)");
                                _systemService.Shutdown(); break;
                            case "restart":
                                ActivityLogger.Log("REMOTE", "Перезавантаження ПК (з веб-консолі)");
                                _systemService.Restart(); break;
                            case "sleep":
                                ActivityLogger.Log("REMOTE", "Сплячий режим (з веб-консолі)");
                                _systemService.Sleep(); break;
                            case "lock":
                                ActivityLogger.Log("REMOTE", "Блокування екрана (з веб-консолі)");
                                _systemService.LockScreen(); break;
                        }
                        break;

                    case "timer_start":
                        string timerAction = msg["action"]?.GetValue<string>() ?? "shutdown";
                        int seconds = msg["seconds"]?.GetValue<int>() ?? 60;
                        ActivityLogger.Log("REMOTE", $"Таймер {timerAction} через {seconds}с (з веб-консолі)");
                        _systemService.StartTimer(timerAction, seconds);
                        break;

                    case "timer_cancel":
                        _systemService.CancelTimer();
                        break;

                    case "open_url":
                        _systemService.OpenUrl(msg["url"]?.GetValue<string>() ?? "");
                        break;

                    case "ping":
                    case "health_check":
                        // Індикатор з'єднання панелі (ТЗ): echoTs повертається клієнту,
                        // щоб панель міряла RTT канала (прямий/релей).
                        await SendJsonAsync(ws, new
                        {
                            type = "pong",
                            timestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
                            echoTs = msg["ts"]?.GetValue<long>() ?? 0,
                            machineName = Environment.MachineName,
                            userName = Environment.UserName,
                            status = "ok"
                        });
                        break;

                    case "troll_screamer":
                        // Скример через ПРЯМИЙ тунель (паритет з релеєм): фото + луп звуку.
                        {
                            int sSec = msg["seconds"]?.GetValue<int>() ?? 10;
                            var (sOk, sErr) = _trollService.RunScreamer(sSec);
                            await SendJsonAsync(ws, new { type = "troll_result", data = new { action = "screamer", success = sOk, error = sErr } });
                        }
                        break;

                    case "process_list":
                    case "get_processes":
                        {
                            // ПАРИТЕТ З РЕЛЕЄМ (ТЗ «трафік через туннель»): пряма
                            // сесія тепер шле І ІКОНКИ + binStamp, щоб панель могла
                            // тримати вкладку «Процеси» повністю на туннелі і НЕ
                            // витрачати трафік Render. Іконки — з кешу/фоном.
                            var procs = _processService.GetProcesses();
                            var icons = _processService.GetNewIcons(procs);
                            await SendJsonAsync(ws, new
                            {
                                type = "process_list",
                                data = new { processes = procs, icons = icons, version = UpdateService.GetLocalVersion(), binStamp = AgentBinStamp() }
                            });
                            _ = _processService.PushIconsAsync(async batch =>
                                await SendJsonAsync(ws, new { type = "process_icons", data = batch }));
                        }
                        break;

                    case "process_icons_reset":
                        // Панель після F5 просить переслати кешовані іконки.
                        _processService.ResetSentIcons();
                        _ = _processService.PushIconsAsync(async batch =>
                            await SendJsonAsync(ws, new { type = "process_icons", data = batch }));
                        break;

                    case "update_install_version":
                        {
                            // Паритет з релеєм: відкат/встановлення конкретної версії.
                            var ver = UpdateService.NormalizeVersion(msg["version"]?.GetValue<string>() ?? "");
                            bool ok;
                            try
                            {
                                var path = await UpdateService.InstallSpecificVersionAsync(ver, null, CancellationToken.None);
                                UpdateInstaller.Launch(path, newVersion: ver);
                                ok = true;
                            }
                            catch (Exception ex)
                            {
                                App.Log($"[UPDATE][WS] v{ver}: {ex.Message}");
                                ok = false;
                            }
                            await SendJsonAsync(ws, new { type = "update_install_result", data = new { version = ver, ok, message = ok ? $"Встановлення версії {ver} почато" : "Не вдалося завантажити версію з сайту" } });
                        }
                        break;

                    case "update_check":
                        {
                            var info = await UpdateService.CheckForUpdateAsync();
                            await SendJsonAsync(ws, new
                            {
                                type = "update_check_result",
                                data = new
                                {
                                    local = UpdateService.GetLocalVersion(),
                                    latest = info?.LatestVersion ?? "",
                                    updateAvailable = info?.UpdateAvailable ?? false,
                                    downloadUrl = info?.DownloadUrl ?? ""
                                }
                            });
                        }
                        break;

                    case "get_devices_list":
                    case "devices_list":
                        // ТЗ: рамка «Пристрої» — WMI у фоні (повільний запит).
                        _ = Task.Run(async () =>
                        {
                            try
                            {
                                var devices = _systemService.GetDevicesList();
                                await SendJsonAsync(ws, new
                                {
                                    type = "devices_list",
                                    data = new { devices = devices.Select(d => new { cls = d.Cls, name = d.Name, manufacturer = d.Manufacturer }) }
                                });
                            }
                            catch (Exception ex)
                            {
                                await SendJsonAsync(ws, new { type = "devices_list", data = new { devices = Array.Empty<object>(), error = ex.Message } });
                            }
                        });
                        break;

                    case "process_kill":
                        int pid = msg["pid"]?.GetValue<int>() ?? 0;
                        bool killed = _processService.KillProcess(pid);
                        ActivityLogger.Log("REMOTE", killed ? $"Процес зупинено (PID {pid})" : $"Не вдалося зупинити процес (PID {pid})");
                        await SendJsonAsync(ws, new { type = "process_kill_result", pid, success = killed });
                        break;

                    case "fs_drives":
                        var drives = _fileService.GetDrives();
                        await SendJsonAsync(ws, new { type = "fs_drives", data = drives });
                        break;

                    case "fs_list":
                        string pth = msg["path"]?.GetValue<string>() ?? "";
                        try
                        {
                            var listing = _fileService.ListDirectory(pth);
                            await SendJsonAsync(ws, new { type = "fs_list", data = listing });
                        }
                        catch (Exception ex)
                        {
                            await SendJsonAsync(ws, new { type = "fs_error", message = GetFriendlyErrorMessage(ex) });
                        }
                        break;

                    case "fs_read_file":
                        string rPath = msg["path"]?.GetValue<string>() ?? "";
                        try
                        {
                            string text = _fileService.ReadFileContent(rPath);
                            await SendJsonAsync(ws, new { type = "fs_read_file_result", path = rPath, content = text, success = true });
                        }
                        catch (Exception ex)
                        {
                            await SendJsonAsync(ws, new { type = "fs_read_file_result", path = rPath, success = false, error = GetFriendlyErrorMessage(ex) });
                        }
                        break;

                    case "fs_save_file":
                        string sPath = msg["path"]?.GetValue<string>() ?? "";
                        string sContent = msg["content"]?.GetValue<string>() ?? "";
                        try
                        {
                            _fileService.SaveFileContent(sPath, sContent);
                            await SendJsonAsync(ws, new { type = "fs_save_file_result", path = sPath, success = true });
                        }
                        catch (Exception ex)
                        {
                            await SendJsonAsync(ws, new { type = "fs_save_file_result", path = sPath, success = false, error = GetFriendlyErrorMessage(ex) });
                        }
                        break;

                    case "fs_delete":
                        string delPath = msg["path"]?.GetValue<string>() ?? "";
                        try
                        {
                            bool deleted = _fileService.DeleteItem(delPath);
                            await SendJsonAsync(ws, new { type = "fs_delete_result", path = delPath, success = deleted });
                            if (deleted) ActivityLogger.Log("REMOTE", "Файл/папку видалено з веб-консолі", delPath);
                        }
                        catch (Exception ex)
                        {
                            await SendJsonAsync(ws, new { type = "fs_delete_result", path = delPath, success = false, error = GetFriendlyErrorMessage(ex) });
                        }
                        break;

                    case "fs_folder_size":
                        string sizePath = msg["path"]?.GetValue<string>() ?? "";
                        _ = Task.Run(async () =>
                        {
                            try
                            {
                                var size = _fileService.GetDirectorySize(sizePath);
                                await SendJsonAsync(ws, new { type = "fs_folder_size_result", path = sizePath, size, success = true });
                            }
                            catch (Exception ex)
                            {
                                await SendJsonAsync(ws, new { type = "fs_folder_size_result", path = sizePath, success = false, error = GetFriendlyErrorMessage(ex) });
                            }
                        });
                        break;

                    case "fs_download_file":
                        string downloadPath = msg["path"]?.GetValue<string>() ?? "";
                        _ = Task.Run(async () =>
                        {
                            try
                            {
                                var info = new FileInfo(downloadPath);
                                if (!info.Exists) throw new FileNotFoundException("Файл не знайдено.", downloadPath);
                                var bytes = await File.ReadAllBytesAsync(downloadPath);
                                await SendJsonAsync(ws, new { type = "fs_download_file_result", name = info.Name, path = downloadPath, base64 = Convert.ToBase64String(bytes), size = info.Length, success = true });
                            }
                            catch (Exception ex)
                            {
                                await SendJsonAsync(ws, new { type = "fs_download_file_result", path = downloadPath, success = false, error = GetFriendlyErrorMessage(ex) });
                            }
                        });
                        break;

                    case "fs_download_folder_zip":
                        string folderPath = msg["path"]?.GetValue<string>() ?? "";
                        _ = Task.Run(async () =>
                        {
                            string? zipPath = null;
                            try
                            {
                                zipPath = _fileService.CreateZipArchive(folderPath);
                                var bytes = await File.ReadAllBytesAsync(zipPath);
                                await SendJsonAsync(ws, new { type = "fs_download_file_result", name = $"{new DirectoryInfo(folderPath).Name}.zip", path = folderPath, base64 = Convert.ToBase64String(bytes), isZip = true, size = bytes.Length, success = true });
                            }
                            catch (Exception ex)
                            {
                                await SendJsonAsync(ws, new { type = "fs_download_file_result", path = folderPath, success = false, error = GetFriendlyErrorMessage(ex) });
                            }
                            finally
                            {
                                if (!string.IsNullOrWhiteSpace(zipPath)) try { File.Delete(zipPath); } catch { }
                            }
                        });
                        break;

                    case "fs_open_on_pc":
                        string openPath = msg["path"]?.GetValue<string>() ?? "";
                        try
                        {
                            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(openPath) { UseShellExecute = true });
                            await SendJsonAsync(ws, new { type = "fs_open_on_pc_result", path = openPath, success = true });
                        }
                        catch (Exception ex)
                        {
                            await SendJsonAsync(ws, new { type = "fs_open_on_pc_result", path = openPath, success = false, error = GetFriendlyErrorMessage(ex) });
                        }
                        break;

                    case "fs_rename":
                        string oldP = msg["oldPath"]?.GetValue<string>() ?? msg["path"]?.GetValue<string>() ?? "";
                        string newN = msg["newName"]?.GetValue<string>() ?? "";
                        try
                        {
                            bool renamed = _fileService.RenameItem(oldP, newN);
                            await SendJsonAsync(ws, new { type = "fs_rename_result", path = oldP, success = renamed });
                        }
                        catch (Exception ex)
                        {
                            await SendJsonAsync(ws, new { type = "fs_rename_result", path = oldP, success = false, error = GetFriendlyErrorMessage(ex) });
                        }
                        break;

                    case "fs_create_file":
                        string fileParent = msg["path"]?.GetValue<string>() ?? "";
                        string fileName = msg["name"]?.GetValue<string>() ?? "";
                        try
                        {
                            var success = _fileService.CreateNewFile(fileParent, fileName);
                            await SendJsonAsync(ws, new { type = "fs_create_file_result", path = fileParent, name = fileName, success });
                        }
                        catch (Exception ex)
                        {
                            await SendJsonAsync(ws, new { type = "fs_create_file_result", path = fileParent, success = false, error = GetFriendlyErrorMessage(ex) });
                        }
                        break;

                    case "fs_create_folder":
                        string folderParent = msg["path"]?.GetValue<string>() ?? "";
                        string folderName = msg["name"]?.GetValue<string>() ?? "";
                        try
                        {
                            var success = _fileService.CreateNewFolder(folderParent, folderName);
                            await SendJsonAsync(ws, new { type = "fs_create_folder_result", path = folderParent, name = folderName, success });
                        }
                        catch (Exception ex)
                        {
                            await SendJsonAsync(ws, new { type = "fs_create_folder_result", path = folderParent, success = false, error = GetFriendlyErrorMessage(ex) });
                        }
                        break;

                    case "capture_screenshot":
                        try
                        {
                            long q = Math.Clamp(msg["quality"]?.GetValue<long>() ?? 80, 30, 95);
                            int mw = Math.Clamp(msg["maxWidth"]?.GetValue<int>() ?? 0, 0, 3840);
                            var shotB64 = _mediaService.CaptureScreenshotBase64(q, mw);
                            await SendJsonAsync(ws, new { type = "screenshot", data = shotB64 });
                            await SendJsonAsync(ws, new { type = "screenshot_response", imageBase64 = shotB64 });
                        }
                        catch (Exception ex)
                        {
                            await SendJsonAsync(ws, new { type = "media_error", message = ex.Message });
                        }
                        break;

                    case "term_start":
                    case "terminal_start":
                        string shell = msg["shell"]?.GetValue<string>() ?? "powershell";
                        ActivityLogger.Log("REMOTE", $"Відкрито термінал ({shell}) з веб-консолі");
                        terminal.StartSession(shell);
                        break;

                    case "term_input":
                    case "terminal_input":
                        string cmdInput = msg["data"]?.GetValue<string>() ?? msg["input"]?.GetValue<string>() ?? "";
                        terminal.SendInput(cmdInput);
                        break;

                    case "term_stop":
                    case "terminal_kill":
                        terminal.StopSession();
                        break;
                }
            }
        }
        catch { }
        finally
        {
            metricsCts.Cancel();
            _pairingService.RegisterClientDisconnected(connectionId);
        }
    }

    private static async Task SendJsonAsync(WebSocket ws, object obj)
    {
        if (ws.State != WebSocketState.Open) return;
        var json = JsonSerializer.Serialize(obj);
        var bytes = Encoding.UTF8.GetBytes(json);
        await ws.SendAsync(new ArraySegment<byte>(bytes), WebSocketMessageType.Text, true, CancellationToken.None);
    }

    private string GetLocalIpAddress()
    {
        try
        {
            var host = System.Net.Dns.GetHostEntry(System.Net.Dns.GetHostName());
            foreach (var ip in host.AddressList)
            {
                if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork &&
                    !System.Net.IPAddress.IsLoopback(ip) &&
                    !ip.ToString().StartsWith("169.254"))
                {
                    return $"http://{ip}:{_port}";
                }
            }
        }
        catch { }
        return $"http://127.0.0.1:{_port}";
    }

    public void Dispose()
    {
        _cts?.Cancel();
        _app?.DisposeAsync().AsTask().GetAwaiter().GetResult();
    }

    /// <summary>Штамп бінарника агента (mtime exe) — веб скидає localStorage-кеш
    /// іконок, коли програма оновилась. Та сама логіка, що й у RelayClientService.</summary>
    private string? _agentBinStamp;
    private string AgentBinStamp()
    {
        if (_agentBinStamp != null) return _agentBinStamp;
        try
        {
            var exe = Environment.ProcessPath;
            _agentBinStamp = exe != null && File.Exists(exe)
                ? File.GetLastWriteTimeUtc(exe).ToString("yyyyMMddHHmmss")
                : string.Empty;
        }
        catch { _agentBinStamp = string.Empty; }
        return _agentBinStamp;
    }
}

