using System.Collections.Concurrent;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;

namespace FluxControl.Agent.Services;

public class ProcessItem
{
    public int Pid { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public double MemoryMb { get; set; }
    public float CpuPercent { get; set; }
    public string ExePath { get; set; } = string.Empty;
    /// <summary>"app" (має вікно) | "background" | "system" (сесія 0) — як у Task Manager.</summary>
    public string Category { get; set; } = "background";
    /// <summary>true = програма НЕ відповідає (не обробляє повідомлення вікна) — веб малює червону рамку.</summary>
    public bool? Responding { get; set; }
    /// <summary>Процес заморожено з сайту (NtSuspendProcess).</summary>
    public bool Frozen { get; set; }
    /// <summary>Чи має процес видиме головне вікно (можна витягнути на передній план).</summary>
    public bool HasWindow { get; set; }
}

public class ProcessManagerService
{
    // ТЗ 53: 24 за виклик (було 12) + швидший фоновий пуш (90мс) — іконки
    // списку processes з'являються практично миттєво, а не «через раз».
    private const int MaxIconExtractionsPerCall = 24;
    private const int IconPushDelayMs = 90;
    /// <summary>Скільки часу НЕ ретраїмо невдалу екстракцію іконки (мс). Раніше
    /// негативний кеш був назавжди: одна випадкова помилка (процес вийшов під
    /// час читання, антивірус заблокував файл) — і іконка цієї програми ніколи
    /// більше не з'являлася. Тепер ретраїмо кожні 90 секунд.</summary>
    private const long IconFailRetryMs = 90_000;

    /// <summary>ТЗ 55: маркер «справжню іконку добути не вдалося» у кеші. Замість
    /// порожнього значення кладе ЗАГЛУШКУ — стандартну іконку Windows «без
    /// іконки» (білий прямокутник + блакитний прямокутник у центрі), щоб
    /// системні процеси типу ApplicationFrameHost/TextInputHost і Memory
    /// Compression не виглядали «безіконковими». Заглушка надсилається одразу,
    /// а ретрай справжньої екстракції триває за IconFailRetryMs.</summary>
    private const string GenericMarker = "GENERIC";

    // Кешована заглушка (рендериться один раз).
    private static string? _genericIconUrl;

    /// <summary>
    /// Заглушка «програма без іконки» (ТЗ юзера): РЕАЛЬНА стандартна іконка
    /// Windows, яку система ставить програмам без власної іконки — беремо її
    /// з %SystemRoot%\System32\svchost.exe (є в кожній Windows). Витягується
    /// один раз тими самими шляхами, що й іконки звичайних програм; якщо
    /// екстракція раптом не вдалася — малюємо резервний «аркуш» GDI+.
    /// </summary>
    private static string GetGenericIconDataUrl()
    {
        if (_genericIconUrl != null) return _genericIconUrl;

        // 1) ТЗ: іконка svchost.exe — стандартна іконка Windows «без іконки».
        try
        {
            var svchostPath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.System), "svchost.exe");
            if (File.Exists(svchostPath))
            {
                var url = ExtractIconDataUrl(svchostPath);
                if (!string.IsNullOrEmpty(url))
                {
                    _genericIconUrl = url;
                    return url;
                }
            }
        }
        catch { }

        // 2) Резерв: класичний «білий аркуш із блакитним прямокутником».
        try
        {
            using var bmp = new Bitmap(48, 48, PixelFormat.Format32bppArgb);
            using (var g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                g.Clear(Color.Transparent);

                using var pageFill = new SolidBrush(Color.FromArgb(246, 248, 251));
                using var pageBorder = new Pen(Color.FromArgb(186, 196, 208), 1.6f);
                var pageRect = new Rectangle(6, 4, 36, 40);
                using (var pagePath = RoundedPath(pageRect, 6))
                {
                    g.FillPath(pageFill, pagePath);
                    g.DrawPath(pageBorder, pagePath);
                }

                using var blueFill = new SolidBrush(Color.FromArgb(90, 162, 232));
                using var blueBorder = new Pen(Color.FromArgb(56, 128, 194), 1.2f);
                var blueRect = new Rectangle(15, 17, 18, 14);
                using (var bluePath = RoundedPath(blueRect, 3))
                {
                    g.FillPath(blueFill, bluePath);
                    g.DrawPath(blueBorder, bluePath);
                }
            }
            var url = ToPngDataUrl(bmp, 48);
            _genericIconUrl = url ?? string.Empty;
        }
        catch { _genericIconUrl = string.Empty; }
        return _genericIconUrl;
    }

    /// <summary>Допоміжний шлях із заокругленими кутами для заглушки.</summary>
    private static System.Drawing.Drawing2D.GraphicsPath RoundedPath(Rectangle r, int radius)
    {
        var path = new System.Drawing.Drawing2D.GraphicsPath();
        var d = radius * 2;
        path.AddArc(r.X, r.Y, d, d, 180, 90);
        path.AddArc(r.Right - d, r.Y, d, d, 270, 90);
        path.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
        path.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
        path.CloseFigure();
        return path;
    }

    // exePath (lowercase) → PNG data URL | GenericMarker = екстракція поки не вдалася
    private readonly ConcurrentDictionary<string, string> _iconCache = new();
    // exePath (lowercase) → Environment.TickCount64 останньої невдалої екстракції
    private readonly ConcurrentDictionary<string, long> _iconFailAt = new();
    private readonly HashSet<string> _sentIconKeys = new(StringComparer.Ordinal);
    private readonly object _sentIconLock = new();

    // Per-PID CPU sampling: TotalProcessorTime ticks + wall-clock ticks of the
    // previous GetProcesses() call. Real CPU% = Δcpu / Δwall × 100 / cores —
    // the same math Task Manager uses, without PerformanceCounter spam.
    private readonly ConcurrentDictionary<int, (long CpuTicks, long WallTicks)> _lastCpuSample = new();

    // Заморожені з сайту процеси (ТЗ 46): NtSuspendProcess тримається, доки
    // ми явно не розморозимо — список потрібен і для прапорця у списку.
    private readonly ConcurrentDictionary<int, byte> _frozenPids = new();

    // Усі exe-шляхи останнього списку (для фонового добування іконок) + guard
    // від паралельного фонового пуша.
    private string[] _lastIconPaths = Array.Empty<string>();
    private int _iconPushRunning;

    public List<ProcessItem> GetProcesses()
    {
        var result = new List<ProcessItem>();
        var processes = Process.GetProcesses();
        long nowTicks = DateTime.UtcNow.Ticks;
        double coreCount = Math.Max(1, Environment.ProcessorCount);
        var alivePids = new HashSet<int>();

        foreach (var p in processes)
        {
            try
            {
                string exePath = string.Empty;
                try { exePath = p.MainModule?.FileName ?? string.Empty; }
                catch { exePath = string.Empty; } // access denied / exited / bitness mismatch

                var mem = Math.Round(p.WorkingSet64 / (1024.0 * 1024.0), 1);

                // ---- Category (Task Manager logic) ----
                string category = "background";
                try
                {
                    if (!string.IsNullOrEmpty(p.MainWindowTitle)) category = "app";
                    else if (p.SessionId == 0) category = "system";
                }
                catch { /* SessionId may throw for exited processes */ }

                // ---- «Не відповідає» / має вікно (ТЗ 46: червона рамка) ----
                bool? responding = null;
                bool hasWindow = false;
                try
                {
                    hasWindow = p.MainWindowHandle != IntPtr.Zero;
                    if (category == "app" && hasWindow) responding = p.Responding;
                }
                catch { /* exited between calls */ }

                // ---- Real CPU% (delta of TotalProcessorTime) ----
                float cpuPercent = 0f;
                try
                {
                    long cpuTicks = p.TotalProcessorTime.Ticks;
                    alivePids.Add(p.Id);
                    if (_lastCpuSample.TryGetValue(p.Id, out var prev))
                    {
                        long dWall = nowTicks - prev.WallTicks;
                        long dCpu = cpuTicks - prev.CpuTicks;
                        if (dWall > 0 && dCpu > 0)
                        {
                            cpuPercent = (float)Math.Clamp(dCpu / (dWall * coreCount) * 100.0, 0.0, 100.0);
                        }
                    }
                    _lastCpuSample[p.Id] = (cpuTicks, nowTicks);
                }
                catch { /* process may exit between calls */ }

                result.Add(new ProcessItem
                {
                    Pid = p.Id,
                    Name = p.ProcessName,
                    Title = p.MainWindowTitle,
                    MemoryMb = mem,
                    CpuPercent = cpuPercent,
                    ExePath = exePath,
                    Category = category,
                    Responding = responding,
                    Frozen = _frozenPids.ContainsKey(p.Id),
                    HasWindow = hasWindow
                });
            }
            catch
            {
                // Access denied or process exited
            }
        }

        // Drop samples of processes that no longer exist (PID reuse guard).
        foreach (var stalePid in _lastCpuSample.Keys)
        {
            if (!alivePids.Contains(stalePid))
            {
                _lastCpuSample.TryRemove(stalePid, out _);
                _frozenPids.TryRemove(stalePid, out _); // процес помер — заморозка вже не актуальна
            }
        }

        // Запам'ятовуємо всі exe-шляхи — фоновий пуш добуде іконки для всіх,
        // а не тільки для перших 12.
        _lastIconPaths = result
            .Where(p => !string.IsNullOrWhiteSpace(p.ExePath))
            .Select(p => p.ExePath)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToArray();

        // ТЗ: сортування ЗА НАЗВОЮ (алфавіт) — веб теж сортує за алфавітом.
        return result.OrderBy(p => p.Name, StringComparer.OrdinalIgnoreCase).Take(200).ToList();
    }

    /// <summary>
    /// true = іконка для цього ключа вже готова АБО невдача ще «свіжа»
    /// (ретрай пізніше). Протилежність — настав час спробувати знову.
    /// </summary>
    private bool IconReadyOrCooldown(string key)
    {
        if (_iconCache.TryGetValue(key, out var v))
        {
            if (!string.IsNullOrEmpty(v)) return true; // готово
            if (_iconFailAt.TryGetValue(key, out var t) &&
                Environment.TickCount64 - t < IconFailRetryMs) return true; // нещодавно фейкнулась
            _iconCache.TryRemove(key, out _); // стара невдача — ретраїмо
        }
        return false;
    }

    /// <summary>Екстракція з записом результату в кеш (успіх / заглушка + час).
    /// Якщо після серії невдач справжня іконка ТАКІ отримана — ключ повертається
    /// у чергу надсилання (веб побачить апгрейд заглушки → справжня іконка).</summary>
    private string ExtractAndCache(string exePath, string key)
    {
        var dataUrl = ExtractIconDataUrl(exePath);
        if (string.IsNullOrEmpty(dataUrl))
        {
            _iconFailAt[key] = Environment.TickCount64;
            _iconCache[key] = GenericMarker;
            return GenericMarker;
        }
        _iconFailAt.TryRemove(key, out _);
        var wasGeneric = _iconCache.TryGetValue(key, out var prev) && prev == GenericMarker;
        _iconCache[key] = dataUrl;
        if (wasGeneric) MarkIconResendNeeded(key); // заглушка → справжня: перешлимо
        return dataUrl;
    }

    private void MarkIconResendNeeded(string key)
    {
        lock (_sentIconLock) { _sentIconKeys.Remove(key); }
    }

    /// <summary>
    /// ФОНОВЕ добування іконок для ВСІХ процесів останнього списку.
    /// Кеш уже містить перші 12 (з GetNewIcons) — цей метод добуде решту
    /// і надішле вебу окремими повідомленнями process_icons (партіями по 1),
    /// щоб списки іконок з'являлися поступово без перезапиту списку.
    /// </summary>
    public async Task PushIconsAsync(Func<Dictionary<string, string>, Task> sendBatch)
    {
        if (Interlocked.CompareExchange(ref _iconPushRunning, 1, 0) != 0) return;
        try
        {
            foreach (var path in _lastIconPaths)
            {
                var key = path.ToLowerInvariant();
                string dataUrl;
                if (IconReadyOrCooldown(key))
                {
                    // ТЗ 55 «іконки зникли після F5»: РАНІШЕ готові (кешовані)
                    // іконки тут просто пропускались — тому ResetSentIcons()
                    // при новій панелі не призводив до повторного надсилання.
                    // Тепер беремо значення з кешу і шлемо, якщо ще не слали.
                    if (!_iconCache.TryGetValue(key, out dataUrl!) || string.IsNullOrEmpty(dataUrl)) continue;
                }
                else
                {
                    dataUrl = ExtractAndCache(path, key);
                }
                if (dataUrl == GenericMarker) dataUrl = GetGenericIconDataUrl();
                if (string.IsNullOrEmpty(dataUrl)) continue;

                bool alreadySent;
                lock (_sentIconLock)
                {
                    alreadySent = !_sentIconKeys.Add(key);
                }
                if (alreadySent) continue;

                try
                {
                    await sendBatch(new Dictionary<string, string>(StringComparer.Ordinal) { [key] = dataUrl });
                }
                catch
                {
                    break; // сокет мертвий — далі шлювати нікуди
                }
                await Task.Delay(IconPushDelayMs);
            }
        }
        catch { }
        finally
        {
            Interlocked.Exchange(ref _iconPushRunning, 0);
        }
    }

    /// <summary>
    /// Скидає множину «вже надісланих» іконок. Викликається при КОЖНОМУ новому
    /// підключенні релея: свіжа веб-панель не має іконок попередньої сесії,
    /// тому все треба надіслати заново (інакше після F5 список без іконок).
    /// </summary>
    public void ResetSentIcons()
    {
        lock (_sentIconLock)
        {
            _sentIconKeys.Clear();
        }
    }

    /// <summary>
    /// Returns { exePath (lowercase) → "data:image/png;base64,…" } for process
    /// icons not sent to the web yet. At most 12 new extractions per call (the
    /// rest stay in the cache and are returned by a later call). The web falls
    /// back to a letter avatar for processes without an icon.
    /// </summary>
    public Dictionary<string, string> GetNewIcons(List<ProcessItem> processes)
    {
        var newIcons = new Dictionary<string, string>();
        try
        {
            var presentKeys = new HashSet<string>(StringComparer.Ordinal);
            int extractions = 0;

            foreach (var process in processes)
            {
                if (string.IsNullOrWhiteSpace(process.ExePath)) continue;
                var key = process.ExePath.ToLowerInvariant();
                presentKeys.Add(key);
                if (IconReadyOrCooldown(key)) continue;
                if (extractions >= MaxIconExtractionsPerCall) continue; // next call
                ExtractAndCache(process.ExePath, key);
                extractions++;
            }

            lock (_sentIconLock)
            {
                foreach (var key in presentKeys)
                {
                    if (_sentIconKeys.Contains(key)) continue;
                    if (_iconCache.TryGetValue(key, out string? dataUrl) && !string.IsNullOrEmpty(dataUrl))
                    {
                        // ТЗ 55: заглушка замість реальної іконки теж надсилається —
                        // список виглядає завершеним навіть для системних exe.
                        if (dataUrl == GenericMarker) dataUrl = GetGenericIconDataUrl();
                        if (string.IsNullOrEmpty(dataUrl)) continue;
                        newIcons[key] = dataUrl;
                        _sentIconKeys.Add(key);
                        // ТЗ «іконки ВСІХ програм»: дублюємо ключ і за КОРОТКИМ
                        // ім'ям процесу — веб уміє шукати і за шляхом, і за назвою.
                        var nameKey = key.Substring(key.LastIndexOf('\\') + 1);
                        if (nameKey.EndsWith(".exe", StringComparison.Ordinal))
                            nameKey = nameKey[..^4];
                        if (!string.IsNullOrWhiteSpace(nameKey) && !newIcons.ContainsKey(nameKey))
                            newIcons[nameKey] = dataUrl;
                    }
                    // Empty cache values (failed extraction) are skipped silently.
                }
            }
        }
        catch { }
        return newIcons;
    }

    /// <summary>Публічний доступ для AppLauncherService (іконки застосунків Пуску).</summary>
    public static string ExtractIconDataUrl(string exePath)
    {
        // 1) Найкраща якість: SHDefExtractIcon у 48px (реальна іконка оболонки
        //    Windows — працює для практично ВСІХ застосунків, не тільки системних).
        //    nIconSize = MAKELONG(large 32, small 48) => GREAT іконка 48px —
        //    у LOWWORD великий розмір, у HIWORD малий (було інвертовано).
        try
        {
            if (Win32Api.SHDefExtractIcon(exePath, 0, 0, out IntPtr hIcon, out _, (48u << 16) | 32u) == 0 && hIcon != IntPtr.Zero)
            {
                using var bmp48 = Icon.FromHandle(hIcon).ToBitmap();
                Win32Api.DestroyIcon(hIcon);
                var png48 = ToPngDataUrl(bmp48, 48);
                if (png48 != null) return png48;
            }
        }
        catch { }

        // 2) Фолбек: ExtractIconEx — велика іконка безпосередньо з exe.
        try
        {
            if (Win32Api.ExtractIconEx(exePath, 0, out IntPtr hLarge, out IntPtr hSmall, 1) > 0)
            {
                try
                {
                    var use = hLarge != IntPtr.Zero ? hLarge : hSmall;
                    if (use != IntPtr.Zero)
                    {
                        using var bmpEx = Icon.FromHandle(use).ToBitmap();
                        var pngEx = ToPngDataUrl(bmpEx, 48);
                        if (pngEx != null) return pngEx;
                    }
                }
                finally
                {
                    if (hLarge != IntPtr.Zero) Win32Api.DestroyIcon(hLarge);
                    if (hSmall != IntPtr.Zero) Win32Api.DestroyIcon(hSmall);
                }
            }
        }
        catch { }

        // 3) Фолбек: ExtractAssociatedIcon (32px) — старий шлях.
        try
        {
            using var icon = Icon.ExtractAssociatedIcon(exePath);
            if (icon == null) return string.Empty;
            using var source = icon.ToBitmap();
            var png = ToPngDataUrl(source, 32);
            return png ?? string.Empty;
        }
        catch
        {
            // Icon extraction of some system processes throws — cache the
            // negative result so we never retry-spam it.
            return string.Empty;
        }
    }

    private static string? ToPngDataUrl(Bitmap source, int size)
    {
        try
        {
            using var bitmap = new Bitmap(size, size, PixelFormat.Format32bppArgb);
            using (var graphics = Graphics.FromImage(bitmap))
            {
                graphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
                graphics.PixelOffsetMode = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;
                graphics.Clear(Color.Transparent);
                graphics.DrawImage(source, 0, 0, size, size);
            }
            using var stream = new MemoryStream();
            bitmap.Save(stream, ImageFormat.Png);
            return "data:image/png;base64," + Convert.ToBase64String(stream.ToArray());
        }
        catch
        {
            return null;
        }
    }

    public bool KillProcess(int pid)
    {
        try
        {
            var p = Process.GetProcessById(pid);
            p.Kill(entireProcessTree: true);
            return true;
        }
        catch (Exception ex)
        {
            Debug.WriteLine($"Failed to kill process {pid}: {ex.Message}");
            return false;
        }
    }

    // ================= Заморозка / передній план (ТЗ 46) =================

    /// <summary>Заморозити/розморозити процес (NtSuspend/NtResume, як у Explorer
    /// «Suspend» у Process Hacker). Системні процеси не чіпаємо.</summary>
    public (bool success, string? error) SetFrozen(int pid, bool freeze)
    {
        try
        {
            using var p = Process.GetProcessById(pid);
            if (p.SessionId == 0 && freeze)
                return (false, "Системні процеси сесії 0 заморожувати не можна");
            var result = freeze
                ? Win32Api.NtSuspendProcess(p.Handle)
                : Win32Api.NtResumeProcess(p.Handle);
            if (result != 0)
                return (false, $"NtSuspend/Resume код {result}");

            if (freeze) _frozenPids[pid] = 1;
            else _frozenPids.TryRemove(pid, out _);
            return (true, null);
        }
        catch (Exception ex)
        {
            return (false, ex.Message);
        }
    }

    /// <summary>Чи заморожено процес зараз (для веб-перемикача).</summary>
    public bool IsFrozen(int pid) => _frozenPids.ContainsKey(pid);

    /// <summary>Розморозити ВСЕ, що заморозили (викликається при зупинці агента,
    /// щоб після перезавантаження ПК не лишалися «звисаючі» програми).</summary>
    public void ResumeAllFrozen()
    {
        foreach (var pid in _frozenPids.Keys)
        {
            try
            {
                using var p = Process.GetProcessById(pid);
                Win32Api.NtResumeProcess(p.Handle);
            }
            catch { }
        }
        _frozenPids.Clear();
    }

    /// <summary>Витягнути вікно процесу на передній план ПК (ТЗ: «натиснув Chrome —
    /// він відкрився поверх гри»). Розгортає згорнуті вікна.</summary>
    public (bool success, string? error) BringToFront(int pid)
    {
        try
        {
            using var p = Process.GetProcessById(pid);
            var hwnd = p.MainWindowHandle;
            if (hwnd == IntPtr.Zero)
                return (false, "У процесу немає вікна");

            if (Win32Api.IsIconic(hwnd))
                Win32Api.ShowWindow(hwnd, Win32Api.SW_RESTORE);

            Win32Api.SwitchToThisWindow(hwnd, true);
            Win32Api.SetForegroundWindow(hwnd);
            return (true, null);
        }
        catch (Exception ex)
        {
            return (false, ex.Message);
        }
    }
}
