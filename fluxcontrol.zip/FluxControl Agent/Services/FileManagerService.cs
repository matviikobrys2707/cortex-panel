using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Threading.Tasks;

namespace FluxControl.Agent.Services;

public class FileItem
{
    public string Name { get; set; } = string.Empty;
    public string Path { get; set; } = string.Empty;
    public bool IsDirectory { get; set; }
    public long Size { get; set; }
    public DateTime LastModified { get; set; }
    public string Extension { get; set; } = string.Empty;
    public bool IsHidden { get; set; }
}

public class DirectoryContentResult
{
    public string CurrentPath { get; set; } = string.Empty;
    public string? ParentPath { get; set; }
    public List<FileItem> Items { get; set; } = new();
}

public partial class FileManagerService
{
    // ================= Швидкі папки (ТЗ: панель зліва у «Файлах») =================

    /// <summary>Шляхи Робочий стіл/Завантаження/Документи/… для панелі швидкого доступу.</summary>
    public static object GetSpecialFolders()
    {
        return new
        {
            desktop = SafeSpecial(Environment.SpecialFolder.DesktopDirectory),
            // ТЗ-ФІКС «немає кнопки Завантаження»: беремо відому папку
            // FOLDERID_Downloads через SHGetKnownFolderPath — вона коректна
            // і на локалізованих Windows (Завантаження/Downloads/Скачанное).
            downloads = KnownDownloadsDir(),
            documents = SafeSpecial(Environment.SpecialFolder.MyDocuments),
            pictures = SafeSpecial(Environment.SpecialFolder.MyPictures),
            music = SafeSpecial(Environment.SpecialFolder.MyMusic),
            videos = SafeSpecial(Environment.SpecialFolder.MyVideos),
        };
    }

    [System.Runtime.InteropServices.DllImport("shell32.dll")]
    private static extern int SHGetKnownFolderPath(in Guid rfid, uint dwFlags, IntPtr hToken, out IntPtr ppszPath);

    private static string? KnownDownloadsDir()
    {
        // FOLDERID_Downloads {374DE290-123F-4565-9164-39C4925E467B}
        var downloads = new Guid("374DE290-123F-4565-9164-39C4925E467B");
        try
        {
            var hr = SHGetKnownFolderPath(in downloads, 0 /*KF_FLAG_DEFAULT*/, IntPtr.Zero, out IntPtr ptr);
            if (hr == 0 && ptr != IntPtr.Zero)
            {
                try
                {
                    var path = System.Runtime.InteropServices.Marshal.PtrToStringUni(ptr);
                    if (!string.IsNullOrWhiteSpace(path) && Directory.Exists(path)) return path;
                }
                finally { System.Runtime.InteropServices.Marshal.FreeCoTaskMem(ptr); }
            }
        }
        catch { }

        // Фолбек: %USERPROFILE%\Downloads або локалізований варіант у профілі.
        try
        {
            var userProfile = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            if (string.IsNullOrEmpty(userProfile)) return null;
            foreach (var name in new[] { "Downloads", "Завантаження", "Скачанные", "Скачанное" })
            {
                var p = Path.Combine(userProfile, name);
                if (Directory.Exists(p)) return p;
            }
        }
        catch { }
        return null;
    }

    private static string? SafeSpecial(Environment.SpecialFolder folder)
    {
        try
        {
            var p = Environment.GetFolderPath(folder);
            return string.IsNullOrWhiteSpace(p) ? null : p;
        }
        catch { return null; }
    }

    // ================= Розміри папок (ТЗ: папки показують розмір/к-сть елементів) =================

    private readonly System.Collections.Concurrent.ConcurrentDictionary<string, (long size, long files, DateTime ts)> _dirStatsCache = new();

    /// <summary>Розмір + кількість файлів папки (кеш 5 хв). Безпечна, best-effort.</summary>
    public (long size, long files) GetDirectoryStats(string path)
    {
        if (string.IsNullOrWhiteSpace(path) || !Directory.Exists(path)) return (0, 0);
        if (_dirStatsCache.TryGetValue(path, out var cached) && (DateTime.UtcNow - cached.ts).TotalMinutes < 5)
            return (cached.size, cached.files);

        long size = 0, files = 0;
        try
        {
            var stack = new Stack<string>();
            stack.Push(path);
            while (stack.Count > 0 && size < 32L * 1024 * 1024 * 1024)
            {
                var current = stack.Pop();
                try { foreach (var d in Directory.EnumerateDirectories(current)) stack.Push(d); } catch { }
                try
                {
                    foreach (var f in Directory.EnumerateFiles(current))
                    {
                        try { var fi = new FileInfo(f); if (fi.Exists) { size += fi.Length; files++; } }
                        catch { }
                    }
                }
                catch { }
            }
        }
        catch { }

        _dirStatsCache[path] = (size, files, DateTime.UtcNow);
        return (size, files);
    }

    // ================= ЧАНКОВЕ ЗАВАНТАЖЕННЯ (ТЗ: без ліміту 48 МБ) =================


    public List<DiskInfo> GetDrives()
    {
        var list = new List<DiskInfo>();
        foreach (var drive in DriveInfo.GetDrives())
        {
            if (drive.IsReady)
            {
                var total = drive.TotalSize / (1024.0 * 1024.0 * 1024.0);
                var free = drive.AvailableFreeSpace / (1024.0 * 1024.0 * 1024.0);
                var used = total - free;
                list.Add(new DiskInfo
                {
                    Name = drive.Name,
                    Label = string.IsNullOrWhiteSpace(drive.VolumeLabel) ? "Локальний диск" : drive.VolumeLabel,
                    TotalGb = Math.Round(total, 2),
                    FreeGb = Math.Round(free, 2),
                    UsedGb = Math.Round(used, 2),
                    PercentUsed = total > 0 ? (int)Math.Round((used / total) * 100) : 0
                });
            }
        }
        return list;
    }

    public DirectoryContentResult ListDirectory(string path)
    {
        if (string.IsNullOrWhiteSpace(path))
        {
            var firstDrive = DriveInfo.GetDrives().FirstOrDefault(d => d.IsReady);
            path = firstDrive?.Name ?? Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
        }

        var dirInfo = new DirectoryInfo(path);
        if (!dirInfo.Exists)
        {
            throw new DirectoryNotFoundException($"Папку '{path}' не знайдено.");
        }

        var result = new DirectoryContentResult
        {
            CurrentPath = dirInfo.FullName,
            ParentPath = dirInfo.Parent?.FullName
        };

        try
        {
            foreach (var dir in dirInfo.GetDirectories())
            {
                bool isHidden = (dir.Attributes & FileAttributes.Hidden) != 0;
                result.Items.Add(new FileItem
                {
                    Name = dir.Name,
                    Path = dir.FullName,
                    IsDirectory = true,
                    Size = 0,
                    LastModified = dir.LastWriteTime,
                    Extension = "",
                    IsHidden = isHidden
                });
            }
        }
        catch { }

        try
        {
            foreach (var file in dirInfo.GetFiles())
            {
                bool isHidden = (file.Attributes & FileAttributes.Hidden) != 0;
                result.Items.Add(new FileItem
                {
                    Name = file.Name,
                    Path = file.FullName,
                    IsDirectory = false,
                    Size = file.Length,
                    LastModified = file.LastWriteTime,
                    Extension = file.Extension.TrimStart('.').ToLowerInvariant(),
                    IsHidden = isHidden
                });
            }
        }
        catch { }

        result.Items = result.Items
            .OrderByDescending(i => i.IsDirectory)
            .ThenBy(i => i.Name)
            .ToList();

        return result;
    }

    public string ReadFileContent(string path)
    {
        if (!File.Exists(path))
        {
            throw new FileNotFoundException("Файл не знайдено.", path);
        }
        return File.ReadAllText(path);
    }

    public void SaveFileContent(string path, string content)
    {
        var dir = Path.GetDirectoryName(path);
        if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
        {
            Directory.CreateDirectory(dir);
        }
        File.WriteAllText(path, content);
        InvalidateFolderSize(Path.GetDirectoryName(path));
    }

    /// <summary>
    /// Бінарне збереження файлу з сайту (ТЗ: Drag&amp;Drop у «Файли»):
    /// веб шле base64-дані, агент пише їх як байти. Розмір обмежено ~48 МБ
    /// (обмеження WebSocket-повідомлення релея).
    /// </summary>
    public void SaveFileBytesFromBase64(string path, string base64)
    {
        if (string.IsNullOrWhiteSpace(base64))
            throw new ArgumentException("Порожні дані файлу.", nameof(base64));

        // Допускаємо dataURL («data:image/png;base64,....»).
        var comma = base64.IndexOf(',');
        if (base64.StartsWith("data:") && comma > 0) base64 = base64[(comma + 1)..];

        var bytes = Convert.FromBase64String(base64);
        if (bytes.Length > 48 * 1024 * 1024)
            throw new IOException("Файл більший за 48 МБ — завантажте його іншим способом.");

        var dir = Path.GetDirectoryName(path);
        if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir)) Directory.CreateDirectory(dir);
        File.WriteAllBytes(path, bytes);
        InvalidateFolderSize(Path.GetDirectoryName(path));
    }

    public bool DeleteItem(string path)
    {
        if (File.Exists(path))
        {
            File.Delete(path);
            InvalidateFolderSize(Path.GetDirectoryName(path));
            return true;
        }

        if (Directory.Exists(path))
        {
            Directory.Delete(path, recursive: true);
            InvalidateFolderSize(Path.GetDirectoryName(path));
            return true;
        }

        throw new FileNotFoundException("Файл або папку не знайдено.");
    }

    private readonly System.Collections.Concurrent.ConcurrentDictionary<string, (long size, DateTime timestamp)> _folderSizeCache = new();

    public long GetDirectorySize(string path)
    {
        if (string.IsNullOrWhiteSpace(path) || !Directory.Exists(path)) return 0;
        if (_folderSizeCache.TryGetValue(path, out var cached) && (DateTime.UtcNow - cached.timestamp).TotalMinutes < 5)
        {
            return cached.size;
        }

        long totalSize = 0;
        try
        {
            var dirInfo = new DirectoryInfo(path);
            // Deliberately run in the request's background task. A depth cap makes
            // Explorer report incorrect values for ordinary nested directories.
            totalSize = CalculateDirSizeSafe(dirInfo);
            _folderSizeCache[path] = (totalSize, DateTime.UtcNow);
        }
        catch { }

        return totalSize;
    }

    private static long CalculateDirSizeSafe(DirectoryInfo dir)
    {
        long size = 0;
        try
        {
            foreach (var file in dir.EnumerateFiles())
            {
                try { size += file.Length; } catch { }
            }
            foreach (var subDir in dir.EnumerateDirectories())
            {
                try
                {
                    if ((subDir.Attributes & FileAttributes.ReparsePoint) == 0)
                    {
                        size += CalculateDirSizeSafe(subDir);
                    }
                }
                catch { }
            }
        }
        catch { }
        return size;
    }

    public string CreateZipArchive(string directoryPath)
    {
        if (!Directory.Exists(directoryPath))
        {
            throw new DirectoryNotFoundException($"Папка '{directoryPath}' не існує.");
        }

        var dirName = new DirectoryInfo(directoryPath).Name;
        var tempZip = Path.Combine(Path.GetTempPath(), $"{dirName}_{Guid.NewGuid():N}.zip");
        ZipFile.CreateFromDirectory(directoryPath, tempZip, CompressionLevel.Fastest, includeBaseDirectory: false);
        return tempZip;
    }

    public bool CreateNewFile(string parentDir, string fileName)
    {
        if (!Directory.Exists(parentDir)) Directory.CreateDirectory(parentDir);
        var target = Path.Combine(parentDir, fileName);
        if (!File.Exists(target))
        {
            File.WriteAllText(target, "");
            InvalidateFolderSize(parentDir);
            return true;
        }
        return true;
    }

    public bool CreateNewFolder(string parentDir, string folderName)
    {
        if (!Directory.Exists(parentDir)) Directory.CreateDirectory(parentDir);
        var target = Path.Combine(parentDir, folderName);
        Directory.CreateDirectory(target);
        InvalidateFolderSize(parentDir);
        return true;
    }

    public async Task<string> SaveAndProcessUploadAsync(string targetDir, string fileName, Stream fileStream)
    {
        if (!Directory.Exists(targetDir))
        {
            Directory.CreateDirectory(targetDir);
        }

        var destinationPath = Path.Combine(targetDir, fileName);

        await using (var output = File.Create(destinationPath))
        {
            await fileStream.CopyToAsync(output);
        }

        if (fileName.EndsWith(".zip", StringComparison.OrdinalIgnoreCase))
        {
            try
            {
                ZipFile.ExtractToDirectory(destinationPath, targetDir, overwriteFiles: true);
                File.Delete(destinationPath);
                return $"ZIP-архів розархівовано в '{targetDir}'.";
            }
            catch (Exception ex)
            {
                return $"Завантажено, але помилка розархівації: {ex.Message}";
            }
        }

        return $"Файл '{fileName}' успішно завантажено!";
    }

    public bool RenameItem(string oldPath, string newName)
    {
        if (string.IsNullOrWhiteSpace(oldPath) || string.IsNullOrWhiteSpace(newName)) return false;

        var dir = Path.GetDirectoryName(oldPath);
        if (string.IsNullOrWhiteSpace(dir)) return false;

        var newPath = Path.Combine(dir, newName);

        if (File.Exists(oldPath))
        {
            File.Move(oldPath, newPath, overwrite: true);
            InvalidateFolderSize(dir);
            return true;
        }

        if (Directory.Exists(oldPath))
        {
            Directory.Move(oldPath, newPath);
            InvalidateFolderSize(dir);
            return true;
        }

        throw new FileNotFoundException("Елемент для перейменування не знайдено.");
    }

    private void InvalidateFolderSize(string? changedDirectory)
    {
        if (string.IsNullOrWhiteSpace(changedDirectory)) return;
        foreach (var key in _folderSizeCache.Keys)
        {
            if (key.StartsWith(changedDirectory, StringComparison.OrdinalIgnoreCase) ||
                changedDirectory.StartsWith(key, StringComparison.OrdinalIgnoreCase))
            {
                _folderSizeCache.TryRemove(key, out _);
            }
        }
    }

    // ================= Пошук у поточній папці (ТЗ 46: «пошук по всьому диску»,
    // але СКОПОВАНИЙ: диск → весь диск, папка Ігри → тільки папка Ігри) ======

    private static readonly string[] SkipDirNames = { "$recycle.bin", "system volume information", "node_modules", ".git", "$windows.~bt", "windows.old" };

    /// <summary>Рекурсивний пошук імені всередині rootPath (BFS, без reparse points).
    /// Обмеження: maxResults елементів, 16 рівнів глибини, 150k відвіданих
    /// папок/файлів — щоб пошук по великому диску не жував CPU вічно.</summary>
    public (List<FileItem> items, bool truncated) SearchFiles(string rootPath, string query, int maxResults = 300)
    {
        var results = new List<FileItem>();
        if (string.IsNullOrWhiteSpace(query) || !Directory.Exists(rootPath))
            return (results, false);

        var q = query.Trim();
        var root = new DirectoryInfo(rootPath);
        var visited = 0;
        bool truncated = false;
        var queue = new Queue<DirectoryInfo>();
        queue.Enqueue(root);

        while (queue.Count > 0)
        {
            if (results.Count >= maxResults || visited > 150_000) { truncated = true; break; }

            var dir = queue.Dequeue();
            try
            {
                foreach (var file in dir.EnumerateFiles())
                {
                    visited++;
                    if (results.Count >= maxResults) { truncated = true; break; }
                    if (file.Name.IndexOf(q, StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        results.Add(new FileItem
                        {
                            Name = file.Name,
                            Path = file.FullName,
                            IsDirectory = false,
                            Size = file.Length,
                            LastModified = file.LastWriteTime,
                            Extension = file.Extension.TrimStart('.').ToLowerInvariant(),
                            IsHidden = (file.Attributes & FileAttributes.Hidden) != 0
                        });
                    }
                }
            }
            catch { }

            try
            {
                foreach (var sub in dir.EnumerateDirectories())
                {
                    visited++;
                    if ((sub.Attributes & FileAttributes.ReparsePoint) != 0) continue;
                    var lower = sub.Name.ToLowerInvariant();
                    if (SkipDirNames.Any(s => lower == s)) continue;

                    // Сама папка теж може бути збігом — повертаємо її.
                    if (results.Count < maxResults && sub.Name.IndexOf(q, StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        results.Add(new FileItem
                        {
                            Name = sub.Name,
                            Path = sub.FullName,
                            IsDirectory = true,
                            Size = 0,
                            LastModified = sub.LastWriteTime,
                            Extension = "",
                            IsHidden = (sub.Attributes & FileAttributes.Hidden) != 0
                        });
                    }

                    // Глибина ≤ 16: усе, що глибше, у файлових пошуках майже ніколи
                    // не потрібно, зате диски типу C:\ не скануються нескінченно.
                    if (RelDepth(root.FullName, sub.FullName) <= 16) queue.Enqueue(sub);
                }
            }
            catch { }
        }

        results = results
            .OrderByDescending(i => i.IsDirectory)
            .ThenBy(i => i.Name, StringComparer.OrdinalIgnoreCase)
            .Take(maxResults)
            .ToList();
        return (results, truncated);
    }

    private static int RelDepth(string root, string path)
    {
        try
        {
            var rel = path.Substring(root.Length).Trim(Path.DirectorySeparatorChar);
            if (rel.Length == 0) return 0;
            return rel.Split(Path.DirectorySeparatorChar).Length;
        }
        catch { return 0; }
    }

    // ================= Контекст-меню: ZIP / розпакування (ТЗ 46) =================

    /// <summary>Стиснути файл або папку в ZIP поруч із оригіналом (Ігри → Ігри.zip).</summary>
    public string CompressToZip(string itemPath)
    {
        var source = itemPath.TrimEnd(Path.DirectorySeparatorChar);
        var parent = Path.GetDirectoryName(source) ?? throw new DirectoryNotFoundException("Немає батьківської папки.");
        var baseName = Path.GetFileName(source);
        var target = Path.Combine(parent, baseName + ".zip");

        int suffix = 1;
        while (File.Exists(target) || Directory.Exists(target))
        {
            target = Path.Combine(parent, $"{baseName} ({suffix}).zip");
            suffix++;
        }

        if (Directory.Exists(source))
        {
            ZipFile.CreateFromDirectory(source, target, CompressionLevel.Optimal, includeBaseDirectory: true);
        }
        else if (File.Exists(source))
        {
            using var archive = ZipFile.Open(target, ZipArchiveMode.Create);
            archive.CreateEntryFromFile(source, baseName, CompressionLevel.Optimal);
        }
        else throw new FileNotFoundException("Файл або папку не знайдено.", source);

        InvalidateFolderSize(parent);
        return target;
    }

    /// <summary>Розпакувати ZIP/RAR у папку поруч (Архів.zip → папка «Архів»).
    /// ZIP — вбудований .NET; RAR/7z — через встановлені 7-Zip/WinRAR/tar.</summary>
    public (string dir, string tool) ExtractArchive(string archivePath)
    {
        if (!File.Exists(archivePath)) throw new FileNotFoundException("Архів не знайдено.", archivePath);

        var parent = Path.GetDirectoryName(archivePath) ?? throw new DirectoryNotFoundException("Немає батьківської папки.");
        var name = Path.GetFileNameWithoutExtension(archivePath);
        var ext = Path.GetExtension(archivePath).ToLowerInvariant();
        var targetDir = Path.Combine(parent, name);

        int suffix = 1;
        while (Directory.Exists(targetDir))
        {
            targetDir = Path.Combine(parent, $"{name} ({suffix})");
            suffix++;
        }

        if (ext == ".zip" || ext == ".cbz")
        {
            Directory.CreateDirectory(targetDir);
            ZipFile.ExtractToDirectory(archivePath, targetDir, overwriteFiles: false);
            InvalidateFolderSize(parent);
            return (targetDir, "zip");
        }

        // RAR / 7z / інші — зовнішні розпакувальники (у порядку переваги).
        var candidates = new (string exe, string args)[]
        {
            (@"C:\Program Files\7-Zip\7z.exe", "x \"{0}\" -o\"{1}\" -y"),
            (@"C:\Program Files (x86)\7-Zip\7z.exe", "x \"{0}\" -o\"{1}\" -y"),
            (@"C:\Program Files\WinRAR\WinRAR.exe", "x -y \"{0}\" \"{1}\\\""),
            (@"C:\Program Files\WinRAR\UnRAR.exe", "x -y \"{0}\" \"{1}\\\""),
            (@"C:\Program Files (x86)\WinRAR\WinRAR.exe", "x -y \"{0}\" \"{1}\\\"")
        };

        foreach (var (exe, argsTemplate) in candidates)
        {
            if (!File.Exists(exe)) continue;
            Directory.CreateDirectory(targetDir);
            var psi = new System.Diagnostics.ProcessStartInfo
            {
                FileName = exe,
                Arguments = string.Format(argsTemplate, archivePath, targetDir),
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true
            };
            using var proc = System.Diagnostics.Process.Start(psi);
            if (proc == null) continue;
            var stdout = proc.StandardOutput.ReadToEnd();
            proc.WaitForExit(10 * 60 * 1000);
            if (proc.ExitCode == 0 && Directory.Exists(targetDir))
            {
                InvalidateFolderSize(parent);
                return (targetDir, Path.GetFileNameWithoutExtension(exe).ToLowerInvariant());
            }
            try { Directory.Delete(targetDir, true); } catch { }
        }

        // Останній шанс: bsdtar (System32) читає zip/некаторі rar.
        var tar = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "tar.exe");
        if (File.Exists(tar))
        {
            Directory.CreateDirectory(targetDir);
            var psi = new System.Diagnostics.ProcessStartInfo
            {
                FileName = tar,
                Arguments = $"-xf \"{archivePath}\" -C \"{targetDir}\"",
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardError = true
            };
            using var proc = System.Diagnostics.Process.Start(psi);
            if (proc != null)
            {
                proc.WaitForExit(10 * 60 * 1000);
                if (proc.ExitCode == 0)
                {
                    InvalidateFolderSize(parent);
                    return (targetDir, "tar");
                }
            }
            try { Directory.Delete(targetDir, true); } catch { }
        }

        throw new IOException("Для RAR-архівів потрібен 7-Zip або WinRAR на ПК (ZIP розпаковується без них).");
    }

    // ================= Копіювати / Вставити (ТЗ 46: системний буфер ФМ) ======

    private readonly object _clipLock = new();
    private List<string>? _clipPaths;   // що «скопійовано»
    private bool _clipCut;              // true = вирізати (перемістити)

    public void SetClipboard(List<string> paths, bool cut)
    {
        lock (_clipLock)
        {
            _clipPaths = paths?.Where(p => File.Exists(p) || Directory.Exists(p)).Select(p => p).ToList();
            _clipCut = cut;
            if (_clipPaths == null || _clipPaths.Count == 0) _clipPaths = null;
        }
    }

    public bool HasClipboard()
    {
        lock (_clipLock) return _clipPaths != null && _clipPaths.Count > 0;
    }

    /// <summary>Вставити буфер у targetDir. Повертає кількість успішно вставлених
    /// елементів. Конфлікти імен — «ім'я (2).розширення» / «ім'я - копія».</summary>
    public int PasteClipboard(string targetDir)
    {
        List<string>? items;
        bool cut;
        lock (_clipLock)
        {
            items = _clipPaths;
            cut = _clipCut;
        }
        if (items == null || items.Count == 0)
            throw new InvalidOperationException("Буфер обміну порожній — спочатку скопіюйте файл або папку.");
        if (!Directory.Exists(targetDir)) throw new DirectoryNotFoundException($"Папку '{targetDir}' не знайдено.");

        int pasted = 0;
        foreach (var item in items)
        {
            try
            {
                var newName = UniqueTargetName(targetDir, Path.GetFileName(item.TrimEnd(Path.DirectorySeparatorChar)));
                var dest = Path.Combine(targetDir, newName);
                var sameDir = string.Equals(Path.GetDirectoryName(item.TrimEnd(Path.DirectorySeparatorChar)), targetDir, StringComparison.OrdinalIgnoreCase);

                if (cut)
                {
                    if (sameDir) continue; // переміщення в ту саму папку — нічого не робимо
                    if (File.Exists(item)) File.Move(item, dest);
                    else if (Directory.Exists(item)) Directory.Move(item, dest);
                    else continue;
                    pasted++;
                }
                else
                {
                    CopyWithConflictNames(item, dest);
                    pasted++;
                }
            }
            catch { }
        }

        if (cut)
        {
            lock (_clipLock) { _clipPaths = null; _clipCut = false; }
        }
        InvalidateFolderSize(targetDir);
        return pasted;
    }

    private static string UniqueTargetName(string targetDir, string originalName)
    {
        var dest = Path.Combine(targetDir, originalName);
        if (!File.Exists(dest) && !Directory.Exists(dest)) return originalName;

        var ext = Path.HasExtension(originalName) ? Path.GetExtension(originalName) : "";
        var stem = ext.Length > 0 ? originalName[..^ext.Length] : originalName;
        for (int i = 1; i < 1000; i++)
        {
            var candidate = $"{stem} ({i}){ext}";
            if (!File.Exists(Path.Combine(targetDir, candidate)) && !Directory.Exists(Path.Combine(targetDir, candidate)))
                return candidate;
        }
        return $"{stem} - копія{ext}";
    }

    private static void CopyWithConflictNames(string source, string destDir)
    {
        if (File.Exists(source))
        {
            var name = UniqueTargetName(destDir, Path.GetFileName(source));
            File.Copy(source, Path.Combine(destDir, name), overwrite: false);
        }
        else if (Directory.Exists(source))
        {
            var name = UniqueTargetName(destDir, Path.GetFileName(source.TrimEnd(Path.DirectorySeparatorChar)));
            var target = Path.Combine(destDir, name);
            // .NET не вміє CopyDirectory — власна рекурсія з перейменуванням
            // КОНКРЕТНОГО верхнього рівня, всередині можна перезаписувати.
            Directory.CreateDirectory(target);
            foreach (var file in Directory.GetFiles(source))
                File.Copy(file, Path.Combine(target, Path.GetFileName(file)), overwrite: true);
            foreach (var dir in Directory.GetDirectories(source))
                CopyWithConflictNames(dir, target);
        }
        else throw new FileNotFoundException("Джерело зникло.", source);
    }

    // ================= Мініатюри фото/відео (ТЗ 46: галерея без скачування) ==

    private static readonly HashSet<string> ImageExt = new(StringComparer.OrdinalIgnoreCase)
        { ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp", ".jfif", ".ico", ".tiff" };
    private static readonly HashSet<string> VideoExt = new(StringComparer.OrdinalIgnoreCase)
        { ".mp4", ".mkv", ".avi", ".mov", ".webm", ".wmv", ".m4v", ".3gp" };

    public static bool IsImageFile(string ext) => ImageExt.Contains(ext);
    public static bool IsVideoFile(string ext) => VideoExt.Contains(ext);

    /// <summary>
    /// Мініатюра size×size у data-URL (PNG): фото — саме фото (System.Drawing),
    /// відео — кадр-превʼю з кешу мініатюр Windows (Shell IShellItemImageFactory).
    /// Повертає null, якщо мініатюру добути не вдалося (веб малює іконку).
    /// </summary>
    public string? GetThumbnail(string path, int size = 320)
    {
        try
        {
            size = Math.Clamp(size, 64, 512);
            var ext = Path.GetExtension(path);
            if (ImageExt.Contains(ext))
            {
                using var img = System.Drawing.Image.FromFile(path);
                var (w, h) = FitSize(img.Width, img.Height, size);
                using var bmp = new System.Drawing.Bitmap(w, h);
                using (var g = System.Drawing.Graphics.FromImage(bmp))
                {
                    g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                    g.Clear(System.Drawing.Color.Transparent);
                    g.DrawImage(img, 0, 0, w, h);
                }
                return ToPngDataUrl(bmp);
            }

            if (VideoExt.Contains(ext))
            {
                // Shell-мініатюра: Windows сам добуде превʼю кадру (як в Explorer).
                var iid = new Guid("bcc18b79-ba16-442f-80c4-8a59c30c463b");
                Win32Api.SHCreateItemFromParsingName(path, IntPtr.Zero, ref iid, out var factory);
                if (factory != null)
                {
                    try
                    {
                        if (factory.GetImage(new Win32Api.SIZE(size, size), Win32Api.SIIGBF_RESIZETOFIT, out IntPtr hbm) == 0 && hbm != IntPtr.Zero)
                        {
                            try
                            {
                                using var shellBmp = System.Drawing.Image.FromHbitmap(hbm);
                                var (w, h) = FitSize(shellBmp.Width, shellBmp.Height, size);
                                using var bmp = new System.Drawing.Bitmap(w, h);
                                using (var g = System.Drawing.Graphics.FromImage(bmp))
                                {
                                    g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                                    g.Clear(System.Drawing.Color.Transparent);
                                    g.DrawImage(shellBmp, 0, 0, w, h);
                                }
                                return ToPngDataUrl(bmp);
                            }
                            finally { Win32Api.DeleteObject(hbm); }
                        }
                    }
                    finally
                    {
                        try { System.Runtime.InteropServices.Marshal.ReleaseComObject(factory); } catch { }
                    }
                }
            }
        }
        catch { }
        return null;
    }

    private static (int w, int h) FitSize(int srcW, int srcH, int maxSide)
    {
        if (srcW <= 0 || srcH <= 0) return (maxSide, maxSide);
        double scale = Math.Min((double)maxSide / srcW, (double)maxSide / srcH);
        if (scale > 1) scale = 1;
        return (Math.Max(1, (int)Math.Round(srcW * scale)), Math.Max(1, (int)Math.Round(srcH * scale)));
    }

    private static string? ToPngDataUrl(System.Drawing.Bitmap bmp)
    {
        try
        {
            using var ms = new MemoryStream();
            bmp.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
            return "data:image/png;base64," + Convert.ToBase64String(ms.ToArray());
        }
        catch { return null; }
    }
}
