using System;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace FluxControl.Agent.Services;

/// <summary>
/// АСЕТИ СКРИМЕРА (ТЗ 2025-10): фото + звук живуть у репозиторії сайту
/// (matviikobrys2707/FluxControl → папка <c>assets/</c>) і НІКОЛИ не деплояться
/// разом із вебом (Web-Deploy.ps1 охороняє цю папку restore-списком).
///
/// КАНАЛИ ЗАВАНТАЖЕННЯ (у порядку спроби):
///   1. fluxcontrol.pages.dev/assets — офіційний сайт (Cloudflare Pages);
///   2. сервер-проксі /update/assets — той самий контент через Render
///      (порятунок на мережах, де ISP ламає DNS для *.pages.dev);
///   3. raw.githubusercontent — останній резерв;
///   4. АСЕТИ, ЗАШИТІ В ЗБІРКУ (embedded resources) — працюють навіть
///      БЕЗ ІНТЕРНЕТУ: скример завжди новий.
///
/// Потік роботи при скримері (ТЗ «щоб не було такого, що звук з'явився,
/// а фотка прогружається»):
///   1. EnsureAssetsAsync — обидва файли (mp3 + jpg) качаються і кешуються
///      в %AppData%\FluxControl\screamer. Кеш перевіряється за розміром:
///      биті/обірвані файли перекачуються. Наступні скримери — миттєво, з диска.
///   2. LoadImageAsync — фото декодується в пам'ять і Freeze()ється (працює
///      з будь-якого потоку, нуль витрат на UI-потоку при показі).
///   3. PrepareSoundAsync — MediaPlayer відкриває файл і ЧЕКАЄ MediaOpened.
/// </summary>
public static class ScreamerAssetsService
{
    /// <summary>Канал 1: Cloudflare Pages (офіційний сайт).</summary>
    public const string SiteBase = "https://fluxcontrol.pages.dev/assets";

    /// <summary>Канал 2: сервер-проксі оновлень (Render) — той самий контент.</summary>
    public const string ProxyBase = UpdateService.ServerUpdateBase + "/assets";

    /// <summary>Канал 3: raw головної гілки репозиторію сайту (останній резерв).</summary>
    public const string RawBase = "https://raw.githubusercontent.com/matviikobrys2707/FluxControl/main/assets";

    public const string SoundFileName = "jeremayjimenez-smile-dog-jumpscare-167171.mp3";
    public const string ImageFileName = "cover-screamer.jpg";

    /// <summary>Embedded-ресурси зашитих ассетів (LogicalName у csproj).</summary>
    private const string EmbeddedSoundResource = "screamer.embedded.sound.mp3";
    private const string EmbeddedImageResource = "screamer.embedded.cover.jpg";

    /// <summary>Мінімальний «здоровий» розмір файла кеша — менший = битий, качаємо заново.</summary>
    private const long MinSoundBytes = 4 * 1024;
    private const long MinImageBytes = 8 * 1024;

    private static readonly HttpClient Http = new()
    {
        Timeout = TimeSpan.FromSeconds(30)
    };

    static ScreamerAssetsService()
    {
        Http.DefaultRequestHeaders.UserAgent.ParseAdd("FluxControl-Agent/1.0");
    }

    private static string CacheDir => Path.Combine(RuntimeFiles.DataRoot, "screamer");
    private static string SoundCachePath => Path.Combine(CacheDir, SoundFileName);
    private static string ImageCachePath => Path.Combine(CacheDir, ImageFileName);

    private static bool IsCacheValid(string path, long minBytes)
    {
        try { return File.Exists(path) && new FileInfo(path).Length >= minBytes; }
        catch { return false; }
    }

    /// <summary>Качає файл: Pages → сервер-проксі → raw → зашитий в збірку. Атомарно (через .tmp).</summary>
    private static async Task DownloadToCacheAsync(string fileName, string destPath, long minBytes)
    {
        Directory.CreateDirectory(CacheDir);
        var tmp = destPath + ".tmp";
        foreach (var baseUrl in new[] { SiteBase, ProxyBase, RawBase })
        {
            var url = $"{baseUrl}/{Uri.EscapeDataString(fileName)}";
            try
            {
                var bytes = await Http.GetByteArrayAsync(url);
                if (bytes.Length < minBytes)
                {
                    App.Log($"Screamer: {fileName} from {url} too small ({bytes.Length}B) — trying next source.");
                    continue;
                }
                await File.WriteAllBytesAsync(tmp, bytes);
                File.Move(tmp, destPath, overwrite: true);
                App.Log($"Screamer: cached {fileName} ({bytes.Length}B) from {url}");
                return;
            }
            catch (Exception ex)
            {
                App.Log($"Screamer: download {fileName} from {url} failed: {ex.Message}");
            }
        }

        // КАНАЛ 4 — ассети, зашиті в збірку (працюють навіть без інтернету).
        foreach (var resName in new[] { EmbeddedImageResource, EmbeddedSoundResource })
        {
            if (!fileName.Equals(
                resName.EndsWith(".mp3", StringComparison.Ordinal) ? SoundFileName : ImageFileName,
                StringComparison.OrdinalIgnoreCase)) continue;
            try
            {
                var asm = typeof(ScreamerAssetsService).Assembly;
                using var rs = asm.GetManifestResourceStream(resName);
                if (rs == null || rs.Length < minBytes) continue;
                await using (var fs = new FileStream(tmp, FileMode.Create, FileAccess.Write, FileShare.None))
                {
                    await rs.CopyToAsync(fs);
                }
                File.Move(tmp, destPath, overwrite: true);
                App.Log($"Screamer: extracted embedded {fileName} ({rs.Length}B)");
                return;
            }
            catch (Exception ex)
            {
                App.Log($"Screamer: embedded {resName} failed: {ex.Message}");
            }
        }
        throw new IOException($"Не вдалося завантажити ассет скримера {fileName} (ні сайт, ні проксі, ні зашитий фолбек).");
    }

    /// <summary>
    /// Готує ОБИДВА файли в кеші (паралельно) і повертає локальні шляхи.
    /// Кеш у %AppData%\FluxControl\screamer переживає оновлення програми.
    /// </summary>
    public static async Task<(string soundPath, string imagePath)> EnsureAssetsAsync()
    {
        if (!IsCacheValid(SoundCachePath, MinSoundBytes))
            await DownloadToCacheAsync(SoundFileName, SoundCachePath, MinSoundBytes);
        if (!IsCacheValid(ImageCachePath, MinImageBytes))
            await DownloadToCacheAsync(ImageFileName, ImageCachePath, MinImageBytes);
        return (SoundCachePath, ImageCachePath);
    }

    /// <summary>
    /// Декодує фото в ImageSource і Freeze()є: показ потім миттєвий, навіть з
    /// фонового потоку (аудит ТЗ: «з'явився звук — фотка прогружається» неможливий,
    /// бо фото вже в пам'яті ДО старту звуку).
    /// </summary>
    public static Task<ImageSource> LoadImageAsync(string imagePath) => Task.Run(() =>
    {
        var bytes = File.ReadAllBytes(imagePath);
        using var ms = new MemoryStream(bytes);
        var bmp = new BitmapImage();
        bmp.BeginInit();
        bmp.CacheOption = BitmapCacheOption.OnLoad; // читаємо все в пам'ять, файл далі не потрібен
        bmp.StreamSource = ms;
        bmp.EndInit();
        bmp.Freeze(); // крос-потоковий доступ + без витрат рендера
        return (ImageSource)bmp;
    });

    /// <summary>
    /// Готує звук: MediaPlayer створюється на UI-потоку (DispatcherObject —
    /// події MediaOpened/MediaEnded живуть лише при працюючому Dispatcher),
    /// файл відкривається асинхронно, очікуємо MediaOpened ДО повернення.
    /// Повертається ЛИШЕ коли плеєр реально готовий грати — синхронний старт.
    /// </summary>
    public static Task<MediaPlayer> PrepareSoundAsync(string soundPath)
    {
        var dispatcher = System.Windows.Application.Current?.Dispatcher
                         ?? System.Windows.Threading.Dispatcher.CurrentDispatcher;
        return dispatcher.InvokeAsync(() =>
        {
            var tcs = new TaskCompletionSource<MediaPlayer>(TaskCreationOptions.RunContinuationsAsynchronously);
            var player = new MediaPlayer();

            player.MediaOpened += (_, _) => tcs.TrySetResult(player);
            player.MediaFailed += (_, e) =>
                tcs.TrySetException(new IOException($"Не вдалося відкрити звук скримера: {e.ErrorException?.Message ?? "MediaFailed"}"));

            player.Open(new Uri(soundPath));
            return tcs.Task; // await цього таску відбувається У ФОНОВОМУ потоці — UI не блокуємо
        }).Task.Unwrap();
    }

    /// <summary>Прогрів кеша у фоні при старті агента: скример потім спрацьовує миттєво.</summary>
    public static async void WarmCacheInBackground()
    {
        try
        {
            await EnsureAssetsAsync();
            App.Log("Screamer: assets cache warm — screamer will start instantly.");
        }
        catch (Exception ex)
        {
            App.Log($"Screamer: warm cache failed (will retry on next screamer): {ex.Message}");
        }
    }
}
