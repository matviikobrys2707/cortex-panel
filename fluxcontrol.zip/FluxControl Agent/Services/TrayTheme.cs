using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace FluxControl.Agent.Services;

/// <summary>
/// Палітра та шрифт фірмового меню трея: чорний фон, фіолетові акценти,
/// мінімалістичні ховери-«пігулки». Шрифт — Segoe UI Variable (Win 11),
/// з graceful-фолбеком на Segoe UI (Win 10).
/// </summary>
internal static class TrayTheme
{
    public static readonly Color Background   = Color.FromArgb(0x0C, 0x0C, 0x16);
    public static readonly Color Background2  = Color.FromArgb(0x11, 0x11, 0x1E);
    public static readonly Color Hover        = Color.FromArgb(0x26, 0x1B, 0x3D);
    public static readonly Color HoverDanger  = Color.FromArgb(0x3D, 0x1B, 0x24);
    public static readonly Color Border       = Color.FromArgb(0x35, 0x24, 0x52);
    public static readonly Color Separator    = Color.FromArgb(0x22, 0x22, 0x32);
    public static readonly Color Text         = Color.FromArgb(0xF1, 0xF1, 0xF6);
    public static readonly Color TextMuted    = Color.FromArgb(0x9A, 0xA0, 0xB4);
    public static readonly Color Icon         = Color.FromArgb(0xC9, 0xCF, 0xF2);
    public static readonly Color Accent       = Color.FromArgb(0x8B, 0x5C, 0xF6);
    public static readonly Color AccentLight  = Color.FromArgb(0xA5, 0xB4, 0xFC);
    public static readonly Color Danger       = Color.FromArgb(0xFF, 0x7A, 0x8B);

    public static readonly Font MenuFont = CreateMenuFont();

    private static Font CreateMenuFont()
    {
        // Segoe UI Variable є лише на Win11; на Win10 PowerShell-перевірка
        // імені дає фолбек на Segoe UI, потім на системний sans-serif.
        foreach (var name in new[] { "Segoe UI Variable Text", "Segoe UI Variable Display", "Segoe UI Semibold", "Segoe UI" })
        {
            try
            {
                using var probe = new Font(name, 10f);
                if (!string.Equals(probe.Name, "Microsoft Sans Serif", StringComparison.OrdinalIgnoreCase))
                    return new Font(name, 10f, FontStyle.Regular, GraphicsUnit.Point);
            }
            catch { }
        }
        return new Font(FontFamily.GenericSansSerif, 10f, FontStyle.Regular, GraphicsUnit.Point);
    }
}

/// <summary>Професійна палітра під фірмовий рендерер: перекриває ВСІ
/// «системні» градієнти, щоб жоден не просвічував.</summary>
public class TrayMenuColorTable : ProfessionalColorTable
{
    public override Color ToolStripDropDownBackground => TrayTheme.Background;
    public override Color ToolStripBorder => TrayTheme.Background;
    public override Color ImageMarginGradientBegin => TrayTheme.Background;
    public override Color ImageMarginGradientMiddle => TrayTheme.Background;
    public override Color ImageMarginGradientEnd => TrayTheme.Background;
    public override Color MenuBorder => TrayTheme.Border;
    public override Color MenuItemBorder => Color.Transparent;
    public override Color MenuItemSelected => TrayTheme.Hover;
    public override Color MenuItemSelectedGradientBegin => TrayTheme.Hover;
    public override Color MenuItemSelectedGradientEnd => TrayTheme.Hover;
    public override Color MenuItemPressedGradientBegin => TrayTheme.Hover;
    public override Color MenuItemPressedGradientEnd => TrayTheme.Hover;
    public override Color SeparatorDark => TrayTheme.Separator;
    public override Color SeparatorLight => TrayTheme.Separator;
}

/// <summary>
/// Фірмовий рендерер меню трея: ховери-«пігулки» зі скругленими кутами,
/// тонкі сепаратори, рамка #352452, акуратні кольори тексту.
/// </summary>
public class TrayMenuRenderer : ToolStripProfessionalRenderer
{
    public TrayMenuRenderer() : base(new TrayMenuColorTable())
    {
        RoundedEdges = false;
    }

    internal static GraphicsPath RoundedPath(Rectangle r, int radius)
    {
        var path = new GraphicsPath();
        if (r.Width <= 0 || r.Height <= 0) { path.AddRectangle(new Rectangle(0, 0, 1, 1)); return path; }
        int d = Math.Min(radius * 2, Math.Min(r.Width, r.Height));
        path.AddArc(r.X, r.Y, d, d, 180, 90);
        path.AddArc(r.Right - d, r.Y, d, d, 270, 90);
        path.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
        path.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
        path.CloseFigure();
        return path;
    }

    protected override void OnRenderMenuItemBackground(ToolStripItemRenderEventArgs e)
    {
        if (e.Item is ToolStripMenuItem item && item.Enabled && item.Selected)
        {
            var g = e.Graphics;
            var rect = new Rectangle(3, 2, item.Width - 7, item.Height - 4);
            var danger = string.Equals(item.Tag as string, "danger", StringComparison.OrdinalIgnoreCase);
            using var brush = new SolidBrush(danger ? TrayTheme.HoverDanger : TrayTheme.Hover);
            using var path = RoundedPath(rect, 6);
            g.FillPath(brush, path);
            return; // системний прямокутник не малюємо
        }
        base.OnRenderMenuItemBackground(e);
    }

    protected override void OnRenderItemText(ToolStripItemTextRenderEventArgs e)
    {
        if (e.Item is ToolStripMenuItem mi)
        {
            var danger = string.Equals(mi.Tag as string, "danger", StringComparison.OrdinalIgnoreCase);
            if (mi.Selected && danger) e.TextColor = TrayTheme.Danger;
            else if (mi.Selected) e.TextColor = TrayTheme.Text;
            else if (mi.Enabled) e.TextColor = TrayTheme.Text;
            else e.TextColor = TrayTheme.TextMuted;
        }
        base.OnRenderItemText(e);
    }

    protected override void OnRenderSeparator(ToolStripSeparatorRenderEventArgs e)
    {
        var g = e.Graphics;
        int y = Math.Max(1, e.Item.Height / 2);
        using var pen = new Pen(TrayTheme.Separator);
        g.DrawLine(pen, 12, y, Math.Max(13, e.Item.Width - 12), y);
    }

    protected override void OnRenderToolStripBorder(ToolStripRenderEventArgs e)
    {
        var g = e.Graphics;
        using var pen = new Pen(TrayTheme.Border);
        var rect = new Rectangle(0, 0, e.ToolStrip.Width - 1, e.ToolStrip.Height - 1);
        g.DrawRectangle(pen, rect);
    }
}

/// <summary>
/// Бренд-заголовок меню: фіолетовий квадрат зі скругленням + біла блискавка
/// + «FluxControl». Неклікабельний, БЕЗ номера версії (ТЗ).
/// </summary>
public sealed class TrayBrandItem : ToolStripMenuItem
{
    public TrayBrandItem()
    {
        Enabled = false;
        AutoSize = false;
        Height = 46;
        Margin = new Padding(0);
        Padding = new Padding(12, 8, 8, 6);
    }

    public override Size GetPreferredSize(Size constrainingSize) => new(constrainingSize.Width, 46);

    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics;
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;

        // Бейдж 26x26: фіолетовий градієнт + блискавка (як в іконці застосунку)
        int badge = 26;
        int bx = 14;
        int by = (Height - badge) / 2;
        using (var badgePath = TrayMenuRenderer.RoundedPath(new Rectangle(bx, by, badge, badge), 8))
        using (var gradient = new LinearGradientBrush(new Rectangle(bx, by, badge, badge), TrayTheme.Accent, Color.FromArgb(0x63, 0x66, 0xF1), 45f))
        {
            g.FillPath(gradient, badgePath);
        }
        DrawBolt(g, bx + badge / 2f, by + badge / 2f, 6.2f, Color.White);

        // Назва бренду — БЕЗ версії (ТЗ)
        using var font = new Font(TrayTheme.MenuFont.FontFamily, 11.5f, FontStyle.Bold, GraphicsUnit.Point);
        TextRenderer.DrawText(g, "FluxControl", font,
            new Rectangle(bx + badge + 10, 0, Width - (bx + badge + 10) - 8, Height),
            TrayTheme.Text, TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.NoPadding);
    }

    internal static void DrawBolt(Graphics g, float cx, float cy, float scale, Color color)
    {
        // Пропорції блискавки бренду (нормалізовані 0..1, центр у 0.5/0.5)
        PointF[] pts =
        {
            new(0.62f, 0.05f), new(0.28f, 0.55f), new(0.50f, 0.55f),
            new(0.40f, 0.95f), new(0.74f, 0.42f), new(0.52f, 0.42f), new(0.66f, 0.05f)
        };
        var translated = new PointF[pts.Length];
        for (int i = 0; i < pts.Length; i++)
            translated[i] = new PointF(cx + (pts[i].X - 0.5f) * 2f * scale, cy + (pts[i].Y - 0.5f) * 2f * scale);
        using var brush = new SolidBrush(color);
        g.FillPolygon(brush, translated);
    }
}

/// <summary>Мінімалістичні монохромні іконки пунктів меню (18x18, малюються кодом).</summary>
internal static class TrayIcons
{
    private static Bitmap Draw(Action<Graphics> painter)
    {
        var bmp = new Bitmap(18, 18);
        using var g = Graphics.FromImage(bmp);
        g.SmoothingMode = SmoothingMode.AntiAlias;
        painter(g);
        return bmp;
    }

    private static GraphicsPath RoundRect(RectangleF r, float radius)
    {
        var path = new GraphicsPath();
        float d = radius * 2;
        path.AddArc(r.X, r.Y, d, d, 180, 90);
        path.AddArc(r.Right - d, r.Y, d, d, 270, 90);
        path.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
        path.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
        path.CloseFigure();
        return path;
    }

    /// <summary>«Відкрити»: вікно зі стрілкою-входом.</summary>
    public static Bitmap Open() => Draw(g =>
    {
        using var pen = new Pen(TrayTheme.Icon, 1.6f);
        using var path = RoundRect(new RectangleF(1.5f, 3f, 10.5f, 11f), 2.5f);
        g.DrawPath(pen, path);
        // стрілка вправо-всередину
        g.DrawLine(pen, 10f, 8.5f, 16f, 8.5f);
        g.DrawLine(pen, 13.2f, 5.7f, 16f, 8.5f);
        g.DrawLine(pen, 13.2f, 11.3f, 16f, 8.5f);
    });

    /// <summary>«Скопіювати»: дві накладені картки.</summary>
    public static Bitmap Copy() => Draw(g =>
    {
        using var pen = new Pen(TrayTheme.Icon, 1.6f);
        using var back = RoundRect(new RectangleF(5.5f, 1.5f, 10f, 10f), 2f);
        g.DrawPath(pen, back);
        using var frontBrush = new SolidBrush(TrayTheme.Background);
        using var front = RoundRect(new RectangleF(2.5f, 6.5f, 10f, 10f), 2f);
        g.FillPath(frontBrush, front);
        g.DrawPath(pen, front);
    });

    /// <summary>«Вихід»: класичний символ живлення.</summary>
    public static Bitmap Exit() => Draw(g =>
    {
        using var pen = new Pen(TrayTheme.Icon, 1.7f);
        // дуга кола з розривом зверху
        var rect = new RectangleF(3.5f, 5f, 11f, 11f);
        g.DrawArc(pen, rect, -60f, 300f);
        // вертикальна лінія
        g.DrawLine(pen, 9f, 1.5f, 9f, 9f);
    });
}

/// <summary>
/// Контекстне меню трея зі скругленими кутами (DWM, Win 11) і короткою
/// fade-анімацією появи (AnimateWindow, graceful-деградація на Win 10).
/// </summary>
public class TrayDropDown : ContextMenuStrip
{
    private const int DWMWA_WINDOW_CORNER_PREFERENCE = 33;
    private const int DWMWCP_ROUND = 2;
    private const int AW_BLEND = 0x00080000;
    private const int AW_ACTIVATE = 0x00020000;

    public TrayDropDown()
    {
        Renderer = new TrayMenuRenderer();
        ShowImageMargin = true;
        ShowCheckMargin = false;
        DoubleBuffered = true;
    }

    protected override void OnHandleCreated(EventArgs e)
    {
        base.OnHandleCreated(e);
        try
        {
            int pref = DWMWCP_ROUND;
            _ = DwmSetWindowAttribute(Handle, DWMWA_WINDOW_CORNER_PREFERENCE, ref pref, sizeof(int));
        }
        catch { }
    }

    protected override void SetVisibleCore(bool visible)
    {
        base.SetVisibleCore(visible);
        if (visible)
        {
            try { _ = AnimateWindow(Handle, 140, AW_BLEND | AW_ACTIVATE); }
            catch { }
        }
    }

    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool AnimateWindow(IntPtr hWnd, int dwTime, int dwFlags);

    [DllImport("dwmapi.dll")]
    private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int value, int attrSize);
}
