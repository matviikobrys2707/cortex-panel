using System;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace FluxControl.Agent.Services;

/// <summary>
/// Крос-ізолятні завдання (Deno Deploy, ТЗ 45) — винесено в окремий partial
/// (аудит п.5 «розбити великі файли по функціях»): полінг agent_jobs,
/// виконання завдань (WoL, share-abort, встановлення версії), звіт результатів.
/// </summary>
public partial class RelayClientService
{

    // ==================== Крос-ізолятні завдання (Deno Deploy, ТЗ 45) ====================
    // Deno Deploy розкидує HTTP-запити по ізолятах: WS агента живе на одному,
    // а REST (WoL з телефона, /s/<token> друга) прилітає на інший. Сервер
    // кладе завдання в D1 (agent_jobs), агент забирає їх полінгом і виконує.

    private int _jobPollerRunning;
    private static readonly HttpClient _jobHttpClient = new() { Timeout = TimeSpan.FromSeconds(8) };

    private void StartJobPoller()
    {
        if (Interlocked.CompareExchange(ref _jobPollerRunning, 1, 0) != 0) return;
        _ = Task.Run(async () =>
        {
            while (true)
            {
                try
                {
                    // Полінг дорогий лише для D1 (1 read / 2.5с — ~35к/добу,
                    // безкоштовний ліміт D1 — 5М читань/добу).
                    await Task.Delay(TimeSpan.FromSeconds(2.5));
                    if (_ws?.State != System.Net.WebSockets.WebSocketState.Open) continue;

                    var url = $"{_relayBaseUrl}/api/agent/jobs?hwid={Uri.EscapeDataString(_pairingService.HardwareId)}";
                    using var resp = await _jobHttpClient.GetAsync(url);
                    if (!resp.IsSuccessStatusCode) continue;
                    var json = await resp.Content.ReadAsStringAsync();
                    using var doc = System.Text.Json.JsonDocument.Parse(json);
                    if (!doc.RootElement.TryGetProperty("jobs", out var jobsEl) || jobsEl.ValueKind != JsonValueKind.Array) continue;

                    foreach (var job in jobsEl.EnumerateArray())
                    {
                        var jobId = job.TryGetProperty("job_id", out var jid) ? jid.GetString() : null;
                        var type = job.TryGetProperty("type", out var t) ? t.GetString() : null;
                        var payloadJson = job.TryGetProperty("payload", out var p) ? p.GetString() : "{}";
                        if (string.IsNullOrEmpty(jobId)) continue;
                        await ExecuteAgentJobAsync(jobId!, type ?? "", payloadJson ?? "{}");
                    }
                }
                catch { /* мережа/парсинг — наступний цикл */ }
            }
        });
    }

    private async Task ExecuteAgentJobAsync(string jobId, string type, string payloadJson)
    {
        try
        {
            using var payload = System.Text.Json.JsonDocument.Parse(payloadJson);
            var root = payload.RootElement;

            if (type == "wol_send")
            {
                var mac = root.TryGetProperty("mac", out var m) ? m.GetString() ?? "" : "";
                var ip = root.TryGetProperty("ip", out var i) ? i.GetString() ?? "" : "";
                var macBytes = WakeOnLanService.ParseMac(mac);
                if (macBytes == null)
                {
                    await PostJobResultAsync(jobId, ok: false, "Некоректний MAC-адреса");
                    return;
                }
                await WakeOnLanService.SendMagicPacketAsync(macBytes, ip);
                App.Log($"[WoL][JOB] Magic packet надіслано: {WakeOnLanService.FormatMac(macBytes)}{(string.IsNullOrWhiteSpace(ip) ? "" : $" → {ip}")}");
                await PostJobResultAsync(jobId, ok: true, "Magic packet надіслано");
            }
            else if (type == "share_download")
            {
                var token = root.TryGetProperty("token", out var tk) ? tk.GetString() ?? "" : "";
                var streamId = root.TryGetProperty("streamId", out var sid) ? sid.GetString() ?? "" : "";
                App.Log($"[Share][JOB] починаю стрім {streamId} для токена {token[..Math.Min(8, token.Length)]}…");
                await _shareService.StreamAsync(token, streamId, SendJsonAsync, CancellationToken.None);
            }
            else if (type == "share_abort")
            {
                var streamId = root.TryGetProperty("streamId", out var sid) ? sid.GetString() ?? "" : "";
                _shareService.CancelStream(streamId);
                await PostJobResultAsync(jobId, ok: true, "aborted");
            }
            else if (type == "update_install_version")
            {
                // Відкладене встановлення конкретної версії (пристрій був офлайн,
                // коли админ натиснув «Встановити» — завдання дочекалось поллінгу).
                var version = UpdateService.NormalizeVersion(root.TryGetProperty("version", out var v) ? v.GetString() ?? "" : "");
                await PostJobResultAsync(jobId, ok: true, $"Встановлення версії {version} почато");
                _ = Task.Run(async () =>
                {
                    try
                    {
                        var path = await UpdateService.InstallSpecificVersionAsync(version, null, CancellationToken.None);
                        UpdateInstaller.Launch(path, newVersion: version);
                    }
                    catch (Exception ex)
                    {
                        App.Log($"[UPDATE][JOB] Не вдалося встановити v{version}: {ex.Message}");
                    }
                });
            }
        }
        catch (Exception ex)
        {
            try { await PostJobResultAsync(jobId, ok: false, ex.Message); } catch { }
        }
    }

    private async Task PostJobResultAsync(string jobId, bool ok, string message)
    {
        try
        {
            var json = JsonSerializer.Serialize(new { jobId, ok, message }, _jsonOptions);
            using var content = new StringContent(json, Encoding.UTF8, "application/json");
            using var resp = await _jobHttpClient.PostAsync($"{_relayBaseUrl}/api/agent/jobs/result", content);
        }
        catch { }
    }

    /// <summary>
    /// Завантажує конкретну версію з архіву сайту і запускає штатний move-swap.
    /// true = встановлення почато (програма перезапуститься), false = сайт не віддав exe.
    /// </summary>
    private async Task<bool> RunVersionInstallAsync(string version)
    {
        try
        {
            var path = await UpdateService.InstallSpecificVersionAsync(version, null, CancellationToken.None);
            App.Log($"[UPDATE] v{version} завантажено ({new FileInfo(path).Length} байт) — запускаю swap");
            UpdateInstaller.Launch(path, newVersion: version);
            return true;
        }
        catch (Exception ex)
        {
            App.Log($"[UPDATE] Не вдалося встановити v{version}: {ex.Message}");
            return false;
        }
    }
}
