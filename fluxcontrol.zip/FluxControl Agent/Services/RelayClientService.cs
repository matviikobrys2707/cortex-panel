using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.WebSockets;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace FluxControl.Agent.Services;

public partial class RelayClientService : IDisposable
{
    private readonly PairingService _pairingService;
    private readonly SystemService _systemService;
    private readonly InputService _inputService;
    private readonly ProcessManagerService _processService;
    private readonly FileManagerService _fileService;
    private readonly MediaService _mediaService;

    private readonly string _relayBaseUrl;
    private ClientWebSocket? _ws;
    private CancellationTokenSource? _cts;
    private CancellationTokenSource? _screenStreamCts;
    private readonly SemaphoreSlim _sendLock = new(1, 1);
    private int _screenStreamFps;
    private int _screenStreamQuality;
    private int _screenStreamMaxWidth;
    // ТЗ 49 (економія трафіку): FNV-1a хеш останнього надісланого кадру (base64
    // рядка JPEG). Екран не змінився → кадр НЕ летить у релей (статиці ≈ 0 байт).
    private ulong _lastFrameHash;
    private long _lastFrameSentMs;
    private bool _isDisposed;

    // «Пряме з'єднання» (ТЗ 49): панельний сокет, прийнятий локальним шлюзом
    // DirectLinkService через публічний тунель. Коли він відкритий — ВЕСЬ
    // панельний трафік (стрим екрана, звук, файли, скриншоти, команди) йде
    // НАПРЯМУКУ на ПК, а не через хмарний релей: трафік Render ≈ 0.
    private volatile System.Net.WebSockets.WebSocket? _directSocket;
    private DirectLinkService? _directLink;
    // Спільний хаб терміналів: працює і для релей-сесії, і для прямої —
    // вкладки не рвуться при переключенні каналу.
    private readonly TerminalHubService _terminalHub = new();

    /// <summary>Разовий 64-символьний ключ прямої сесії (живе до перезапуску
    /// агента). Реєструється на сервері разом із URL тунеля; сервер віддає
    /// його лише власнику пристрою, тому знати його може тільки панель власника.</summary>
    public string DirectKey { get; } =
        Guid.NewGuid().ToString("N") + Guid.NewGuid().ToString("N");

    /// <summary>Поточний канал, на який треба відправляти панельні повідомлення:
    /// пряма сесія має пріоритет, релей — фолбек.</summary>
    private System.Net.WebSockets.WebSocket? PanelSocket
    {
        get
        {
            var direct = _directSocket;
            if (direct != null && direct.State == WebSocketState.Open) return direct;
            return _ws;
        }
    }

    public bool IsDirectPanelAttached
    {
        get
        {
            var d = _directSocket;
            return d != null && d.State == WebSocketState.Open;
        }
    }

    /// <summary>Сервіс прямого каналу (ставить MainWindow разом із PanelAttach).</summary>
    public DirectLinkService? DirectLink
    {
        get => _directLink;
        set
        {
            _directLink = value;
            if (value != null)
            {
                // URL тунеля змінився (рестарт ядра) — одразу реєструємо новий.
                value.OnUrlChanged += url => { _ = SendDirectRegisterIfConnectedAsync(); };
            }
        }
    }

    // Адаптивна частота телеметрії: сервер надсилає telemetry_rate — 1с поки
    // хтось дивиться сесію, 8с в очікуванні. 2500 — безпечний дефолт для
    // старого сервера: без команди трафік уже в 2.5 рази менший (економія
    // ліміту 5 ГБ/міс безкоштовного Render).
    private int _telemetryIntervalMs = 2500;

    private static readonly HttpClient _httpClient = new() { Timeout = TimeSpan.FromSeconds(6) };

    // Окремий клієнт для пробудження безкоштовного Render: інстанс засинає
    // без трафіку і тримає перший запит до ~хвилини, тому 6-секундний
    // таймаут основного клієнта тут не підходить.
    private static readonly HttpClient _warmupClient = new() { Timeout = TimeSpan.FromSeconds(70) };
    private static readonly JsonSerializerOptions _jsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        DictionaryKeyPolicy = JsonNamingPolicy.CamelCase
    };

    public bool IsConnected => _ws != null && _ws.State == WebSocketState.Open;
    public string Status { get; private set; } = "connecting"; // "connecting", "connected", "error"
    public string? LastError { get; private set; } = null;
    public event Action<bool>? OnConnectionStatusChanged;
    public event Action<string, string?>? OnStateChanged;
    private bool _lastConnectionStatus = false;
    private readonly SpeedTestService _speedTestService = new();
    public SpeedTestService SpeedTest => _speedTestService;
    private readonly ScheduledActionService _scheduledActions = new();
    public ScheduledActionService ScheduledActions => _scheduledActions;
    // «Додаткове» (ТЗ): очистка диска і блокування миші/клавіатури.
    private readonly DiskCleanupService _diskCleanup = new();
    private readonly InputBlockService _inputBlock = new();

    private readonly AppLauncherService _appLauncher = new();
    private readonly ShareService _shareService = new();
    private readonly TrollService _trollService = new();
    public InputBlockService InputBlock => _inputBlock;
    private WinLockService? _winLockService;
    private bool _autoSpeedtestDone;
    private int _reconnectAttempt;

    // ТЗ 46: стрим звука ПК + здоров'я ПК + «примусовий запуск».
    private readonly AudioStreamService _audioStream = new();
    private readonly SystemHealthService _healthService = new();
    /// <summary>MainWindow підключає збереження налаштування і сторожа.</summary>
    public Action<bool>? ForcedLaunchChanged { get; set; }
    /// <summary>Доступ для OnClosing (розморозити все при штатному виході).</summary>
    public ProcessManagerService ProcessOps => _processService;

    public RelayClientService(
        PairingService pairingService,
        SystemService systemService,
        InputService inputService,
        ProcessManagerService processService,
        FileManagerService fileService,
        MediaService mediaService,
        string relayBaseUrl = "https://fluxcontrol-backend-bl3u.onrender.com")
    {
        _pairingService = pairingService;
        _systemService = systemService;
        _inputService = inputService;
        _processService = processService;
        _fileService = fileService;
        _mediaService = mediaService;
        _relayBaseUrl = relayBaseUrl.TrimEnd('/');
        _speedTestService.OnResult += result => _ = SendSpeedTestResultAsync(result);
        _scheduledActions.StateChanged += state => { _ = SendTimerStateAsync(); };
        // Аварійна комбінація на ПК зняла блокування — миттєво синхронізуємо сайт.
        _inputBlock.AutoUnlocked += () => { _ = SendInputBlockStateAsync(); };

        // Хаб терміналів тепер спільний (релей + пряме з'єднання), тому його
        // події підключаються один раз тут, а не в циклі реконекту.
        _terminalHub.OnOutput += (tabId, text) => _ = SendJsonAsync(new { type = "terminal_output", tabId, data = text });
        _terminalHub.OnTabExited += (tabId) => _ = SendJsonAsync(new { type = "terminal_exit", tabId });
    }

    private async Task SendInputBlockStateAsync()
    {
        try { await SendJsonAsync(new { type = "input_block_state", data = _inputBlock.GetState() }); } catch { }
    }

    /// <summary>
    /// «Поділитися» (ТЗ): реєстрація активних токенів на релей-сервері.
    /// Сервер тримає їх у ПАМ'ЯТІ (сеансове життя); при реконекті агента
    /// реєстрація повторюється, при перезапуску агента токени зникають —
    /// посилання перестають працювати, як і домовлялись.
    /// </summary>
    private async Task RegisterSharesAsync()
    {
        try
        {
            var all = _shareService.All();
            if (all.Count == 0) return;
            await SendJsonAsync(new
            {
                type = "share_register_all",
                data = new
                {
                    shares = all.Select(s => new { token = s.Token, name = s.Name, isDir = s.IsDir, sizeBytes = s.SizeBytes })
                }
            });
        }
        catch { }
    }

    private async Task SendSpeedTestResultAsync(SpeedTestResultDto result)
    {
        try { await SendJsonAsync(new { type = "speedtest_result", data = result }); } catch { }
    }

    private async Task SendTimerStateAsync()
    {
        try { await SendJsonAsync(new { type = "timer_state", data = _scheduledActions.GetState() }); } catch { }
    }

    /// <summary>
    /// РЕАЛЬНИЙ стан відтворення (ТЗ): грає щось на ПК чи пауза — за піком
    /// гучності аудіовиходу (WASAPI, без WinRT). Плюс поточна гучність/mute.
    /// </summary>
    private async Task SendMediaStateAsync()
    {
        try
        {
            bool playing = false;
            bool sensorOk = false;
            try { sensorOk = AudioService.TryIsPlaying(out playing); } catch { }
            AudioService.TryGetVolume(out int volume);
            AudioService.TryGetMute(out bool muted);
            await SendJsonAsync(new
            {
                type = "media_state",
                data = new
                {
                    playing,
                    supported = sensorOk,
                    volume,
                    muted
                }
            });
        }
        catch { }
    }

    public void SetWinLockService(WinLockService winLockService)
    {
        _winLockService = winLockService;
        _winLockService.StateChanged += state => { _ = SendWinLockStateAsync(); };
    }

    private async Task SendWinLockStateAsync()
    {
        var svc = _winLockService;
        if (svc == null) return;
        try
        {
            await SendJsonAsync(new
            {
                type = "winlock_state",
                data = new { locked = svc.IsLocked, mode = svc.Mode, lockedAt = svc.LockedAt }
            });
        }
        catch { }
    }

    public void Start()
    {
        _cts = new CancellationTokenSource();
        _ = ConnectLoopAsync(_cts.Token);
    }

    public void ForceReconnect()
    {
        try
        {
            _ws?.Dispose();
            _ws = null;
        }
        catch { }
    }

    private void NotifyConnectionStatus(bool isConnected, string? error = null)
    {
        Status = isConnected ? "connected" : "error";
        LastError = error;
        if (_lastConnectionStatus != isConnected)
        {
            _lastConnectionStatus = isConnected;
            OnConnectionStatusChanged?.Invoke(isConnected);
            OnStateChanged?.Invoke(Status, LastError);
            App.Log($"[Relay] Connection status changed: {(isConnected ? "ONLINE" : "OFFLINE")} (Error: {error ?? "None"})");
        }
    }

    private async Task ConnectLoopAsync(CancellationToken ct)
    {
        while (!ct.IsCancellationRequested && !_isDisposed)
        {
            try
            {
                await RegisterWithRelayHttpAsync();

                // Прогрів хмари: сплячий Render віддає на WS-апгрейд 503
                // замість 101 («status code '503' when '101' was expected»),
                // тому спершу будимо інстанс простим GET.
                await WarmUpRelayAsync(ct);

                var wssUrl = _relayBaseUrl.Replace("https://", "wss://").Replace("http://", "ws://");
                var uri = new Uri($"{wssUrl}/ws?role=agent&code={_pairingService.DeviceCode}&hwid={_pairingService.HardwareId}");

                _ws = new ClientWebSocket();
                // Protocol-level ping/pong every 25s: Render's idle timeout was
                // silently killing the socket and the agent looked offline.
                _ws.Options.KeepAliveInterval = TimeSpan.FromSeconds(25);
                App.Log($"[Relay] Connecting to Render Relay: {uri}");
                using (var connectCts = CancellationTokenSource.CreateLinkedTokenSource(ct))
                {
                    connectCts.CancelAfter(TimeSpan.FromSeconds(12));
                    await _ws.ConnectAsync(uri, connectCts.Token);
                }
                App.Log("[Relay] Connected to Render Relay successfully!");
                NotifyConnectionStatus(true);
                _reconnectAttempt = 0;

                // Нова сесія веб-панелі (сторінка оновили / реконект) не має
                // іконок від попередньої сесії — скидання «вже надісланих»,
                // інакше після F5 список залишався БЕЗ іконок взагалі.
                _processService.ResetSentIcons();

                await SendInitialTelemetryAsync();

                // Push current WinLock state to every freshly (re)connected panel session.
                await SendWinLockStateAsync();

                // Фікс «з телефона кнопка розблокування недоступна»: нова панель
                // одразу отримує РЕАЛЬНИЙ стан блокування вводу (без чекання).
                await SendInputBlockStateAsync();

                // «Поділитися» (ТЗ): реєструємо активні токени на сервері після
                // кожного реконекту — посилання живуть, поки живий агент.
                await RegisterSharesAsync();

                // «Пряме з'єднання» (ТЗ 49): реєструємо URL тунеля на сервері.
                // Релей перезапускається (Render спить) → in-memory реєстр зникає,
                // тому повторюємо при кожному підключенні + періодично нижче.
                await SendDirectRegisterIfConnectedAsync();

                // Крос-ізолятні завдання (Deno Deploy): донор WoL і стрім
                // «Поділитися», коли REST-запит потрапив на інший ізолят.
                StartJobPoller();

                // Push the pending power timer (if any) so a refreshed page or a
                // newly connected panel shows the real countdown immediately.
                await SendTimerStateAsync();

                // Push current master volume so the web slider initializes instantly.
                try
                {
                    if (AudioService.TryGetVolume(out int initVolume) && AudioService.TryGetMute(out bool initMuted))
                    {
                        await SendJsonAsync(new { type = "volume_state", data = new { value = initVolume, muted = initMuted, success = true } });
                    }
                }
                catch { }

                // One automatic speed measurement per agent lifetime, right after
                // the relay link is up — the site shows it on the device Info tab.
                if (!_autoSpeedtestDone && _speedTestService.Last == null)
                {
                    _autoSpeedtestDone = true;
                    _ = Task.Run(() => _speedTestService.RunAsync(auto: true));
                }

                using var streamCts = CancellationTokenSource.CreateLinkedTokenSource(ct);

                // Періодична реєстрація URL прямого каналу (страховка від рестарту
                // релея) + тунель міг піднятися вже ПІСЛЯ підключення до релея.
                var directRegTask = Task.Run(async () =>
                {
                    while (!streamCts.Token.IsCancellationRequested && _ws?.State == WebSocketState.Open)
                    {
                        await SendDirectRegisterIfConnectedAsync();
                        await Task.Delay(TimeSpan.FromSeconds(60), streamCts.Token).ContinueWith(_ => { });
                    }
                }, streamCts.Token);

                var metricsTask = Task.Run(async () =>
                {
                    while (!streamCts.Token.IsCancellationRequested && _ws?.State == WebSocketState.Open)
                    {
                        try
                        {
                            var metrics = _systemService.GetMetrics();
                            var telemetry = new
                            {
                                type = "telemetry",
                                data = metrics,
                                speedTest = _speedTestService.Last,
                                isOnline = true,
                                lastSeen = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()
                            };
                            // Панель отримує телеметрію на АКТИВНИЙ канал (прямий має
                            // пріоритет). Якщо пряма сесія відкрита — дублюємо КОРІНЬ
                            // (кілька сотень байт) у релей, щоб сервер не позначив ПК
                            // офлайн, поки глядач сидить напряму.
                            if (IsDirectPanelAttached)
                            {
                                await SendRelayJsonAsync(telemetry);
                                var directActive = _directSocket;
                                if (directActive != null && directActive.State == WebSocketState.Open)
                                {
                                    await SendJsonAsync(telemetry);
                                }
                            }
                            else
                            {
                                await SendJsonAsync(telemetry);
                            }
                        }
                        catch { }
                        // Глядач напряму — 1с (свіжі метрики), інакше адаптивний інтервал.
                        var intervalMs = IsDirectPanelAttached ? 1000 : Math.Clamp(_telemetryIntervalMs, 500, 60000);
                        await Task.Delay(intervalMs, streamCts.Token).ContinueWith(_ => { });
                    }
                }, streamCts.Token);

                // ТЗ «гучність у реальному часі без затримки»: агент САМ пушить
                // volume_state при зміні (користувач покрутив гучність на ПК —
                // слайдер на сайті рухається за ним за ~0.7с, без перезавантажень)
                // + media_state при зміні «грає/пауза».
                var audioWatchTask = Task.Run(async () =>
                {
                    bool hasLast = false;
                    int lastVolume = -1; bool lastMuted = false; bool lastPlaying = false;
                    int tick = 0;
                    while (!streamCts.Token.IsCancellationRequested && _ws?.State == WebSocketState.Open)
                    {
                        try
                        {
                            if (AudioService.TryGetVolume(out int v) && AudioService.TryGetMute(out bool m))
                            {
                                if (!hasLast || v != lastVolume || m != lastMuted)
                                {
                                    lastVolume = v; lastMuted = m; hasLast = true;
                                    await SendJsonAsync(new { type = "volume_state", data = new { value = v, muted = m, success = true } });
                                }
                            }
                            // Пік звуку міряється ~180мс — достатньо раз на ~2с.
                            if (tick % 3 == 0 && AudioService.TryIsPlaying(out bool playing) && hasLast && playing != lastPlaying)
                            {
                                lastPlaying = playing;
                                await SendMediaStateAsync();
                            }
                            else if (tick % 3 == 0 && !hasLast && AudioService.TryIsPlaying(out bool p0))
                            {
                                lastPlaying = p0; hasLast = true;
                            }
                            tick++;
                        }
                        catch { }
                        await Task.Delay(700, streamCts.Token).ContinueWith(_ => { });
                    }
                }, streamCts.Token);

                var buffer = new byte[64 * 1024];
                while (_ws.State == WebSocketState.Open && !ct.IsCancellationRequested)
                {
                    var ms = new MemoryStream();
                    WebSocketReceiveResult result;
                    do
                    {
                        result = await _ws.ReceiveAsync(new ArraySegment<byte>(buffer), ct);
                        if (result.MessageType == WebSocketMessageType.Close)
                        {
                            await _ws.CloseAsync(WebSocketCloseStatus.NormalClosure, "Closing", ct);
                            break;
                        }
                        ms.Write(buffer, 0, result.Count);
                    } while (!result.EndOfMessage);

                    if (result.MessageType == WebSocketMessageType.Close) break;

                    var jsonStr = Encoding.UTF8.GetString(ms.ToArray());
                    _ = HandleIncomingMessageAsync(jsonStr, _terminalHub);
                }

                streamCts.Cancel();
                // Стрим звука не повинен пережити мертвий сокет.
                try { _audioStream.Stop(); } catch { }
                await metricsTask.ContinueWith(_ => { });
            }
            catch (Exception ex)
            {
                if (!ct.IsCancellationRequested)
                {
                    _reconnectAttempt++;
                    var delay = TimeSpan.FromSeconds(Math.Min(60, 4 * _reconnectAttempt));
                    App.Log($"[Relay] Disconnected: {ex.Message}. Reconnecting in {delay.TotalSeconds:F0}s...");
                    NotifyConnectionStatus(false, ex.Message);
                }
                // БЕЗПЕКА: рвалися зв’язок — знімаємо блокування вводу, щоб
                // власник не залишився з «мертвою» мишею/клавіатурою назавжди.
                try { if (_inputBlock.IsBlocked) _inputBlock.Release(); } catch { }
            }
            finally
            {
                _ws?.Dispose();
                _ws = null;
            }

            if (!ct.IsCancellationRequested && !_isDisposed)
            {
                var backoff = TimeSpan.FromSeconds(Math.Min(60, 4 * Math.Max(1, _reconnectAttempt)));
                await Task.Delay(backoff, ct).ContinueWith(_ => { });
            }
        }
    }

    /// <summary>
    /// Будимо безкоштовний Render (інстанс засинає без трафіку).
    /// GET "/" повертає 200/404, як тільки служба жива; 5xx/таймаут —
    /// інстанс ще прокидається, повторюємо. До ~2 хв у гіршому разі.
    /// </summary>
    private async Task WarmUpRelayAsync(CancellationToken ct)
    {
        for (int attempt = 1; attempt <= 8; attempt++)
        {
            try
            {
                using var cts = CancellationTokenSource.CreateLinkedTokenSource(ct);
                cts.CancelAfter(TimeSpan.FromSeconds(65));
                using var resp = await _warmupClient.GetAsync($"{_relayBaseUrl}/", cts.Token);
                if ((int)resp.StatusCode < 500)
                {
                    App.Log($"[Relay] Cloud service is awake (HTTP {(int)resp.StatusCode}).");
                    return;
                }
                App.Log($"[Relay] Warm-up: HTTP {(int)resp.StatusCode} (instance still waking), attempt {attempt}/8.");
            }
            catch (OperationCanceledException) when (!ct.IsCancellationRequested)
            {
                App.Log($"[Relay] Warm-up: request timed out, attempt {attempt}/8.");
            }
            catch (Exception ex)
            {
                App.Log($"[Relay] Warm-up attempt {attempt}/8 failed: {ex.Message}");
            }
            await Task.Delay(TimeSpan.FromSeconds(4), ct).ContinueWith(_ => { });
        }
        App.Log("[Relay] Warm-up finished without confirmation — trying WebSocket anyway.");
    }

    private async Task RegisterWithRelayHttpAsync()
    {
        try
        {
            var payload = new
            {
                hwid = _pairingService.HardwareId,
                code = _pairingService.DeviceCode,
                name = Environment.MachineName,
                username = Environment.UserName,
                os = _systemService.OsName,
                cpu = _systemService.CpuName,
                ram = $"{_systemService.TotalRamGb:F0} GB",
                gpu = _systemService.GpuName,
                localIp = _systemService.LanIp,
                adapters = _systemService.GetNetworkAdapters(),
                localUrl = "http://127.0.0.1:5080",
                activeUrl = $"{_relayBaseUrl}/ws?role=client&code={_pairingService.DeviceCode}"
            };
            var json = JsonSerializer.Serialize(payload, _jsonOptions);
            using var content1 = new StringContent(json, Encoding.UTF8, "application/json");
            using var content2 = new StringContent(json, Encoding.UTF8, "application/json");

            // Register with Render
            try { await _httpClient.PostAsync($"{_relayBaseUrl}/api/register", content1); } catch { }
            // Register with Cloudflare Pages D1
            try { await _httpClient.PostAsync("https://fluxcontrol.pages.dev/api/agent/register", content2); } catch { }
        }
        catch { }
    }

    private async Task SendInitialTelemetryAsync()
    {
        await SendJsonAsync(new
        {
            type = "telemetry",
            code = _pairingService.DeviceCode,
            pcUsername = Environment.UserName,
            machineName = Environment.MachineName,
            osName = _systemService.OsName,
            cpuName = _systemService.CpuName,
            gpuName = _systemService.GpuName,
            ramTotal = $"{_systemService.TotalRamGb:F0} GB",
            isOnline = true
        });
    }

    private async Task HandleIncomingMessageAsync(string jsonStr, TerminalHubService terminalHub)
    {
        JsonObject? msg = null;
        try { msg = JsonSerializer.Deserialize<JsonObject>(jsonStr); } catch { }
        if (msg == null) return;

        var type = msg["type"]?.GetValue<string>() ?? "";

        switch (type)
        {
            case "ping":
            case "health_check":
                await SendJsonAsync(new
                {
                    type = "pong",
                    timestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
                    // Індикатор з'єднання панелі: echoTs для вимірювання RTT канала.
                    echoTs = msg["ts"]?.GetValue<long>() ?? 0,
                    machineName = Environment.MachineName,
                    userName = Environment.UserName,
                    pcUsername = Environment.UserName,
                    status = "ok",
                    cpuName = _systemService.CpuName,
                    gpuName = _systemService.GpuName
                });
                try
                {
                    var instantMetrics = _systemService.GetMetrics();
                    await SendJsonAsync(new
                    {
                        type = "telemetry",
                        data = instantMetrics,
                        speedTest = _speedTestService.Last,
                        isOnline = true,
                        lastSeen = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()
                    });
                }
                catch { }
                break;

            case "telemetry_rate":
                // Економія трафіку хмари: сервер каже, як часто слати телеметрію.
                _telemetryIntervalMs = Math.Clamp(msg["ms"]?.GetValue<int>() ?? 2500, 500, 60000);
                App.Log($"[Relay] Telemetry interval set to {_telemetryIntervalMs}ms");
                break;

            case "mouse_move":
                _inputService.MoveMouse(msg["dx"]?.GetValue<int>() ?? 0, msg["dy"]?.GetValue<int>() ?? 0);
                break;

            case "mouse_move_abs":
                // AI-агент: абсолютні нормалізовані координати 0..1000.
                _inputService.MoveMouseAbsoluteNormalized(
                    msg["nx"]?.GetValue<double>() ?? 0,
                    msg["ny"]?.GetValue<double>() ?? 0);
                break;

            case "mouse_click":
                _inputService.MouseClick(msg["button"]?.GetValue<string>() ?? "left", msg["double"]?.GetValue<bool>() ?? false);
                break;

            case "mouse_down":
                _inputService.MouseDown(msg["button"]?.GetValue<string>() ?? "left");
                break;

            case "mouse_up":
                _inputService.MouseUp(msg["button"]?.GetValue<string>() ?? "left");
                break;

            case "mouse_scroll":
                // Тачпад (ТЗ 46): щипок двома пальцями = скрол із Ctrl (зум).
                _inputService.MouseScrollEx(
                    msg["dx"]?.GetValue<int>() ?? 0,
                    msg["dy"]?.GetValue<int>() ?? 0,
                    msg["ctrl"]?.GetValue<bool>() ?? false,
                    msg["shift"]?.GetValue<bool>() ?? false,
                    msg["alt"]?.GetValue<bool>() ?? false);
                break;

            case "key_press":
                string key = msg["key"]?.GetValue<string>() ?? "";
                var mods = msg["modifiers"]?.AsArray().Select(x => x?.ToString() ?? "").ToList();
                _inputService.KeyPress(key, mods);
                break;

            case "key_down":
                _inputService.KeyDown(msg["key"]?.GetValue<string>() ?? "");
                break;

            case "key_up":
                _inputService.KeyUp(msg["key"]?.GetValue<string>() ?? "");
                break;

            case "key_text":
                _inputService.SendText(msg["text"]?.GetValue<string>() ?? "");
                break;

            case "volume_get":
                {
                    bool gotVol = AudioService.TryGetVolume(out int curVolume);
                    bool gotMute = AudioService.TryGetMute(out bool curMuted);
                    await SendJsonAsync(new { type = "volume_state", data = new { value = curVolume, muted = curMuted, success = gotVol && gotMute } });
                }
                break;

            case "volume":
                {
                    string direction = msg["direction"]?.GetValue<string>() ?? "set";
                    int step = Math.Clamp(msg["step"]?.GetValue<int>() ?? 2, 1, 20);
                    int target = Math.Clamp(msg["value"]?.GetValue<int>() ?? 50, 0, 100);

                    bool ok;
                    if (direction == "set")
                    {
                        ok = AudioService.TrySetVolume(target);
                        if (!ok) _inputService.SetVolume(target);
                    }
                    else
                    {
                        ok = AudioService.TryGetVolume(out int cur)
                             && AudioService.TrySetVolume(Math.Clamp(cur + (direction == "up" ? step : -step), 0, 100));
                        if (!ok) _inputService.MediaControl(direction == "up" ? "volume_up" : "volume_down");
                    }

                    AudioService.TryGetVolume(out int finalVolume);
                    AudioService.TryGetMute(out bool finalMuted);
                    await SendJsonAsync(new { type = "volume_state", data = new { value = finalVolume, muted = finalMuted, success = ok } });
                }
                break;

            case "media":
            case "media_control":
                string mediaCmd = msg["command"]?.GetValue<string>() ?? "";
                _inputService.MediaControl(mediaCmd);
                // РЕАЛЬНИЙ статус плеєра (ТЗ): після дії трохи чекаємо і шлемо
                // свіжий стан (грає/пауза + пік гучності).
                _ = Task.Run(async () =>
                {
                    await Task.Delay(500);
                    await SendMediaStateAsync();
                });
                break;

            case "shortcut":
                string sc = msg["shortcut"]?.GetValue<string>() ?? "";
                if (!string.IsNullOrWhiteSpace(sc))
                {
                    _inputService.ExecuteShortcut(sc);
                }
                break;

            case "get_network_info":
                {
                    var netMetrics = _systemService.GetMetrics();
                    await SendJsonAsync(new
                    {
                        type = "network_info",
                        data = new { lanIp = netMetrics.LanIp, wanIp = netMetrics.WanIp }
                    });
                }
                break;

            case "get_screen_info":
                // Рамка «Екран» (ТЗ): модель монітора / роздільність / герцовка / масштаб.
                {
                    var m = _systemService.GetMetrics();
                    await SendJsonAsync(new
                    {
                        type = "screen_info",
                        data = new
                        {
                            model = m.ScreenModel,
                            resolution = m.ScreenResolution,
                            refreshHz = m.ScreenRefreshHz,
                            scalePercent = m.ScreenScalePercent
                        }
                    });
                }
                break;

            case "get_media_status":
                // РЕАЛЬНИЙ статус відтворення (ТЗ «Медіа та звук»).
                await SendMediaStateAsync();
                break;

            case "clean_disk_scan":
                // «Очистка диска» (ТЗ): рахуємо розміри категорій у фоні.
                _ = Task.Run(async () =>
                {
                    try
                    {
                        var scan = await _diskCleanup.ScanAsync();
                        await SendJsonAsync(new { type = "clean_disk_report", data = scan });
                    }
                    catch (Exception ex)
                    {
                        await SendJsonAsync(new { type = "clean_disk_report", data = new { error = ex.Message, categories = Array.Empty<object>() } });
                    }
                });
                break;

            case "clean_disk_run":
                {
                    var keys = new List<string>();
                    try
                    {
                        if (msg["keys"] is JsonArray arr)
                            foreach (var el in arr)
                                keys.Add(el?.ToString() ?? "");
                        keys = keys.Where(k => !string.IsNullOrWhiteSpace(k)).ToList();
                    }
                    catch { }
                    _ = Task.Run(async () =>
                    {
                        try
                        {
                            var run = await _diskCleanup.CleanAsync(keys.Count > 0 ? keys : null);
                            await SendJsonAsync(new { type = "clean_disk_result", data = run });
                        }
                        catch (Exception ex)
                        {
                            await SendJsonAsync(new { type = "clean_disk_result", data = new { freedBytes = 0, error = ex.Message, results = Array.Empty<object>() } });
                        }
                    });
                }
                break;

            case "block_input":
            case "input_block":
                {
                    var state = _inputBlock.Engage();
                    await SendJsonAsync(new { type = "input_block_state", data = state });
                }
                break;

            case "unblock_input":
            case "input_unblock":
                {
                    var state = _inputBlock.Release();
                    await SendJsonAsync(new { type = "input_block_state", data = state });
                }
                break;

            case "input_block_get":
                await SendJsonAsync(new { type = "input_block_state", data = _inputBlock.GetState() });
                break;

            case "fs_special":
                // Панель швидкого доступу (ТЗ): Робочий стіл / Завантаження / …
                await SendJsonAsync(new { type = "fs_special_result", data = FileManagerService.GetSpecialFolders() });
                break;

            // ========================= «Поділитися» (ТЗ) =========================
            case "fs_share_create":
                {
                    string sharePath = msg["path"]?.GetValue<string>() ?? "";
                    var entry = _shareService.Create(sharePath);
                    if (entry != null)
                    {
                        await SendJsonAsync(new
                        {
                            type = "fs_share_result",
                            data = new { ok = true, token = entry.Token, name = entry.Name, isDir = entry.IsDir, sizeBytes = entry.SizeBytes }
                        });
                        // Реєструємо токен на сервері одразу (не чекаючи реконекту).
                        await RegisterSharesAsync();
                    }
                    else
                    {
                        await SendJsonAsync(new { type = "fs_share_result", data = new { ok = false, error = "Файл/папку не знайдено на ПК" } });
                    }
                }
                break;

            case "fs_share_remove":
                _shareService.Remove(msg["token"]?.GetValue<string>() ?? "");
                // Оновлюємо реєстр на сервері (токен більше не активний).
                await RegisterSharesAsync();
                break;

            case "fs_trash_list":
                await SendJsonAsync(new { type = "fs_trash_list_result", data = new { items = _shareService.ListTrash() } });
                break;

            case "fs_trash_empty":
                {
                    var (ok, err) = _shareService.EmptyTrash();
                    await SendJsonAsync(new { type = "fs_trash_empty_result", data = new { success = ok, error = err } });
                }
                break;

            case "share_stream_begin":
                {
                    string token = msg["token"]?.GetValue<string>() ?? "";
                    string streamId = msg["streamId"]?.GetValue<string>() ?? "";
                    _ = Task.Run(async () =>
                    {
                        try { await _shareService.StreamAsync(token, streamId, SendJsonAsync, CancellationToken.None); }
                        catch { }
                    });
                }
                break;

            case "share_stream_abort":
                _shareService.CancelStream(msg["streamId"]?.GetValue<string>() ?? "");
                break;

            // ==================== «Функції для тролінгу» (ТЗ) ====================
            case "troll_messageboxes":
                {
                    string text = msg["text"]?.GetValue<string>() ?? "";
                    int count = msg["count"]?.GetValue<int>() ?? 1;
                    var (ok, err) = _trollService.ShowMessageBoxes(text, count);
                    await SendJsonAsync(new { type = "troll_result", data = new { action = "messageboxes", success = ok, error = err } });
                }
                break;

            case "troll_speak":
                {
                    string text = msg["text"]?.GetValue<string>() ?? "";
                    int repeat = msg["repeat"]?.GetValue<int>() ?? 1;
                    var (ok, err) = _trollService.SpeakText(text, repeat);
                    await SendJsonAsync(new { type = "troll_result", data = new { action = "speak", success = ok, error = err } });
                }
                break;

            case "troll_consoles":
                {
                    int count = msg["count"]?.GetValue<int>() ?? 1;
                    bool autoClose = msg["autoClose"]?.GetValue<bool>() ?? false;
                    var (ok, err) = _trollService.OpenConsoles(count, autoClose);
                    await SendJsonAsync(new { type = "troll_result", data = new { action = "consoles", success = ok, error = err } });
                }
                break;

            case "troll_rotate":
                {
                    int degrees = msg["degrees"]?.GetValue<int>() ?? 0;
                    var (ok, err) = _trollService.RotateScreen(degrees);
                    await SendJsonAsync(new { type = "troll_result", data = new { action = "rotate", success = ok, error = err, degrees } });
                }
                break;

            case "troll_screamer":
                // СКРИМЕР (ТЗ 2025-10): ассети з GitHub assets/, кеш у %AppData%,
                // синхронний старт фото+звуку, безкінечний луп 2с-звуку до кінця.
                {
                    int scrSec = msg["seconds"]?.GetValue<int>() ?? 10;
                    var (ok, err) = _trollService.RunScreamer(scrSec);
                    await SendJsonAsync(new { type = "troll_result", data = new { action = "screamer", success = ok, error = err } });
                }
                break;

            case "fs_upload_begin":
                // Чанкове завантаження (ТЗ: без ліміту 48 МБ).
                {
                    string upId = msg["id"]?.GetValue<string>() ?? "";
                    string target = msg["path"]?.GetValue<string>() ?? "";
                    int totalChunks = msg["totalChunks"]?.GetValue<int>() ?? 1;
                    try
                    {
                        _fileService.BeginUpload(upId, target, totalChunks);
                        await SendJsonAsync(new { type = "fs_upload_begin_result", uploadId = upId, success = true });
                    }
                    catch (Exception ex)
                    {
                        await SendJsonAsync(new { type = "fs_upload_file_result", uploadId = upId, success = false, path = target, error = ex.Message });
                    }
                }
                break;

            case "fs_upload_chunk":
                {
                    string upId = msg["id"]?.GetValue<string>() ?? "";
                    int idx = msg["index"]?.GetValue<int>() ?? -1;
                    string data = msg["data"]?.GetValue<string>() ?? "";
                    try
                    {
                        _fileService.AppendUploadChunk(upId, idx, data);
                    }
                    catch (Exception ex)
                    {
                        _fileService.AbortUpload(upId);
                        await SendJsonAsync(new { type = "fs_upload_file_result", uploadId = upId, success = false, error = ex.Message });
                    }
                }
                break;

            case "fs_upload_end":
                {
                    string upId = msg["id"]?.GetValue<string>() ?? "";
                    try
                    {
                        var finalPath = _fileService.EndUpload(upId);
                        await SendJsonAsync(new { type = "fs_upload_file_result", uploadId = upId, success = true, path = finalPath });
                    }
                    catch (Exception ex)
                    {
                        _fileService.AbortUpload(upId);
                        await SendJsonAsync(new { type = "fs_upload_file_result", uploadId = upId, success = false, error = ex.Message });
                    }
                }
                break;

            case "fs_upload_cancel":
                _fileService.AbortUpload(msg["id"]?.GetValue<string>() ?? "");
                break;

            case "apps_list":
                // Запуск програм (ТЗ): список встановлених застосунків Пуску.
                _ = Task.Run(async () =>
                {
                    try
                    {
                        var apps = _appLauncher.GetInstalledApps();
                        await SendJsonAsync(new
                        {
                            type = "apps_list_result",
                            data = new { apps = apps.Select(a => new { name = a.Name, path = a.Path }) }
                        });
                        // Іконки — фоном партіями по 10, щоб список з'являвся миттєво.
                        var paths = apps.Select(a => a.Path).ToList();
                        for (int i = 0; i < paths.Count && _ws?.State == WebSocketState.Open; i += 10)
                        {
                            var icons = AppLauncherService.ExtractIconsBatch(paths.Skip(i).Take(10));
                            if (icons.Count > 0)
                                await SendJsonAsync(new { type = "app_icons", data = new { icons } });
                            await Task.Delay(60);
                        }
                    }
                    catch (Exception ex)
                    {
                        await SendJsonAsync(new { type = "apps_list_result", data = new { apps = Array.Empty<object>(), error = ex.Message } });
                    }
                });
                break;

            case "app_launch":
                {
                    string appPath = msg["path"]?.GetValue<string>() ?? "";
                    var (ok, err) = _appLauncher.Launch(appPath);
                    await SendJsonAsync(new
                    {
                        type = "app_launch_result",
                        data = new { success = ok, path = appPath, name = Path.GetFileNameWithoutExtension(appPath), error = err }
                    });
                }
                break;

            case "windows_list":
                // Перегляд вікон (ТЗ): список видимих вікон без виведення на перед.
                _ = Task.Run(async () =>
                {
                    try
                    {
                        var wins = WindowCaptureService.GetVisibleWindows();
                        await SendJsonAsync(new
                        {
                            type = "windows_list_result",
                            data = new { windows = wins.Select(w => new { hwnd = w.Hwnd, title = w.Title, process = w.Process, minimized = w.Minimized }) }
                        });
                    }
                    catch (Exception ex)
                    {
                        await SendJsonAsync(new { type = "windows_list_result", data = new { windows = Array.Empty<object>(), error = ex.Message } });
                    }
                });
                break;

            case "window_capture":
                {
                    long hwnd = msg["hwnd"]?.GetValue<long>() ?? 0;
                    int quality = Math.Clamp(msg["quality"]?.GetValue<int>() ?? 70, 30, 95);
                    _ = Task.Run(async () =>
                    {
                        try
                        {
                            var b64 = WindowCaptureService.CaptureWindowBase64(hwnd, quality);
                            await SendJsonAsync(new
                            {
                                type = "window_capture_result",
                                data = new { hwnd, imageBase64 = b64, error = b64 == null ? "Вікно недоступне для знімка" : null }
                            });
                        }
                        catch (Exception ex)
                        {
                            await SendJsonAsync(new { type = "window_capture_result", data = new { hwnd, imageBase64 = (string?)null, error = ex.Message } });
                        }
                    });
                }
                break;

            case "clean_disk_smart_scan":
                // «Умне сканування» (ТЗ): ШІ шукає кеші, додає у список і запам'ятовує.
                _ = Task.Run(async () =>
                {
                    try
                    {
                        var scan = await _diskCleanup.SmartScanAsync();
                        await SendJsonAsync(new { type = "clean_disk_smart_report", data = scan });
                    }
                    catch (Exception ex)
                    {
                        await SendJsonAsync(new { type = "clean_disk_smart_report", data = new { error = ex.Message, categories = Array.Empty<object>() } });
                    }
                });
                break;

            case "ai_cleanup_gather":
                // УМНА ОЧИСТКА (ТЗ): збираємо огляд ПК — ШІ проаналізує і запитає.
                _ = Task.Run(async () =>
                {
                    try
                    {
                        var overview = await _diskCleanup.GatherAiOverviewAsync();
                        await SendJsonAsync(new { type = "ai_cleanup_overview", data = overview });
                    }
                    catch (Exception ex)
                    {
                        await SendJsonAsync(new { type = "ai_cleanup_overview", data = new { error = ex.Message } });
                    }
                });
                break;

            case "ai_cleanup_apply":
                // Затверджені користувачем пункти (ТЗ: ШІ запитав → користувач «Так»).
                {
                    var accepted = new List<(string Title, string Path)>();
                    foreach (var it in msg["items"] as JsonArray ?? new JsonArray())
                    {
                        var obj = it as JsonObject;
                        if (obj == null) continue;
                        accepted.Add((
                            obj["title"]?.GetValue<string>() ?? "",
                            obj["path"]?.GetValue<string>() ?? ""
                        ));
                    }
                    _ = Task.Run(async () =>
                    {
                        try
                        {
                            var added = _diskCleanup.ApplyAiItems(accepted);
                            await SendJsonAsync(new { type = "ai_cleanup_apply_result", data = new { categories = added, added = added.Count } });
                        }
                        catch (Exception ex)
                        {
                            await SendJsonAsync(new { type = "ai_cleanup_apply_result", data = new { categories = Array.Empty<object>(), added = 0, error = ex.Message } });
                        }
                    });
                }
                break;

            case "clean_disk_remove":
                {
                    var removeKeys = new List<string>();
                    try
                    {
                        if (msg["keys"] is JsonArray rarr)
                            foreach (var el in rarr)
                                removeKeys.Add(el?.ToString() ?? "");
                    }
                    catch { }
                    _diskCleanup.RemoveAiKeys(removeKeys);
                }
                break;

            case "get_network_adapters":
                // Живий список адаптерів для вкладки «Додаткове» (Wake-on-LAN).
                await SendJsonAsync(new
                {
                    type = "network_adapters",
                    data = new { adapters = _systemService.GetNetworkAdapters() }
                });
                break;

            case "run_speedtest":
                _ = Task.Run(() => _speedTestService.RunAsync());
                await SendJsonAsync(new { type = "speedtest_progress", data = new { running = true, stage = "підготовка…" } });
                break;

            case "power":
                string action = msg["action"]?.GetValue<string>() ?? "";
                switch (action.ToLowerInvariant())
                {
                    case "shutdown": _systemService.Shutdown(); break;
                    case "restart": _systemService.Restart(); break;
                    case "sleep": _systemService.Sleep(); break;
                    case "hibernate": _systemService.Hibernate(); break;
                    case "monitor_off": _systemService.MonitorOff(); break;
                    case "lock": _systemService.LockScreen(); break;
                }
                break;

            case "wol_send":
                {
                    // Wake-on-LAN релей: цей ПК онлайн і виступає донором для
                    // вимкненої машини в тій самій локальній мережі. Хмара
                    // фізично не може надіслати UDP-broadcast — тому сервер
                    // передає команду сюди, а ми розсилаємо пакет локально.
                    string wolMac = msg["mac"]?.GetValue<string>() ?? "";
                    string wolRequestId = msg["requestId"]?.GetValue<string>() ?? "";
                    // Опційна IP для спрямованого бродкасту (ТЗ: поле IP у налаштуваннях WoL).
                    string wolIp = msg["ip"]?.GetValue<string>() ?? "";
                    _ = Task.Run(async () =>
                    {
                        var macBytes = WakeOnLanService.ParseMac(wolMac);
                        if (macBytes == null)
                        {
                            await SendJsonAsync(new { type = "wol_result", requestId = wolRequestId, ok = false,
                                message = "Некоректний MAC-адреса" });
                            return;
                        }
                        try
                        {
                            await WakeOnLanService.SendMagicPacketAsync(macBytes, wolIp);
                            App.Log($"[WoL] Magic packet надіслано: {WakeOnLanService.FormatMac(macBytes)}{(string.IsNullOrWhiteSpace(wolIp) ? "" : $" → {wolIp}")}");
                            await SendJsonAsync(new { type = "wol_result", requestId = wolRequestId, ok = true,
                                message = "Magic packet надіслано" });
                        }
                        catch (Exception ex)
                        {
                            App.Log($"[WoL] Помилка надсилання: {ex.Message}");
                            await SendJsonAsync(new { type = "wol_result", requestId = wolRequestId, ok = false,
                                message = ex.Message });
                        }
                    });
                }
                break;

            case "winlock_lock":
                {
                    try
                    {
                        var lockMode = msg["mode"]?.GetValue<string>() ?? WinLockService.ModeCode;
                        var lockCode = msg["code"]?.GetValue<string>();
                        _winLockService?.Lock(lockMode, lockCode);
                    }
                    catch (ArgumentException ex)
                    {
                        App.Log($"[WinLock] Rejected lock request: {ex.Message}");
                    }
                    catch (Exception ex)
                    {
                        App.Log($"[WinLock] Lock request failed: {ex.Message}");
                    }
                    await SendWinLockStateAsync();
                }
                break;

            case "winlock_unlock":
                // The owner's web panel is trusted — explicit site override always unlocks.
                _winLockService?.UnlockFromSite();
                await SendWinLockStateAsync();
                break;

            case "winlock_get":
                await SendWinLockStateAsync();
                break;

            case "camera_list":
                {
                    var cams = await _mediaService.ListVideoDevicesAsync();
                    await SendJsonAsync(new { type = "camera_list", data = new { cameras = cams.Select(n => new { name = n }) } });
                }
                break;

            case "timer_start":
                {
                    // Unified power timer: ANY action (shutdown/restart/sleep/
                    // hibernate/lock) with minutes OR raw seconds from the site.
                    string timerAction = msg["action"]?.GetValue<string>() ?? "shutdown";
                    int seconds = msg["seconds"]?.GetValue<int>() ?? 0;
                    if (seconds <= 0)
                    {
                        double minutes = msg["minutes"]?.GetValue<double>() ?? 0;
                        seconds = (int)Math.Round(minutes * 60);
                    }
                    if (seconds <= 0) seconds = 60;
                    try
                    {
                        _scheduledActions.Start(timerAction, seconds);
                        await SendJsonAsync(new { type = "timer_ack", ok = true, action = timerAction, seconds });
                    }
                    catch (ArgumentException ex)
                    {
                        App.Log($"[Timer] Rejected start: {ex.Message}");
                        await SendJsonAsync(new { type = "timer_ack", ok = false, error = ex.Message });
                    }
                }
                break;

            case "timer_cancel":
                _scheduledActions.Cancel();
                break;

            case "timer_get":
                await SendTimerStateAsync();
                break;

            case "open_url":
                _systemService.OpenUrl(msg["url"]?.GetValue<string>() ?? "");
                break;

            case "get_processes":
            case "process_list":
                {
                    var procs = _processService.GetProcesses();
                    var icons = _processService.GetNewIcons(procs);
                    // version/binStamp (ТЗ 55): веб-кеш іконок у localStorage
                    // скидається, коли програма оновилась (змінився час exe агента).
                    // FIX: реальна вшита версія (CurrentVersion — це лише фолбек-константа 1.0.0).
                    await SendJsonAsync(new { type = "process_list", data = new { processes = procs, icons = icons, version = UpdateService.GetLocalVersion(), binStamp = AgentBinStamp() } });
                    // Фонове добування решти іконок (повідомлення process_icons):
                    // ВСІ процеси отримують свою іконку, а не тільки перші 12.
                    _ = _processService.PushIconsAsync(async batch =>
                        await SendJsonAsync(new { type = "process_icons", data = batch }));
                }
                break;

            // ТЗ 55 «іконки пропали після F5»: панель шле це при маунті вкладки
            // «Процеси» та після реконекту — агент-релей WS живе довше за сторінку,
            // тому без явного скидання агент вважав іконки «вже надісланими».
            case "process_icons_reset":
                _processService.ResetSentIcons();
                _ = _processService.PushIconsAsync(async batch =>
                    await SendJsonAsync(new { type = "process_icons", data = batch }));
                break;

            // ТЗ «вкладка Оновлення»: встановлення КОНКРЕТНОЇ версії з архіву сайту
            // (відкат на стару або перехід на нову за вибором адміна).
            case "update_install_version":
                {
                    var ver = UpdateService.NormalizeVersion(msg["version"]?.GetValue<string>() ?? "");
                    var ok = await RunVersionInstallAsync(ver);
                    await SendJsonAsync(new { type = "update_install_result", data = new { version = ver, ok, message = ok ? $"Встановлення версії {ver} почато" : "Не вдалося завантажити вказану версію з сайту" } });
                }
                break;

            case "update_check":
                {
                    var info = await UpdateService.CheckForUpdateAsync();
                    await SendJsonAsync(new
                    {
                        type = "update_check_result",
                        data = new
                        {
                            local = UpdateService.GetLocalVersion(),
                            latest = info?.LatestVersion ?? "",
                            updateAvailable = info?.UpdateAvailable ?? false,
                            downloadUrl = info?.DownloadUrl ?? ""
                        }
                    });
                }
                break;

            case "kill_process":
            case "process_kill":
                int pid = msg["pid"]?.GetValue<int>() ?? 0;
                bool killed = _processService.KillProcess(pid);
                var updatedList = _processService.GetProcesses();
                await SendJsonAsync(new { type = "process_kill_result", pid, success = killed });
                await SendJsonAsync(new { type = "process_list", data = new { processes = updatedList, icons = _processService.GetNewIcons(updatedList), version = UpdateService.GetLocalVersion(), binStamp = AgentBinStamp() } });
                _ = _processService.PushIconsAsync(async batch =>
                    await SendJsonAsync(new { type = "process_icons", data = batch }));
                break;

            case "get_devices_list":
            case "devices_list":
                // ТЗ: рамка «Пристрої» — реальні моделі з Диспетчера пристроїв.
                // WMI повільний → шукаємо у ФОНІ, щоб не блокувати пумпу повідомлень.
                _ = Task.Run(async () =>
                {
                    try
                    {
                        var devices = _systemService.GetDevicesList();
                        await SendJsonAsync(new
                        {
                            type = "devices_list",
                            data = new { devices = devices.Select(d => new { cls = d.Cls, name = d.Name, manufacturer = d.Manufacturer }) }
                        });
                    }
                    catch (Exception ex)
                    {
                        await SendJsonAsync(new { type = "devices_list", data = new { devices = Array.Empty<object>(), error = ex.Message } });
                    }
                });
                break;

            case "fs_drives":
                var drives = _fileService.GetDrives();
                await SendJsonAsync(new { type = "fs_drives", data = drives });
                break;

            case "fs_list":
                string pth = msg["path"]?.GetValue<string>() ?? "";
                try
                {
                    var listing = _fileService.ListDirectory(pth);
                    await SendJsonAsync(new { type = "fs_list", data = listing });

                    // ТЗ: папки в списку показують свій розмір/к-сть файлів.
                    // Рахуємо у фоні (з кешем 5хв) і шлемо партіями fs_dir_meta.
                    _ = Task.Run(async () =>
                    {
                        try
                        {
                            // ТЗ-фікс «не в усіх папок показується розмір»: раніше
                            // бралося лише 24 перші папки — решта лишалась «папка».
                            var dirs = listing.Items.Where(i => i.IsDirectory).Take(80).ToList();
                            var batch = new List<object>();
                            foreach (var d in dirs)
                            {
                                var (size, files) = _fileService.GetDirectoryStats(d.Path);
                                batch.Add(new { path = d.Path, sizeBytes = size, fileCount = files });
                                if (batch.Count >= 8)
                                {
                                    await SendJsonAsync(new { type = "fs_dir_meta", data = new { dirs = batch } });
                                    batch.Clear();
                                    await Task.Delay(40);
                                }
                            }
                            if (batch.Count > 0)
                                await SendJsonAsync(new { type = "fs_dir_meta", data = new { dirs = batch } });
                        }
                        catch { }
                    });
                }
                catch (Exception ex)
                {
                    await SendJsonAsync(new { type = "fs_error", message = ex.Message });
                }
                break;

            case "fs_read_file":
                string rPath = msg["path"]?.GetValue<string>() ?? "";
                try
                {
                    string text = _fileService.ReadFileContent(rPath);
                    await SendJsonAsync(new { type = "fs_read_file_result", path = rPath, content = text, success = true });
                }
                catch (Exception ex)
                {
                    await SendJsonAsync(new { type = "fs_read_file_result", path = rPath, success = false, error = ex.Message });
                }
                break;

            case "fs_save_file":
                string sPath = msg["path"]?.GetValue<string>() ?? "";
                string sContent = msg["content"]?.GetValue<string>() ?? "";
                try
                {
                    _fileService.SaveFileContent(sPath, sContent);
                    await SendJsonAsync(new { type = "fs_save_file_result", path = sPath, success = true });
                }
                catch (Exception ex)
                {
                    await SendJsonAsync(new { type = "fs_save_file_result", path = sPath, success = false, error = ex.Message });
                }
                break;

            case "fs_upload_file":
                // Drag & Drop з сайту (ТЗ): бінарний файл у base64 → запис на ПК.
                {
                    string upPath = msg["path"]?.GetValue<string>() ?? "";
                    string upB64 = msg["base64"]?.GetValue<string>() ?? "";
                    _ = Task.Run(async () =>
                    {
                        try
                        {
                            _fileService.SaveFileBytesFromBase64(upPath, upB64);
                            await SendJsonAsync(new { type = "fs_upload_file_result", path = upPath, success = true });
                            App.Log($"[Files] Upload OK: {upPath}");
                        }
                        catch (Exception ex)
                        {
                            await SendJsonAsync(new { type = "fs_upload_file_result", path = upPath, success = false, error = ex.Message });
                        }
                    });
                }
                break;

            case "fs_delete":
                string delPath = msg["path"]?.GetValue<string>() ?? "";
                try
                {
                    bool deleted = _fileService.DeleteItem(delPath);
                    await SendJsonAsync(new { type = "fs_delete_result", path = delPath, success = deleted });
                }
                catch (Exception ex)
                {
                    await SendJsonAsync(new { type = "fs_delete_result", path = delPath, success = false, error = ex.Message });
                }
                break;

            case "fs_folder_size":
                string fszPath = msg["path"]?.GetValue<string>() ?? "";
                _ = Task.Run(async () =>
                {
                    try
                    {
                        long sz = _fileService.GetDirectorySize(fszPath);
                        await SendJsonAsync(new { type = "fs_folder_size_result", path = fszPath, size = sz, success = true });
                    }
                    catch { }
                });
                break;

            case "fs_download_file":
                string dlFilePath = msg["path"]?.GetValue<string>() ?? "";
                _ = Task.Run(async () =>
                {
                    try
                    {
                        if (!File.Exists(dlFilePath)) throw new FileNotFoundException("Файл не знайдено.");
                        var fi = new FileInfo(dlFilePath);
                        var bytes = await File.ReadAllBytesAsync(dlFilePath);
                        var b64 = Convert.ToBase64String(bytes);
                        await SendJsonAsync(new
                        {
                            type = "fs_download_file_result",
                            name = fi.Name,
                            path = dlFilePath,
                            base64 = b64,
                            size = fi.Length,
                            success = true
                        });
                    }
                    catch (Exception ex)
                    {
                        await SendJsonAsync(new { type = "fs_download_file_result", path = dlFilePath, success = false, error = ex.Message });
                    }
                });
                break;

            case "fs_download_folder_zip":
                string dlFolderPath = msg["path"]?.GetValue<string>() ?? "";
                _ = Task.Run(async () =>
                {
                    string? zipPath = null;
                    try
                    {
                        zipPath = _fileService.CreateZipArchive(dlFolderPath);
                        var folderName = new DirectoryInfo(dlFolderPath).Name;
                        var bytes = await File.ReadAllBytesAsync(zipPath);
                        var b64 = Convert.ToBase64String(bytes);
                        await SendJsonAsync(new
                        {
                            type = "fs_download_file_result",
                            name = $"{folderName}.zip",
                            path = dlFolderPath,
                            base64 = b64,
                            isZip = true,
                            size = bytes.Length,
                            success = true
                        });
                    }
                    catch (Exception ex)
                    {
                        await SendJsonAsync(new { type = "fs_download_file_result", path = dlFolderPath, success = false, error = ex.Message });
                    }
                    finally
                    {
                        if (!string.IsNullOrEmpty(zipPath) && File.Exists(zipPath))
                        {
                            try { File.Delete(zipPath); } catch { }
                        }
                    }
                });
                break;

            case "fs_open_on_pc":
                string openTarget = msg["path"]?.GetValue<string>() ?? "";
                try
                {
                    Process.Start(new ProcessStartInfo(openTarget) { UseShellExecute = true });
                    await SendJsonAsync(new { type = "fs_open_on_pc_result", path = openTarget, success = true });
                }
                catch (Exception ex)
                {
                    await SendJsonAsync(new { type = "fs_open_on_pc_result", path = openTarget, success = false, error = ex.Message });
                }
                break;

            case "fs_rename":
                string rOldPath = msg["oldPath"]?.GetValue<string>() ?? "";
                string rNewName = msg["newName"]?.GetValue<string>() ?? "";
                try
                {
                    bool renamed = _fileService.RenameItem(rOldPath, rNewName);
                    await SendJsonAsync(new { type = "fs_rename_result", oldPath = rOldPath, newName = rNewName, success = renamed });
                }
                catch (Exception ex)
                {
                    await SendJsonAsync(new { type = "fs_rename_result", oldPath = rOldPath, newName = rNewName, success = false, error = ex.Message });
                }
                break;

            case "fs_create_file":
                string cfParent = msg["path"]?.GetValue<string>() ?? "";
                string cfName = msg["name"]?.GetValue<string>() ?? "";
                try
                {
                    _fileService.CreateNewFile(cfParent, cfName);
                    await SendJsonAsync(new { type = "fs_create_file_result", path = cfParent, name = cfName, success = true });
                }
                catch (Exception ex)
                {
                    await SendJsonAsync(new { type = "fs_create_file_result", success = false, error = ex.Message });
                }
                break;

            case "fs_create_folder":
                string cfdParent = msg["path"]?.GetValue<string>() ?? "";
                string cfdName = msg["name"]?.GetValue<string>() ?? "";
                try
                {
                    _fileService.CreateNewFolder(cfdParent, cfdName);
                    await SendJsonAsync(new { type = "fs_create_folder_result", path = cfdParent, name = cfdName, success = true });
                }
                catch (Exception ex)
                {
                    await SendJsonAsync(new { type = "fs_create_folder_result", success = false, error = ex.Message });
                }
                break;

            case "take_screenshot":
            case "capture_screenshot":
                try
                {
                    // AI-запрос может ужать картинку (payload WS ограничен);
                    // UI-запросы идут без параметров — как раньше.
                    long q = Math.Clamp(msg["quality"]?.GetValue<long>() ?? 80, 30, 95);
                    int mw = Math.Clamp(msg["maxWidth"]?.GetValue<int>() ?? 0, 0, 3840);
                    var shotB64 = _mediaService.CaptureScreenshotBase64(q, mw);
                    await SendJsonAsync(new { type = "screenshot_response", imageBase64 = shotB64 });
                }
                catch (Exception ex)
                {
                    await SendJsonAsync(new { type = "media_error", message = ex.Message });
                }
                break;

            case "capture_webcam":
            case "webcam_snap":
                try
                {
                    string? preferredCamera = msg["camera"]?.GetValue<string>();
                    int delaySeconds = Math.Clamp(msg["delaySeconds"]?.GetValue<int>() ?? 0, 0, 600);
                    var webcamBase64 = await _mediaService.CaptureWebcamPhotoBase64Async(
                        preferredCamera,
                        delaySeconds,
                        secondsLeft => _ = SendJsonAsync(new { type = "webcam_status", data = new { secondsLeft = secondsLeft } }));
                    await SendJsonAsync(new
                    {
                        type = "webcam_response",
                        imageBase64 = webcamBase64,
                        success = webcamBase64 != null,
                        error = webcamBase64 == null ? _mediaService.LastError : null
                    });
                }
                catch (Exception ex)
                {
                    await SendJsonAsync(new { type = "webcam_response", success = false, error = ex.Message });
                }
                break;

            case "record_capture":
                var recordingSource = msg["source"]?.GetValue<string>() ?? "screen";
                var recordingSeconds = msg["seconds"]?.GetValue<int>() ?? 5;
                var recordingCamera = msg["camera"]?.GetValue<string>();
                try
                {
                    var videoBase64 = await _mediaService.RecordShortVideoBase64Async(recordingSource, recordingSeconds, recordingCamera);
                    await SendJsonAsync(new
                    {
                        type = "recording_result",
                        source = recordingSource,
                        name = $"FluxControl_{recordingSource}_{DateTime.Now:yyyyMMdd_HHmmss}.mp4",
                        videoBase64,
                        success = videoBase64 != null,
                        error = videoBase64 == null ? _mediaService.LastError : null
                    });
                }
                catch (Exception ex)
                {
                    await SendJsonAsync(new { type = "recording_result", source = recordingSource, success = false, error = ex.Message });
                }
                break;

            case "record_cancel":
                _mediaService.CancelRecording();
                await SendJsonAsync(new { type = "recording_cancelled", success = true });
                break;

            case "screen_stream_start":
                StartScreenStream(
                    msg["fps"]?.GetValue<int>() ?? 60,
                    msg["quality"]?.GetValue<int>() ?? 80,
                    msg["maxWidth"]?.GetValue<int>() ?? 1920);
                await SendJsonAsync(new
                {
                    type = "screen_stream_started",
                    fps = Volatile.Read(ref _screenStreamFps),
                    quality = Volatile.Read(ref _screenStreamQuality),
                    maxWidth = Volatile.Read(ref _screenStreamMaxWidth)
                });
                break;

            case "screen_stream_stop":
                StopScreenStream();
                break;

            case "screen_stream_feedback":
                ApplyScreenStreamFeedback(msg["fps"]?.GetValue<int>() ?? 0);
                break;

            case "ai_memory_get":
                {
                    // Пам'ять AI-агента: файл %APPDATA%\FluxControl\ai_memory.json.
                    // Фронт чекає ai_memory_data (таймаут 4с — старі exe просто мовчать,
                    // і цикл працює без пам'яті, як раніше).
                    try
                    {
                        string? memData = null;
                        var memReadPath = AiMemoryPath();
                        if (File.Exists(memReadPath))
                            memData = File.ReadAllText(memReadPath);
                        await SendJsonAsync(new { type = "ai_memory_data", data = memData });
                    }
                    catch (Exception ex)
                    {
                        await SendJsonAsync(new { type = "ai_memory_data", data = (string?)null, error = ex.Message });
                    }
                }
                break;

            case "ai_memory_set":
                {
                    try
                    {
                        var memSavePath = AiMemoryPath();
                        Directory.CreateDirectory(Path.GetDirectoryName(memSavePath)!);
                        var memData = msg["data"]?.GetValue<string>() ?? "";
                        if (memData.Length > 64 * 1024) memData = memData.Substring(0, 64 * 1024);
                        File.WriteAllText(memSavePath, memData);
                        await SendJsonAsync(new { type = "ai_memory_saved", success = true, bytes = memData.Length });
                    }
                    catch (Exception ex)
                    {
                        await SendJsonAsync(new { type = "ai_memory_saved", success = false, error = ex.Message });
                    }
                }
                break;

            case "terminal_start":
            case "terminal_input":
            case "terminal_kill":
            case "terminal_history_get":
                await HandleTerminalMessageAsync(type, msg, terminalHub);
                break;

            // ================= ТЗ 46: нові можливості =================

            case "fs_search":
                {
                    var searchPath = msg["path"]?.GetValue<string>() ?? "";
                    var query = msg["query"]?.GetValue<string>() ?? "";
                    _ = Task.Run(async () =>
                    {
                        try
                        {
                            var (items, truncated) = _fileService.SearchFiles(searchPath, query);
                            await SendJsonAsync(new { type = "fs_search_result", path = searchPath, query, truncated, success = true, data = items });
                        }
                        catch (Exception ex)
                        {
                            await SendJsonAsync(new { type = "fs_search_result", path = searchPath, query, success = false, error = ex.Message });
                        }
                    });
                }
                break;

            case "fs_compress":
                {
                    var zipTarget = msg["path"]?.GetValue<string>() ?? "";
                    _ = Task.Run(async () =>
                    {
                        try
                        {
                            var zipPath = _fileService.CompressToZip(zipTarget);
                            ActivityLogger.Log("REMOTE", "Стиснуто в ZIP з веб-консолі", zipPath);
                            await SendJsonAsync(new { type = "fs_compress_result", path = zipTarget, zipPath, success = true });
                        }
                        catch (Exception ex)
                        {
                            await SendJsonAsync(new { type = "fs_compress_result", path = zipTarget, success = false, error = FriendlyFsError(ex) });
                        }
                    });
                }
                break;

            case "fs_extract":
                {
                    var archivePath = msg["path"]?.GetValue<string>() ?? "";
                    _ = Task.Run(async () =>
                    {
                        try
                        {
                            var (dir, tool) = _fileService.ExtractArchive(archivePath);
                            ActivityLogger.Log("REMOTE", "Розпаковано архів з веб-консолі", dir);
                            await SendJsonAsync(new { type = "fs_extract_result", path = archivePath, dir, tool, success = true });
                        }
                        catch (Exception ex)
                        {
                            await SendJsonAsync(new { type = "fs_extract_result", path = archivePath, success = false, error = FriendlyFsError(ex) });
                        }
                    });
                }
                break;

            case "fs_clipboard_set":
                {
                    try
                    {
                        var clipPaths = msg["paths"]?.AsArray().Select(x => x?.GetValue<string>() ?? "").Where(p => p.Length > 0).ToList() ?? new List<string>();
                        var clipCut = msg["cut"]?.GetValue<bool>() ?? false;
                        _fileService.SetClipboard(clipPaths, clipCut);
                        await SendJsonAsync(new { type = "fs_clipboard_set_result", success = true, count = clipPaths.Count, cut = clipCut });
                    }
                    catch (Exception ex)
                    {
                        await SendJsonAsync(new { type = "fs_clipboard_set_result", success = false, error = ex.Message });
                    }
                }
                break;

            case "fs_clipboard_get":
                await SendJsonAsync(new { type = "fs_clipboard_state", hasItems = _fileService.HasClipboard() });
                break;

            case "fs_paste":
                {
                    var pasteDir = msg["path"]?.GetValue<string>() ?? "";
                    _ = Task.Run(async () =>
                    {
                        try
                        {
                            var count = _fileService.PasteClipboard(pasteDir);
                            ActivityLogger.Log("REMOTE", $"Вставлено {count} елемент(ів) з веб-консолі", pasteDir);
                            await SendJsonAsync(new { type = "fs_paste_result", path = pasteDir, count, success = true });
                        }
                        catch (Exception ex)
                        {
                            await SendJsonAsync(new { type = "fs_paste_result", path = pasteDir, success = false, error = FriendlyFsError(ex) });
                        }
                    });
                }
                break;

            case "fs_thumbnail":
                {
                    var thumbPath = msg["path"]?.GetValue<string>() ?? "";
                    var thumbSize = msg["size"]?.GetValue<int>() ?? 320;
                    _ = Task.Run(async () =>
                    {
                        try
                        {
                            var dataUrl = _fileService.GetThumbnail(thumbPath, thumbSize);
                            await SendJsonAsync(new { type = "fs_thumbnail_result", path = thumbPath, dataUrl, success = dataUrl != null });
                        }
                        catch
                        {
                            await SendJsonAsync(new { type = "fs_thumbnail_result", path = thumbPath, dataUrl = (string?)null, success = false });
                        }
                    });
                }
                break;

            case "process_freeze":
                {
                    int freezePid = msg["pid"]?.GetValue<int>() ?? 0;
                    bool freeze = msg["freeze"]?.GetValue<bool>() ?? true;
                    var (ok, err) = _processService.SetFrozen(freezePid, freeze);
                    ActivityLogger.Log("REMOTE", $"{(ok ? (freeze ? "Процес заморожено" : "Процес розморожено") : "Заморозка не вдалася")} (PID {freezePid})");
                    await SendJsonAsync(new { type = "process_freeze_result", pid = freezePid, frozen = freeze && ok, success = ok, error = err });
                }
                break;

            case "process_bring_front":
            case "process_focus":
                {
                    int frontPid = msg["pid"]?.GetValue<int>() ?? 0;
                    var (ok, err) = _processService.BringToFront(frontPid);
                    await SendJsonAsync(new { type = "process_bring_front_result", pid = frontPid, success = ok, error = err });
                }
                break;

            case "stream_audio_start":
                {
                    try
                    {
                        _audioStream.Stop();
                        _audioStream.Start(chunk => { _ = SendBinaryAsync(2, chunk); });
                        await SendJsonAsync(new { type = "stream_audio_started", success = true });
                    }
                    catch (Exception ex)
                    {
                        await SendJsonAsync(new { type = "stream_audio_started", success = false, error = ex.Message });
                    }
                }
                break;

            case "stream_audio_stop":
                _audioStream.Stop();
                break;

            case "forced_launch_get":
                await SendJsonAsync(new { type = "forced_launch_state", enabled = ForcedLaunchEnabled, success = true });
                break;

            case "forced_launch_set":
                {
                    bool enabled = msg["enabled"]?.GetValue<bool>() ?? false;
                    try { ForcedLaunchChanged?.Invoke(enabled); } catch { }
                    await SendJsonAsync(new { type = "forced_launch_state", enabled, success = true });
                }
                break;

            case "health_report_get":
                _ = Task.Run(async () =>
                {
                    try
                    {
                        var report = _healthService.GetReport();
                        await SendJsonAsync(new { type = "health_report", data = report });
                    }
                    catch (Exception ex)
                    {
                        await SendJsonAsync(new { type = "health_report", error = ex.Message });
                    }
                });
                break;
        }
    }

    /// <summary>Поточний стан «примусового запуску» (джерело правди — settings.json,
    /// який веде MainWindow через ForcedLaunchChanged).</summary>
    private bool ForcedLaunchEnabled
    {
        get
        {
            try
            {
                var path = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                    "FluxControl", "settings.json");
                if (!File.Exists(path)) return false;
                using var doc = System.Text.Json.JsonDocument.Parse(File.ReadAllText(path));
                return doc.RootElement.TryGetProperty("ForcedLaunch", out var prop) &&
                       prop.ValueKind == System.Text.Json.JsonValueKind.True;
            }
            catch { return false; }
        }
    }

    private async Task HandleTerminalMessageAsync(string type, JsonObject msg, TerminalHubService hub)
    {
        switch (type)
        {
            case "terminal_start":
                {
                    string shellType = msg["shell"]?.GetValue<string>() ?? "powershell";
                    string tabId = msg["tabId"]?.GetValue<string>() ?? "t1";
                    ActivityLogger.Log("REMOTE", $"Відкрито термінал ({shellType}) з веб-консолі");
                    hub.StartSession(tabId, shellType);
                    await SendJsonAsync(new { type = "terminal_started", tabId, shell = shellType, isAdmin = TerminalHubService.IsAdmin });
                }
                break;

            case "terminal_input":
                hub.SendInput(msg["tabId"]?.GetValue<string>(), msg["data"]?.GetValue<string>() ?? msg["input"]?.GetValue<string>() ?? "");
                break;

            case "terminal_kill":
                hub.StopSession(msg["tabId"]?.GetValue<string>());
                break;

            case "terminal_history_get":
                await SendJsonAsync(new
                {
                    type = "terminal_history_data",
                    items = hub.GetHistory(),
                    isAdmin = TerminalHubService.IsAdmin
                });
                break;
        }
    }

    private static string FriendlyFsError(Exception ex)
    {
        if (ex is UnauthorizedAccessException)
            return "Відмовлено в доступі (недостатньо прав або файл захищено).";
        if (ex is FileNotFoundException || ex is DirectoryNotFoundException)
            return "Файл або папку не знайдено (можливо, вже видалені).";
        return ex.Message;
    }

    private async Task SendJsonAsync(object data)
    {
        var target = PanelSocket;
        if (target == null || target.State != WebSocketState.Open) return;
        var json = JsonSerializer.Serialize(data, _jsonOptions);
        var bytes = Encoding.UTF8.GetBytes(json);
        await _sendLock.WaitAsync();
        try
        {
            await target.SendAsync(new ArraySegment<byte>(bytes), WebSocketMessageType.Text, true, CancellationToken.None);
        }
        catch { }
        finally { _sendLock.Release(); }
    }

    // ТЗ 55: відбиток часу останньої зміни exe агента — веб-кеш іконок у
    // localStorage скидається, коли цей штамп змінився (програма оновилась),
    // а старі іконки не «залипають» після апдейта.
    private string? _agentBinStamp;
    private string AgentBinStamp()
    {
        if (_agentBinStamp != null) return _agentBinStamp;
        try
        {
            var exe = Environment.ProcessPath;
            _agentBinStamp = exe != null && File.Exists(exe)
                ? File.GetLastWriteTimeUtc(exe).ToString("yyyyMMddHHmmss")
                : string.Empty;
        }
        catch { _agentBinStamp = string.Empty; }
        return _agentBinStamp;
    }

    /// <summary>Повідомлення СТРОГО у релей (незалежно від прямої сесії):
    /// keepalive телеметрія та реєстрація прямого каналу.</summary>
    private async Task SendRelayJsonAsync(object data)
    {
        if (_ws == null || _ws.State != WebSocketState.Open) return;
        var json = JsonSerializer.Serialize(data, _jsonOptions);
        var bytes = Encoding.UTF8.GetBytes(json);
        await _sendLock.WaitAsync();
        try
        {
            await _ws.SendAsync(new ArraySegment<byte>(bytes), WebSocketMessageType.Text, true, CancellationToken.None);
        }
        catch { }
        finally { _sendLock.Release(); }
    }

    /// <summary>Реєстрація URL прямого каналу на релей-сервері. Сервер зберігає
    /// {url,key} на записі пристрою і віддає їх лише власнику (devices list /
    /// direct_info). Без URL або без релея — тихо нічого не робимо: панель
    /// автоматично працює через релей, як раніше.</summary>
    private async Task SendDirectRegisterIfConnectedAsync()
    {
        try
        {
            var link = _directLink;
            var url = link?.PublicUrl;
            if (string.IsNullOrEmpty(url) || _ws == null || _ws.State != WebSocketState.Open) return;
            await SendRelayJsonAsync(new { type = "direct_register", data = new { url, key = DirectKey } });
            App.Log("[Direct] Tunnel URL registered with the relay.");
        }
        catch { }
    }

    // ==================== «Пряме з'єднання» (ТЗ 49) ====================

    /// <summary>
    /// Викликається локальним шлюзом DirectLinkService, коли панель підключилась
    /// через публічний тунель. Перевіряємо code+key; у разі успіху сокет стає
    /// активним каналом панелі (усі відповіді/кадри йдуть напряму, минаючи релей).
    /// Повертає Task життєвого циклу сесії (шилюз очікує його) або null — відмова.
    /// </summary>
    public Task? AttachDirectPanelAsync(System.Net.WebSockets.WebSocket ws, string code, string key)
    {
        if (_isDisposed || ws == null || ws.State != WebSocketState.Open) return null;

        var cleanCode = new string((code ?? "").Where(char.IsLetterOrDigit).ToArray()).ToUpperInvariant();
        var expected = (_pairingService.DeviceCode ?? "").Trim().ToUpperInvariant();
        if (string.IsNullOrEmpty(expected) || cleanCode != expected)
        {
            App.Log("[Direct] Panel rejected: wrong device code.");
            return null;
        }
        if (string.IsNullOrWhiteSpace(key) || key != DirectKey)
        {
            App.Log("[Direct] Panel rejected: wrong session key.");
            return null;
        }

        var old = Interlocked.Exchange(ref _directSocket, ws);
        if (old != null && !ReferenceEquals(old, ws))
        {
            try { old.Dispose(); } catch { }
        }

        App.Log("[Direct] Panel attached — traffic now goes straight to this device.");
        return Task.Run(() => DirectReceiveLoopAsync(ws));
    }

    /// <summary>Прийом повідомлень панелі через прямий канал. Протокол ТОЙ САМИЙ,
    /// що й через релей — вся обробка йде через HandleIncomingMessageAsync.</summary>
    private async Task DirectReceiveLoopAsync(System.Net.WebSockets.WebSocket ws)
    {
        var buffer = new byte[64 * 1024];
        try
        {
            while (ws.State == WebSocketState.Open && !_isDisposed)
            {
                using var ms = new MemoryStream();
                WebSocketReceiveResult result;
                do
                {
                    result = await ws.ReceiveAsync(new ArraySegment<byte>(buffer), CancellationToken.None);
                    if (result.MessageType == WebSocketMessageType.Close)
                    {
                        try { await ws.CloseAsync(WebSocketCloseStatus.NormalClosure, "Closing", CancellationToken.None); } catch { }
                        return;
                    }
                    ms.Write(buffer, 0, result.Count);
                } while (!result.EndOfMessage);

                if (result.Count == 0) return;

                var jsonStr = Encoding.UTF8.GetString(ms.ToArray());
                _ = HandleIncomingMessageAsync(jsonStr, _terminalHub);
            }
        }
        catch { }
        finally
        {
            if (ReferenceEquals(_directSocket, ws)) _directSocket = null;
            try { ws.Dispose(); } catch { }
            // Стрими не повинні «перескакнути» у релей після зникнення глядача —
            // інакше кіновимота кадрів/звуку спалить ліміт сервера вхолосту.
            StopScreenStream();
            try { _audioStream.Stop(); } catch { }
            App.Log("[Direct] Panel detached — back to relay-only mode.");
        }
    }

    /// <summary>
    /// Бінарний медіа-кадр (ТЗ 49): [0xFC][тип][timestamp u32 LE][payload].
    /// Релей форвардить Buffer як є: мінус 25% байт (нема base64) і нуль
    /// JSON-парсингу гігантських рядків на сервері (CPU Render теж економимо).
    /// Типи: 1 = JPEG екрана, 2 = PCM s16le mono 24кГц.
    /// </summary>
    private async Task SendBinaryAsync(byte mediaType, byte[] payload)
    {
        var target = PanelSocket;
        if (target == null || target.State != WebSocketState.Open) return;
        var frame = new byte[payload.Length + 6];
        frame[0] = 0xFC;
        frame[1] = mediaType;
        var ts = (uint)(DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() & 0xFFFFFFFF);
        frame[2] = (byte)ts; frame[3] = (byte)(ts >> 8); frame[4] = (byte)(ts >> 16); frame[5] = (byte)(ts >> 24);
        Buffer.BlockCopy(payload, 0, frame, 6, payload.Length);
        await _sendLock.WaitAsync();
        try
        {
            await target.SendAsync(new ArraySegment<byte>(frame), WebSocketMessageType.Binary, true, CancellationToken.None);
        }
        catch { }
        finally { _sendLock.Release(); }
    }

    /// <summary>FNV-1a 64 по UTF-16 символах рядка — детермінований, швидкий.</summary>
    private static ulong Fnv1a(string s)
    {
        unchecked
        {
            ulong hash = 14695981039346656037UL;
            foreach (char c in s)
            {
                hash ^= c;
                hash *= 1099511628211UL;
            }
            return hash;
        }
    }

    /// <summary>Шлях до файлу пам'яті AI-агента (%APPDATA%\FluxControl\ai_memory.json).</summary>
    private static string AiMemoryPath()
    {
        return Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "FluxControl",
            "ai_memory.json");
    }

    private void StartScreenStream(int requestedFps, int requestedQuality, int requestedMaxWidth)
    {
        StopScreenStream();
        var streamCts = new CancellationTokenSource();
        _screenStreamCts = streamCts;
        // The relay carries text WebSocket messages, not a media transport.
        // Start with a sustainable profile; feedback below continuously reduces
        // it before a queue can form and increase latency on a phone.
        // ТЗ 49: нижчі мінімуми — веб може просити економний профіль.
        _screenStreamFps = Math.Clamp(requestedFps, 8, 30);
        _screenStreamQuality = Math.Clamp(requestedQuality, 30, 80);
        _screenStreamMaxWidth = Math.Clamp(requestedMaxWidth, 640, 1600);
        Volatile.Write(ref _lastFrameHash, 0);
        Volatile.Write(ref _lastFrameSentMs, 0);

        _ = Task.Run(async () =>
        {
            try
            {
                while (!streamCts.IsCancellationRequested && PanelSocket?.State == WebSocketState.Open)
                {
                    var started = Stopwatch.GetTimestamp();
                    // JPEG capture adapts to the available CPU/network bandwidth:
                    // frames are dropped rather than queued, keeping latency low.
                    var imageBase64 = await Task.Run(() => _mediaService.CaptureScreenshotBase64(
                        Volatile.Read(ref _screenStreamQuality),
                        Volatile.Read(ref _screenStreamMaxWidth)), streamCts.Token);
                    // ТЗ 49: екран не змінився → кадр не надсилаємо взагалі.
                    // Новий глядач усе одно отримає картинку: перший кадр після
                    // старту завжди летить + «пульс» щонайменше раз на 3с.
                    var hash = Fnv1a(imageBase64);
                    long nowMs = Environment.TickCount64;
                    if (hash == Volatile.Read(ref _lastFrameHash) && nowMs - Volatile.Read(ref _lastFrameSentMs) < 3000)
                    {
                        continue;
                    }
                    Volatile.Write(ref _lastFrameHash, hash);
                    Volatile.Write(ref _lastFrameSentMs, nowMs);
                    var jpeg = Convert.FromBase64String(imageBase64);
                    await SendBinaryAsync(1, jpeg);
                    var elapsed = Stopwatch.GetElapsedTime(started);
                    var frameInterval = TimeSpan.FromSeconds(1d / Volatile.Read(ref _screenStreamFps));
                    var delay = frameInterval - elapsed;
                    if (delay > TimeSpan.Zero) await Task.Delay(delay, streamCts.Token);
                }
            }
            catch (OperationCanceledException) { }
            catch (Exception ex)
            {
                await SendJsonAsync(new { type = "screen_stream_error", message = ex.Message });
            }
            finally
            {
                if (ReferenceEquals(_screenStreamCts, streamCts)) _screenStreamCts = null;
                streamCts.Dispose();
            }
        });
    }

    private void StopScreenStream()
    {
        var streamCts = Interlocked.Exchange(ref _screenStreamCts, null);
        if (streamCts != null) streamCts.Cancel();
    }

    private void ApplyScreenStreamFeedback(int receivedFps)
    {
        if (_screenStreamCts == null || receivedFps <= 0) return;
        var target = Volatile.Read(ref _screenStreamFps);
        if (receivedFps >= target * 0.8) return;

        // Reduce bytes first (resolution and JPEG quality); only then reduce the
        // capture rate. This preserves visual smoothness where the channel allows.
        if (Volatile.Read(ref _screenStreamMaxWidth) > 720)
            Interlocked.Exchange(ref _screenStreamMaxWidth, Math.Max(720, Volatile.Read(ref _screenStreamMaxWidth) * 3 / 4));
        else if (Volatile.Read(ref _screenStreamQuality) > 40)
            Interlocked.Add(ref _screenStreamQuality, -5);
        else
            Interlocked.Exchange(ref _screenStreamFps, Math.Max(8, Math.Min(target - 3, receivedFps + 3)));
    }

    public static string GetExactWindowsVersion()
    {
        try
        {
            using var key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion");
            if (key != null)
            {
                string productName = key.GetValue("ProductName")?.ToString() ?? "";
                string buildNumberStr = key.GetValue("CurrentBuildNumber")?.ToString() ?? "0";

                if (int.TryParse(buildNumberStr, out int build))
                {
                    if (build >= 22000) return "Windows 11 Pro";
                    if (build >= 10240) return "Windows 10 Pro";
                }

                if (!string.IsNullOrEmpty(productName)) return productName;
            }
        }
        catch { }
        return System.Runtime.InteropServices.RuntimeInformation.OSDescription;
    }

    public void Dispose()
    {
        if (_isDisposed) return;
        _isDisposed = true;
        StopScreenStream();
        _cts?.Cancel();
        try { _terminalHub.Dispose(); } catch { }
        try { _directSocket?.Dispose(); } catch { }
        _ws?.Dispose();
    }
}
