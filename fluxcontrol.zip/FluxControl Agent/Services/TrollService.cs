using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace FluxControl.Agent.Services;

/// <summary>
/// «Функції для тролінгу» (ТЗ, вкладка Додаткова):
///  • ВСПЛИВЧІ ВІКНА — N вікон (до 100, ТЗ) з заданим текстом, КОЖНЕ у
///    ВЛАСНІЙ ВИПАДКОВІЙ позиції екрана (MB_DEFAULT_DESKTOP нецентрований:
///    після появи діалог рухається EnumThreadWindows + MoveWindow);
///  • ОЗВУЧИТИ ТЕКСТ — SAPI через PowerShell, script передається
///    -EncodedCommand (Base64) — БЕЗ проблем лапок (фікс «не працює»);
///  • КОНСОЛІ — N cmd-вікон у випадкових місцях, НЕВЕЛИКА ЗАТРИМКА між
///    відкриттями (ТЗ), опція «закрити всі після завершення»;
///  • ПЕРЕВОРОТ ЕКРАНА — 0/90/180/270° через НАТИВНЕ базове розмірнення:
///    фікс «код помилки 2» (DISP_CHANGE_BADMODE) і неможливості повернути
///    назад — завжди рахуємо W/H від базових (ландшафтних) розмірів.
/// Усе — для свого ПК через власну панель.
/// </summary>
public class TrollService
{
    private readonly Random _rnd = new();

    // ------------------------------------------------------------------ popups

    public (bool ok, string error) ShowMessageBoxes(string text, int count)
    {
        // ТЗ: «можно было открыть до 100 окон».
        count = Math.Clamp(count, 1, 100);
        if (string.IsNullOrWhiteSpace(text)) return (false, "Порожній текст");
        string msg = text.Length > 500 ? text[..500] : text;

        var screen = System.Windows.Forms.Screen.PrimaryScreen?.Bounds;
        int sw = screen?.Width ?? 1920;
        int sh = screen?.Height ?? 1080;

        for (int i = 0; i < count; i++)
        {
            // Кожне вікно — окремий потік: MessageBox блокує свій потік до
            // закриття, але всі N вікон відкриті ОДНОЧАСНО. Невеликий розкид
            // у часі (35мс) дає моверу час розставити кожне у свою позицію.
            int tx = _rnd.Next(Math.Max(1, sw - 420));
            int ty = _rnd.Next(Math.Max(1, sh - 220));
            _ = Task.Run(async () =>
            {
                try
                {
                    uint tid = GetCurrentThreadId();
                    // Мовер: чекає появи діалогу класу #32770 у ЦЬОМУ потоці
                    // і тягне його у випадкову точку (ТЗ: «на разных позициях»).
                    _ = Task.Run(async () =>
                    {
                        for (int attempt = 0; attempt < 20; attempt++)
                        {
                            await Task.Delay(60);
                            if (MoveDialogOfThread(tid, tx, ty)) return;
                        }
                    });
                    _ = MessageBoxW(IntPtr.Zero, msg, "FluxControl", 0x40 | 0x40000 | 0x10000); // INFO|TOPMOST|SETFOREGROUND
                }
                catch { }
            });
        }
        return (true, string.Empty);
    }

    private static bool MoveDialogOfThread(uint tid, int x, int y)
    {
        IntPtr hwnd = IntPtr.Zero;
        EnumThreadWindows(tid, (h, l) =>
        {
            var sb = new StringBuilder(256);
            _ = GetClassNameW(h, sb, 256);
            if (sb.ToString() == "#32770") { hwnd = h; return false; }
            return true;
        }, IntPtr.Zero);
        if (hwnd == IntPtr.Zero) return false;
        return MoveWindow(hwnd, x, y, 0, 0, true);
    }

    // --------------------------------------------------------------------- TTS

    public (bool ok, string error) SpeakText(string text, int repeat)
    {
        if (string.IsNullOrWhiteSpace(text)) return (false, "Порожній текст");
        repeat = Math.Clamp(repeat, 1, 50);

        // ТЗ-ФІКС «озвучка не працює»: попередній варіант клеїв PS-скрипт
        // рядком — лапки в тексті ламали команду. Тепер скрипт передається
        // через -EncodedCommand (UTF-16LE Base64) — будь-який текст безпечний.
        string safe = text.Replace("\r", " ").Replace("\n", " ");
        if (safe.Length > 400) safe = safe[..400];
        string script =
            "Add-Type -AssemblyName System.Speech; " +
            "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer; " +
            $"for($i=0; $i -lt {repeat}; $i++) {{ $s.Speak(@'\n{safe}\n'@); }}";
        string encoded = Convert.ToBase64String(Encoding.Unicode.GetBytes(script));

        var psi = new ProcessStartInfo
        {
            FileName = "powershell.exe",
            Arguments = $"-NoProfile -ExecutionPolicy Bypass -EncodedCommand {encoded}",
            UseShellExecute = true,
            CreateNoWindow = true,
            WindowStyle = ProcessWindowStyle.Hidden
        };
        try
        {
            Process.Start(psi);
            return (true, string.Empty);
        }
        catch (Exception ex)
        {
            return (false, ex.Message);
        }
    }

    // ---------------------------------------------------------------- consoles

    public (bool ok, string error) OpenConsoles(int count, bool autoClose)
    {
        count = Math.Clamp(count, 1, 50);
        var screen = System.Windows.Forms.Screen.PrimaryScreen?.Bounds;
        int sw = screen?.Width ?? 1920;
        int sh = screen?.Height ?? 1080;

        // ТЗ: «небольшая задержка» між відкриттями + розкид позицій + автозакриття.
        _ = Task.Run(async () =>
        {
            var pids = new List<int>();
            var rnd = new Random();
            try
            {
                for (int i = 0; i < count; i++)
                {
                    try
                    {
                        var psi = new ProcessStartInfo
                        {
                            FileName = "cmd.exe",
                            Arguments = "/k title FluxTroll",
                            UseShellExecute = true,
                            CreateNoWindow = false
                        };
                        var p = Process.Start(psi);
                        if (p != null) pids.Add(p.Id);
                    }
                    catch { }
                    await Task.Delay(220); // невелика затримка (ТЗ)
                }

                // Дамо вікнам з'явитись, потім розкидаємо у випадкові частини екрана.
                await Task.Delay(700);
                foreach (var pid in pids)
                {
                    try
                    {
                        int w = 420, h = 260;
                        int x = rnd.Next(Math.Max(0, sw - w));
                        int y = rnd.Next(Math.Max(0, sh - h));
                        MoveWindowOfPid(pid, x, y, w, h);
                    }
                    catch { }
                }

                if (autoClose)
                {
                    // ТЗ: «після відкриття всіх консолей — закрити, якщо обрано так».
                    await Task.Delay(2500);
                    foreach (var pid in pids)
                    {
                        try
                        {
                            using var proc = Process.GetProcessById(pid);
                            proc.Kill(entireProcessTree: true);
                        }
                        catch { }
                    }
                }
            }
            catch { }
        });
        return (true, string.Empty);
    }

    private static void MoveWindowOfPid(int pid, int x, int y, int w, int h)
    {
        IntPtr hwnd = IntPtr.Zero;
        EnumWindows((h, l) =>
        {
            _ = GetWindowThreadProcessId(h, out uint winPid);
            if (winPid == (uint)pid && IsWindowVisible(h))
            {
                var sb = new StringBuilder(256);
                _ = GetClassNameW(h, sb, 256);
                if (sb.ToString().Contains("ConsoleWindowClass")) { hwnd = h; return false; }
            }
            return true;
        }, IntPtr.Zero);
        if (hwnd != IntPtr.Zero) MoveWindow(hwnd, x, y, w, h, true);
    }

    // ---------------------------------------------------------------- rotation

    private static int _baseW;
    private static int _baseH;

    /// <summary>Поворот основного екрана: 0/90/180/270 градусів.
    /// ФІКС «код помилки 2 / не повертається назад»: розмірнення завжди
    /// рахується від БАЗОВОГО (нативного ландшафтного) режиму, а не від
    /// поточного — тому 90° після 180° більше не дає DISP_CHANGE_BADMODE,
    /// а 0° завжди повертає рідний режим.</summary>
    public (bool ok, string error) RotateScreen(int degrees)
    {
        int orientation = degrees switch
        {
            90 => 1,   // DMDO_90
            180 => 2,  // DMDO_180
            270 => 3,  // DMDO_270
            0 => 0,    // DMDO_DEFAULT
            _ => -1
        };
        if (orientation < 0) return (false, "Кут має бути 0/90/180/270");

        try
        {
            var dm = new DEVMODE { dmSize = (short)Marshal.SizeOf<DEVMODE>() };
            if (EnumDisplaySettingsW(null, ENUM_CURRENT_SETTINGS, ref dm) == 0)
                return (false, "Не вдалося прочитати параметри екрана");

            // Базовий (нативний ландшафтний) режим: фіксуємо першого разу, коли
            // екран ще не повернутий; якщо агент стартував уже на повернутому
            // екрані — база = поточні розміри, розвернуті назад.
            if (_baseW <= 0 || _baseH <= 0)
            {
                if (dm.dmDisplayOrientation is 1 or 3)
                {
                    _baseW = dm.dmPelsHeight;
                    _baseH = dm.dmPelsWidth;
                }
                else
                {
                    _baseW = dm.dmPelsWidth;
                    _baseH = dm.dmPelsHeight;
                }
                // Страховка: база має бути ландшафтною (W >= H) для типового монітора.
                if (_baseW < _baseH) (_baseW, _baseH) = (_baseH, _baseW);
            }

            // Для портретних орієнтацій міняємо місцями БАЗОВІ W/H.
            if (orientation == 1 || orientation == 3)
            {
                dm.dmPelsWidth = _baseH;
                dm.dmPelsHeight = _baseW;
            }
            else
            {
                dm.dmPelsWidth = _baseW;
                dm.dmPelsHeight = _baseH;
            }

            dm.dmFields = DM_DISPLAYORIENTATION | DM_PELSWIDTH | DM_PELSHEIGHT;
            dm.dmDisplayOrientation = orientation;

            const int CDS_UPDATEREGISTRY = 0x01;
            var res = ChangeDisplaySettingsW(ref dm, CDS_UPDATEREGISTRY);
            if (res != 0)
            {
                // Друга спроба БЕЗ запису в реєстр (тимчасово до перезавантаження) —
                // деякі драйвери відмовляють лише persistent-зміні.
                res = ChangeDisplaySettingsW(ref dm, 0);
            }
            return res == 0
                ? (true, string.Empty)
                : (false, res == 1 ? "Драйвер не підтримує цей поворот" : $"Код помилки: {res}");
        }
        catch (Exception ex)
        {
            return (false, ex.Message);
        }
    }

    // ---------------------------------------------------------------- screamer

    private static readonly object _screamerLock = new();
    private static bool _screamerRunning;
    private static MediaPlayer? _screamerPlayer;
    private static Window? _screamerWindow;

    /// <summary>
    /// СКРИМЕР v2 (ТЗ: «фото+звук грати МГНОВЕННО, без чорного екрана»).
    ///
    ///  • ВІКНО З'ЯВЛЯЄТЬСЯ НЕГАЙНО (перший же Dispatcher-такт): чорний фон
    ///    на весь екран, Topmost, курсор схований. Жодного очікування мережі.
    ///  • Асети (кеш %AppData%\FluxControl\screamer → Pages → сервер-проксі →
    ///    raw → ЗАШИТІ В ЗБІРКУ) підтягуються паралельно: фото з'являється
    ///    в той самий кадр, як тільки декодоване (Freeze → Source), звук
    ///    стартує одразу після MediaOpened. Кеш гріється на старті агента,
    ///    тому в 99% випадків фото+звук живуть миттєво.
    ///  • Звук (~2с) ПРОГРАЄ БЕСКІНЕЧНИМ ЛУПОМ (MediaEnded → Position=0 →
    ///    Play), поки не закінчиться час скримера — тоді стоп і закриття.
    ///  • Тривалість рахується ВІД ПОВНОЇ ГОТОВНОСТІ (фото+звук), тож юзер
    ///    завжди отримує повноцінні N секунд скримера.
    ///  • Нагрузка мінімальна: статичне фото (без анімацій), один плеєр.
    /// </summary>
    public (bool ok, string error) RunScreamer(int seconds)
    {
        seconds = Math.Clamp(seconds, 3, 120);
        lock (_screamerLock)
        {
            if (_screamerRunning) return (false, "Скример уже триває — дочекайся завершення");
            _screamerRunning = true;
        }

        var app = System.Windows.Application.Current;
        if (app == null)
        {
            lock (_screamerLock) { _screamerRunning = false; }
            return (false, "Програма завершується — скример неможливий");
        }

        _ = Task.Run(async () =>
        {
            try
            {
                App.Log($"Screamer: starting ({seconds}s) — window goes up INSTANTLY…");

                // 1) ВІКНО НЕГАЙНО: чорний фон, без контента, поверх усього.
                System.Windows.Controls.Image? imgCtrl = null;
                await app.Dispatcher.InvokeAsync(() =>
                {
                    var screen = System.Windows.Forms.Screen.PrimaryScreen?.Bounds;
                    int sw = screen?.Width ?? 1920;
                    imgCtrl = new System.Windows.Controls.Image
                    {
                        Stretch = Stretch.Uniform,
                        Margin = new Thickness(0),
                        Opacity = 0 // фото з'явиться одним кадром, як тільки буде готове
                    };
                    var win = new Window
                    {
                        WindowStyle = WindowStyle.None,
                        ResizeMode = ResizeMode.NoResize,
                        WindowState = WindowState.Maximized,
                        Topmost = true,
                        ShowInTaskbar = false,
                        ShowActivated = true,
                        Background = System.Windows.Media.Brushes.Black,
                        Cursor = System.Windows.Input.Cursors.None,
                        Content = imgCtrl,
                        Width = sw,
                        Left = 0,
                        Top = 0
                    };
                    _screamerWindow = win;
                    win.Show();
                });
                App.Log("Screamer: window shown — preparing assets…");

                // 2) Асети: кеш → завантаження → зашитий у збірку фолбек.
                var (soundPath, imagePath) = await ScreamerAssetsService.EnsureAssetsAsync();

                // 3) ФОТО В ПАМ'ЯТЬ → показ одним кадром (Opacity 0→1, без моргання).
                var image = await ScreamerAssetsService.LoadImageAsync(imagePath);
                await app.Dispatcher.InvokeAsync(() =>
                {
                    if (imgCtrl != null)
                    {
                        imgCtrl.Source = image;
                        imgCtrl.Opacity = 1;
                    }
                });
                App.Log("Screamer: image live.");

                // 4) ЗВУК: чекаємо MediaOpened (плеєр на UI-потоку) — і миттєвий Play.
                var player = await ScreamerAssetsService.PrepareSoundAsync(soundPath);
                _screamerPlayer = player;
                void LoopHandler(object? s, EventArgs e)
                {
                    try
                    {
                        if (_screamerRunning)
                        {
                            player.Position = TimeSpan.Zero;
                            player.Play();
                        }
                    }
                    catch { }
                }
                player.MediaEnded += LoopHandler;
                await app.Dispatcher.InvokeAsync(() => { try { player.Play(); } catch { } });
                App.Log($"Screamer: sound live — looping for {seconds}s.");

                // 5) Тримаємо рівно вказаний час ВІД ПОВНОЇ ГОТОВНОСТІ.
                await Task.Delay(TimeSpan.FromSeconds(seconds));

                // 6) Фініш: стоп звуку, закриття вікна, прибирання.
                await app.Dispatcher.InvokeAsync(() =>
                {
                    try
                    {
                        player.MediaEnded -= LoopHandler;
                        player.Stop();
                        player.Close();
                    }
                    catch { }
                    try { _screamerWindow?.Close(); } catch { }
                    _screamerWindow = null;
                    _screamerPlayer = null;
                });
                App.Log("Screamer: finished, window closed.");
            }
            catch (Exception ex)
            {
                App.Log($"Screamer: failed: {ex.Message}");
                try
                {
                    await app.Dispatcher.InvokeAsync(() =>
                    {
                        try { _screamerPlayer?.Stop(); _screamerPlayer?.Close(); } catch { }
                        try { _screamerWindow?.Close(); } catch { }
                        _screamerWindow = null;
                        _screamerPlayer = null;
                    });
                }
                catch { }
            }
            finally
            {
                lock (_screamerLock) { _screamerRunning = false; }
            }
        });

        return (true, string.Empty);
    }

    // ------------------------------------------------------------------ Win32

    private delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int MessageBoxW(IntPtr hWnd, string text, string caption, uint type);

    [DllImport("user32.dll")]
    private static extern bool EnumWindows(EnumWindowsProc proc, IntPtr lParam);

    [DllImport("user32.dll")]
    private static extern bool EnumThreadWindows(uint dwThreadId, EnumWindowsProc proc, IntPtr lParam);

    [DllImport("kernel32.dll")]
    private static extern uint GetCurrentThreadId();

    [DllImport("user32.dll")]
    private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);

    [DllImport("user32.dll")]
    private static extern bool IsWindowVisible(IntPtr hWnd);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int GetClassNameW(IntPtr hWnd, StringBuilder sb, int max);

    [DllImport("user32.dll")]
    private static extern bool MoveWindow(IntPtr hWnd, int x, int y, int w, int h, bool repaint);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int EnumDisplaySettingsW(string? deviceName, int modeNum, ref DEVMODE dm);

    [DllImport("user32.dll")]
    private static extern int ChangeDisplaySettingsW(ref DEVMODE dm, int flags);

    private const int ENUM_CURRENT_SETTINGS = -1;
    private const int DM_DISPLAYORIENTATION = 0x00000080;
    private const int DM_PELSWIDTH = 0x00080000;
    private const int DM_PELSHEIGHT = 0x00100000;

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct DEVMODE
    {
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string dmDeviceName;
        public short dmSpecVersion;
        public short dmDriverVersion;
        public short dmSize;
        public short dmDriverExtra;
        public int dmFields;
        public int dmPositionX;
        public int dmPositionY;
        public int dmDisplayOrientation;
        public int dmDisplayFixedOutput;
        public short dmColor;
        public short dmDuplex;
        public short dmYResolution;
        public short dmTTOption;
        public short dmCollate;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string dmFormName;
        public short dmLogPixels;
        public int dmBitsPerPel;
        public int dmPelsWidth;
        public int dmPelsHeight;
        public int dmDisplayFlags;
        public int dmDisplayFrequency;
        public int dmICMMethod;
        public int dmICMIntent;
        public int dmMediaType;
        public int dmDitherType;
        public int dmReserved1;
        public int dmReserved2;
        public int dmPanningWidth;
        public int dmPanningHeight;
    }
}
