using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace FluxControl.Agent.Services;

/// <summary>
/// ПЕРЕВІРКА СПРАВЖНОСТІ + ВІДКАТ ОНОВЛЕННЯ (Security Fix 2025-10, аудит п.3).
///
 /// Раніше завантажувач просто записував новий exe і запускав його — без жодної
/// перевірки: пошкоджений/підмінений файл назавжди «цегляв» програму.
///
/// Тепер:
///   1) SHA-256: манифест version.json несе sha256 нового exe (пишить
///      Auto-Deploy.ps1). UpdateService звіряє хеш скачаного файлу ДО
///      встановлення; розбіжність → файл видаляється, встановлення СКАСОВУЄТЬСЯ.
///      Для версій з архіву (versions/&lt;v&gt;/) хеш береться з sha256.txt поруч
///      (best-effort: немає файлу — працюємо без нього, але логуємо).
///   2) ВІДКАТ: перед підміною exe копія РОБОЧОЇ версії кладеться в
///      %AppData%\FluxControl\rollback\FluxControl_prev.exe + маркер
///      update_pending.json. Якщо нова версія НЕ змогла стабільно стартувати
///      (3 спроби без «успішних 90 секунд»), СТОЯЧИЙ exe сам відкочує попередню
///      версію і перезапуститься на ній.
///   3) Страхувальний sentinel: одноразовий cmd у %TEMP%, який через 4 хвилини
///      перевіряє маркер: якщо новий exe навіть НЕ СТАРТУВАВ (цігла цегла) —
///      sentinel відновлює попередню версію. Один прогін, самовидалення —
///      жодних циклів, які тривожать антивіруси.
/// </summary>
public static class UpdateRollbackService
{
    private static string AppDataDir => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FluxControl");

    private static string RollbackDir => Path.Combine(AppDataDir, "rollback");

    private static string RollbackExe => Path.Combine(RollbackDir, "FluxControl_prev.exe");

    private static string MarkerPath => Path.Combine(AppDataDir, "update_pending.json");

    /// <summary>Скільки спроб старту нової версії терпимо до відкату.</summary>
    private const int MaxStartupAttempts = 3;

    /// <summary>Успішним вважаємо запуск, який прожив ≥90 секунд.</summary>
    private const int SuccessUptimeMs = 90_000;

    private sealed class PendingMarker
    {
        public string fromVersion { get; set; } = "";
        public string toVersion { get; set; } = "";
        public long startedAt { get; set; }
        public int attempts { get; set; }
    }

    // ================================================================ SHA-256

    /// <summary>SHA-256 файлу_hex (нижній регістр, без пробілів).</summary>
    public static string ComputeSha256(string filePath)
    {
        using var sha = System.Security.Cryptography.SHA256.Create();
        using var fs = File.OpenRead(filePath);
        var hash = sha.ComputeHash(fs);
        return Convert.ToHexString(hash).ToLowerInvariant();
    }

    /// <summary>
    /// Звіряє SHA-256 скачаного файлу з очікуваним. expectedNullOrEmpty = null →
    /// перевірка неможлива (старий манифест) — пропускаємо з логом.
    /// Розбіжність → файл ВИДАЛЯЄТЬСЯ + InvalidDataException.
    /// </summary>
    public static void VerifyChecksumOrThrow(string filePath, string? expectedSha256)
    {
        var expected = (expectedSha256 ?? "").Trim().ToLowerInvariant();
        if (expected.Length == 0)
        {
            App.Log("Update checksum: manifest has no sha256 — skipping verification (old deploy).");
            return;
        }
        if (!File.Exists(filePath))
            throw new FileNotFoundException("Оновлення не знайдено після завантаження", filePath);

        var actual = ComputeSha256(filePath);
        if (!string.Equals(actual, expected, StringComparison.OrdinalIgnoreCase))
        {
            try { File.Delete(filePath); } catch { }
            App.Log($"Update checksum MISMATCH: expected {expected}, got {actual} — file deleted, install ABORTED.");
            throw new InvalidDataException("Перевірка справжності оновлення не пройшла (SHA-256 не збігається). Встановлення скасовано — файл міг бути пошкоджений або підмінений.");
        }
        App.Log($"Update checksum OK: {actual[..12]}… matches manifest.");
    }

    /// <summary>
    /// Тягне sha256 для конкретної версії з архіву сайту:
    ///   1) versions/&lt;v&gt;/sha256.txt (пишить Auto-Deploy v6.1+),
    ///   2) резерв — поле sha256 у versions.json,
    ///   3) резерв — raw гілки репозиторію.
    /// null = недоступний (краще встановити без перевірки, ніж не встановити).
    /// </summary>
    public static async Task<string?> FetchVersionSha256Async(string version)
    {
        var rel = $"versions/{Uri.EscapeDataString(version)}/sha256.txt";
        foreach (var url in new[]
        {
            $"{UpdateService.SiteBase}/{rel}",
            $"{UpdateService.ServerUpdateBase}/{rel}",
            $"https://raw.githubusercontent.com/matviikobrys2707/FluxControl/main/{rel}"
        })
        {
            try
            {
                using var resp = await UpdateService.CheckClient.GetAsync(url + "?t=" + DateTimeOffset.UtcNow.ToUnixTimeSeconds());
                if (!resp.IsSuccessStatusCode) continue;
                var body = (await resp.Content.ReadAsStringAsync()).Trim();
                // Формат: «<hex>  FluxControl.exe» (sha256sum) або просто hex.
                var first = body.Split('\n').FirstOrDefault()?.Trim() ?? "";
                var hex = first.Split(' ', StringSplitOptions.RemoveEmptyEntries).FirstOrDefault() ?? "";
                if (hex.Length == 64 && hex.All(Uri.IsHexDigit)) return hex.ToLowerInvariant();
            }
            catch { }
        }

        // Резерв 2: поле sha256 у versions.json (index усіх версій).
        foreach (var url in new[]
        {
            $"{UpdateService.SiteBase}/versions.json",
            $"{UpdateService.ServerUpdateBase}/versions.json",
            "https://raw.githubusercontent.com/matviikobrys2707/FluxControl/main/versions.json"
        })
        {
            try
            {
                using var resp = await UpdateService.CheckClient.GetAsync(url + "?t=" + DateTimeOffset.UtcNow.ToUnixTimeSeconds());
                if (!resp.IsSuccessStatusCode) continue;
                var body = (await resp.Content.ReadAsStringAsync()).TrimStart('\uFEFF');
                using var doc = JsonDocument.Parse(body);
                foreach (var v in doc.RootElement.TryGetProperty("versions", out var list) && list.ValueKind == JsonValueKind.Array
                             ? list.EnumerateArray() : Enumerable.Empty<JsonElement>())
                {
                    if (v.TryGetProperty("version", out var vp) &&
                        string.Equals(vp.GetString()?.Trim(), version, StringComparison.OrdinalIgnoreCase) &&
                        v.TryGetProperty("sha256", out var sp))
                    {
                        var hex = sp.GetString()?.Trim().ToLowerInvariant() ?? "";
                        if (hex.Length == 64 && hex.All(Uri.IsHexDigit)) return hex;
                    }
                }
            }
            catch { }
        }
        return null;
    }

    // ================================================================ ВІДКАТ

    /// <summary>
    /// Викликається ПЕРЕД підміною exe (UpdateInstaller.Launch): зберігає копію
    /// поточної РОБОЧОЇ версії + пише маркер «оновлення в процесі».
    /// Будь-яка помилка НЕ зриває оновлення — просто без страхування.
    /// </summary>
    public static void PrepareForUpdate(string newVersion)
    {
        try
        {
            var current = System.Diagnostics.Process.GetCurrentProcess().MainModule?.FileName;
            if (string.IsNullOrEmpty(current) || !File.Exists(current))
            {
                App.Log("Rollback: current exe path unknown — rollback protection unavailable this update.");
                return;
            }

            Directory.CreateDirectory(RollbackDir);
            File.Copy(current, RollbackExe, overwrite: true);
            try { File.SetAttributes(RollbackExe, FileAttributes.Hidden | FileAttributes.Archive); } catch { }

            var marker = new PendingMarker
            {
                fromVersion = UpdateService.GetLocalVersion(),
                toVersion = UpdateService.NormalizeVersion(newVersion),
                startedAt = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
                attempts = 0
            };
            File.WriteAllText(MarkerPath, JsonSerializer.Serialize(marker));
            App.Log($"Rollback: backup {marker.fromVersion} → rollback\\FluxControl_prev.exe; pending marker for {marker.toVersion}.");

            WriteSentinelScript();
        }
        catch (Exception ex)
        {
            try { App.Log($"Rollback: prepare failed (update continues without safety net): {ex.Message}"); } catch { }
        }
    }

    /// <summary>
    /// Викликається на СТАРТІ застосунку (перший екземпляр). Повертає true,
    /// якщо виконано ВІДКАТ і процес треба ЗАВЕРШИТИ (стартує відновлена
    /// версія). Інакше false — звичайний старт.
    /// </summary>
    public static bool OnStartupCheckIfRollbackPerformed()
    {
        try
        {
            if (!File.Exists(MarkerPath)) return false;

            PendingMarker? marker;
            try
            {
                marker = JsonSerializer.Deserialize<PendingMarker>(File.ReadAllText(MarkerPath));
            }
            catch
            {
                try { File.Delete(MarkerPath); } catch { }
                return false;
            }
            if (marker == null) return false;

            marker.attempts++;
            var me = UpdateService.GetLocalVersion();

            if (marker.attempts >= MaxStartupAttempts)
            {
                // ТРИ невдачі поспіль — нова версія не живе. Відкочуємось.
                App.Log($"Rollback: {marker.attempts} failed startups of {marker.toVersion} — RESTORING {marker.fromVersion}.");
                return RestorePreviousVersion(marker);
            }

            // Ще одна спроба: зберігаємо лічильник; успіх зафіксує MarkSuccess.
            File.WriteAllText(MarkerPath, JsonSerializer.Serialize(marker));
            App.Log($"Rollback: startup attempt {marker.attempts}/{MaxStartupAttempts} of {marker.toVersion} (running {me}).");
            ScheduleSuccessMark();
            return false;
        }
        catch (Exception ex)
        {
            try { App.Log($"Rollback: startup check failed: {ex.Message}"); } catch { }
            return false;
        }
    }

    /// <summary>Планує «оновлення успішне» — маркер знімається через 90с аптайму.</summary>
    private static void ScheduleSuccessMark()
    {
        _ = System.Threading.Tasks.Task.Run(async () =>
        {
            await Task.Delay(SuccessUptimeMs);
            try
            {
                if (System.Windows.Application.Current == null) return; // уже виходимо
                MarkSuccess();
            }
            catch { }
        });
    }

    /// <summary>Оновлення визнано успішним: маркер знято, копію тримаємо для майбутніх оновлень.</summary>
    public static void MarkSuccess()
    {
        try
        {
            if (File.Exists(MarkerPath))
            {
                File.Delete(MarkerPath);
                App.Log("Rollback: update confirmed stable (90s uptime) — pending marker cleared.");
            }
        }
        catch { }
    }

    /// <summary>Відновлення попередньої версії з rollback-копії + перезапуск.</summary>
    private static bool RestorePreviousVersion(PendingMarker marker)
    {
        try
        {
            if (!File.Exists(RollbackExe))
            {
                App.Log("Rollback: backup exe missing — cannot restore. Clearing marker (stay on current).");
                try { File.Delete(MarkerPath); } catch { }
                return false;
            }

            var current = System.Diagnostics.Process.GetCurrentProcess().MainModule?.FileName;
            if (string.IsNullOrEmpty(current))
            {
                App.Log("Rollback: cannot resolve current exe path — restore aborted.");
                return false;
            }

            // Підмінити себе НЕМОЖЛИВО (файл запущений) — класичний move-swap:
            // запущений exe переносимо, відновлений ставає на місце.
            var stale = Path.Combine(Path.GetTempPath(), $"FluxControl.rollback-{Environment.ProcessId}.exe");
            try { File.Delete(stale); } catch { }
            try
            {
                File.Move(current, stale);
            }
            catch (Exception moveEx)
            {
                App.Log($"Rollback: move current exe failed ({moveEx.Message}) — restore aborted.");
                try { File.Delete(MarkerPath); } catch { }
                return false;
            }

            File.Copy(RollbackExe, current, overwrite: true);
            try { File.Delete(MarkerPath); } catch { }

            var psi = new System.Diagnostics.ProcessStartInfo
            {
                FileName = current,
                UseShellExecute = false,
                WorkingDirectory = Path.GetDirectoryName(current) ?? AppContext.BaseDirectory,
                Arguments = "--waitForUpdate"
            };
            System.Diagnostics.Process.Start(psi);
            App.Log($"Rollback: restored {marker.fromVersion} and relaunched. Rolling back from {marker.toVersion}.");
            return true;
        }
        catch (Exception ex)
        {
            try { App.Log($"Rollback: restore failed: {ex.Message}"); } catch { }
            try { File.Delete(MarkerPath); } catch { }
            return false;
        }
    }

    // ============================================================ SENTINEL

    /// <summary>
    /// Одноразовий cmd-страж: через 4 хв перевіряє маркер. Якщо новий exe
    /// навіть не стартував (нікому було зняти маркер) — сам відновлює версію.
    /// Один прогін + self-delete: без циклів taskkill (AV-безпечно).
    /// </summary>
    private static void WriteSentinelScript()
    {
        try
        {
            var bat = Path.Combine(Path.GetTempPath(), "FluxControl_rollback_sentinel.cmd");
            var markerLocal = MarkerPath;
            var backupLocal = RollbackExe;

            var script = new StringBuilder();
            script.AppendLine("@echo off");
            script.AppendLine("rem FluxControl one-shot update sentinel (restore previous version if new exe never started)");
            script.AppendLine("timeout /t 240 /nobreak >nul");
            script.AppendLine($"if not exist \"{markerLocal}\" goto :done");
            script.AppendLine($"if not exist \"{backupLocal}\" goto :done");
            script.AppendLine("tasklist /FI \"IMAGENAME eq FluxControl.exe\" 2>nul | find /I \"FluxControl.exe\" >nul");
            script.AppendLine("if errorlevel 1 goto :restore");
            script.AppendLine("goto :done");
            script.AppendLine(":restore");
            script.AppendLine("for /f \"tokens=1\" %%A in ('dir /b /o-d \"%LOCALAPPDATA%\\FluxControl\\*.log\" 2^>nul') do (");
            script.AppendLine("  rem логи не чіпаємо — просто відновлюємо exe");
            script.AppendLine(")");
            script.AppendLine("set TARGET=");
            script.AppendLine("for /f \"delims=\" %%F in ('wmic process where \"name='FluxControl.exe'\" get ExecutablePath /value 2^>nul ^| find \"=\"') do (");
            script.AppendLine("  set TARGET=%%F");
            script.AppendLine(")");
            script.AppendLine("if \"%TARGET%\"==\"\" goto :done");
            script.AppendLine("set TARGET=%TARGET:ExecutablePath=%");
            script.AppendLine("if \"%TARGET%\"==\"\" goto :done");
            script.AppendLine("del /F /Q \"%TARGET%\" >nul 2>&1");
            script.AppendLine($"copy /y \"{backupLocal}\" \"%TARGET%\" >nul 2>&1");
            script.AppendLine($"del /F /Q \"{markerLocal}\" >nul 2>&1");
            script.AppendLine("start \"\" \"%TARGET%\"");
            script.AppendLine(":done");
            script.AppendLine("(goto) 2>nul & del \"%~f0\"");

            File.WriteAllText(bat, script.ToString(), Encoding.ASCII);

            var psi = new System.Diagnostics.ProcessStartInfo
            {
                FileName = bat,
                UseShellExecute = false,
                CreateNoWindow = true,
                WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden
            };
            System.Diagnostics.Process.Start(psi);
            App.Log($"Rollback: one-shot sentinel scheduled ({bat}).");
        }
        catch (Exception ex)
        {
            try { App.Log($"Rollback: sentinel scheduling failed: {ex.Message}"); } catch { }
        }
    }
}
