using System;
using System.IO;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Windows;
using System.Windows.Threading;

namespace FluxControl.Agent.Services;

/// <summary>
/// Fullscreen uncloseable window shown while WinLock is engaged.
/// ДИЗАЙН — ВИКЛЮЧНО WebView2 (ТЗ: нативний C#-фолбек ВИДАЛЕНИЙ З КОДУ).
/// Джерело дизайну — САЙТ: https://fluxcontrol.pages.dev/winlock-offline.html
/// (сторінка завжди свіжа); якщо сайт недосяжний — локальний кеш-файл
/// (%AppData%\FluxControl\UI\winlock.html, оновлюється з сайту фоново).
/// Якщо WebView2/сайт/кеш тимчасово впали — Автоматичні РЕТРАЇ (нативної
/// панелі більше не існує, сплеш лишається до появи веб-дизайну; розблокувати
/// власник може з сайту — сервіс сам закриє вікно через ForceClose()).
/// Alt+F4 etc. swallowed by the service's keyboard hook; Closing guard cancels
/// every external close attempt. Only <see cref="WinLockService"/> may dismiss
/// it via <see cref="ForceClose"/>.
/// </summary>
public partial class LockWindow : Window
{
    private const string SiteDesignUrl = "https://fluxcontrol.pages.dev/winlock-offline.html";

    private readonly WinLockService _service;
    private readonly DispatcherTimer _topmostTimer;
    private readonly DispatcherTimer _retryTimer;
    private readonly string _mode;
    private readonly long _lockedAt;
    private bool _forceCloseAllowed;
    private bool _webShown;
    private bool _webReady;
    private int _retryCount;
    private bool _busy;

    /// <summary>
    /// Прогрів середовища WebView2 ще на старті застосунку (ТЗ: «блокування
    /// миттєве»). EnsureCoreWebView2Async без прогріву займає 1–3с.
    /// </summary>
    private static Task<Microsoft.Web.WebView2.Core.CoreWebView2Environment>? _envWarm;
    public static void PreWarmWebView2()
    {
        if (_envWarm != null) return;
        _envWarm = Task.Run(async () =>
        {
            var userDataDir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "FluxControl", "WebView2Lock");
            Directory.CreateDirectory(userDataDir);
            return await Microsoft.Web.WebView2.Core.CoreWebView2Environment.CreateAsync(null, userDataDir);
        });
    }

    public LockWindow(WinLockService service, string mode, long lockedAt)
    {
        InitializeComponent();

        _service = service;
        _mode = mode;
        _lockedAt = lockedAt;

        Loaded += OnLoaded;
        Deactivated += OnDeactivated;
        Closing += OnClosingGuard;

        // Re-assert Topmost periodically in case something stole it.
        _topmostTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(2) };
        _topmostTimer.Tick += (_, _) => AssertTopmost();

        // Ретраї завантаження веб-дизайну (ТЗ: нативного фолбеку більше немає —
        // якщо сайт/WebView впали, пробуємо знову; нативна панель НЕ показується).
        _retryTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(4) };
        _retryTimer.Tick += async (_, _) => await LoadDesignAsync();
    }

    private async void OnLoaded(object sender, RoutedEventArgs e)
    {
        AssertTopmost();
        _topmostTimer.Start();
        await LoadDesignAsync();

        // Фонове оновлення локального кеш-дизайну з сайту (офлайн-страховка на
        // НАСТУПНІ блокування) — не блокує показ поточного.
        _ = Task.Run(RefreshDesignFromSiteAsync);
    }

    private string LocalDesignPath => RuntimeFiles.WinLockHtmlPath;

    private async Task LoadDesignAsync()
    {
        if (_webShown || _busy) return;
        _busy = true;
        try
        {
            _retryCount++;
            if (_retryCount > 3) _retryTimer.Interval = TimeSpan.FromSeconds(8);

            var env = await (_envWarm ?? Microsoft.Web.WebView2.Core.CoreWebView2Environment.CreateAsync(null,
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "FluxControl", "WebView2Lock")));
            await LockWeb.EnsureCoreWebView2Async(env);

            if (!_webReady)
            {
                LockWeb.DefaultBackgroundColor = System.Drawing.Color.FromArgb(0xFF, 0x05, 0x05, 0x08);
                LockWeb.CoreWebView2.Settings.AreDevToolsEnabled = false;
                LockWeb.CoreWebView2.Settings.IsZoomControlEnabled = false;
                LockWeb.CoreWebView2.Settings.AreDefaultContextMenusEnabled = false;
                LockWeb.CoreWebView2.Settings.IsStatusBarEnabled = false;
                LockWeb.CoreWebView2.WebMessageReceived += OnWebMessageReceived;
                LockWeb.NavigationCompleted += OnLockWebNavigationCompleted;
                _webReady = true;
            }

            // САЙТ — першоджерело (ТЗ: «завантажувало HTML-файл з сайту»).
            var pc = Uri.EscapeDataString(Environment.MachineName);
            LockWeb.CoreWebView2.Navigate($"{SiteDesignUrl}?mode={Uri.EscapeDataString(_mode)}&lockedAt={_lockedAt}&pc={pc}");
            _retryTimer.Stop();
        }
        catch (Exception ex)
        {
            App.Log($"[WinLock] web design load failed (attempt {_retryCount}): {ex.Message}");
            // WebView2 впав — пробуємо ще; якщо середовище живе, наступна
            // спроба підхопить локальний кеш у OnLockWebNavigationCompleted.
            if (!_retryTimer.IsEnabled) _retryTimer.Start();
        }
        finally
        {
            _busy = false;
        }
    }

    /// <summary>
    /// Тихо тягне свіжу версію дизайну з сайту у локальний файл (кеш на випадок
    /// офлайну). Помилки/відсутність мережі — просто ігноруємо.
    /// </summary>
    private static async Task RefreshDesignFromSiteAsync()
    {
        try
        {
            using var http = new System.Net.Http.HttpClient { Timeout = TimeSpan.FromSeconds(12) };
            var html = await http.GetStringAsync(SiteDesignUrl);
            if (string.IsNullOrWhiteSpace(html) || html.Length < 500 || !html.Contains("winlock_try")) return;

            var dest = RuntimeFiles.WinLockHtmlPath;
            var dir = Path.GetDirectoryName(dest);
            if (!string.IsNullOrEmpty(dir)) Directory.CreateDirectory(dir);

            // Перезаписуємо лише якщо змінився (без зайвого дискового I/O).
            if (File.Exists(dest))
            {
                var old = await File.ReadAllTextAsync(dest);
                if (old == html) return;
            }
            await File.WriteAllTextAsync(dest, html);
            App.Log("[WinLock] Дизайн блокування оновлено з сайту у локальний кеш.");
        }
        catch { /* офлайн/таймаут — лишається попередній кеш */ }
    }

    private void OnLockWebNavigationCompleted(object? sender, Microsoft.Web.WebView2.Core.CoreWebView2NavigationCompletedEventArgs e)
    {
        if (_webShown) return;
        if (!e.IsSuccess)
        {
            // Сайт не завантажився (офлайн) — фолбек на локальний кеш-файл.
            if (File.Exists(LocalDesignPath))
            {
                try
                {
                    var pc = Uri.EscapeDataString(Environment.MachineName);
                    var fileUrl = new Uri(LocalDesignPath).AbsoluteUri;
                    LockWeb.CoreWebView2.Navigate($"{fileUrl}?mode={Uri.EscapeDataString(_mode)}&lockedAt={_lockedAt}&pc={pc}");
                    return;
                }
                catch (Exception ex)
                {
                    App.Log($"[WinLock] cache design navigate failed: {ex.Message}");
                }
            }
            if (!_retryTimer.IsEnabled) _retryTimer.Start();
            return;
        }

        try
        {
            _webShown = true;
            _retryTimer.Stop();

            // CS0200-фікс: у WebView2 (HwndHost) Opacity лише для читання,
            // тому сторінку розкриваємо зворотним fade «кришки» поверх.
            BootSplash.Visibility = Visibility.Collapsed;
            LockWeb.Visibility = Visibility.Visible;
            WebCover.Visibility = Visibility.Visible;
            WebCover.Opacity = 1d;
            var fade = new System.Windows.Media.Animation.DoubleAnimation(0, TimeSpan.FromMilliseconds(360))
            {
                EasingFunction = new System.Windows.Media.Animation.CubicEase { EasingMode = System.Windows.Media.Animation.EasingMode.EaseOut }
            };
            fade.Completed += (s, args) =>
            {
                try { WebCover.Visibility = Visibility.Collapsed; } catch { }
            };
            WebCover.BeginAnimation(OpacityProperty, fade);

            // разова синхронізація стану для сторінки
            PostToPage(new { type = "winlock_state", mode = _mode, lockedAt = _lockedAt, pc = Environment.MachineName });
        }
        catch { }
    }

    private void OnWebMessageReceived(object? sender, Microsoft.Web.WebView2.Core.CoreWebView2WebMessageReceivedEventArgs e)
    {
        try
        {
            // ТЗ-ФІКС БАГА «код перевіряється, але нічого не відбувається»:
            // сторінка може надіслати ОБ'ЄКТ (WebMessageAsJson = {"type":...})
            // АБО JSON-рядок (WebMessageAsJson = "{\"type\"...}") — приймаємо обидва.
            JsonObject? msg = null;
            try
            {
                msg = JsonSerializer.Deserialize<JsonObject>(e.WebMessageAsJson);
            }
            catch
            {
                try
                {
                    var asString = JsonSerializer.Deserialize<string>(e.WebMessageAsJson);
                    if (!string.IsNullOrWhiteSpace(asString))
                        msg = JsonSerializer.Deserialize<JsonObject>(asString);
                }
                catch { }
            }

            var type = msg?["type"]?.GetValue<string>() ?? "";
            if (type == "winlock_try")
            {
                var code = msg?["code"]?.GetValue<string>() ?? string.Empty;
                var ok = _service.TryUnlock(code);
                if (!ok)
                {
                    PostToPage(new { type = "winlock_unlock_result", ok = false });
                }
                // ok == true → сервіс сам закриє це вікно через ForceClose()
            }
            else if (type == "winlock_ready")
            {
                PostToPage(new { type = "winlock_state", mode = _mode, lockedAt = _lockedAt, pc = Environment.MachineName });
            }
        }
        catch (Exception ex)
        {
            App.Log($"[WinLock] web message error: {ex.Message}");
        }
    }

    private void PostToPage(object payload)
    {
        try
        {
            LockWeb.CoreWebView2?.PostWebMessageAsJson(JsonSerializer.Serialize(payload));
        }
        catch { }
    }

    private void OnDeactivated(object? sender, EventArgs e)
    {
        AssertTopmost();
    }

    private void AssertTopmost()
    {
        try
        {
            Topmost = true;
            Activate();
        }
        catch { }
    }

    private void OnClosingGuard(object? sender, System.ComponentModel.CancelEventArgs e)
    {
        if (_forceCloseAllowed)
        {
            _topmostTimer.Stop();
            _retryTimer.Stop();
            return;
        }
        e.Cancel = true; // this window is the lock surface — nothing external may close it
    }

    /// <summary>Service-initiated dismissal (unlock): bypasses the OnClosing guard.</summary>
    internal void ForceClose()
    {
        _forceCloseAllowed = true;
        try { Close(); } catch { }
    }
}
