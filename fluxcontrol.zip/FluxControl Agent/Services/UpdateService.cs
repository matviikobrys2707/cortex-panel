using System;
using System.Linq;
using System.Net.Http;
using System.IO;
using System.Reflection;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Threading;
using System.Threading.Tasks;

namespace FluxControl.Agent.Services;

/// <summary>Результат перевірки оновлень (ТЗ: манифест version.json на сайті).</summary>
public sealed class UpdateInfo
{
    public string LocalVersion { get; init; } = "";
    public string LatestVersion { get; init; } = "";
    public string DownloadUrl { get; init; } = "";
    public bool UpdateAvailable { get; init; }
    /// <summary>SHA-256 нового exe з манифесту (hex, 64 символи) або null/порожній —
    /// старий деплой без хеша (перевірка тоді пропускається з логом).</summary>
    public string? Sha256 { get; init; }
}

/// <summary>Прогрес завантаження оновлення.</summary>
public sealed class DownloadProgress
{
    public long ReceivedBytes { get; init; }
    public long TotalBytes { get; init; }
    public double Percent => TotalBytes > 0 ? Math.Min(100d, ReceivedBytes * 100d / TotalBytes) : 0d;
}

/// <summary>
/// Система автоматичних оновлень ЧЕРЕЗ ВЛАСНИЙ САЙТ (ТЗ «убери гитхаб»)
/// з ПРОКСІ-ФОЛБЕКОМ через власний сервер (фікс мереж, де ISP ламає
/// DNS для *.pages.dev: «запрошенное имя верно, но запрошенного типа
/// не найдено» — сайт у браузері є, а прямі запити з агенту падають).
///
/// Джерело даних про версію і сам файл — офіційний сайт застосунку:
///     https://fluxcontrol.pages.dev/version.json      (манифест)
///     https://fluxcontrol.pages.dev/FluxControl.exe   (сам exe)
/// Сайт — це Cloudflare Pages над репозиторієм matviikobrys2707/FluxControl,
/// куди деплоїть Auto-Deploy.ps1: exe + version.json + UI + logo лежать
/// у корені гілки main і роздаються звідти як статика. Жодних GitHub
/// Releases / api.github.com більше немає.
///
/// Резервний канал (той самий вміст, якщо Cloudflare тимчасово недоступний):
///     https://raw.githubusercontent.com/matviikobrys2707/FluxControl/main/...
///
/// Кеш: Cloudflare Pages віддає статику з revalidation (etag), плюс ?t={timestamp}
/// і no-cache заголовки — манифест завжди свіжий, нова версія помічається одразу.
/// </summary>
public static class UpdateService
{
    /// <summary>Офіційний сайт застосунку (єдине джерело оновлень).</summary>
    public const string SiteBase = "https://fluxcontrol.pages.dev";

    public const string VersionJsonUrl = SiteBase + "/version.json";

    /// <summary>Резервний шлях до манифесту: raw головної гілки репозиторію сайту.</summary>
    public const string VersionJsonFallbackUrl =
        "https://raw.githubusercontent.com/matviikobrys2707/FluxControl/main/version.json";

    /// <summary>
    /// Сервер-релей (Render): маршрут /update/* віддає ТОЙ САМИЙ статичний
    /// контент, що й сайт (version.json, versions.json, exe, UI, assets).
    /// Працює навіть коли pages.dev заблокований/ламається DNS — агент сам
    /// автоматично переключається, без жодних налаштувань.
    /// </summary>
    public const string ServerUpdateBase = "https://fluxcontrol-backend-bl3u.onrender.com/update";

    /// <summary>Константа-фолбек, якщо версію збірки не прочитано.</summary>
    public const string CurrentVersion = "1.0.0";

    internal static readonly HttpClient CheckClient = new(new HttpClientHandler
    {
        AllowAutoRedirect = true
    })
    {
        // ФІКС хибного «немає зв'язку з сайтом оновлень»: 12с не вистачало на
        // повільних DNS/мобільних мережах (особливо при автозапуску Windows,
        // коли мережа піднімається ПІЗНІШЕ за програму) — 25с покриває.
        Timeout = TimeSpan.FromSeconds(25)
    };

    private static readonly HttpClient DownloadClient = new(new HttpClientHandler
    {
        AllowAutoRedirect = true,
        AutomaticDecompression = System.Net.DecompressionMethods.None
    })
    {
        // Стрім великого файлу: таймаут не обмежуємо, скасування — через CancellationToken.
        Timeout = Timeout.InfiniteTimeSpan
    };

    static UpdateService()
    {
        foreach (var client in new[] { CheckClient, DownloadClient })
        {
            client.DefaultRequestHeaders.UserAgent.ParseAdd("FluxControl-Updater/1.0");
            client.DefaultRequestHeaders.Accept.ParseAdd("*/*");
        }
        // ТЗ «нова версія помічається ОДРАЗУ»: забороняємо кеш манифесту на
        // проміжних проксі; ?t={timestamp} дає свіжий ключ кеша Cloudflare.
        CheckClient.DefaultRequestHeaders.CacheControl =
            new System.Net.Http.Headers.CacheControlHeaderValue { NoCache = true, MustRevalidate = true };
        CheckClient.DefaultRequestHeaders.Pragma.ParseAdd("no-cache");
    }

    /// <summary>
    /// Локальна версія — ЛИШЕ з метаданих збірки (AssemblyInformationalVersion),
    /// які деплой-скрипт зашиває всередину exe через -p:Version.
    /// Фолбек — константа.
    /// </summary>
    public static string GetLocalVersion()
    {
        try
        {
            var entry = Assembly.GetEntryAssembly();
            var attr = entry?.GetCustomAttribute<AssemblyInformationalVersionAttribute>();
            var info = attr?.InformationalVersion;
            if (!string.IsNullOrEmpty(info))
            {
                // -p:Version=1.0.3 може дати "1.0.3+abc123" — відрізаємо хвіст
                var v = info.Split('+')[0].Trim();
                if (v.Length > 0) return NormalizeVersion(v);
            }
        }
        catch { }
        return CurrentVersion;
    }

    /// <summary>
    /// ТЗ юзера: версія ЗАВЖДИ з ТРЬОХ цифр (1.2.3), а не чотирьох (1.2.3.0).
    /// .NET додає четвертий сегмент «.0» до FileVersion — відрізаємо його всюди.
    /// </summary>
    public static string NormalizeVersion(string? raw)
    {
        var v = (raw ?? string.Empty).Trim().TrimStart('v', 'V').Split('+')[0].Trim();
        var parts = v.Split('.');
        if (parts.Length > 3) v = string.Join('.', parts.Take(3));
        return v;
    }

    /// <summary>URL exe КОНКРЕТНОЇ версії в архіві на сайті (ТЗ «скачати будь-яку версію»).</summary>
    public static string VersionArchiveUrl(string version)
        => $"{SiteBase}/versions/{Uri.EscapeDataString(NormalizeVersion(version))}/FluxControl.exe";

    /// <summary>
    /// Встановлення КОНКРЕТНОЇ версії (відкат або апгрейд за вибором юзера):
    /// скачує versions/&lt;version&gt;/FluxControl.exe з сайту (резерв — raw GitHub)
    /// і запускає штатний move-swap оновлювач. Працює навіть коли «нова» версія
    /// СТАРІША за поточну — це свідомий відкат.
    /// </summary>
    public static async Task<string> InstallSpecificVersionAsync(
        string version, IProgress<DownloadProgress>? progress, CancellationToken ct)
    {
        var target = NormalizeVersion(version);
        if (string.IsNullOrWhiteSpace(target) || !target.Contains('.'))
            throw new ArgumentException("Некоректна версія: " + version);

        var url = VersionArchiveUrl(target);
        App.Log($"Update: installing specific version {target} from {url}");
        // SECURITY FIX: хеш версії з архіву (sha256.txt поруч із exe, best-effort).
        var sha = await UpdateRollbackService.FetchVersionSha256Async(target);
        if (sha == null) App.Log("Update: no sha256.txt for archived version — checksum verification skipped.");
        var path = await DownloadReleaseZipAsync(url, "v" + target, progress, ct, expectedSha256: sha);
        App.Log($"Update: version {target} downloaded ({new FileInfo(path).Length} bytes)");
        return path;
    }

    /// <summary>Порівняння версій "1.0.1" / "v1.0.1" — System.Version.</summary>
    public static bool IsNewerVersion(string? remote, string? local)
    {
        remote = remote?.Trim().TrimStart('v', 'V') ?? "";
        local = local?.Trim().TrimStart('v', 'V') ?? "";
        if (!Version.TryParse(remote, out var rv)) return false;
        if (!Version.TryParse(local, out var lv)) return true; // локальну не прочитали — оновлюємось
        return rv > lv;
    }

    /// <summary>
    /// Читає манифест version.json з конкретної адреси. null = недоступний/пошкоджений.
    /// </summary>
    private static async Task<UpdateInfo?> TryFetchManifestAsync(string url)
    {
        var busted = url + (url.IndexOf('?') >= 0 ? "&t=" : "?t=") +
            DateTimeOffset.UtcNow.ToUnixTimeSeconds();
        using var resp = await CheckClient.GetAsync(busted);
        resp.EnsureSuccessStatusCode();
        var body = await resp.Content.ReadAsStringAsync();
        // захист від BOM, якщо version.json редагували руками
        body = body.TrimStart('\uFEFF');
        var json = JsonSerializer.Deserialize<JsonObject>(body);
        var latest = json?["latest_version"]?.GetValue<string>();
        var download = json?["download_url"]?.GetValue<string>();
        // SECURITY FIX: хеш справжності, який деплой-скрипт зашиває в манифест.
        var sha = json?["sha256"]?.GetValue<string>();

        if (string.IsNullOrWhiteSpace(latest) || string.IsNullOrWhiteSpace(download))
        {
            App.Log($"Update check: manifest has empty fields ({url})");
            return null;
        }

        var local = GetLocalVersion();
        return new UpdateInfo
        {
            LocalVersion = local,
            LatestVersion = NormalizeVersion(latest),
            DownloadUrl = download.Trim(),
            UpdateAvailable = IsNewerVersion(latest, local),
            Sha256 = string.IsNullOrWhiteSpace(sha) ? null : sha.Trim().ToLowerInvariant()
        };
    }

    /// <summary>
    /// GET version.json: спершу офіційний сайт, потім сервер-проксі /update/*,
    /// в кінці — raw-резерв того самого репозиторію.
    /// null = мережа/формат недоступні (тихий пропуск).
    /// </summary>
    public static async Task<UpdateInfo?> CheckForUpdateAsync()
    {
        // ФІКС хибного «немає зв'язку» (балун у треї при робочому інтернеті):
        // один прогін трьох джерел не покриває ривки маршрутизації та DNS-
        // таймаути на мобільних мережах. Два повні прогони всіх 3 джерел
        // з паузою 1.5с — сумарно до ~2 хв у найгіршому випадку, але
        // зазвичай перше ж джерело відповідає за ~1с.
        var first = await TryAllSourcesOnceAsync();
        if (first != null) return first;
        try { await Task.Delay(1500); } catch { }
        App.Log("Update check: all 3 sources failed once — second pass...");
        return await TryAllSourcesOnceAsync();
    }

    private static async Task<UpdateInfo?> TryAllSourcesOnceAsync()
    {
        try
        {
            var info = await TryFetchManifestAsync(VersionJsonUrl);
            if (info != null) return info;
        }
        catch (Exception ex)
        {
            App.Log($"Update check via site failed: {ex.Message}");
        }

        // ФІКС (мережі з блокуванням pages.dev): той самий манифест через
        // власний сервер — той самий вміст, той самий релей, без налаштувань.
        try
        {
            var info = await TryFetchManifestAsync(ServerUpdateBase + "/version.json");
            if (info != null)
            {
                App.Log("Update check: fallback to server proxy manifest");
                return info;
            }
        }
        catch (Exception ex)
        {
            App.Log($"Update check via server proxy failed: {ex.Message}");
        }

        try
        {
            var info = await TryFetchManifestAsync(VersionJsonFallbackUrl);
            if (info != null)
            {
                App.Log("Update check: fallback to raw.githubusercontent manifest");
                return info;
            }
        }
        catch (Exception ex)
        {
            App.Log($"Update check fallback failed: {ex.Message}");
        }
        return null;
    }
    /// <summary>
    /// Адреса завантаження самого exe: download_url з манифесту (посилання на
    /// сайт), за потреби виправлена на резервний raw-канал того ж репозиторію.
    /// </summary>
    public static async Task<string?> GetLatestReleaseZipUrlAsync()
    {
        var info = await CheckForUpdateAsync();
        var url = info?.DownloadUrl;
        if (string.IsNullOrEmpty(url))
            url = SiteBase + "/FluxControl.exe";
        return NormalizeDownloadUrl(url);
    }

    /// <summary>
    /// Сайт недоступний? Той самий файл лежить у головній гілці репозиторію
    /// сайту — підміняємо хост на raw (вміст ідентичний, деплой пушить обидва).
    /// </summary>
    public static string NormalizeDownloadUrl(string url)
    {
        if (string.IsNullOrEmpty(url)) return url;
        if (url.StartsWith(SiteBase + "/", StringComparison.OrdinalIgnoreCase))
        {
            return "https://raw.githubusercontent.com/matviikobrys2707/FluxControl/main/" +
                   url.Substring(SiteBase.Length + 1);
        }
        return url;
    }

    /// <summary>
    /// Той самий файл через сервер-проксі /update/* (фікс блокування pages.dev):
    /// https://fluxcontrol.pages.dev/FluxControl.exe →
    /// https://fluxcontrol-backend-bl3u.onrender.com/update/FluxControl.exe
    /// </summary>
    public static string? ProxyDownloadUrl(string url)
    {
        if (string.IsNullOrEmpty(url)) return null;
        if (url.StartsWith(SiteBase + "/", StringComparison.OrdinalIgnoreCase))
            return ServerUpdateBase + "/" + url.Substring(SiteBase.Length + 1);
        return null;
    }

    /// <summary>
    /// Завантаження оновлення (FluxControl.exe або zip старого формату) у %TEMP%
    /// зі стрімінгом прогресу. Якщо сайт не відповів — автоматичний ретрай через
    /// raw-резерв того ж файлу. Редиректи проходять автоматично.
    /// </summary>
    public static async Task<string> DownloadReleaseZipAsync(
        string url, string versionTag, IProgress<DownloadProgress>? progress, CancellationToken ct,
        string? expectedSha256 = null)
    {
        try
        {
            var p = await DownloadToFileAsync(url, versionTag, progress, ct);
            // SECURITY FIX: перевірка справжності ДО встановлення (аудит п.3).
            UpdateRollbackService.VerifyChecksumOrThrow(p, expectedSha256);
            return p;
        }
        catch (Exception first) when (!(ct.IsCancellationRequested) &&
                                       first is not InvalidDataException &&
                                       url.StartsWith(SiteBase, StringComparison.OrdinalIgnoreCase))
        {
            // ФІКС: фолбек-ланцюжок сервер-проксі → raw. Дві спроби замість однієї.
            var proxy = ProxyDownloadUrl(url);
            if (!string.IsNullOrEmpty(proxy))
            {
                try
                {
                    App.Log($"Update: site download failed ({first.Message}) — retrying via server proxy");
                    progress?.Report(new DownloadProgress { ReceivedBytes = 0, TotalBytes = 0 });
                    var pp = await DownloadToFileAsync(proxy, versionTag, progress, ct);
                    UpdateRollbackService.VerifyChecksumOrThrow(pp, expectedSha256);
                    return pp;
                }
                catch (Exception second) when (!(ct.IsCancellationRequested) && second is not InvalidDataException)
                {
                    App.Log($"Update: proxy download failed ({second.Message}) — retrying via raw fallback");
                }
            }
            else
            {
                App.Log($"Update: download failed ({first.Message}) — retrying via raw fallback");
            }
            progress?.Report(new DownloadProgress { ReceivedBytes = 0, TotalBytes = 0 });
            var p = await DownloadToFileAsync(NormalizeDownloadUrl(url), versionTag, progress, ct);
            UpdateRollbackService.VerifyChecksumOrThrow(p, expectedSha256);
            return p;
        }
    }

    private static async Task<string> DownloadToFileAsync(
        string url, string versionTag, IProgress<DownloadProgress>? progress, CancellationToken ct)
    {
        // ?t={timestamp} — свіжий ключ кеша, щоб не віддати старий exe
        var busted = url + (url.IndexOf('?') >= 0 ? "&t=" : "?t=") +
            DateTimeOffset.UtcNow.ToUnixTimeSeconds();
        using var resp = await DownloadClient.GetAsync(busted, HttpCompletionOption.ResponseHeadersRead, ct);
        resp.EnsureSuccessStatusCode();

        long total = resp.Content.Headers.ContentLength ?? 0;
        var safeTag = string.Concat(versionTag.Where(char.IsLetterOrDigit)).Replace(" ", "");
        if (safeTag.Length == 0) safeTag = "update";
        var ext = url.EndsWith(".exe", StringComparison.OrdinalIgnoreCase) ? ".exe" : ".zip";
        var tmpPath = Path.Combine(Path.GetTempPath(), $"FluxControl-{safeTag}{ext}");

        await using (var fs = new FileStream(tmpPath, FileMode.Create, FileAccess.Write, FileShare.None, 81920, useAsync: true))
        {
            await using (var net = await resp.Content.ReadAsStreamAsync(ct))
            {
                var buffer = new byte[81920];
                long received = 0;
                int read;
                while ((read = await net.ReadAsync(buffer, ct)) > 0)
                {
                    await fs.WriteAsync(buffer.AsMemory(0, read), ct);
                    received += read;
                    progress?.Report(new DownloadProgress { ReceivedBytes = received, TotalBytes = total });
                }
            }
        }
        App.Log($"Update: downloaded {tmpPath} ({total} bytes) from {url}");
        return tmpPath;
    }
}
