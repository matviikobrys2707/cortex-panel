using System;
using System.Collections.Concurrent;
using System.IO;
using System.Linq;

namespace FluxControl.Agent.Services;

/// <summary>
/// Чанкові завантаження НА ПК (upload) — винесено в окремий partial
/// (аудит п.5 «розбити великі файли по функціях»). Основний клас тримає
/// навігацію/файли, цей файл — сесії UploadSession (begin/chunk/end/abort).
/// </summary>
public partial class FileManagerService
{
    private sealed class UploadSession
    {
        public string TargetPath = string.Empty;
        public string TempPath = string.Empty;
        public FileStream? Stream;
        public int NextIndex;
        public int TotalChunks;
        public long BytesWritten;
    }

    private readonly System.Collections.Concurrent.ConcurrentDictionary<string, UploadSession> _uploads = new();

    /// <summary>Почати завантаження: файл пишеться у .fluxpart, у кінці перейменовується.</summary>
    public void BeginUpload(string id, string targetPath, int totalChunks)
    {
        if (string.IsNullOrWhiteSpace(id) || string.IsNullOrWhiteSpace(targetPath))
            throw new ArgumentException("Порожній id або шлях файлу");

        AbortUpload(id);

        var dir = Path.GetDirectoryName(targetPath);
        if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir)) Directory.CreateDirectory(dir);

        var tempPath = targetPath + ".fluxpart";
        var session = new UploadSession
        {
            TargetPath = targetPath,
            TempPath = tempPath,
            TotalChunks = Math.Max(1, totalChunks),
            Stream = new FileStream(tempPath, FileMode.Create, FileAccess.Write, FileShare.Read),
        };
        _uploads[id] = session;
    }

    /// <summary>Дописати chunk (base64, суворо за порядком — веб шле послідовно).</summary>
    public void AppendUploadChunk(string id, int index, string base64)
    {
        if (!_uploads.TryGetValue(id, out var s) || s.Stream == null)
            throw new InvalidOperationException("Завантаження не почато або вже завершене");
        if (index != s.NextIndex)
            throw new InvalidOperationException($"Очікувався chunk #{s.NextIndex}, а прийшов #{index}");

        var bytes = Convert.FromBase64String(base64);
        s.Stream.Write(bytes, 0, bytes.Length);
        s.BytesWritten += bytes.Length;
        s.NextIndex = index + 1;
    }

    /// <summary>Завершити: закрити стрім, перейменувати .fluxpart → цільовий файл.</summary>
    public string EndUpload(string id)
    {
        if (!_uploads.TryGetValue(id, out var s) || s.Stream == null)
            throw new InvalidOperationException("Завантаження не почато або вже завершене");

        try
        {
            s.Stream.Flush();
            s.Stream.Dispose();
            s.Stream = null;

            if (File.Exists(s.TargetPath)) File.Delete(s.TargetPath);
            File.Move(s.TempPath, s.TargetPath);
            InvalidateFolderSize(Path.GetDirectoryName(s.TargetPath));
            return s.TargetPath;
        }
        finally
        {
            _uploads.TryRemove(id, out _);
        }
    }

    /// <summary>Скасувати/прибрати сесію (і залишковий .fluxpart).</summary>
    public void AbortUpload(string id)
    {
        if (!_uploads.TryRemove(id, out var s)) return;
        try { s.Stream?.Dispose(); } catch { }
        try { if (File.Exists(s.TempPath)) File.Delete(s.TempPath); } catch { }
    }
}
