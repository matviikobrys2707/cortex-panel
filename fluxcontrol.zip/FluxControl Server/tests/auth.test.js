/**
 * FluxControl Server — АВТОМАТИЧНІ ТЕСТИ БЕЗПЕКИ (аудит, п.4).
 *
 * Запускає РЕАЛЬНИЙ сервер дочірнім процесом на тестовому порту і проганяє
 * головні сценарії (npm test):
 *   1. Роль призначає ТІЛЬКИ сервер: role тіла запиту / підстроки email
 *      НЕ дають адмінку; ADMIN_EMAILS (точний збіг) — дає.
 *   2. Адмін-ендпоінти: без сесії → 403 (раніше БАЙПАС!), зі спуфленим
 *      x-fc-user-id → 403, з юзерською сесією → 403, з Bearer адміна → 200.
 *   3. Чужий доступ: чужий список пристроїв → 403, свій → 200; чужий профіль
 *      → 403; активація ключа на чужий акаунт → 403; approve без сесії → 401.
 *   4. Сесійні токени: логін повертає sessionToken, Bearer працює.
 */

const { spawn } = require('child_process');
const http = require('http');
const path = require('path');

const PORT = 3777;
const BASE = `http://127.0.0.1:${PORT}`;

function req(method, path, { body, headers } = {}) {
  return new Promise((resolve, reject) => {
    const data = body ? JSON.stringify(body) : null;
    const r = http.request(`${BASE}${path}`, {
      method,
      headers: {
        ...(data ? { 'content-type': 'application/json', 'content-length': Buffer.byteLength(data) } : {}),
        ...(headers || {}),
      },
    }, (res) => {
      let buf = '';
      res.on('data', (c) => (buf += c));
      res.on('end', () => {
        let json = null;
        try { json = JSON.parse(buf); } catch {}
        resolve({ status: res.statusCode, json, raw: buf });
      });
    });
    r.on('error', reject);
    r.setTimeout(8000, () => r.destroy(new Error('timeout')));
    if (data) r.write(data);
    r.end();
  });
}

let passed = 0, failed = 0;
let adminSession2 = null;
function ok(name, cond, extra = '') {
  if (cond) { passed++; console.log(`  PASS  ${name}`); }
  else { failed++; console.log(`  FAIL  ${name} ${extra}`); }
}

async function waitReady() {
  for (let i = 0; i < 60; i++) {
    try {
      const r = await req('GET', '/health');
      if (r.status === 200) return true;
    } catch {}
    await new Promise((r) => setTimeout(r, 250));
  }
  return false;
}

(async () => {
  const serverPath = path.join(__dirname, '..', 'server.js');
  const child = spawn(process.execPath, [serverPath], {
    env: {
      ...process.env,
      PORT: String(PORT),
      ADMIN_EMAILS: 'owner@fluxcontrol.app',
      CF_D1_TOKEN: 'test-token-invalid-on-purpose',
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  let serverLog = '';
  child.stdout.on('data', (d) => (serverLog += d));
  child.stderr.on('data', (d) => (serverLog += d));

  console.log('== FluxControl Security Tests ==\n[boot] waiting for /health...');

  try {
    if (!(await waitReady())) throw new Error('server did not start:\n' + serverLog.slice(-2000));
    console.log('[boot] server is up\n');

    // ---------- 0. СІЄННЯ: справжній адмін першим (щоб bootstrap-правило
    // «перший користувач стає адміном» спрацювало на НЬОГО, а не на атакера).
    const seed = await req('POST', '/api/auth/google', {
      body: { user: { sub: 'owner_real', email: 'owner@fluxcontrol.app' } },
    });
    ok('seed: ADMIN_EMAILS owner -> admin', seed.json?.user?.role === 'admin', `got ${seed.json?.user?.role}`);
    const adminSession = seed.json?.sessionToken;

    // ---------- 1. РОЛЬ ТІЛЬКИ СЕРВЕР ----------
    console.log('\n-- 1. Role assignment is server-only --');

    // Спроба самозанесення в адміни через тіло запиту.
    const r1 = await req('POST', '/api/auth/google', {
      body: { user: { sub: 'attacker_1', email: 'attacker1@gmail.com', role: 'admin' } },
    });
    ok('login returns sessionToken', r1.status === 200 && !!r1.json?.sessionToken, JSON.stringify(r1.json).slice(0, 120));
    ok('body role=admin ignored (role=user)', r1.json?.user?.role === 'user', `got ${r1.json?.user?.role}`);
    const attackerSession = r1.json?.sessionToken;

    // Підстрока email «blazix» / «admin@» БІЛЬШЕ не дає адмінку.
    const r2 = await req('POST', '/api/auth/google', {
      body: { user: { sub: 'spoof_blazix', email: 'blazix.evildude@gmail.com' } },
    });
    ok('email substring "blazix" no longer admin', r2.json?.user?.role === 'user', `got ${r2.json?.user?.role}`);

    const r3 = await req('POST', '/api/auth/google', {
      body: { user: { sub: 'spoof_admin_at', email: 'hacker-admin@evil.com' } },
    });
    ok('email substring "admin@" no longer admin', r3.json?.user?.role === 'user', `got ${r3.json?.user?.role}`);

    // ADMIN_EMAILS — ТОЧНИЙ збіг.
    const r4 = await req('POST', '/api/auth/google', {
      body: { user: { sub: 'owner_relogin', email: 'owner@fluxcontrol.app' } },
    });
    ok('ADMIN_EMAILS exact match -> admin (re-login keeps role)', r4.json?.user?.role === 'admin', `got ${r4.json?.user?.role}`);
    adminSession2 = r4.json?.sessionToken;

    const r5 = await req('POST', '/api/auth/google', {
      body: { user: { sub: 'owner_spoof', email: 'owner+phish@fluxcontrol.app.evil.io' } },
    });
    ok('ADMIN_EMAILS substring of email NOT admin', r5.json?.user?.role === 'user', `got ${r5.json?.user?.role}`);

    // ---------- 2. АДМІН-ЕНДПОІНТИ ----------
    console.log('\n-- 2. Admin endpoints require REAL admin session --');

    const a1 = await req('GET', '/api/admin/keys');
    ok('GET /api/admin/keys WITHOUT anything -> 403 (was bypass!)', a1.status === 403, `got ${a1.status}`);

    const a2 = await req('GET', '/api/admin/keys', { headers: { 'x-fc-user-id': 'owner_real' } });
    ok('admin API with spoofed x-fc-user-id -> 403', a2.status === 403, `got ${a2.status}`);

    const a3 = await req('GET', '/api/admin/keys', { headers: { Authorization: `Bearer ${attackerSession}` } });
    ok('admin API with USER session -> 403', a3.status === 403, `got ${a3.status}`);

    const a4 = await req('GET', '/api/admin/keys', { headers: { Authorization: `Bearer ${adminSession}` } });
    ok('admin API with ADMIN Bearer -> 200', a4.status === 200, `got ${a4.status} ${a4.raw.slice(0, 100)}`);

    const a5 = await req('POST', '/api/admin/keys/generate', {
      headers: { 'x-fc-user-id': 'owner_real' },
      body: { durationType: '30d', count: 1 },
    });
    ok('key GENERATION with spoofed header -> 403 (was unprotected!)', a5.status === 403, `got ${a5.status}`);

    const a6 = await req('POST', '/api/admin/keys/generate', {
      headers: { Authorization: `Bearer ${adminSession}` },
      body: { durationType: '30d', count: 2 },
    });
    ok('key GENERATION with admin session -> 200', a6.status === 200 && a6.json?.count === 2, `got ${a6.status}`);
    const testKey = a6.json?.keys?.[0]?.key;

    const a7 = await req('POST', '/api/admin/users/role', {
      body: { userId: 'attacker_1', role: 'admin' },
    });
    ok('role change without session -> 403', a7.status === 403, `got ${a7.status}`);

    // ---------- 3. ЧУЖИЙ ДОСТУП ----------
    console.log('\n-- 3. Cross-user access denied --');

    // attacker прив’язує собі ПК, потім намагається глянути список owner.
    // НОВІ акаунти заблоковані (accessEnabled=false) — адмін спершу відкриває
    // доступ атакеру, щоб тест пішов далі (це існуюча фіча доступу).
    const unlock = await req('POST', '/api/admin/users/update', {
      headers: { Authorization: `Bearer ${adminSession}` },
      body: { userId: 'attacker_1', accessEnabled: true },
    });
    ok('admin unlocks new account -> 200', unlock.status === 200, `got ${unlock.status} ${unlock.raw.slice(0, 100)}`);

    const l1 = await req('POST', '/api/devices', {
      headers: { Authorization: `Bearer ${attackerSession}` },
      body: { userId: 'attacker_1', hwid: 'HWID_TEST_1', name: 'TestPC' },
    });
    ok('link own device -> 200', l1.status === 200, `got ${l1.status} ${l1.raw.slice(0, 100)}`);

    const l2 = await req('POST', '/api/devices', {
      headers: { Authorization: `Bearer ${attackerSession}` },
      body: { userId: 'owner_real', hwid: 'HWID_STOLEN', name: 'Stolen' },
    });
    ok('link device to FOREIGN account -> 403', l2.status === 403, `got ${l2.status}`);

    const l3 = await req('POST', '/api/devices', {
      headers: { 'x-fc-user-id': 'attacker_1' },
      body: { userId: 'attacker_1', hwid: 'HWID_HDR', name: 'HdrPC' },
    });
    ok('link via legacy header -> denied 401 (write needs session)', l3.status === 401, `got ${l3.status}`);

    const d1 = await req('GET', '/api/devices?userId=owner_real', { headers: { Authorization: `Bearer ${attackerSession}` } });
    ok('foreign device list -> 403', d1.status === 403, `got ${d1.status}`);

    const d2 = await req('GET', '/api/devices?userId=attacker_1', { headers: { Authorization: `Bearer ${attackerSession}` } });
    ok('own device list -> 200', d2.status === 200 && Array.isArray(d2.json?.devices), `got ${d2.status}`);

    const d3 = await req('GET', '/api/devices?userId=attacker_1');
    ok('device list WITHOUT auth -> 401', d3.status === 401, `got ${d3.status}`);

    const d4 = await req('GET', '/api/devices?userId=attacker_1', { headers: { Authorization: `Bearer ${adminSession}` } });
    ok('admin can view ANY device list -> 200', d4.status === 200, `got ${d4.status}`);

    const p1 = await req('GET', '/api/auth/profile?id=owner_real', { headers: { Authorization: `Bearer ${attackerSession}` } });
    ok('foreign profile read -> 403', p1.status === 403, `got ${p1.status}`);

    const p2 = await req('GET', '/api/auth/profile?id=attacker_1', { headers: { Authorization: `Bearer ${attackerSession}` } });
    ok('own profile read -> 200', p2.status === 200, `got ${p2.status}`);

    // Ключ на чужий акаунт.
    if (testKey) {
      const k1 = await req('POST', '/api/license/activate', {
        headers: { Authorization: `Bearer ${attackerSession}` },
        body: { userId: 'owner_real', keyCode: testKey },
      });
      ok('activate key on FOREIGN account -> 403', k1.status === 403, `got ${k1.status}`);
    }

    const ap1 = await req('POST', '/api/auth/device-session/approve', {
      body: { token: 'auth_req_doesnotexist', action: 'approve' },
    });
    ok('device-session approve WITHOUT session -> 401', ap1.status === 401, `got ${ap1.status}`);

    // ---------- 4. СЕСІЇ ----------
    console.log('\n-- 4. Sessions --');
    const s1 = await req('POST', '/api/auth/google', {
      body: { user: { sub: 'owner_real', email: 'owner@fluxcontrol.app' } },
    });
    ok('re-login keeps admin role (existing user)', s1.json?.user?.role === 'admin', `got ${s1.json?.user?.role}`);
    ok('re-login issues NEW sessionToken', !!s1.json?.sessionToken && s1.json.sessionToken !== adminSession);

    const s2 = await req('GET', '/api/admin/keys', { headers: { Authorization: 'Bearer invalid_token_123' } });
    ok('invalid Bearer token -> 403', s2.status === 403, `got ${s2.status}`);

    console.log(`\n== RESULTS: ${passed} passed, ${failed} failed ==`);
    child.kill('SIGKILL');
    process.exit(failed > 0 ? 1 : 0);
  } catch (e) {
    console.error('TEST RUNNER ERROR:', e.message);
    console.error(serverLog.slice(-3000));
    child.kill('SIGKILL');
    process.exit(2);
  }
})();
