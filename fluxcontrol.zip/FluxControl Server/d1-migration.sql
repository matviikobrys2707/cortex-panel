-- FluxControl D1 migration (Cloudflare Dashboard → Storage & Databases → D1 → fluxcontrol → Console)
-- Вставь весь файл и нажми Execute. Безопасно запускать повторно (IF NOT EXISTS).
-- После миграции таблицы существуют, но СЕРВЕРУ всё равно нужен токен с правом
-- ЗАПИСИ (D1:Edit): My Profile → API Tokens → Create Token → Custom Token →
-- Account → D1 → Edit → вставить в Render → Environment → CF_D1_TOKEN.

CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  email TEXT,
  name TEXT,
  picture TEXT,
  role TEXT DEFAULT 'user',
  subscription_expires_at INTEGER,
  access_enabled INTEGER DEFAULT 1,
  created_at INTEGER
);

CREATE TABLE IF NOT EXISTS license_keys (
  id TEXT PRIMARY KEY,
  key TEXT UNIQUE,
  type TEXT,
  duration_ms INTEGER,
  created_at INTEGER,
  expires_at INTEGER,
  used INTEGER DEFAULT 0,
  used_by_user_id TEXT,
  used_by_user_name TEXT,
  used_at INTEGER
);

CREATE TABLE IF NOT EXISTS computers (
  id TEXT PRIMARY KEY,
  hwid TEXT,
  code TEXT,
  name TEXT,
  os_info TEXT,
  cpu_info TEXT,
  gpu TEXT,
  ram_info TEXT,
  username TEXT,
  status TEXT DEFAULT 'offline',
  active_url TEXT,
  local_url TEXT,
  last_seen TEXT,
  local_ip TEXT,
  adapters TEXT,
  wol_mac TEXT
);

CREATE TABLE IF NOT EXISTS users_computers (
  user_id TEXT,
  computer_id TEXT,
  custom_name TEXT,
  PRIMARY KEY (user_id, computer_id)
);

CREATE TABLE IF NOT EXISTS auth_sessions (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  device TEXT,
  created_at INTEGER
);

CREATE TABLE IF NOT EXISTS share_tokens (
  token TEXT PRIMARY KEY,
  hwid TEXT,
  code TEXT,
  name TEXT,
  is_dir INTEGER DEFAULT 0,
  size_bytes INTEGER DEFAULT 0,
  created_at INTEGER
);

CREATE TABLE IF NOT EXISTS agent_jobs (
  job_id TEXT PRIMARY KEY,
  hwid TEXT,
  type TEXT,
  payload TEXT,
  status TEXT DEFAULT 'new',
  result TEXT,
  created_at INTEGER
);

CREATE TABLE IF NOT EXISTS share_chunks (
  stream_id TEXT,
  seq INTEGER,
  data TEXT,
  last INTEGER DEFAULT 0,
  PRIMARY KEY (stream_id, seq)
);

CREATE INDEX IF NOT EXISTS idx_users_computers_user ON users_computers (user_id);
CREATE INDEX IF NOT EXISTS idx_agent_jobs_hwid ON agent_jobs (hwid, status);
CREATE INDEX IF NOT EXISTS idx_computers_code ON computers (code);
