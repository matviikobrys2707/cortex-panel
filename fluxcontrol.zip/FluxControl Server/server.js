/**
 * FluxControl Render Backend Server
 * Integrated with Cloudflare D1 Database (Single Source of Truth),
 * High-speed WebSocket Relay with Instant Disconnect Handling, HWID/Code DB,
 * License Keys, Subscriptions, Admin API, and Web-Device OAuth.
 */

const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// ЯДРО АВТОРИЗАЦІЇ (Security Fix: сесійні токени, роль тільки сервером).
const authCore = require('./lib/auth');

const PORT = process.env.PORT || 3000;
const app = express();

app.use(cors());
// ВАЖЛИВО: AI-зріс надсилає скриншоти екрана в base64 (сотні КБ на кадр).
// Дефолтний ліміт express.json() — 100KB, через що будь-який запит зі
// скриншотом падав із HTTP 413 Payload Too Large («Помилка з’єднання» у чаті).
app.use(express.json({ limit: '30mb' }));
app.use(express.urlencoded({ extended: true, limit: '30mb' }));

// Cloudflare D1 Credentials
// Токен берётся СНАЧАЛА из переменной окружения CF_D1_TOKEN (Render →
// Environment → Add Environment Variable), fallback — вшитый ниже. Вшитый
// токен может протухнуть/быть отозван: Cloudflare тогда отвечает
// { code: 10000, message: 'Authentication error' } и кэш грузится пустым.
// Новый токен: dash.cloudflare.com → My Profile → API Tokens → Create Token
// → Custom Token → Permissions: Account → D1 → Edit → Create → скопировать.
const CLOUDFLARE_D1_CONFIG = {
  accountId: '959f0a3b73e2617a7204d8f6dc1dc8aa',
  databaseId: '7c290aee-b48e-463d-8b97-d8d571c2d986',
  authToken: process.env.CF_D1_TOKEN || 'cfut_ay92huwH2nP9mqorosoYx6tYoxeDjaP6oC0kji5Pf6e3556d',
  endpoint: 'https://api.cloudflare.com/client/v4/accounts/959f0a3b73e2617a7204d8f6dc1dc8aa/d1/database/7c290aee-b48e-463d-8b97-d8d571c2d986/query'
};
console.log(`[D1] Auth token source: ${process.env.CF_D1_TOKEN ? 'CF_D1_TOKEN (env)' : 'built-in fallback'}`);

// Ошибка авторизации (10000) не должна спамить в лог на каждый запрос:
// печатаем развёрнутую подсказку не чаще одного раза в 5 минут.
let _d1AuthFailLoggedAt = 0;

// Дедуп ЛЮБЫХ D1-ошибок: каждая уникальная (code+message) печатается максимум
// раз в 5 минут. Раньше «no such table: agent_jobs» спамил десятки строк за
// минуту и топил полезные логи релея.
const _d1ErrLoggedAt = new Map();
const D1_ERR_DEDUPE_MS = 5 * 60 * 1000;

async function rawQueryD1(sql, params = []) {
  const postData = JSON.stringify({ sql, params });
  const response = await fetch(CLOUDFLARE_D1_CONFIG.endpoint, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${CLOUDFLARE_D1_CONFIG.authToken}`,
      'Content-Type': 'application/json'
    },
    body: postData
  });
  const data = await response.json();
  if (!data.success) {
    const errs = Array.isArray(data.errors) ? data.errors : [{ code: 0, message: 'Unknown D1 error' }];
    const authFail = errs.some(e => e && e.code === 10000);
    const now = Date.now();
    if (!(authFail && now - _d1AuthFailLoggedAt < 5 * 60 * 1000)) {
      const key = errs.map(e => `${e && e.code}:${e && e.message}`).join('|');
      if (!(now - (_d1ErrLoggedAt.get(key) || 0) < D1_ERR_DEDUPE_MS)) {
        _d1ErrLoggedAt.set(key, now);
        console.error('[D1 Error]', errs);
        if (authFail) {
          console.error('[D1] AUTH FAILED (code 10000): Cloudflare API token невалиден/протух — БД недоступна, работает memory-only режим.');
          console.error('[D1] Фикс: Render Dashboard → fluxcontrol-backend-bl3u → Environment → CF_D1_TOKEN = новый токен (Account → D1 → Edit) → Save Changes (редеплой автоматом).');
          console.error('[D1] Данные в D1 НЕ потеряны — вернутся в кэш после первого успешного sync (до 30с).');
          _d1AuthFailLoggedAt = now;
        }
      }
    }
    const err = new Error(errs[0]?.message || 'D1 query failed');
    err.code = errs[0]?.code;
    throw err;
  }
  return data.result?.[0]?.results || [];
}

async function queryD1(sql, params = []) {
  try {
    return await rawQueryD1(sql, params);
  } catch (e) {
    return [];
  }
}

// ================= ПРОВЕРКА ПРАВА ЗАПИСИ (read-only токен) =================
// Симптом, из-за которого всё началось: SELECT работает, но CREATE TABLE /
// INSERT / UPDATE падают с { code: 7500, message: 'You do not have permission
// to perform this operation.' } / 'not authorized: SQLITE_AUTH'. Токен валиден,
// но у него только D1:Read. Сервер живёт на in-memory кэше, но все записи
// (регистрация ПК, активация ключей, agent_jobs, share_tokens) молча теряются.
// Пробуем запись на старте и раз в 10 минут (если юзер поменял токен —
// подхватится без правки кода), при провале печатаем ГРОМКУЮ инструкцию ОДИН раз.
let d1WriteOk = null;          // null = ещё не проверяли
let _d1WriteProbeAt = 0;
let _d1WriteFailAnnounced = false;
const D1_WRITE_PROBE_EVERY_MS = 10 * 60 * 1000;

async function probeD1Write(force = false) {
  if (!force && d1WriteOk === true) return true;
  if (!force && d1WriteOk === false && Date.now() - _d1WriteProbeAt < D1_WRITE_PROBE_EVERY_MS) return false;
  _d1WriteProbeAt = Date.now();
  try {
    await rawQueryD1('CREATE TABLE IF NOT EXISTS _fc_rw_probe (id INTEGER PRIMARY KEY, ts INTEGER);');
    if (d1WriteOk !== true) console.log('[D1] Write check: OK — токен может создавать/писать таблицы.');
    d1WriteOk = true;
    _d1WriteFailAnnounced = false;
    return true;
  } catch (e) {
    d1WriteOk = false;
    if (!_d1WriteFailAnnounced) {
      _d1WriteFailAnnounced = true;
      console.error('[D1] ============================================================');
      console.error('[D1] !! ТOКЕН D1 БЕЗ ПРАВА ЗАПИСУ — работает MEMORY-ONLY режим !!');
      console.error(`[D1] Причина: ${e.message} (код ${e.code || '?'})`);
      console.error('[D1] Что сломано: записи в D1 не сохраняются (регистрация ПК,');
      console.error('[D1] активация ключей, agent_jobs, share_tokens). Чтение — работает.');
      console.error('[D1] ФИКС (2 минуты):');
      console.error('[D1]   1. dash.cloudflare.com → My Profile → API Tokens → Create Token');
      console.error('[D1]   2. Custom Token → Permissions: Account → D1 → EDIT (не Read!)');
      console.error('[D1]   3. Render Dashboard → fluxcontrol-backend-bl3u → Environment →');
      console.error('[D1]      CF_D1_TOKEN = новый токен → Save Changes.');
      console.error('[D1] Таблицы (agent_jobs и др.) создадутся автоматически при первом');
      console.error('[D1] успешном старте, либо залей FluxControl.Server/d1-migration.sql');
      console.error('[D1] через Cloudflare Dashboard → D1 → Console.');
      console.error('[D1] ============================================================');
    }
    return false;
  }
}
probeD1Write();
setInterval(() => probeD1Write(true), D1_WRITE_PROBE_EVERY_MS).unref();

// In-memory fast cache
const usersDb = new Map();
const computersDb = new Map();
const userComputersDb = new Map();
// Персональні назви ПК (custom_name). Ключ `${userId}||${computerId}`.
// БЕЗ ЦЬОГО була публічна помилка: користувач перейменовував ПК, за секунди
// назва поверталася — GET /api/devices віддавав hostname з таблиці computers,
// який агент перезаписує при кожному heartbeat/register, а custom_name з
// users_computers не застосовувався. Тепер custom_name ПЕРЕМОЖЄ hostname.
const userCustomNames = new Map();
const licenseKeysDb = new Map();
const authSessionsDb = new Map();
const webClients = new Map();
const _unreachLogAt = new Map(); // тротлінг «AGENT NOT REACHABLE» у логах
const AGENT_HEARTBEAT_INTERVAL_MS = 4000;
const AGENT_STALE_AFTER_MS = 12000;

// Персональна назва ПК (custom_name) з кешу або D1.
async function getCustomName(userId, computerId) {
  const key = `${userId}||${computerId}`;
  if (userCustomNames.has(key)) return userCustomNames.get(key);
  let name = null;
  try {
    const nm = await queryD1(`SELECT custom_name FROM users_computers WHERE user_id = ? AND computer_id = ? LIMIT 1;`, [userId, computerId]);
    name = nm?.[0]?.custom_name || null;
  } catch {}
  userCustomNames.set(key, name);
  return name;
}

// SECURITY FIX: admin-ендпоінти приймають ЛИШЕ справжню Bearer-сесію з роллю
// admin. Раніше: відсутній заголовок x-fc-user-id = «пропусти» (байпас!), сам
// заголовок підроблявся одним рядком у DevTools, підстроки email давали адмінку.
function adminGuard(req, res) {
  if (!authCore.hasAdminSession(req, usersDb)) {
    res.status(403).json({ success: false, error: 'Тільки для адміністраторів. Увійдіть заново (сесія відсутня або не адмінська).' });
    return false;
  }
  return true;
}

/**
 * Перевірка власності на пристрій: запитуваний userId мусить збігатися з
 * автентифікованим користувачем.
 *   • write (link/delete/rename/активація ключа) — ЛИШЕ перевірювана Bearer-сесія;
 *     legacy-заголовок x-fc-user-id підробляється, тому запис ним НЕ приймається.
 *   • read (список пристроїв, профіль) — legacy-заголовок ще приймається для
 *     НЕоновленого веб-клієнта (сумісність на час деплою).
 *   • admin-сесія може все.
 */
function authorizeDeviceAccess(req, res, requestedUserId, { write = false } = {}) {
  const auth = authCore.authenticate(req, usersDb);
  if (!auth) {
    res.status(401).json({ success: false, error: 'Потрібна авторизація: перезайдіть у акаунт' });
    return null;
  }
  if (write && auth.via !== 'session') {
    res.status(401).json({ success: false, error: 'Зміни — лише через сесійний вхід. Перезайдіть у акаунт (оновіть сторінку).' });
    return null;
  }
  const requested = String(requestedUserId || '').trim();
  const sameUser = requested && requested === String(auth.user.id);
  const adminSession = auth.via === 'session' && auth.user.role === 'admin';
  if (!sameUser && !adminSession) {
    res.status(403).json({ success: false, error: 'Немає доступу до пристроїв іншого користувача' });
    return null;
  }
  return auth;
}

// Runtime reachability belongs to the relay, not D1. D1 contains device
// metadata and survives restarts, but it cannot know whether an agent socket
// is answering right now.
function isComputerOnline(comp, now = Date.now()) {
  return Boolean(comp && now - Number(comp.lastSeen || 0) <= AGENT_STALE_AFTER_MS);
}

function uniqueComputers() {
  return Array.from(new Set(computersDb.values()));
}

// Адаптери зберігаються в D1 як JSON-строка, у пам'яті — як масив об'єктів.
function parseAdapters(raw) {
  if (!raw) return null;
  if (Array.isArray(raw)) return raw;
  try { const v = JSON.parse(raw); return Array.isArray(v) ? v : null; } catch { return null; }
}

// Helper to generate key: FC-XXXX-XXXX-XXXX-XXXX
function generateLicenseKeyCode() {
  const chars = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';
  const getChunk = (len) => {
    let res = '';
    for (let i = 0; i < len; i++) {
      res += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return res;
  };
  return `FC-${getChunk(4)}-${getChunk(4)}-${getChunk(4)}-${getChunk(4)}`;
}

// Convert duration string to milliseconds
function getDurationMs(type) {
  switch (type) {
    case '1m': return 60 * 1000;
    case '5m': return 5 * 60 * 1000;
    case '1h': return 60 * 60 * 1000;
    case '1d': return 24 * 60 * 60 * 1000;
    case '7d': return 7 * 24 * 60 * 60 * 1000;
    case '30d': return 30 * 24 * 60 * 60 * 1000;
    case '90d': return 90 * 24 * 60 * 60 * 1000;
    case '1y': return 365 * 24 * 60 * 60 * 1000;
    case 'lifetime': return 0;
    default: return 30 * 24 * 60 * 60 * 1000;
  }
}

// Initialize and sync cache from Cloudflare D1
async function syncFromCloudflareD1() {
  console.log('[D1] Syncing cache from Cloudflare D1 Database...');
  try {
    const users = await queryD1('SELECT * FROM users;');
    for (const u of users) {
      usersDb.set(u.id, {
        id: u.id,
        email: u.email,
        name: u.name,
        picture: u.picture,
        role: u.role || 'user',
        subscriptionExpiresAt: u.subscription_expires_at,
        // access_enabled: 1 = повний доступ, 0 = заблокований (нові акаунти).
        // undefined/null у старих записах трактується як доступ відкрито.
        accessEnabled: u.access_enabled === 0 ? false : true,
        createdAt: u.created_at
      });
    }

    const keys = await queryD1('SELECT * FROM license_keys;');
    for (const k of keys) {
      const keyObj = {
        id: k.id,
        keyCode: k.key,
        key: k.key,
        durationType: k.type,
        durationMs: k.duration_ms,
        createdAt: k.created_at,
        expiresAt: k.expires_at,
        isUsed: Boolean(k.used),
        used: Boolean(k.used),
        usedBy: k.used_by_user_id,
        usedByEmail: k.used_by_user_name,
        usedAt: k.used_at
      };
      licenseKeysDb.set(k.id, keyObj);
      licenseKeysDb.set(k.key, keyObj);
    }

    const comps = await queryD1('SELECT * FROM computers;');
    for (const c of comps) {
      // Mutate an existing live record instead of replacing it. Replacing this
      // object used to discard agentWs/lastSeen every 30 seconds while the
      // original WebSocket closure kept forwarding commands.
      const compObj = computersDb.get(c.id) || computersDb.get(c.hwid) || computersDb.get(c.code) || {};
      Object.assign(compObj, {
        id: c.id,
        hwid: c.hwid || c.id,
        code: c.code,
        connection_code: c.code,
        name: c.name,
        os: c.os_info,
        cpu: c.cpu_info,
        gpu: c.gpu,
        ram: c.ram_info,
        activeUrl: c.active_url,
        localUrl: c.local_url,
        // Остання відома локальна IP + адаптери (JSON). Wake-on-LAN видалено.
        localIp: c.local_ip || compObj.localIp || '',
        adapters: parseAdapters(c.adapters) || compObj.adapters || null,
        status: c.status || 'offline',
        // A current socket's heartbeat is always newer and authoritative.
        lastSeen: compObj.lastSeen || (c.last_seen ? new Date(c.last_seen).getTime() : 0),
        isOnline: isComputerOnline(compObj)
      });
      computersDb.set(c.id, compObj);
      if (c.code) computersDb.set(c.code, compObj);
    }

    const links = await queryD1('SELECT * FROM users_computers;');
    for (const l of links) {
      const userList = userComputersDb.get(l.user_id) || [];
      if (!userList.includes(l.computer_id)) {
        userList.push(l.computer_id);
      }
      userComputersDb.set(l.user_id, userList);
    }

    console.log(`[D1] Cache primed: ${users.length} users, ${keys.length} keys, ${comps.length} computers.`);
  } catch (e) {
    console.error('[D1] Sync error:', e.message);
  }
}

// Background sync every 30 seconds
setInterval(syncFromCloudflareD1, 30000);
syncFromCloudflareD1();

// Wake-on-LAN: гарантуємо колонки в старих БД (best-effort — повторний
// ALTER на колонці, що вже існує, D1 відхилить і queryD1 поверне []).
// GATE:ALTER-и має сенс пробувати лише коли токен вміє писати — інакше
// три permission-помилки на кожен старт.
(async () => {
  if (!(await probeD1Write())) return;
  for (const col of ['local_ip TEXT', 'adapters TEXT', 'wol_mac TEXT']) {
    try { await queryD1(`ALTER TABLE computers ADD COLUMN ${col};`); } catch {}
  }
})();

app.get('/', (req, res) => {
  res.json({
    service: 'FluxControl Relay Backend',
    status: 'online',
    version: '5.7.0',
    ai: true,
    database: 'Cloudflare D1 SQL (fluxcontrol)',
    users: usersDb.size,
    computers: computersDb.size,
    keys: licenseKeysDb.size,
    uptime: Math.floor(process.uptime())
  });
});

app.get('/health', (req, res) => res.status(200).send('OK'));

// ==========================================
// 1.5 ПРОКСІ ОНОВЛЕНЬ /update/* (фікс мереж, де ISP ламає DNS для *.pages.dev:
// «запрошенное имя верно, но запрошенного типа не найдено» — у браузері сайт є,
// а прямі запити з агента/деплою падають). Віддає ТОЙ САМИЙ статичний контент,
// що й сайт: version.json, versions.json, FluxControl.exe, UI, assets.
// Захист від HTML-заглушок: якщо Pages віддав HTML на запит не-HTML ассета — 502.
// ==========================================
const UPDATE_PROXY_UPSTREAM = 'https://fluxcontrol.pages.dev';

app.use('/update', async (req, res) => {
  try {
    const rel = String(req.path || '').replace(/^\/+/, '');
    if (!rel) return res.status(404).json({ ok: false, error: 'empty update path' });
    if (rel.includes('..')) return res.status(400).json({ ok: false, error: 'bad update path' });
    const upstream = UPDATE_PROXY_UPSTREAM + '/' + rel;
    const bust = upstream + (upstream.includes('?') ? '&' : '?') + 't=' + Date.now();
    const upstreamRes = await fetch(bust, {
      redirect: 'follow',
      headers: { 'user-agent': 'FluxControl-UpdateProxy/1.0', 'accept': '*/*' },
      signal: AbortSignal.timeout(30000)
    });
    if (!upstreamRes.ok) {
      const code = upstreamRes.status === 404 ? 404 : 502;
      return res.status(code).json({ ok: false, error: 'upstream ' + upstreamRes.status });
    }
    const ct = String(upstreamRes.headers.get('content-type') || '').toLowerCase();
    const isHtmlAsset = /\.html?$/i.test(rel);
    if (ct.includes('text/html') && !isHtmlAsset) {
      // Pages віддав SPA-заглушку замість ассета — не пропускаємо такий контент
      return res.status(502).json({ ok: false, error: 'html stub instead of asset' });
    }
    const buf = Buffer.from(await upstreamRes.arrayBuffer());
    res.set('Access-Control-Allow-Origin', '*');
    res.set('Cache-Control', 'no-store');
    if (ct) res.set('Content-Type', ct);
    return res.status(200).send(buf);
  } catch (e) {
    return res.status(502).json({ ok: false, error: 'proxy failed: ' + ((e && e.message) || 'unknown') });
  }
});

// 1. Auth Endpoint: Google & Email login (GET & POST)
app.get(['/api/auth/profile', '/api/auth/google'], async (req, res) => {
  const userId = req.query.id || req.query.userId;
  const email = (req.query.email || '').trim().toLowerCase();

  let user = null;
  if (userId) user = usersDb.get(userId);
  if (!user && email) {
    for (const u of usersDb.values()) {
      if (u.email === email) {
        user = u;
        break;
      }
    }
  }

  if (!user && (userId || email)) {
    const rows = await queryD1('SELECT * FROM users WHERE id = ? OR email = ? LIMIT 1;', [userId || '', email || '']);
    if (rows && rows.length > 0) {
      const u = rows[0];
      user = {
        id: u.id,
        uid: u.id,
        email: u.email,
        name: u.name,
        displayName: u.name,
        picture: u.picture,
        photoURL: u.picture,
        role: u.role || 'user',
        subscriptionExpiresAt: u.subscription_expires_at,
        accessEnabled: u.access_enabled === 0 ? false : true,
        createdAt: u.created_at
      };
      usersDb.set(u.id, user);
    }
  }

  if (!user) {
    return res.status(404).json({ success: false, error: 'User not found' });
  }

  // SECURITY FIX: профіль (email/ім'я/роль) віддаємо лише самому користувачу
  // або адміну. Раніше будь-хто читав чужі акаунти за id/email.
  if (!authorizeDeviceAccess(req, res, user.id)) return;

  res.json({ success: true, user });
});

app.post(['/api/auth/google', '/api/auth/profile'], async (req, res) => {
  const body = req.body || {};
  const u = body.user || body;
  const uid = String(u.sub || u.id || u.uid || '').trim();
  const email = String(u.email || '').trim().toLowerCase();

  if (!uid && !email) {
    return res.status(400).json({ error: 'User ID or Email missing' });
  }

  const finalId = uid || `usr_${Buffer.from(email).toString('hex').slice(0, 16)}`;
  let existingUser = usersDb.get(finalId);

  if (!existingUser && email) {
    for (const usr of usersDb.values()) {
      if (usr.email === email) {
        existingUser = usr;
        break;
      }
    }
  }

  // SECURITY FIX: роль призначає ТІЛЬКИ сервер. Тіло запиту (u.role) ігнорується,
  // підстроки email більше НЕ дають адмінку. Правила: збережена роль існуючого
  // акаунта → ADMIN_EMAILS (env, точний збіг) → bootstrap «перший без адмінів».
  // Самозанесення себе в адміни з клієнта більше неможливе.
  const assigned = authCore.resolveRoleForLogin({ email, existingUser, usersDb });
  const role = assigned.role;
  if (assigned.reason !== 'existing') {
    console.log(`[AUTH] Role assigned server-side for ${email || finalId}: ${role} (${assigned.reason})`);
  }
  const subscriptionExpiresAt = role === 'admin' 
    ? -1 
    : (existingUser?.subscriptionExpiresAt !== undefined && existingUser?.subscriptionExpiresAt !== null
        ? existingUser.subscriptionExpiresAt 
        : null);

  // НОВІ акаунти починають заблокованими: функціонал сайту відкривається
  // адміністратором або активацією ключа доступу. Існуючі користувачі
  // (existingUser) зберігають свій попередній стан.
  const accessEnabled = existingUser
    ? (existingUser.accessEnabled !== false)
    : (role === 'admin' ? true : false);

  const userData = {
    id: existingUser ? existingUser.id : finalId,
    uid: existingUser ? existingUser.id : finalId,
    email: email || (existingUser ? existingUser.email : ''),
    name: u.name || u.displayName || (existingUser ? existingUser.name : (email ? email.split('@')[0] : 'Користувач')),
    displayName: u.name || u.displayName || (existingUser ? existingUser.name : 'Користувач'),
    picture: u.picture || u.photoURL || (existingUser ? existingUser.picture : ''),
    photoURL: u.picture || u.photoURL || (existingUser ? existingUser.picture : ''),
    role,
    subscriptionExpiresAt,
    accessEnabled,
    updatedAt: Date.now(),
    createdAt: existingUser ? existingUser.createdAt : Date.now()
  };

  usersDb.set(userData.id, userData);

  // Write to Cloudflare D1 (access_enabled оновлюємо лише для нових записів,
  // щоб повторні логіни не перетирали рішення адміністратора). РОЛЬ у D1
  // НЕ перезаписуємо значенням із запиту — лише коли в БД її ще не було.
  queryD1(`
    INSERT INTO users (id, email, name, picture, role, subscription_expires_at, access_enabled)
    VALUES (?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(id) DO UPDATE SET
      email=excluded.email,
      name=excluded.name,
      picture=excluded.picture,
      role=COALESCE(users.role, excluded.role),
      subscription_expires_at=COALESCE(users.subscription_expires_at, excluded.subscription_expires_at);
  `, [userData.id, userData.email, userData.name, userData.picture, userData.role, userData.subscriptionExpiresAt, userData.accessEnabled ? 1 : 0]);

  // SECURITY FIX: видаємо сесійний токен. Далі КЛІЄНТ доводить себе Bearer-заголовком,
  // а не підроблюваним x-fc-user-id. Токен живе 30 днів (sliding).
  const sessionToken = authCore.createSession(userData.id);

  console.log(`[AUTH] User verified: ${userData.email || userData.id} (Role: ${userData.role})`);
  res.json({ success: true, user: userData, sessionToken });
});

// 2. Register Computer from Desktop Agent
app.post(['/api/register', '/api/agent/register'], async (req, res) => {
  const body = req.body || {};
  const hwid = String(body.hwid || body.id || '').trim();
  const code = String(body.code || '').replace(/[^A-Za-z0-9]/g, '').trim().toUpperCase();
  const name = String(body.name || body.machineName || 'Мій ПК').trim();
  const username = String(body.username || '').trim();
  const os = String(body.os || body.osInfo || 'Windows').trim();
  const cpu = String(body.cpu || body.cpuInfo || 'CPU').trim();
  const ram = String(body.ram || body.ramInfo || '').trim();
  const gpu = String(body.gpu || body.gpuInfo || '').trim();
  const localUrl = String(body.localUrl || '').trim();
  const activeUrl = String(body.activeUrl || body.publicUrl || '').trim();
  const localIp = String(body.localIp || '').trim();
  // Wake-on-LAN: агент надсилає список мережевих адаптерів при кожній реєстрації.
  let adaptersArr = null;
  if (Array.isArray(body.adapters)) {
    adaptersArr = body.adapters.slice(0, 12).map((a) => ({
      name: String(a?.name || '').slice(0, 64),
      description: String(a?.description || '').slice(0, 128),
      type: String(a?.type || '').slice(0, 24),
      mac: String(a?.mac || '').slice(0, 20),
      ip: String(a?.ip || '').slice(0, 45),
      hasGateway: Boolean(a?.hasGateway)
    })).filter((a) => a.mac);
  }

  if (!hwid && !code) {
    return res.status(400).json({ error: 'HWID or code required' });
  }

  const primaryKey = hwid || `hwid_${code}`;
  const existing = computersDb.get(primaryKey) || {};

  const compData = existing;
  Object.assign(compData, {
    id: primaryKey,
    hwid: primaryKey,
    connection_code: code || existing.connection_code,
    code: code || existing.code,
    name: name || existing.name,
    username: username || existing.username,
    os: os || existing.os,
    cpu: cpu || existing.cpu,
    ram: ram || existing.ram,
    gpu: gpu || existing.gpu,
    localUrl: localUrl || existing.localUrl,
    localIp: localIp || existing.localIp || '',
    adapters: adaptersArr || (Array.isArray(existing.adapters) ? existing.adapters : null),
    activeUrl: activeUrl || existing.activeUrl,
    lastSeen: Date.now(),
    isOnline: isComputerOnline(existing)
  });

  computersDb.set(primaryKey, compData);
  if (code) {
    computersDb.set(code, compData);
  }

  // Save to Cloudflare D1 (wol_mac НЕ перезаписуємо — його задає користувач на сайті)
  const adaptersJson = adaptersArr
    ? JSON.stringify(adaptersArr)
    : (Array.isArray(existing.adapters) ? JSON.stringify(existing.adapters) : null);
  queryD1(`
    INSERT INTO computers (id, hwid, code, name, os_info, cpu_info, gpu, ram_info, status, active_url, local_url, last_seen, local_ip, adapters)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'online', ?, ?, CURRENT_TIMESTAMP, ?, ?)
    ON CONFLICT(id) DO UPDATE SET
      code=excluded.code,
      name=excluded.name,
      os_info=excluded.os_info,
      cpu_info=excluded.cpu_info,
      gpu=excluded.gpu,
      ram_info=excluded.ram_info,
      status='online',
      active_url=excluded.active_url,
      local_url=excluded.local_url,
      last_seen=CURRENT_TIMESTAMP,
      local_ip=excluded.local_ip,
      adapters=excluded.adapters;
  `, [compData.hwid, compData.hwid, compData.code, compData.name, compData.os, compData.cpu, compData.gpu, compData.ram, compData.activeUrl, compData.localUrl, compData.localIp || null, adaptersJson]);

  res.json({ success: true, hwid: primaryKey, code });
});

// ==================== Wake-on-LAN (ВИДАЛЕНО) ====================
// ТЗ: функцію Wake-on-LAN прибрано з проєкту — на сайті більше немає
// ні кнопок пробудження, ні налаштувань MAC, тож /api/wol* ендпоінти
// знято. Агентський обробник wol_send лишається, але ніхто не надсилає.

// КРОС-ІЗОЛЯТНІ ЗАВДАННЯ (WoL-донор, share-стрім): D1 як черга.
// Якщо токен без права запису (d1WriteOk === false) — черга ЖИВЕ В ПАМ'ЯТІ:
// на Render один інстанс, тому memory-черга повністю функціональна, а спам
// «no such table: agent_jobs» у логах зникає.
const agentJobsMem = new Map(); // job_id → { job_id, hwid, type, payload, status, result, created_at }

function jobEnqueueMem(jobId, hwid, type, payload) {
  agentJobsMem.set(jobId, { job_id: jobId, hwid, type, payload, status: 'new', result: null, created_at: Date.now() });
  return jobId;
}

async function jobEnqueue(jobId, hwid, type, payload) {
  if (await probeD1Write()) {
    try {
      await queryD1(`INSERT INTO agent_jobs (job_id, hwid, type, payload, status, created_at)
        VALUES (?, ?, ?, ?, 'new', ?);`, [jobId, hwid, type, JSON.stringify(payload), Date.now()]);
      return jobId;
    } catch { /* впали у memory-fallback */ }
  }
  return jobEnqueueMem(jobId, hwid, type, payload);
}

async function jobStatus(jobId) {
  const mem = agentJobsMem.get(jobId);
  if (mem) return { status: mem.status, result: mem.result };
  try {
    const rows = await queryD1(`SELECT status, result FROM agent_jobs WHERE job_id = ?;`, [jobId]);
    return rows && rows[0] ? { status: rows[0].status, result: rows[0].result } : null;
  } catch { return null; }
}

async function jobDone(jobId, resultObj) {
  const mem = agentJobsMem.get(jobId);
  if (mem) { mem.status = 'done'; mem.result = JSON.stringify(resultObj); return; }
  try { await queryD1(`UPDATE agent_jobs SET status = 'done', result = ? WHERE job_id = ?;`, [JSON.stringify(resultObj), jobId]); } catch {}
}

async function jobClaimFor(hwid) {
  const now = Date.now();
  const memJobs = [];
  for (const [id, j] of agentJobsMem) {
    if (j.hwid === hwid && j.status === 'new') {
      j.status = 'claimed';
      memJobs.push({ job_id: id, type: j.type, payload: j.payload });
    } else if (j.status === 'done' && now - (j.doneAt || j.created_at) > 10 * 60 * 1000) {
      agentJobsMem.delete(id); // прибираємо сміття з пам'яті
    }
  }
  if (!(await probeD1Write())) return memJobs;
  try {
    const rows = await queryD1(`SELECT job_id, type, payload FROM agent_jobs WHERE hwid = ? AND status = 'new' ORDER BY created_at LIMIT 5;`, [hwid]);
    for (const j of (rows || [])) {
      try { await queryD1(`UPDATE agent_jobs SET status = 'claimed' WHERE job_id = ?;`, [j.job_id]); } catch {}
      memJobs.push(j);
    }
  } catch {}
  return memJobs;
}

async function jobCleanup(jobId) {
  agentJobsMem.delete(jobId);
  try { await queryD1(`DELETE FROM agent_jobs WHERE job_id = ?;`, [jobId]); } catch {}
}

// Крос-ізолятні завдання агенту (ТЗ 45): WoL-донор / стрім «Поділитися».
app.get('/api/agent/jobs', async (req, res) => {
  const hwid = String(req.query.hwid || '').trim();
  if (!hwid) return res.json({ success: true, jobs: [] });
  try {
    const jobs = await jobClaimFor(hwid);
    res.json({ success: true, jobs });
  } catch (e) {
    res.json({ success: true, jobs: [] });
  }
});

app.post('/api/agent/jobs/result', async (req, res) => {
  const body = req.body || {};
  const jobId = String(body.jobId || '').trim();
  if (!jobId) return res.status(400).json({ success: false, message: 'jobId required' });
  try {
    await jobDone(jobId, { ok: Boolean(body.ok), message: String(body.message || '') });
    res.json({ success: true });
  } catch (e) {
    res.status(502).json({ success: false });
  }
});

// 3. Verify 16-character connection code
app.get('/api/devices/verify-code', async (req, res) => {
  const rawCode = String(req.query.code || '').replace(/[^A-Za-z0-9]/g, '').trim().toUpperCase();
  if (!rawCode) {
    return res.status(400).json({ success: false, message: 'Введіть код підключення' });
  }

  let found = computersDb.get(rawCode);
  if (!found) {
    for (const comp of computersDb.values()) {
      const c1 = String(comp.connection_code || '').toUpperCase();
      const c2 = String(comp.code || '').toUpperCase();
      const c3 = String(comp.hwid || '').toUpperCase();
      if (c1 === rawCode || c2 === rawCode || c3 === rawCode) {
        found = comp;
        break;
      }
    }
  }

  // If not in cache, check Cloudflare D1 directly
  if (!found) {
    const rows = await queryD1(`SELECT * FROM computers WHERE code = ? OR hwid = ? OR id = ?;`, [rawCode, rawCode, rawCode]);
    if (rows && rows.length > 0) {
      const c = rows[0];
      found = {
        id: c.id,
        hwid: c.hwid || c.id,
        code: c.code,
        connection_code: c.code,
        name: c.name,
        os: c.os_info,
        cpu: c.cpu_info,
        gpu: c.gpu,
        ram: c.ram_info,
        activeUrl: c.active_url,
        localUrl: c.local_url,
        status: c.status || 'offline',
        lastSeen: c.last_seen ? new Date(c.last_seen).getTime() : 0,
        isOnline: false
      };
      computersDb.set(c.id, found);
      if (c.code) computersDb.set(c.code, found);
    }
  }

  if (!found) {
    return res.status(404).json({
      success: false,
      message: 'Комп\'ютер з таким кодом не знайдено в базі даних'
    });
  }

  const isOnline = isComputerOnline(found);

  res.json({
    success: true,
    data: {
      hwid: found.hwid || rawCode,
      code: found.connection_code || found.code || rawCode,
      name: found.name || 'Мій ПК',
      os: found.os || 'Windows',
      cpu: found.cpu || 'Невідомий процесор',
      gpu: found.gpu || 'Невідома відеокарта',
      ram: found.ram || '8 GB',
      isOnline
    }
  });
});

// 4. Link Computer to User
app.post(['/api/user/computers/link', '/api/devices'], async (req, res) => {
  const { userId, hwid, code, computerId, connectionCode, customName, name } = req.body || {};
  const finalUserId = userId;
  const targetId = hwid || computerId || code || connectionCode;
  const finalName = customName || name;

  if (!finalUserId || !targetId) {
    return res.status(400).json({ success: false, message: 'User ID and HWID/Code required' });
  }

  // SECURITY FIX: прив’язати можна ЛИШЕ до себе (сесія), адмін — до когось.
  if (!authorizeDeviceAccess(req, res, finalUserId, { write: true })) return;

  // Заблокований акаунт (нові користувачі без доступу) не може прив'язувати ПК.
  let linkUser = usersDb.get(finalUserId);
  if (linkUser && linkUser.accessEnabled === false) {
    return res.status(403).json({ success: false, message: 'Функціонал заблоковано: зверніться до адміністратора, щоб отримати доступ' });
  }

  const list = userComputersDb.get(finalUserId) || [];
  if (!list.includes(targetId)) {
    list.push(targetId);
    userComputersDb.set(finalUserId, list);
  }

  // Персональна назва одразу в кеш — GET /api/devices віддає її миттєво.
  userCustomNames.set(`${finalUserId}||${targetId}`, finalName || null);

  // Save to Cloudflare D1 (safe upsert: read-then-write, works without UNIQUE constraints)
  (async () => {
    try {
      const existing = await queryD1(
        `SELECT rowid FROM users_computers WHERE user_id = ? AND computer_id = ? LIMIT 1;`,
        [finalUserId, targetId]
      );
      if (existing && existing.length > 0) {
        await queryD1(
          `UPDATE users_computers SET custom_name = ? WHERE user_id = ? AND computer_id = ?;`,
          [finalName || null, finalUserId, targetId]
        );
      } else {
        await queryD1(
          `INSERT INTO users_computers (user_id, computer_id, custom_name) VALUES (?, ?, ?);`,
          [finalUserId, targetId, finalName || null]
        );
      }
    } catch (e) {
      console.error('[D1] Link computer error:', e.message);
    }
  })();

  res.json({ success: true, message: 'Пристрій успішно додано до вашого акаунту' });
});

// 4.1 Get User Computers
app.get(['/api/user/computers', '/api/devices'], async (req, res) => {
  const userId = req.query.userId;
  if (!userId) return res.status(400).json({ error: 'Missing userId' });

  // SECURITY FIX: чужий список пристроїв більше не віддається «за бажанням».
  // Сесія/свій legacy-заголовок обов’язкові; admin-сесія може дивитись усіх.
  if (!authorizeDeviceAccess(req, res, userId)) return;

  let compIds = userComputersDb.get(userId) || [];
  // Always refresh the link list straight from D1 so nothing is lost between restarts
  try {
    const rows = await queryD1(`SELECT computer_id FROM users_computers WHERE user_id = ?;`, [userId]);
    if (rows && rows.length > 0) {
      const d1Ids = rows.map(r => r.computer_id);
      compIds = Array.from(new Set([...d1Ids, ...compIds]));
      userComputersDb.set(userId, d1Ids);
    }
  } catch {}

  const result = [];
  for (const cid of compIds) {
    let comp = computersDb.get(cid);
    if (!comp) {
      const rows = await queryD1(`SELECT * FROM computers WHERE id = ? OR hwid = ? OR code = ?;`, [cid, cid, cid]);
      if (rows && rows.length > 0) {
        const c = rows[0];
        comp = {
          id: c.id,
          hwid: c.hwid || c.id,
          code: c.code,
          name: c.name,
          os: c.os_info,
          cpu: c.cpu_info,
          gpu: c.gpu,
          ram: c.ram_info,
          username: c.username || 'Адміністратор',
          lastSeen: c.last_seen ? new Date(c.last_seen).getTime() : 0,
          isOnline: false
        };
      }
    }
    if (!comp) {
      // Linked, but the computer row is not in DB yet — still show the device
      let customName = null;
      try {
        const nm = await queryD1(`SELECT custom_name FROM users_computers WHERE user_id = ? AND computer_id = ? LIMIT 1;`, [userId, cid]);
        customName = nm?.[0]?.custom_name || null;
      } catch {}
      result.push({
        id: cid,
        hwid: cid,
        code: cid,
        name: customName || 'Мій ПК',
        os: 'Windows',
        osInfo: 'Windows',
        cpu: '',
        cpuInfo: '',
        gpu: '',
        gpuInfo: '',
        ram: '',
        ramInfo: '',
        username: 'Адміністратор',
        lastSeen: 0,
        isOnline: false
      });
      continue;
    }
    if (comp) {
      const isOnline = isComputerOnline(comp);
      // ФИКС ПЕРЕЙМЕНУВАННЯ: персональна назва користувача ПЕРЕМОЖЄ hostname,
      // який агент перезаписує в таблиці computers при кожному heartbeat.
      // machineName зберігає оригінальне ім'я машини для довідки.
      const custom = await getCustomName(userId, cid);
      result.push({
        ...comp,
        // НЕ серіалізуємо живий сокет у відповідь: WebSocket-об'єкт має
        // циклічні посилання (loader'і ws), що часом валить JSON.stringify
        // і весь GET /api/devices з 500.
        agentWs: undefined,
        lastTelemetry: undefined,
        // «Пряме з'єднання»: URL тунелю віддаємо ЛИШЕ коли агент живий.
        // Тунель живе разом із процесом агента — мертвий агент = мертвий
        // тунель, і панель не має витрачати 6с на спробу підключитись.
        directUrl: isOnline ? (comp.directUrl || null) : null,
        directKey: isOnline ? (comp.directKey || null) : null,
        isOnline,
        machineName: comp.machineName || comp.name,
        name: custom || comp.name,
        username: comp.username || 'Адміністратор',
        osInfo: comp.os,
        cpuInfo: comp.cpu,
        gpuInfo: comp.gpu,
        ramInfo: comp.ram
      });
    }
  }

  // ДЕДУПЛИКАЦІЯ ПРИСТРОЇВ: users_computers могли накопичити і старі коди
  // підключення (код змінюється при кожному старті агента), і hwid — той самий
  // фізичний ПК повертався двічі («два однакові ноутбуки в оффлайні»).
  // Правила: 1) перетин за id/hwid/code → один ПК, лишаємо свіжіший/онлайн;
  // 2) однакова назва + «неживий» дубль → лишаємо запис зі свіжішим lastSeen.
  const seenIdentity = new Map();
  const deduped = [];
  for (const d of result) {
    const norm = (s) => String(s || '').trim().toUpperCase();
    const keys = [norm(d.id), norm(d.hwid), norm(d.code)].filter(Boolean);
    const isOnlineD = Boolean(d.isOnline);
    const fresh = (x) => Number(x.lastSeen || 0);
    const hit = keys.map(k => seenIdentity.get(k)).find(v => v !== undefined);
    if (hit !== undefined) {
      const prev = deduped[hit];
      const preferNew = isOnlineD !== Boolean(prev.isOnline) ? isOnlineD : fresh(d) > fresh(prev);
      if (preferNew) deduped[hit] = d;
      keys.forEach(k => seenIdentity.set(k, hit));
      continue;
    }
    const idx = deduped.push(d) - 1;
    keys.forEach(k => seenIdentity.set(k, idx));
  }

  const FRESH_ONLINE_MS = 15 * 60_000;
  const finalList = [];
  const byName = new Map();
  for (const d of deduped) {
    const nm = String(d.name || '').trim().toUpperCase();
    const live = Boolean(d.isOnline) || (Date.now() - Number(d.lastSeen || 0) < FRESH_ONLINE_MS);
    const prevIdx = nm ? byName.get(nm) : undefined;
    if (prevIdx === undefined) {
      const idx = finalList.push(d) - 1;
      if (nm) byName.set(nm, idx);
      continue;
    }
    const prev = finalList[prevIdx];
    const prevLive = Boolean(prev.isOnline) || (Date.now() - Number(prev.lastSeen || 0) < FRESH_ONLINE_MS);
    if (prevLive && live) finalList.push(d);          // два живі ПК з однаковою назвою
    else if (!prevLive && !live) {
      if (Number(d.lastSeen || 0) > Number(prev.lastSeen || 0)) finalList[prevIdx] = d;
    } else if (!prevLive && live) finalList[prevIdx] = d; // свіжий витісняє привида
  }

  res.json({ success: true, devices: finalList, computers: finalList });
});

// 4.2 Delete User Computer
app.delete('/api/devices', async (req, res) => {
  const { userId, computerId, deviceId } = req.body || {};
  const targetId = computerId || deviceId;
  if (!userId || !targetId) {
    return res.status(400).json({ success: false, message: 'User ID and Computer ID required' });
  }

  // SECURITY FIX: видаляти прив’язку можна лише у себе (адмін — у когось).
  if (!authorizeDeviceAccess(req, res, userId, { write: true })) return;

  const list = userComputersDb.get(userId) || [];
  const updated = list.filter(id => id !== targetId);
  userComputersDb.set(userId, updated);
  userCustomNames.delete(`${userId}||${targetId}`);

  queryD1(`DELETE FROM users_computers WHERE user_id = ? AND (computer_id = ? OR computer_id LIKE ?);`, [userId, targetId, `%${targetId}%`]);
  res.json({ success: true, message: 'Пристрій від\'єднано' });
});

// 4.3 Rename User Computer
app.patch(['/api/devices', '/api/devices/rename'], async (req, res) => {
  const { userId, computerId, deviceId, newName, name, customName } = req.body || {};
  const targetId = computerId || deviceId;
  const targetName = (newName || name || customName || '').trim();

  if (!userId || !targetId || !targetName) {
    return res.status(400).json({ success: false, message: 'User ID, Computer ID, and newName required' });
  }

  // SECURITY FIX: перейменовувати чужий пристрій заборонено.
  if (!authorizeDeviceAccess(req, res, userId, { write: true })) return;

  queryD1(`
    UPDATE users_computers 
    SET custom_name = ? 
    WHERE user_id = ? AND (computer_id = ? OR computer_id LIKE ?);
  `, [targetName, userId, targetId, `%${targetId}%`]);

  // Прописуємо нову назву для ВСІХ можливих ключів (hwid/code/link-id), щоб
  // наступний GET /api/devices віддав її одразу, до відповіді D1.
  userCustomNames.set(`${userId}||${targetId}`, targetName);
  try {
    const rows = await queryD1(`SELECT computer_id FROM users_computers WHERE user_id = ? AND (computer_id = ? OR computer_id LIKE ?);`, [userId, targetId, `%${targetId}%`]);
    for (const r of rows || []) userCustomNames.set(`${userId}||${r.computer_id}`, targetName);
  } catch {}

  const comp = computersDb.get(targetId);
  if (comp) {
    // hostname зберігаємо окремо: machines.json повертає його як machineName,
    // а name лишається персональною назвою користувача.
    comp.machineName = comp.machineName || comp.name;
    comp.name = targetName;
  }

  res.json({ success: true, message: 'Назву оновлено', name: targetName });
});

// ==========================================
// 5. LICENSE KEYS & SUBSCRIPTION API
// ==========================================

// 5.1 Admin: List License Keys
app.get('/api/admin/keys', async (req, res) => {
  if (!adminGuard(req, res)) return;
  const rows = await queryD1('SELECT * FROM license_keys ORDER BY created_at DESC;');
  const keys = rows.map(k => ({
    id: k.id,
    keyCode: k.key,
    key: k.key,
    durationType: k.type,
    durationMs: k.duration_ms,
    createdAt: k.created_at,
    expiresAt: k.expires_at,
    isUsed: Boolean(k.used),
    used: Boolean(k.used),
    usedBy: k.used_by_user_id,
    usedByEmail: k.used_by_user_name,
    usedAt: k.used_at
  }));
  res.json({ success: true, keys });
});

// 5.2 Admin: Generate License Keys
app.post('/api/admin/keys/generate', async (req, res) => {
  if (!adminGuard(req, res)) return;
  const { durationType, count = 1, customLabel } = req.body || {};
  const validTypes = ['1m', '5m', '1h', '1d', '7d', '30d', '90d', '1y', 'lifetime'];
  const type = validTypes.includes(durationType) ? durationType : '30d';
  const durationMs = getDurationMs(type);

  const generated = [];
  for (let i = 0; i < Math.min(Math.max(Number(count) || 1, 1), 50); i++) {
    const keyId = `key_${crypto.randomBytes(8).toString('hex')}`;
    const keyCode = generateLicenseKeyCode();
    const createdAt = Date.now();

    const keyItem = {
      id: keyId,
      keyCode,
      key: keyCode,
      durationType: type,
      durationMs,
      createdAt,
      expiresAt: null,
      isUsed: false,
      used: false,
      usedBy: null,
      usedByEmail: null,
      usedAt: null
    };

    licenseKeysDb.set(keyId, keyItem);
    licenseKeysDb.set(keyCode, keyItem);
    generated.push(keyItem);

    // Insert into Cloudflare D1
    queryD1(`
      INSERT INTO license_keys (id, key, type, duration_ms, created_at, expires_at, used)
      VALUES (?, ?, ?, ?, ?, ?, 0);
    `, [keyId, keyCode, type, durationMs, createdAt, null]);
  }

  res.json({ success: true, count: generated.length, keys: generated });
});

// 5.3 Admin: Delete License Key
app.delete('/api/admin/keys/:id', async (req, res) => {
  if (!adminGuard(req, res)) return;
  const idOrCode = req.params.id;
  licenseKeysDb.delete(idOrCode);
  queryD1(`DELETE FROM license_keys WHERE id = ? OR key = ?;`, [idOrCode, idOrCode]);
  res.json({ success: true });
});

// 5.4 Activate License Key (User)
app.post('/api/license/activate', async (req, res) => {
  const body = req.body || {};
  const userId = String(body.userId || '').trim();
  const rawKey = String(body.keyCode || body.key || '').trim().toUpperCase();

  if (!userId || !rawKey) {
    return res.status(400).json({ success: false, message: 'Вкажіть ID користувача та ліцензійний ключ' });
  }

  // SECURITY FIX: активувати ключ можна лише на СВІЙ акаунт (адмін — на будь-який).
  if (!authorizeDeviceAccess(req, res, userId, { write: true })) return;

  let cleanKey = rawKey.replace(/[^A-Za-z0-9]/g, '');
  let foundKey = licenseKeysDb.get(rawKey);

  if (!foundKey) {
    const rows = await queryD1(`SELECT * FROM license_keys WHERE key = ? OR key = ?;`, [rawKey, `FC-${cleanKey}`]);
    if (rows && rows.length > 0) {
      const k = rows[0];
      foundKey = {
        id: k.id,
        keyCode: k.key,
        key: k.key,
        durationType: k.type,
        durationMs: k.duration_ms,
        createdAt: k.created_at,
        isUsed: Boolean(k.used),
        usedBy: k.used_by_user_id
      };
    }
  }

  if (!foundKey) {
    return res.status(404).json({ success: false, message: 'Ліцензійний ключ не знайдено або він недійсний' });
  }

  if (foundKey.isUsed) {
    return res.status(400).json({ success: false, message: 'Цей ключ вже був активований раніше' });
  }

  let user = usersDb.get(userId);
  if (!user) {
    const uRows = await queryD1(`SELECT * FROM users WHERE id = ?;`, [userId]);
    if (uRows && uRows.length > 0) {
      const u = uRows[0];
      user = {
        id: u.id,
        email: u.email,
        name: u.name,
        role: u.role || 'user',
        subscriptionExpiresAt: u.subscription_expires_at
      };
      usersDb.set(user.id, user);
    }
  }

  if (!user) {
    return res.status(404).json({ success: false, message: 'Користувача не знайдено' });
  }

  const now = Date.now();
  let newExpiresAt = null;

  if (foundKey.durationType === 'lifetime' || foundKey.durationMs === 0) {
    newExpiresAt = -1; // -1 denotes lifetime PRO
  } else {
    const currentExpiry = user.subscriptionExpiresAt && user.subscriptionExpiresAt > now 
      ? user.subscriptionExpiresAt 
      : now;
    newExpiresAt = currentExpiry + foundKey.durationMs;
  }

  foundKey.isUsed = true;
  foundKey.usedBy = user.id;
  foundKey.usedByEmail = user.email || user.name;
  foundKey.usedAt = now;

  licenseKeysDb.set(foundKey.id, foundKey);
  licenseKeysDb.set(foundKey.keyCode, foundKey);

  user.subscriptionExpiresAt = newExpiresAt;
  user.updatedAt = now;
  // Активація ключа = ключ доступу: відкриває функціонал заблокованим акаунтам.
  user.accessEnabled = true;
  usersDb.set(user.id, user);

  // Update in Cloudflare D1
  queryD1(`UPDATE license_keys SET used = 1, used_by_user_id = ?, used_by_user_name = ?, used_at = ? WHERE id = ? OR key = ?;`, [user.id, user.email, now, foundKey.id, foundKey.keyCode]);
  queryD1(`UPDATE users SET subscription_expires_at = ?, access_enabled = 1 WHERE id = ?;`, [newExpiresAt, user.id]);

  console.log(`[KEY] Activated key ${foundKey.keyCode} for ${user.email} until ${newExpiresAt}`);
  res.json({
    success: true,
    message: 'Підписку успішно активовано!',
    user,
    expiresAt: newExpiresAt,
    durationType: foundKey.durationType
  });
});

// 5.5 List Users & Manage Roles (Admin)
app.get('/api/admin/users', async (req, res) => {
  if (!adminGuard(req, res)) return;
  const rows = await queryD1('SELECT * FROM users ORDER BY created_at DESC;');
  const list = rows.map(u => ({
    id: u.id,
    email: u.email,
    name: u.name,
    picture: u.picture,
    role: u.role || 'user',
    subscriptionExpiresAt: u.subscription_expires_at,
    accessEnabled: u.access_enabled === 0 ? false : true,
    createdAt: u.created_at
  }));
  res.json({ success: true, users: list });
});

app.post('/api/admin/users/role', async (req, res) => {
  if (!adminGuard(req, res)) return;
  const { userId, role, subscriptionExpiresAt } = req.body || {};
  if (!userId) return res.status(400).json({ error: 'Missing userId' });

  let user = usersDb.get(userId);
  if (!user) {
    const rows = await queryD1('SELECT * FROM users WHERE id = ?;', [userId]);
    if (rows && rows.length > 0) {
      user = rows[0];
      usersDb.set(userId, user);
    }
  }

  if (!user) return res.status(404).json({ error: 'User not found' });

  if (role) user.role = role;
  if (subscriptionExpiresAt !== undefined) user.subscriptionExpiresAt = subscriptionExpiresAt;
  user.updatedAt = Date.now();

  usersDb.set(user.id, user);
  queryD1(`UPDATE users SET role = ?, subscription_expires_at = ? WHERE id = ?;`, [user.role, user.subscriptionExpiresAt, userId]);

  res.json({ success: true, user });
});

// 5.6 Admin: повне керування користувачем одним запитом.
// Тіло: { userId, role?, accessEnabled?, subscriptionExpiresAt? (ms | -1 lifetime | null забрати), addDays? }
app.post('/api/admin/users/update', async (req, res) => {
  if (!adminGuard(req, res)) return;
  const { userId, role, accessEnabled, subscriptionExpiresAt, addDays, name } = req.body || {};
  if (!userId) return res.status(400).json({ success: false, error: 'Missing userId' });

  let user = usersDb.get(userId);
  if (!user) {
    const rows = await queryD1('SELECT * FROM users WHERE id = ?;', [userId]);
    if (rows && rows.length > 0) {
      const u = rows[0];
      user = {
        id: u.id,
        email: u.email,
        name: u.name,
        picture: u.picture,
        role: u.role || 'user',
        subscriptionExpiresAt: u.subscription_expires_at,
        accessEnabled: u.access_enabled === 0 ? false : true
      };
      usersDb.set(user.id, user);
    }
  }
  if (!user) return res.status(404).json({ success: false, error: 'User not found' });

  if (role === 'admin' || role === 'user') user.role = role;
  if (accessEnabled === true || accessEnabled === false) user.accessEnabled = accessEnabled;
  if (typeof name === 'string' && name.trim()) user.name = name.trim();

  const now = Date.now();
  if (subscriptionExpiresAt !== undefined) {
    user.subscriptionExpiresAt = subscriptionExpiresAt === null ? null : Number(subscriptionExpiresAt);
  }
  if (addDays !== undefined && addDays !== null && Number.isFinite(Number(addDays))) {
    const base = (user.subscriptionExpiresAt && Number(user.subscriptionExpiresAt) > now)
      ? Number(user.subscriptionExpiresAt)
      : now;
    user.subscriptionExpiresAt = Math.round(base + Number(addDays) * 86400000);
  }
  if (user.role === 'admin') user.subscriptionExpiresAt = -1;

  user.updatedAt = now;
  usersDb.set(user.id, user);
  queryD1(`UPDATE users SET role = ?, subscription_expires_at = ?, access_enabled = ?, name = ? WHERE id = ?;`, [
    user.role,
    user.subscriptionExpiresAt === undefined ? null : user.subscriptionExpiresAt,
    user.accessEnabled === false ? 0 : 1,
    user.name,
    user.id
  ]);

  console.log(`[ADMIN] User updated: ${user.email} role=${user.role} access=${user.accessEnabled} sub=${user.subscriptionExpiresAt}`);
  res.json({ success: true, user });
});

// 5.7 Admin: видалити користувача (разом із прив'язками пристроїв)
app.delete('/api/admin/users/:id', async (req, res) => {
  if (!adminGuard(req, res)) return;
  const id = req.params.id;
  const user = usersDb.get(id);
  usersDb.delete(id);
  await queryD1(`DELETE FROM users WHERE id = ?;`, [id]);
  await queryD1(`DELETE FROM users_computers WHERE user_id = ?;`, [id]);
  console.log(`[ADMIN] User deleted: ${user?.email || id}`);
  res.json({ success: true });
});

// 5.8 Admin: список усіх комп'ютерів + онлайн-статус
app.get('/api/admin/computers', async (req, res) => {
  if (!adminGuard(req, res)) return;
  const rows = await queryD1('SELECT * FROM computers;');
  const owners = await queryD1('SELECT computer_id, user_id FROM users_computers;');
  const ownerMap = new Map();
  for (const o of owners) {
    if (!ownerMap.has(o.computer_id)) ownerMap.set(o.computer_id, []);
    ownerMap.get(o.computer_id).push(o.user_id);
  }
  const seen = new Set();
  const list = [];
  for (const c of rows) {
    if (seen.has(c.id)) continue;
    seen.add(c.id);
    const live = findComputer(c.hwid || c.id || c.code);
    list.push({
      id: c.id,
      hwid: c.hwid || c.id,
      code: c.code,
      name: c.name,
      os: c.os_info,
      cpu: c.cpu_info,
      gpu: c.gpu,
      ram: c.ram_info,
      lastSeen: c.last_seen,
      isOnline: isComputerOnline(live || {}),
      ownerIds: ownerMap.get(c.id) || ownerMap.get(c.hwid) || []
    });
  }
  res.json({ success: true, computers: list });
});

// ==========================================
// 5.10 АРХІВ ВЕРСІЙ: СПИСОК + РЕДАГУВАННЯ + ВИДАЛЕННЯ (ТЗ «вкладка Оновлення»)
// Список версій живе на сайті (versions.json + versions/<v>/FluxControl.exe,
// репозиторій matviikobrys2707/FluxControl → Cloudflare Pages).
// ТЗ: віддалене «Встановити на пристрій» ВИДАЛЕНО. Натомість адмін може:
//   • РЕДАГУВАТИ версію (номер, дата, опис) і позначити її «поточною» —
//     тоді саме цю версію скачуватимуть агенти, навіть якщо в архіві є
//     номери з більшими цифрами;
//   • ВИДАЛЯТИ версію з архіву (exe + sha256 + запис у маніфесті).
// Обидві операції комітять зміни в GitHub через Content/Git Data API
// (потрібен GITHUB_TOKEN у Render Environment: fine-grained PAT із правом
// «Contents: Read and write» на репозиторій FluxControl). Cloudflare Pages
// підхоплює коміт і автоматично перезбирає сайт.
// ============================================================================

const SITE_UPDATES_BASE = 'https://fluxcontrol.pages.dev';
const UPDATES_FALLBACK_BASE = 'https://raw.githubusercontent.com/matviikobrys2707/FluxControl/main';
const UPDATES_GITHUB_REPO = process.env.GITHUB_UPDATES_REPO || 'matviikobrys2707/FluxControl';

function githubToken() {
  return String(process.env.GITHUB_TOKEN || '').trim();
}

/** Базовий клієнт GitHub API (json). 404 → { status: 404 }. */
async function ghApi(path, opts = {}) {
  const token = githubToken();
  if (!token) throw Object.assign(new Error('NO_TOKEN'), { code: 'NO_TOKEN' });
  const r = await fetch(`https://api.github.com${path}`, {
    ...opts,
    headers: {
      'Authorization': `Bearer ${token}`,
      'Accept': 'application/vnd.github+json',
      'X-GitHub-Api-Version': '2022-11-28',
      'user-agent': 'FluxControl-Server',
      ...(opts.body ? { 'Content-Type': 'application/json' } : {}),
      ...(opts.headers || {})
    }
  });
  if (r.status === 404) return { status: 404 };
  if (!r.ok) {
    const text = await r.text().catch(() => '');
    throw Object.assign(new Error(`GitHub API ${r.status}: ${text.slice(0, 200)}`), { code: 'GH_HTTP', status: r.status });
  }
  return { status: r.status, json: r.status === 204 ? null : await r.json() };
}

/** Дефолтна гілка репозиторію (зазвичай main). */
async function ghDefaultBranch() {
  const r = await ghApi(`/repos/${UPDATES_GITHUB_REPO}`);
  return r.json?.default_branch || 'main';
}

/** HEAD-коміт і дерево гілки. */
async function ghHead(branch) {
  const ref = await ghApi(`/repos/${UPDATES_GITHUB_REPO}/git/ref/heads/${encodeURIComponent(branch)}`);
  const headSha = ref.json?.object?.sha;
  if (!headSha) throw Object.assign(new Error('Не вдалося прочитати HEAD репозиторію'), { code: 'GH_HEAD' });
  const commit = await ghApi(`/repos/${UPDATES_GITHUB_REPO}/git/commits/${headSha}`);
  return { headSha, treeSha: commit.json?.tree?.sha };
}

/** Вміст файлу з дерева репозиторію за blob-SHA (base64 → text). */
async function ghBlobText(sha) {
  const r = await ghApi(`/repos/${UPDATES_GITHUB_REPO}/git/blobs/${sha}`);
  if (r.status === 404) return null;
  return Buffer.from(r.json.content || '', 'base64').toString('utf-8');
}

/** Повне дерево (recursive) — дає blob-SHA всіх файлів за один запит. */
async function ghTree(treeSha) {
  const r = await ghApi(`/repos/${UPDATES_GITHUB_REPO}/git/trees/${treeSha}?recursive=1`);
  if (r.status === 404 || !r.json?.tree) return [];
  return r.json.tree || [];
}

/** Один коміт із набором змін дерева. */
async function ghCommitTree(branch, baseTreeSha, headSha, message, entries) {
  const tree = await ghApi(`/repos/${UPDATES_GITHUB_REPO}/git/trees`, {
    method: 'POST',
    body: JSON.stringify({ base_tree: baseTreeSha, tree: entries })
  });
  const commit = await ghApi(`/repos/${UPDATES_GITHUB_REPO}/git/commits`, {
    method: 'POST',
    body: JSON.stringify({ message, tree: tree.json.sha, parents: [headSha] })
  });
  await ghApi(`/repos/${UPDATES_GITHUB_REPO}/git/refs/heads/${encodeURIComponent(branch)}`, {
    method: 'PATCH',
    body: JSON.stringify({ sha: commit.json.sha, force: false })
  });
  return commit.json.sha;
}

/** Читає versions.json із репозиторію (+ blob-sha) напряму через дерево. */
async function ghLoadVersionsIndex(tree) {
  const entry = tree.find(t => t.path === 'versions.json' && t.type === 'blob');
  if (!entry) throw Object.assign(new Error('versions.json не знайдено в репозиторії'), { code: 'NO_MANIFEST' });
  const text = await ghBlobText(entry.sha);
  if (!text) throw Object.assign(new Error('versions.json порожній'), { code: 'EMPTY_MANIFEST' });
  return { index: JSON.parse(text), blobSha: entry.sha };
}

const VER_RE = /^\d+\.\d+\.\d+$/;
const ghNoToken = (res) => res.status(501).json({
  success: false,
  message: 'На сервері не налаштовано GITHUB_TOKEN (Render Environment → GITHUB_TOKEN, fine-grained PAT із правом Contents: Read and write на репозиторій FluxControl). Після додавання — рестарт сервісу.'
});

// Список версій (публічний проксі — сайту/ RAW, щоб агенти й адмінка бачили одне й те саме).
app.get('/api/updates/versions', async (req, res) => {
  const bust = '?t=' + Date.now();
  for (const base of [SITE_UPDATES_BASE, UPDATES_FALLBACK_BASE]) {
    try {
      const r = await fetch(base + '/versions.json' + bust, { headers: { 'user-agent': 'FluxControl-Server' } });
      if (r.ok) {
        const j = await r.json();
        if (j && Array.isArray(j.versions)) return res.json({ success: true, index: j, source: base });
      }
    } catch {}
  }
  res.status(502).json({ success: false, message: 'Список версій недоступний' });
});

// РЕДАГУВАННЯ версії: номер, дата, опис, «зробити поточною».
app.post('/api/admin/updates/edit', async (req, res) => {
  if (!adminGuard(req, res)) return;
  if (!githubToken()) return ghNoToken(res);
  const body = req.body || {};
  const originalVersion = String(body.originalVersion || body.version || '').trim().replace(/^v/i, '');
  const newVersion = String(body.version || originalVersion).trim().replace(/^v/i, '');
  const date = String(body.date || '').trim();
  const changelog = typeof body.changelog === 'string' ? body.changelog : undefined;
  const makeLatest = Boolean(body.makeLatest);

  if (!VER_RE.test(originalVersion) || !VER_RE.test(newVersion)) {
    return res.status(400).json({ success: false, message: 'Версія має бути формату 1.2.3 (три цифри)' });
  }
  if (date && !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
    return res.status(400).json({ success: false, message: 'Дата має бути у форматі РРРР-ММ-РР' });
  }

  try {
    const branch = await ghDefaultBranch();
    const { headSha, treeSha } = await ghHead(branch);
    const tree = await ghTree(treeSha);
    const { index, blobSha } = await ghLoadVersionsIndex(tree);
    const entries = Array.isArray(index.versions) ? index.versions : [];
    const entry = entries.find(v => String(v.version) === originalVersion);
    if (!entry) return res.status(404).json({ success: false, message: `Версію ${originalVersion} не знайдено в маніфесті` });

    const renamed = newVersion !== originalVersion;
    if (renamed && entries.some(v => String(v.version) === newVersion)) {
      return res.status(409).json({ success: false, message: `Версія ${newVersion} вже існує в архіві` });
    }

    // Зміни в маніфесті: оновлений запис (номер/дата/опис), сортування, latest.
    const updated = { ...entry, version: newVersion };
    if (date) updated.date = date; else delete updated.date;
    if (changelog !== undefined) updated.changelog = changelog;
    let list = entries.map(v => (String(v.version) === originalVersion ? updated : v));
    list = list.sort((a, b) => {
      const ka = String(a.version || '0.0.0').split('.').map(x => parseInt(x, 10) || 0);
      const kb = String(b.version || '0.0.0').split('.').map(x => parseInt(x, 10) || 0);
      for (let i = 0; i < 3; i++) { const d = (kb[i] || 0) - (ka[i] || 0); if (d) return d; }
      return 0;
    });
    index.versions = list;

    const treeEntries = [];
    // Перейменування версії = переміщення папки versions/<old> → versions/<new>
    // (blob-и копіюємо за SHA — вміст exe не перекачуємо).
    if (renamed) {
      const files = tree.filter(t => t.type === 'blob' && t.path.startsWith(`versions/${originalVersion}/`));
      if (files.length === 0) {
        return res.status(404).json({ success: false, message: `Папку versions/${originalVersion}/ не знайдено в репозиторії` });
      }
      for (const f of files) {
        const newPath = f.path.replace(`versions/${originalVersion}/`, `versions/${newVersion}/`);
        treeEntries.push({ path: newPath, mode: '100644', type: 'blob', sha: f.sha });
        treeEntries.push({ path: f.path, mode: '100644', type: 'blob', sha: null });
      }
    }

    // «Поточна»: latest_version у versions.json + оновлений version.json (manifest).
    if (makeLatest) {
      index.latest_version = newVersion;
      // sha256 беремо з sha256.txt версії (новий шлях після перейменування).
      const shaPath = `versions/${newVersion}/sha256.txt`;
      const shaEntry = tree.find(t => t.type === 'blob' && (t.path === shaPath || t.path === `versions/${originalVersion}/sha256.txt`));
      let sha = '';
      if (shaEntry) sha = (await ghBlobText(shaEntry.sha) || '').trim().toLowerCase();
      const manifest = {
        latest_version: newVersion,
        download_url: `${SITE_UPDATES_BASE}/versions/${newVersion}/FluxControl.exe`,
        ...(sha ? { sha256: sha } : {})
      };
      const mfEntry = tree.find(t => t.type === 'blob' && t.path === 'version.json');
      if (mfEntry) {
        treeEntries.push({ path: 'version.json', mode: '100644', type: 'blob', content: JSON.stringify(manifest, null, 2) + '\n' });
      }
    } else if (index.latest_version === originalVersion && renamed) {
      index.latest_version = newVersion;
    }

    // Оновлений versions.json (новий blob через content; index уже готовий).
    treeEntries.push({ path: 'versions.json', mode: '100644', type: 'blob', content: JSON.stringify(index, null, 2) + '\n' });

    const msg = `FluxControl: редагування версії ${originalVersion} → ${newVersion}${makeLatest ? ' (поточна)' : ''} [адмінпанель]`;
    await ghCommitTree(branch, treeSha, headSha, msg, treeEntries);
    console.log(`[UPDATES] Версію ${originalVersion} відредаговано → ${newVersion}${makeLatest ? ' (latest)' : ''}`);
    return res.json({ success: true, message: `Версію ${newVersion} збережено${makeLatest ? ' і позначено поточною' : ''}. Cloudflare Pages опублікує зміни за ~1 хвилину.` });
  } catch (e) {
    if (e.code === 'NO_TOKEN') return ghNoToken(res);
    console.error('[UPDATES] edit error:', e.message);
    return res.status(502).json({ success: false, message: `Помилка GitHub: ${e.message}` });
  }
});

// ВИДАЛЕННЯ версії: папку versions/<v>/ + запис у маніфесті. Якщо видаляли
// поточну — «поточною» стає найвища з тих, що лишились (version.json теж).
app.post('/api/admin/updates/delete', async (req, res) => {
  if (!adminGuard(req, res)) return;
  if (!githubToken()) return ghNoToken(res);
  const version = String((req.body || {}).version || '').trim().replace(/^v/i, '');
  if (!VER_RE.test(version)) {
    return res.status(400).json({ success: false, message: 'Версія має бути формату 1.2.3' });
  }
  try {
    const branch = await ghDefaultBranch();
    const { headSha, treeSha } = await ghHead(branch);
    const tree = await ghTree(treeSha);
    const { index, blobSha } = await ghLoadVersionsIndex(tree);
    const before = Array.isArray(index.versions) ? index.versions.length : 0;
    index.versions = (index.versions || []).filter(v => String(v.version) !== version);
    if (index.versions.length === before) {
      return res.status(404).json({ success: false, message: `Версію ${version} не знайдено в маніфесті` });
    }

    const treeEntries = [];
    const files = tree.filter(t => t.type === 'blob' && t.path.startsWith(`versions/${version}/`));
    for (const f of files) treeEntries.push({ path: f.path, mode: '100644', type: 'blob', sha: null });

    let note = '';
    if (index.latest_version === version) {
      const best = [...index.versions].sort((a, b) => {
        const ka = String(a.version || '0.0.0').split('.').map(x => parseInt(x, 10) || 0);
        const kb = String(b.version || '0.0.0').split('.').map(x => parseInt(x, 10) || 0);
        for (let i = 0; i < 3; i++) { const d = (kb[i] || 0) - (ka[i] || 0); if (d) return d; }
        return 0;
      })[0];
      if (best) {
        index.latest_version = best.version;
        const shaEntry = tree.find(t => t.type === 'blob' && t.path === `versions/${best.version}/sha256.txt`);
        let sha = '';
        if (shaEntry) sha = (await ghBlobText(shaEntry.sha) || '').trim().toLowerCase();
        const mfEntry = tree.find(t => t.type === 'blob' && t.path === 'version.json');
        if (mfEntry) {
          const manifest = {
            latest_version: best.version,
            download_url: `${SITE_UPDATES_BASE}/versions/${best.version}/FluxControl.exe`,
            ...(sha ? { sha256: sha } : {})
          };
          treeEntries.push({ path: 'version.json', mode: '100644', type: 'blob', content: JSON.stringify(manifest, null, 2) + '\n' });
        }
        note = `. Поточною автоматично стала v${best.version}`;
      }
    }

    treeEntries.push({ path: 'versions.json', mode: '100644', type: 'blob', content: JSON.stringify(index, null, 2) + '\n' });
    const msg = `FluxControl: видалення версії ${version} з архіву [адмінпанель]`;
    await ghCommitTree(branch, treeSha, headSha, msg, treeEntries);
    console.log(`[UPDATES] Версію ${version} видалено з архіву`);
    return res.json({ success: true, message: `Версію ${version} видалено${note}. Cloudflare Pages опублікує зміни за ~1 хвилину.` });
  } catch (e) {
    if (e.code === 'NO_TOKEN') return ghNoToken(res);
    console.error('[UPDATES] delete error:', e.message);
    return res.status(502).json({ success: false, message: `Помилка GitHub: ${e.message}` });
  }
});

// 5.9 AI PROXY (Gemini) — агент-помічник для вкладки «Штучний інтелект»
// ТЗ 55 — повністю перероблена логіка: кілька ключів з ротацією, окремі
// «автоматики відключення» для ключів (401/403 → 30 хв, 429 → 90с) і моделей
// (404 → 24год), ретраї з бекоffом, чесна діагностика замість голого 502.
// ==========================================

// КЛЮЧІ: GEMINI_API_KEY може містити декілька ключів через кому/крапку з комою;
// додаткові — у GEMINI_API_KEY_2..4. AQ.* — OAuth-токени (живуть ~1 годину),
// AIza.* — класичні безстрокові ключі AI Studio (рекомендовані).
const GEMINI_KEYS = [
  ...(process.env.GEMINI_API_KEY || 'AQ.Ab8RN6JvmZ6xucAgVXoHmqcLNRDV7cGG7onyUv0SDaa2SWHO9A').split(/[,;\s]+/),
  process.env.GEMINI_API_KEY_2 || '',
  process.env.GEMINI_API_KEY_3 || '',
  process.env.GEMINI_API_KEY_4 || '',
].map(k => k.trim()).filter(k => k.length > 20);

// Основна модель — за вимогою власника. Якщо вона ще не доступна на акаунті,
// проксі автоматично пробує сумісні flash-моделі, щоб функція не лежала.
const GEMINI_MODEL_CHAIN = [
  process.env.GEMINI_MODEL || 'gemini-3.5-flash-lite',
  'gemini-3.6-flash',
  'gemini-3.5-flash',
  'gemini-2.5-flash',
  'gemini-2.5-flash-lite',
  'gemini-2.0-flash'
];
let geminiWorkingModel = null;
let geminiWorkingKeyIdx = 0;

// --- Circuit breaker (ТЗ 55) ---
const AI_KEY_DEAD_MS = 30 * 60 * 1000;      // 401/403 — токен протух: 30 хв тиші
const AI_KEY_COOL_MS = 90 * 1000;           // 429 — хвилина-пів тиші на ключ
const AI_MODEL_DEAD_MS = 24 * 60 * 60 * 1000; // 404 — моделі немає на акаунті
const AI_MAX_ATTEMPTS = 10;                 // стеля спроб на один запит чату
const aiKeyState = GEMINI_KEYS.map(() => ({ deadUntil: 0, coolUntil: 0, lastError: '', fails: 0 }));
const aiModelState = new Map(); // model → { deadUntil, reason }

function maskKey(k) { return k.length > 14 ? `${k.slice(0, 6)}…${k.slice(-4)}` : '***'; }
const aiSleep = (ms) => new Promise(r => setTimeout(r, ms));

async function callGemini(key, modelName, contents, systemText) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${modelName}:generateContent`;
  const body = {
    contents,
    systemInstruction: systemText ? { parts: [{ text: systemText }] } : undefined,
    generationConfig: {
      temperature: 0.4,
      // 8192: модель пише відповіді-JSON із ВБУДОВАНИМИ скриптами (напр. python-файл
      // всередині "command"). Стара стеля 2048 обрізала JSON посеред рядка →
      // парсинг падав → цикл «думав і зупинявся», нічого не виконавши.
      maxOutputTokens: 8192,
      responseMimeType: 'application/json'
    }
  };
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), 45000);
  // ФІКС «Expected OAuth 2 access token»: нові ключі AI Studio формату
  // AQ.* — це OAuth-токени, їх треба слати як Authorization: Bearer;
  // класичні AIza-ключі працюють через x-goog-api-key.
  const isOAuthToken = key.startsWith('AQ.');
  const authHeaders = isOAuthToken
    ? { 'Authorization': `Bearer ${key}` }
    : { 'x-goog-api-key': key };
  try {
    const r = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...authHeaders
      },
      body: JSON.stringify(body),
      signal: ctrl.signal
    });
    const data = await r.json().catch(() => null);
    if (!r.ok) {
      const err = new Error(data?.error?.message || `Gemini HTTP ${r.status}`);
      err.status = r.status;
      throw err;
    }
    const parts = data?.candidates?.[0]?.content?.parts || [];
    const text = parts.map(p => p.text || '').join('').trim();
    return { ok: true, text };
  } finally {
    clearTimeout(t);
  }
}

// Швидка перевірка готовності AI з фронтенду + ДІАГНОСТИКА (ТЗ 55):
// скільки ключів живих, яка модель робоча, які моделі відключені автоматом.
// 404 на цей роут означає, що на Render старий server.js.
app.get('/api/ai/status', (req, res) => {
  const now = Date.now();
  const aliveKeys = GEMINI_KEYS.reduce((n, _, i) =>
    n + (aiKeyState[i].deadUntil > now || aiKeyState[i].coolUntil > now ? 0 : 1), 0);
  res.json({
    success: true,
    ai: true,
    version: '5.9.4',
    model: GEMINI_MODEL_CHAIN[0],
    fallbacks: GEMINI_MODEL_CHAIN.slice(1),
    workingModel: geminiWorkingModel || null,
    keysTotal: GEMINI_KEYS.length,
    keysAlive: aliveKeys,
    deadModels: [...aiModelState.entries()].filter(([, s]) => s.deadUntil > now).map(([m]) => m),
    keyTypes: GEMINI_KEYS.map(k => (k.startsWith('AQ.') ? 'oauth' : 'api')),
    maxBodyMb: 30,
    maxOutputTokens: 8192
  });
});

app.post('/api/ai/chat', async (req, res) => {
  const { messages } = req.body || {};
  if (!Array.isArray(messages) || messages.length === 0) {
    return res.status(400).json({ success: false, error: 'messages required' });
  }

  // Кожне повідомлення може нести зображення (скриншот екрана ПК) —
  // тоді формуємо parts із inline_data, щоб Gemini бачив екран (vision).
  const contents = messages.slice(-24).map(m => {
    const parts = [];
    if (m.image) {
      let b64 = String(m.image);
      const dataUrl = b64.match(/^data:image\/(\w+);base64,(.+)$/);
      if (dataUrl) { b64 = dataUrl[2]; }
      if (b64.length > 40) {
        parts.push({ inline_data: { mime_type: 'image/jpeg', data: b64 } });
      }
    }
    parts.push({ text: String(m.text || '').slice(0, 12000) });
    return { role: m.role === 'model' ? 'model' : 'user', parts };
  });
  const systemText = req.body.system || '';

  // --- ТЗ 55: ротація ключ × модель з circuit breaker ---
  const now = Date.now();
  // Ключі, що зараз живі; останній робочий — першим.
  const aliveKeyIdx = [];
  for (let i = 0; i < GEMINI_KEYS.length; i++) {
    if (aiKeyState[i].deadUntil <= now && aiKeyState[i].coolUntil <= now) aliveKeyIdx.push(i);
  }
  // Моделі, що зараз живі; остання робоча — першою.
  const models = [geminiWorkingModel, ...GEMINI_MODEL_CHAIN]
    .filter(Boolean)
    .filter((m, i, arr) => arr.indexOf(m) === i)
    .filter(m => { const st = aiModelState.get(m); return !st || st.deadUntil <= now; });
  const keyOrder = [geminiWorkingKeyIdx, ...aliveKeyIdx.filter(i => i !== geminiWorkingKeyIdx)]
    .filter(i => aliveKeyIdx.includes(i));

  let lastErr = 'немає робочих ключів/моделей';
  let lastErrFull = '';
  let attempts = 0;

  outer:
  for (const model of models) {
    for (const ki of keyOrder) {
      if (attempts >= AI_MAX_ATTEMPTS) break outer;
      attempts++;
      const key = GEMINI_KEYS[ki];
      try {
        const out = await callGemini(key, model, contents, systemText);
        geminiWorkingModel = model;
        geminiWorkingKeyIdx = ki;
        aiKeyState[ki].fails = 0;
        return res.json({ success: true, text: out.text, model, version: '5.9.4' });
      } catch (e) {
        const status = e.status || 0;
        lastErr = `${model} · ключ ${maskKey(key)}: ${e.message}`;
        lastErrFull = e.message;
        console.warn(`[AI] attempt ${attempts}/${AI_MAX_ATTEMPTS} ${lastErr}`);

        // 401/403/невалідний ключ — токен протух/некоректний: вимикаємо
        // КЛЮЧ на 30 хв і пробуємо наступний (модель лишається робочою).
        if (status === 401 || status === 403 || /API key not valid|Expected OAuth 2|invalid authentication|UNAUTHENTICATED/i.test(e.message)) {
          aiKeyState[ki].deadUntil = Date.now() + AI_KEY_DEAD_MS;
          aiKeyState[ki].lastError = e.message;
          continue;
        }
        // 404 — моделі немає на акаунті: вимикаємо МОДЕЛЬ на добу.
        if (status === 404 || /not found|does not exist|is not supported for/i.test(e.message)) {
          aiModelState.set(model, { deadUntil: Date.now() + AI_MODEL_DEAD_MS, reason: e.message });
          continue outer;
        }
        // 429 — ліміт саме цього ключа: коротке охолодження, ретрай тим самим.
        if (status === 429 || /RESOURCE_EXHAUSTED|quota/i.test(e.message)) {
          aiKeyState[ki].coolUntil = Date.now() + AI_KEY_COOL_MS;
          await aiSleep(1500);
          try {
            const out2 = await callGemini(key, model, contents, systemText);
            geminiWorkingModel = model;
            geminiWorkingKeyIdx = ki;
            aiKeyState[ki].coolUntil = 0;
            return res.json({ success: true, text: out2.text, model, version: '5.9.4' });
          } catch (e2) {
            lastErr = `${model} · ключ ${maskKey(key)}: ${e2.message}`;
            lastErrFull = e2.message;
            if ((e2.status || 0) === 401 || (e2.status || 0) === 403) {
              aiKeyState[ki].deadUntil = Date.now() + AI_KEY_DEAD_MS;
              aiKeyState[ki].lastError = e2.message;
            }
          }
          continue;
        }
        // 5xx/таймаут/мережа — тимчасові: одна пауза + ретрай, потім наступна пара.
        if (status >= 500 || status === 0) {
          await aiSleep(1800);
          try {
            const out3 = await callGemini(key, model, contents, systemText);
            geminiWorkingModel = model;
            geminiWorkingKeyIdx = ki;
            return res.json({ success: true, text: out3.text, model, version: '5.9.4' });
          } catch (e3) {
            lastErr = `${model} · ключ ${maskKey(key)}: ${e3.message}`;
            lastErrFull = e3.message;
          }
        }
      }
    }
  }

  // ЧЕСНА помилка замість безликого 502: що саме впало і що з цим робити.
  let hint = '';
  if (GEMINI_KEYS.every(k => k.startsWith('AQ.'))) {
    hint += ' УВАГА: всі ключі — OAuth-токени (AQ.*), які живуть ~1 годину. Додай постійний AIza-ключ: aistudio.google.com → Get API key → Render → GEMINI_API_KEY (можна кілька через кому).';
  } else if (/401|403|Unauthorized|invalid authentication credential|API key not valid/i.test(lastErrFull)) {
    hint += ' Ключ(і) Gemini прострочені або некоректні — онови GEMINI_API_KEY на Render.';
  } else if (/429|quota|RESOURCE_EXHAUSTED/i.test(lastErrFull)) {
    hint += ' Вичерпано ліміт запитів Gemini — спробуйте за кілька хвилин.';
  } else if (/timeout|abort|ETIMEDOUT|ECONNRESET|fetch failed/i.test(lastErrFull)) {
    hint += ' Gemini не встиг відповісти (таймаут/мережа). Спробуйте ще раз.';
  }
  const now2 = Date.now();
  const aliveLeft = GEMINI_KEYS.reduce((n, _, i) =>
    n + (aiKeyState[i].deadUntil <= now2 && aiKeyState[i].coolUntil <= now2 ? 1 : 0), 0);
  if (aliveLeft === 0 && GEMINI_KEYS.length > 0) {
    hint += ' Усі ключі тимчасово вимкнені автоматикою — наступна спроба може пройти, але краще додати свіжий AIza-ключ.';
  }
  res.status(502).json({
    success: false,
    error: `Gemini недоступний (спроб ${attempts}). Остання помилка — ${lastErr}.${hint}`
  });
});

// ==========================================
// 5.95 SHARE LINKS («Поділитися» — ТЗ): сеансові посилання на файл/папку.
// Реєстр — ТІЛЬКИ ПАМ'ЯТЬ релея: агент перезапустив / файл видалено →
// посилання мертві. Папка віддається як ZIP (пакує агент, стрімить частинами).
// ==========================================

const shareRegistry = new Map();     // token → { compKey, code, hwid, name, isDir, sizeBytes, createdAt }
const crossChunkSeq = new Map();     // streamId → останній seq, записаний у D1 (крос-ізолят)
const shareStreams = new Map();      // streamId → { res, token, bytes, startedAt, firstChunkTimer }

const SHARE_MAX_AGE_MS = 24 * 60 * 60 * 1000; // страховка: добре б не жило довше сеансу
setInterval(() => {
  const now = Date.now();
  for (const [token, s] of shareRegistry) {
    if (now - s.createdAt > SHARE_MAX_AGE_MS) shareRegistry.delete(token);
  }
  for (const [streamId, st] of shareStreams) {
    if (now - st.startedAt > 30 * 60 * 1000) {
      try { if (!st.res.writableEnded) st.res.end(); } catch {}
      shareStreams.delete(streamId);
    }
  }
}, 60 * 1000).unref();

// ---- D1-інфраструктура (ТЗ 45: «посилання недійсне» на Deno Deploy) ----
// Deno Deploy розкидує запити по ізолятах: реєстр шейрів у ПАМ'ЯТІ ізолята
// агента не видно /api/share/info|download на інших ізолятах → таблиці в D1.
// Read-only токен: ensureShareInfraTables() періодично перечитує probe (10 хв),
// тож після заміни токена таблиці створяться самі; поки запису немає —
// реєстр живе в пам'яті (Render = один інстанс, все працює).
let _shareTablesReady = false;
let _shareTablesLastTry = 0;
async function ensureShareInfraTables() {
  if (_shareTablesReady) return true;
  // Ретрай не частіше ніж раз на 2 хвилини, щоб не молотити D1 дарма.
  if (Date.now() - _shareTablesLastTry < 2 * 60 * 1000) return false;
  _shareTablesLastTry = Date.now();
  if (!(await probeD1Write(true))) return false;
  try {
    await queryD1(`CREATE TABLE IF NOT EXISTS share_tokens (
      token TEXT PRIMARY KEY, hwid TEXT, code TEXT, name TEXT,
      is_dir INTEGER DEFAULT 0, size_bytes INTEGER DEFAULT 0, created_at INTEGER
    );`);
    await queryD1(`CREATE TABLE IF NOT EXISTS agent_jobs (
      job_id TEXT PRIMARY KEY, hwid TEXT, type TEXT, payload TEXT,
      status TEXT DEFAULT 'new', result TEXT, created_at INTEGER
    );`);
    await queryD1(`CREATE TABLE IF NOT EXISTS share_chunks (
      stream_id TEXT, seq INTEGER, data TEXT, last INTEGER DEFAULT 0,
      PRIMARY KEY (stream_id, seq)
    );`);
    _shareTablesReady = true;
    console.log('[SHARE][D1] Infrastructure tables ready (share_tokens, agent_jobs, share_chunks).');
    return true;
  } catch (e) {
    console.warn('[SHARE][D1] init failed:', e.message);
    return false;
  }
}
_ = ensureShareInfraTables();

// «Онлайн» для крос-ізолятних перевірок: last_seen із D1 (свіжий статус).
function parseD1Timestamp(v) {
  if (!v) return 0;
  if (typeof v === 'number') return v;
  const m = String(v).match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2}):(\d{2})/);
  if (!m) return 0;
  return Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +m[6]);
}
async function shareEntryFromD1(token) {
  try {
    const rows = await queryD1(`SELECT s.token, s.hwid, s.code, s.name, s.is_dir, s.size_bytes, s.created_at,
       c.last_seen, c.name AS device_name, c.status
       FROM share_tokens s LEFT JOIN computers c ON (c.hwid = s.hwid OR c.id = s.hwid) WHERE s.token = ?;`, [token]);
    if (!rows || rows.length === 0) return null;
    const r = rows[0];
    const freshMs = parseD1Timestamp(r.last_seen);
    return {
      token: r.token, hwid: r.hwid, code: r.code,
      name: r.name, isDir: Number(r.is_dir) === 1,
      sizeBytes: Number(r.size_bytes) || 0,
      createdAt: Number(r.created_at) || 0,
      deviceName: r.device_name || 'ПК',
      d1FreshMs: freshMs
    };
  } catch { return null; }
}
function d1SeenFresh(entry, maxAgeMs) {
  if (!entry || !entry.d1FreshMs) return false;
  return Date.now() - entry.d1FreshMs <= maxAgeMs;
}

app.get('/api/share/info', async (req, res) => {
  const token = String(req.query.token || '').trim();
  let entry = shareRegistry.get(token);
  if (!entry) {
    // Крос-ізолят (Deno Deploy): токен живе в D1, а не в пам'яті цього ізолята.
    await ensureShareInfraTables();
    entry = await shareEntryFromD1(token);
    if (!entry) {
      return res.json({ success: false, reason: 'expired', error: 'Посилання більше не дійсне (сеанс агента завершено, програму перезапущено або файл видалено).' });
    }
  }
  const comp = findComputer(entry.hwid) || findComputer(entry.code) || findComputer(entry.compKey);
  const localOnline = Boolean(comp?.isOnline && comp?.agentWs && comp.agentWs.readyState === WebSocket.OPEN);
  const remoteOnline = localOnline || (entry.d1FreshMs !== undefined
    ? d1SeenFresh(entry, AGENT_STALE_AFTER_MS)
    : Boolean(comp && isComputerOnline(comp)));
  if (!remoteOnline) {
    return res.json({ success: false, reason: 'offline', error: 'ПК власника зараз офлайн — посилання активне лише поки працює програма.' });
  }
  res.json({
    success: true,
    name: entry.name,
    isDir: entry.isDir,
    sizeBytes: entry.sizeBytes,
    deviceName: comp?.name || entry.deviceName || 'ПК'
  });
});

app.get('/api/share/download', async (req, res) => {
  const token = String(req.query.token || '').trim();
  let entry = shareRegistry.get(token);
  if (!entry) {
    await ensureShareInfraTables();
    entry = await shareEntryFromD1(token);
  }
  if (!entry) {
    return res.status(410).json({ success: false, error: 'Посилання більше не дійсне (агент перезапущено або файл видалено).' });
  }
  const comp = findComputer(entry.hwid) || findComputer(entry.code) || findComputer(entry.compKey);
  const agentWs = comp?.agentWs && comp.agentWs.readyState === WebSocket.OPEN ? comp.agentWs : null;

  // КРОС-ІЗОЛЯТНИЙ ШЛЯХ (Deno Deploy): WS агента на іншому ізоляту —
  // качаємо через D1 (agent_jobs → share_chunks). Працює незалежно від того,
  // куди прилетів цей HTTP-запит.
  if (!agentWs) {
    const fresh = entry.d1FreshMs !== undefined
      ? d1SeenFresh(entry, AGENT_STALE_AFTER_MS)
      : Boolean(comp && isComputerOnline(comp));
    if (!fresh) {
      return res.status(503).json({ success: false, error: 'ПК власника офлайн — скачати неможливо.' });
    }
    const streamId = crypto.randomBytes(8).toString('hex');
    const fileName = entry.isDir ? `${entry.name}.zip` : entry.name;
    const jobId = `shdl_${streamId}`;
    try {
      await queryD1(`INSERT INTO agent_jobs (job_id, hwid, type, payload, status, created_at)
        VALUES (?, ?, 'share_download', ?, 'new', ?);`,
        [jobId, entry.hwid, JSON.stringify({ token, streamId }), Date.now()]);
    } catch (e) {
      return res.status(502).json({ success: false, error: 'Не вдалося поставити завдання агенту (D1 недоступна).' });
    }

    res.writeHead(200, {
      'Content-Type': entry.isDir ? 'application/zip' : 'application/octet-stream',
      'Content-Disposition': `attachment; filename="download"; filename*=UTF-8''${encodeURIComponent(fileName)}`,
      'Cache-Control': 'no-store',
      'X-Share-Name': encodeURIComponent(fileName)
    });

    let lastSeq = 0; let bytes = 0; let closed = false;
    const startedAt = Date.now();
    req.on('close', () => {
      closed = true;
      // Клієнт обірвав: скасовуємо стрім агента (завдання share_abort).
      queryD1(`INSERT INTO agent_jobs (job_id, hwid, type, payload, status, created_at)
        VALUES (?, ?, 'share_abort', ?, 'new', ?);`,
        [`shab_${streamId}_${Date.now()}`, entry.hwid, JSON.stringify({ streamId }), Date.now()]).catch(() => {});
      queryD1(`DELETE FROM share_chunks WHERE stream_id = ?;`, [streamId]).catch(() => {});
      queryD1(`DELETE FROM agent_jobs WHERE job_id = ?;`, [jobId]).catch(() => {});
    });

    const sleep = (ms) => new Promise(r => setTimeout(r, ms));
    while (!closed && !res.writableEnded) {
      if (Date.now() - startedAt > 30 * 60 * 1000) break; // страховка 30 хв
      if (bytes === 0 && Date.now() - startedAt > 45000) break; // агент мовчить 45с
      try {
        const rows = await queryD1(
          `SELECT seq, data, last FROM share_chunks WHERE stream_id = ? AND seq > ? ORDER BY seq LIMIT 8;`,
          [streamId, lastSeq]);
        if (rows && rows.length > 0) {
          for (const r of rows) {
            const seq = Number(r.seq) || 0;
            if (seq <= lastSeq) continue;
            const buf = Buffer.from(String(r.data || ''), 'base64');
            if (buf.length > 0) { res.write(buf); bytes += buf.length; }
            lastSeq = seq;
            if (Number(r.last) === 1) {
              try { res.end(); } catch {}
              closed = true;
              break;
            }
          }
          // Віддане прибираємо, щоб D1 не роздувалась.
          queryD1(`DELETE FROM share_chunks WHERE stream_id = ? AND seq <= ?;`, [streamId, lastSeq]).catch(() => {});
          continue; // одразу за новими порціями
        }
      } catch { /* D1 тримає паузу — просто наступний тик */ }
      await sleep(300);
    }
    if (!res.writableEnded) { try { res.end(); } catch {} }
    queryD1(`DELETE FROM share_chunks WHERE stream_id = ?;`, [streamId]).catch(() => {});
    queryD1(`DELETE FROM agent_jobs WHERE job_id = ?;`, [jobId]).catch(() => {});
    return;
  }

  const streamId = crypto.randomBytes(8).toString('hex');
  const fileName = entry.isDir ? `${entry.name}.zip` : entry.name;

  res.writeHead(200, {
    'Content-Type': entry.isDir ? 'application/zip' : 'application/octet-stream',
    'Content-Disposition': `attachment; filename="download"; filename*=UTF-8''${encodeURIComponent(fileName)}`,
    'Cache-Control': 'no-store',
    'X-Share-Name': encodeURIComponent(fileName)
  });

  const state = { res, token, bytes: 0, startedAt: Date.now(), firstChunkTimer: null };
  shareStreams.set(streamId, state);

  state.firstChunkTimer = setTimeout(() => {
    if (!res.writableEnded && state.bytes === 0) {
      try { res.end(); } catch {}
      shareStreams.delete(streamId);
      try { agentWs.send(JSON.stringify({ type: 'share_stream_abort', data: { streamId } })); } catch {}
    }
  }, 45000).unref();

  req.on('close', () => {
    if (shareStreams.has(streamId)) {
      shareStreams.delete(streamId);
      try { agentWs.send(JSON.stringify({ type: 'share_stream_abort', data: { streamId } })); } catch {}
    }
  });

  try {
    agentWs.send(JSON.stringify({ type: 'share_stream_begin', data: { token, streamId } }));
  } catch (e) {
    shareStreams.delete(streamId);
    if (!res.writableEnded) res.end();
  }
});

// ==========================================
// 6. DESKTOP APP WEB OAUTH / LOGIN FLOW
// ==========================================

// 6.1 Agent initiates auth request
app.post('/api/auth/device-session/create', async (req, res) => {
  const { computerName, hwid, code } = req.body || {};
  const token = `auth_req_${crypto.randomBytes(12).toString('hex')}`;
  const now = Date.now();
  const expiresAt = now + 15 * 60 * 1000;

  const session = {
    token,
    computerName: computerName || 'Комп\'ютер',
    hwid: hwid || '',
    code: code || '',
    status: 'pending',
    userId: null,
    user: null,
    createdAt: now,
    expiresAt
  };

  authSessionsDb.set(token, session);

  // Write immediately to Cloudflare D1
  queryD1(`
    INSERT INTO auth_sessions (token, computer_name, hwid, code, status, created_at, expires_at)
    VALUES (?, ?, ?, ?, 'pending', ?, ?);
  `, [token, session.computerName, session.hwid, session.code, now, expiresAt]);

  res.json({
    success: true,
    token,
    authUrl: `https://fluxcontrol.pages.dev/auth/device?token=${token}&pc=${encodeURIComponent(session.computerName)}`
  });
});

// 6.2 Agent polls session status
app.get('/api/auth/device-session/status', async (req, res) => {
  const token = req.query.token;
  if (!token) return res.status(400).json({ error: 'Missing token' });

  let session = authSessionsDb.get(token);

  // If not in cache or pending, check Cloudflare D1
  if (!session || session.status === 'pending') {
    const rows = await queryD1(`SELECT * FROM auth_sessions WHERE token = ?;`, [token]);
    if (rows && rows.length > 0) {
      const row = rows[0];
      session = {
        token: row.token,
        computerName: row.computer_name,
        hwid: row.hwid,
        code: row.code,
        status: row.status,
        userId: row.user_id,
        user: row.user_json ? JSON.parse(row.user_json) : null,
        createdAt: row.created_at
      };
      authSessionsDb.set(token, session);
    }
  }

  if (!session) return res.status(404).json({ error: 'Session not found' });

  res.json({
    success: true,
    status: session.status,
    computerName: session.computerName,
    user: session.user
  });
});

// 6.3 Website approves device session
app.post('/api/auth/device-session/approve', async (req, res) => {
  const { token, action } = req.body || {};
  if (!token) return res.status(400).json({ error: 'Missing token' });

  // SECURITY FIX: підтверджувати сесію може ЛИШЕ автентифікований користувач.
  // Раніше тіло запиту могло принести ДОВІЛЬНИЙ providedUser/userId — хтось із
  // відкритою сторінкою авторизації пристрою «підтверджував» її чужим акаунтом.
  const approver = authCore.authenticate(req, usersDb);
  if (!approver || approver.via !== 'session') {
    return res.status(401).json({ error: 'Потрібна авторизація: перезайдіть у акаунт' });
  }
  const userId = approver.user.id;

  let session = authSessionsDb.get(token);
  if (!session) {
    const rows = await queryD1(`SELECT * FROM auth_sessions WHERE token = ?;`, [token]);
    if (rows && rows.length > 0) {
      const row = rows[0];
      session = {
        token: row.token,
        computerName: row.computer_name,
        hwid: row.hwid,
        code: row.code,
        status: row.status,
        createdAt: row.created_at
      };
    }
  }

  if (!session) return res.status(404).json({ error: 'Session not found' });

  if (action === 'reject') {
    session.status = 'rejected';
    authSessionsDb.set(token, session);
    queryD1(`UPDATE auth_sessions SET status = 'rejected' WHERE token = ?;`, [token]);
    return res.json({ success: true, status: 'rejected' });
  }

  // Resolve user info from the VERIFIED session only.
  let user = approver.user;

  const approvedUser = {
    id: user?.id || userId,
    email: user?.email || '',
    name: user?.name || 'Користувач',
    picture: user?.picture || user?.photoURL || '',
    role: user?.role || 'user',
    subscriptionExpiresAt: user?.subscriptionExpiresAt !== undefined ? user.subscriptionExpiresAt : null
  };

  session.status = 'approved';
  session.userId = approvedUser.id;
  session.user = approvedUser;

  authSessionsDb.set(token, session);

  // Update in Cloudflare D1 immediately
  queryD1(`
    UPDATE auth_sessions 
    SET status = 'approved', user_id = ?, user_json = ? 
    WHERE token = ?;
  `, [approvedUser.id, JSON.stringify(approvedUser), token]);

  // Ensure user is also upserted in D1 users table
  queryD1(`
    INSERT INTO users (id, email, name, picture, role, subscription_expires_at)
    VALUES (?, ?, ?, ?, ?, ?)
    ON CONFLICT(id) DO UPDATE SET
      email=excluded.email,
      name=excluded.name,
      picture=excluded.picture,
      role=excluded.role,
      subscription_expires_at=excluded.subscription_expires_at;
  `, [approvedUser.id, approvedUser.email, approvedUser.name, approvedUser.picture, approvedUser.role, approvedUser.subscriptionExpiresAt]);

  console.log(`[AUTH] Device session approved for ${approvedUser.email} on ${session.computerName}`);
  res.json({ success: true, status: 'approved', user: approvedUser });
});

// ==========================================
// 7. WEBSOCKET SERVER RELAY
// ==========================================

const server = http.createServer(app);
// ---------- ТЗ 49: облік трафіку релея (що саме з'їдає ліміт Render) ----------
// Рахуємо байти на обидва плечі: прийом (агент/клієнт → сервер) + відправка
// (сервер → клієнти/агент). Медіа йде бінарними WS-кадрами [0xFC][тип][ts][data].
const trafficStats = {
  since: Date.now(),
  categories: { screen: 0, audio: 0, files: 0, control: 0, telemetry: 0 }
};
function countTraffic(cat, bytes) {
  if (!bytes || bytes <= 0) return;
  if (!trafficStats.categories[cat]) trafficStats.categories[cat] = 0;
  trafficStats.categories[cat] += bytes;
}
function trafficCategory(type) {
  if (type === 'screen_frame' || type === 'screen_stream_feedback') return 'screen';
  if (type === 'audio_chunk') return 'audio';
  if (String(type).startsWith('fs_') || String(type).startsWith('share_')) return 'files';
  if (type === 'telemetry' || type === 'health_check' || type === 'health_response' || type === 'ping' || type === 'pong') return 'telemetry';
  return 'control';
}
const QUIET_LOG_TYPES = new Set([
  'screen_frame', 'audio_chunk', 'screen_stream_feedback',
  'mouse_move', 'mouse_move_abs', 'mouse_down', 'mouse_up', 'mouse_click', 'mouse_scroll',
  'key_text', 'key', 'terminal_input', 'ping', 'pong'
]);

const wss = new WebSocket.Server({ server });

// ТЗ 49: щоб побачити, що саме їсть трафік ліміту, без перезавантаження логів.
app.get('/api/traffic/stats', (req, res) => {
  const categories = { ...trafficStats.categories };
  const totalBytes = Object.values(categories).reduce((a, b) => a + b, 0);
  res.json({
    since: trafficStats.since,
    uptimeHours: Math.round(((Date.now() - trafficStats.since) / 36e5) * 100) / 100,
    categories,
    totalBytes,
    totalMB: Math.round(totalBytes / 1048576),
    totalGB: Math.round((totalBytes / 1073741824) * 100) / 100,
    hint: 'байти пораховані на обидва плечі (прийом + відправка); screen/audio — бінарні медіа-кадри стриму'
  });
});
app.post('/api/traffic/reset', (req, res) => {
  trafficStats.since = Date.now();
  for (const k of Object.keys(trafficStats.categories)) trafficStats.categories[k] = 0;
  res.json({ ok: true, since: trafficStats.since });
});

// One relay-owned heartbeat for all agents. It is intentionally modest: a
// health check every four seconds, and Offline only after three missed slots.
setInterval(() => {
  const now = Date.now();
  for (const comp of uniqueComputers()) {
    const wasOnline = Boolean(comp.isOnline);
    const online = isComputerOnline(comp, now);
    comp.isOnline = online;

    if (comp.agentWs?.readyState === WebSocket.OPEN) {
      try { comp.agentWs.send(JSON.stringify({ type: 'health_check', timestamp: now })); } catch { }
    }

    if (wasOnline && !online) {
      // Persist the honest offline state so the Cloudflare D1 fallback
      // endpoint can never report this PC as online after the relay dies.
      const id = comp.hwid || comp.id;
      if (id) {
        queryD1('UPDATE computers SET status = ? WHERE id = ? OR hwid = ? OR code = ?;', ['offline', id, id, comp.code || '']).catch(() => {});
      }
      for (const clientWs of getClientsForComp(comp, comp.code, comp.hwid)) {
        if (clientWs.readyState === WebSocket.OPEN) {
          try { clientWs.send(JSON.stringify({ type: 'agent_status', status: 'offline' })); } catch { }
        }
      }
    }
  }
}, AGENT_HEARTBEAT_INTERVAL_MS);

// Mirror live agent heartbeats into D1 every 30 seconds. The relay memory is
// the single source of truth, but the D1 tables are what the Cloudflare Pages
// fallback reads while Render is cold-starting — without this refresh the
// fallback sees a stale last_seen and honest devices flip to offline there.
setInterval(() => {
  const online = uniqueComputers().filter(c => c.isOnline && c.hwid);
  for (const comp of online) {
    queryD1(
      `UPDATE computers SET last_seen = CURRENT_TIMESTAMP, status = 'online'
       WHERE id = ? OR hwid = ?;`,
      [comp.hwid, comp.hwid]
    ).catch(() => {});
  }
}, 30000);

wss.on('connection', (ws, req) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const role = url.searchParams.get('role');
  const code = (url.searchParams.get('code') || '').toUpperCase().trim();
  const hwid = url.searchParams.get('hwid') || '';

  if (role === 'agent') {
    handleAgentConnection(ws, code, hwid);
  } else if (role === 'client') {
    handleClientConnection(ws, code, hwid);
  } else {
    // Default identification via handshake message
    ws.on('message', (data) => {
      try {
        const msg = JSON.parse(data.toString());
        if (msg.type === 'register_agent') {
          handleAgentConnection(ws, (msg.code || '').toUpperCase().trim(), msg.hwid || '');
        } else if (msg.type === 'register_client') {
          handleClientConnection(ws, (msg.code || '').toUpperCase().trim(), msg.hwid || '');
        }
      } catch (e) {}
    });
  }
});

function findComputer(key) {
  if (!key) return null;
  const clean = String(key).replace(/[^A-Za-z0-9]/g, '').toUpperCase();
  let found = computersDb.get(key) || computersDb.get(clean);
  if (found) return found;
  for (const comp of computersDb.values()) {
    const c1 = String(comp.code || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase();
    const c2 = String(comp.hwid || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase();
    const c3 = String(comp.id || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase();
    if (c1 === clean || c2 === clean || c3 === clean) {
      return comp;
    }
  }
  return null;
}

function getClientsForComp(comp, code, hwid) {
  const cleanCode = (code || comp?.code || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase();
  const cleanHwid = (hwid || comp?.hwid || comp?.id || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase();
  const cleanCompId = (comp?.id || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase();

  const result = new Set();
  for (const clientWs of wss.clients) {
    if (clientWs.readyState === WebSocket.OPEN && clientWs.isClient) {
      const target = (clientWs.clientTargetKey || '').toUpperCase();
      if (target && (target === cleanCode || target === cleanHwid || target === cleanCompId)) {
        result.add(clientWs);
      }
    }
  }
  return Array.from(result);
}

// Економія трафіку Render (Hobby = 5 ГБ/міс): телеметрія 1/с їла ~4 ГБ/міс
// навіть без активних сесій. Тепер 1с поки є відкриті вкладки-сесії, 8с — ні.
function pushTelemetryRate(comp, code, hwid, agentWsOverride) {
  try {
    const agentWs = agentWsOverride || ((comp && comp.agentWs && comp.agentWs.readyState === WebSocket.OPEN) ? comp.agentWs : null);
    if (!agentWs || agentWs.readyState !== WebSocket.OPEN) return;
    const watching = getClientsForComp(comp, code, hwid).length;
    const ms = watching > 0 ? 1000 : 8000;
    agentWs.send(JSON.stringify({ type: 'telemetry_rate', ms }));
  } catch {}
}

function handleAgentConnection(ws, code, hwid) {
  const cleanCode = (code || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase();
  const primaryKey = hwid || cleanCode || code;
  if (!primaryKey) {
    console.warn('[RELAY] [AGENT REJECTED] Missing HWID and Code');
    ws.close(1008, 'HWID or Code required');
    return;
  }

  ws.isAgent = true;
  ws.agentCode = cleanCode;
  ws.agentHwid = hwid || primaryKey;

  const existing = findComputer(primaryKey) || computersDb.get(primaryKey) || {};
  const comp = {
    ...existing,
    id: primaryKey,
    hwid: hwid || existing.hwid || primaryKey,
    code: cleanCode || existing.code || code,
    connection_code: cleanCode || existing.connection_code || code,
    agentWs: ws,
    lastSeen: Date.now(),
    isOnline: true
  };

  computersDb.set(primaryKey, comp);
  if (cleanCode) computersDb.set(cleanCode, comp);
  if (comp.hwid) computersDb.set(comp.hwid, comp);

  console.log(`[RELAY] [AGENT CONNECTED] HWID=${comp.hwid}, Code=${cleanCode}, PC Name=${comp.name || 'ПК'}`);

  // Notify any waiting web clients that the PC is online
  const waitingClients = getClientsForComp(comp, cleanCode, hwid);
  console.log(`[RELAY] [AGENT ONLINE NOTIFY] Notifying ${waitingClients.length} waiting client(s)`);
  for (const clientWs of waitingClients) {
    clientWs.send(JSON.stringify({ type: 'agent_status', status: 'online', computerName: comp.name || 'ПК' }));
  }

  // Одразу повідомити агенту актуальну частоту телеметрії.
  pushTelemetryRate(comp, cleanCode, hwid);

  ws.on('message', (msg, isBinary) => {
    // Resolve the canonical record every time. This makes a D1 refresh unable
    // to leave the agent message handler updating a detached old object.
    const currentComp = findComputer(comp.hwid) || findComputer(comp.code) || comp;
    currentComp.agentWs = ws;
    currentComp.lastSeen = Date.now();
    currentComp.isOnline = true;

    // ТЗ 49: бінарний медіа-кадр [0xFC][тип][ts u32 LE][payload] — форвард як є.
    // Мінус 25% байт (без base64) і нуль JSON-парсингу мегабайтних рядків.
    if (isBinary) {
      const bin = Buffer.isBuffer(msg) ? msg : Buffer.from(msg);
      const cat = (bin.length > 1 && bin[1] === 2) ? 'audio' : 'screen';
      countTraffic(cat, bin.length);
      const binClients = getClientsForComp(currentComp, cleanCode, hwid);
      for (const clientWs of binClients) {
        if (clientWs.readyState === WebSocket.OPEN) {
          try { countTraffic(cat, bin.length); clientWs.send(bin, { binary: true }); } catch (err) {
            console.error(`[RELAY] Error sending binary to client: ${err.message}`);
          }
        }
      }
      return;
    }

    const textMsg = typeof msg === 'string' ? msg : msg.toString('utf8');
    
    let msgType = 'unknown';
    try {
      const parsed = JSON.parse(textMsg);
      msgType = parsed.type || 'unknown';
      if (parsed && (parsed.type === 'telemetry' || parsed.type === 'pong')) {
        currentComp.lastTelemetry = parsed;
      }
      // WoL: REST-запит /api/wol чекає підтвердження від агента-донора.
      if (parsed && parsed.type === 'wol_result' && parsed.requestId && wolPending.has(parsed.requestId)) {
        const pending = wolPending.get(parsed.requestId);
        wolPending.delete(parsed.requestId);
        clearTimeout(pending.timer);
        if (!pending.res.headersSent) {
          pending.res.json({
            success: Boolean(parsed.ok),
            message: parsed.message || (parsed.ok ? 'Команду пробудження надіслано.' : 'Пристрій-донор не зміг надіслати пакет.')
          });
        }
      }

      countTraffic(trafficCategory(msgType), Buffer.byteLength(textMsg));

      // ---------- DIRECT («Пряме з'єднання», ТЗ 50): URL тунелю пристрою ----------
      // Агент реєструє публічний URL прямого каналу + одноразовий ключ. Сервер
      // зберігає їх на записі пристрою і віддає ЛИШЕ власнику (у device list),
      // щоб панель могла підключатись напряму минаючи релей.
      if (parsed && parsed.type === 'direct_register') {
        try {
          const dUrl = String(parsed.data?.url || '');
          const dKey = String(parsed.data?.key || '');
          if (dUrl.startsWith('https://') && dUrl.includes('.trycloudflare.com') && dKey.length >= 16) {
            currentComp.directUrl = dUrl;
            currentComp.directKey = dKey;
            currentComp.directAt = Date.now();
            console.log(`[DIRECT] ${currentComp.hwid}: tunnel registered`);
          } else {
            // Некоректні дані — прибираємо застарілий запис, щоб панель
            // не намагалась підключитись до мертвого тунелю.
            currentComp.directUrl = null;
            currentComp.directKey = null;
          }
        } catch (e) {}
        return; // оброблено сервером, панелям не форвардимо
      }

      // ---------- SHARE («Поділитися», ТЗ): серверні типи, клієнтам НЕ форвардимо ----------
      if (parsed && parsed.type === 'share_register_all') {
        try {
          const shares = Array.isArray(parsed.data?.shares) ? parsed.data.shares : [];
          // Прибираємо попередні токени цього агента, реєструємо свіжі.
          for (const [t, s] of shareRegistry) {
            if (s.hwid === comp.hwid) shareRegistry.delete(t);
          }
          for (const s of shares) {
            if (!s?.token) continue;
            shareRegistry.set(String(s.token), {
              compKey: comp.id, code: comp.code, hwid: comp.hwid,
              name: String(s.name || 'share'),
              isDir: Boolean(s.isDir),
              sizeBytes: Number(s.sizeBytes) || 0,
              createdAt: Date.now()
            });
          }
          console.log(`[RELAY] [SHARE] ${comp.hwid}: registered ${shares.length} share link(s)`);
          // ТЗ 45: дублюємо реєстр у D1 — /s/<token> може прилетіти на ІНШИЙ
          // ізолят Deno Deploy, де пам'яті цього процесу немає.
          (async () => {
            if (!(await ensureShareInfraTables())) return;
            try {
              await queryD1(`DELETE FROM share_tokens WHERE hwid = ?;`, [comp.hwid]);
              for (const sh of shares) {
                if (!sh?.token) continue;
                await queryD1(`INSERT INTO share_tokens (token, hwid, code, name, is_dir, size_bytes, created_at)
                  VALUES (?, ?, ?, ?, ?, ?, ?)
                  ON CONFLICT(token) DO UPDATE SET hwid=excluded.hwid, name=excluded.name,
                    is_dir=excluded.is_dir, size_bytes=excluded.size_bytes, created_at=excluded.created_at;`,
                  [String(sh.token), comp.hwid, comp.code || '',
                   String(sh.name || 'share'), sh.isDir ? 1 : 0, Number(sh.sizeBytes) || 0, Date.now()]);
              }
            } catch (e) { console.warn('[SHARE][D1] register failed:', e.message); }
          })();
        } catch (e) {}
        return; // оброблено сервером
      }
      if (parsed && (parsed.type === 'share_chunk' || parsed.type === 'share_chunk_end' || parsed.type === 'share_stream_meta')) {
        try {
          const st = shareStreams.get(parsed.data?.streamId);
          if (st && !st.res.writableEnded) {
            if (parsed.type === 'share_chunk') {
              const buf = Buffer.from(String(parsed.data.data || ''), 'base64');
              st.bytes += buf.length;
              st.res.write(buf);
              if (parsed.data.last) {
                st.res.end();
                shareStreams.delete(parsed.data.streamId);
              }
            } else if (parsed.type === 'share_chunk_end') {
              // ok=false → агент впав/файл зник: закриваємо те, що встигли віддати.
              st.res.end();
              shareStreams.delete(parsed.data.streamId);
            }
            // share_stream_meta — інформаційний, у відповідь не пише.
          } else {
            // КРОС-ІЗОЛЯТ (ТЗ 45): цей HTTP-стрім тримає ІНШИЙ ізолят —
            // складаємо чанки в D1, той ізолят забере їх полінгом.
            // Чанки пишемо ЛИШЕ коли D1-інфраструктура реально готова
            // (інакше read-only токен спамив «no such table» на кожен чанк).
            const sid = String(parsed.data?.streamId || '');
            if (sid && _shareTablesReady) {
              if (!crossChunkSeq.has(sid)) crossChunkSeq.set(sid, 0);
              const seq = crossChunkSeq.get(sid) + 1;
              crossChunkSeq.set(sid, seq);
              const last = parsed.type === 'share_chunk' ? (parsed.data?.last ? 1 : 0) : 1;
              const data = parsed.type === 'share_chunk' ? String(parsed.data?.data || '') : '';
              if (parsed.type === 'share_chunk_end') crossChunkSeq.delete(sid);
              queryD1(`INSERT INTO share_chunks (stream_id, seq, data, last) VALUES (?, ?, ?, ?);`,
                [sid, seq, data, last]).catch(() => {});
            }
          }
        } catch (e) {}
        return; // оброблено сервером
      }
    } catch {}

    const clients = getClientsForComp(currentComp, cleanCode, hwid);
    if (clients.length > 0) {
      const cat = trafficCategory(msgType);
      if (!QUIET_LOG_TYPES.has(msgType) && msgType !== 'telemetry') {
        console.log(`[RELAY] [AGENT -> CLIENT] Type: ${msgType} -> forwarding to ${clients.length} client(s)`);
      }
      for (const clientWs of clients) {
        if (clientWs.readyState === WebSocket.OPEN) {
          try { countTraffic(cat, Buffer.byteLength(textMsg)); clientWs.send(textMsg); } catch (err) {
            console.error(`[RELAY] Error sending to client: ${err.message}`);
          }
        }
      }
    }
  });

  ws.on('close', (codeNum, reason) => {
    console.log(`[RELAY] [AGENT DISCONNECTED] HWID=${comp.hwid}, Code=${cleanCode} (Code: ${codeNum})`);
    comp.isOnline = false;
    if (comp.agentWs === ws) comp.agentWs = null;
    // Тунель прямого каналу живе разом із процесом агента — URL більше не
    // працює. Прибираємо, щоб панель одразу йшла через релей без таймаутів.
    comp.directUrl = null;
    comp.directKey = null;
    // Do not broadcast Offline immediately: the desktop agent reconnects in
    // four seconds. The health monitor below confirms a real 12s timeout.
  });

  ws.on('error', (err) => {
    console.error(`[RELAY] [AGENT WS ERROR] HWID=${comp.hwid}: ${err.message}`);
  });
}

function handleClientConnection(ws, code, hwid) {
  const targetKey = (code || hwid || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase();
  if (!targetKey) {
    console.warn('[RELAY] [CLIENT REJECTED] Missing target Code or HWID');
    ws.close(1008, 'Target code or HWID required');
    return;
  }

  ws.isClient = true;
  ws.clientTargetKey = targetKey;

  const currentList = webClients.get(targetKey) || [];
  currentList.push(ws);
  webClients.set(targetKey, currentList);

  const comp = findComputer(targetKey) || computersDb.get(targetKey);

  // Find active agent WebSocket
  let activeAgentWs = (comp?.agentWs && comp.agentWs.readyState === WebSocket.OPEN) ? comp.agentWs : null;
  if (!activeAgentWs) {
    for (const clientSocket of wss.clients) {
      if (clientSocket.readyState === WebSocket.OPEN && clientSocket.isAgent) {
        if (clientSocket.agentCode === targetKey || clientSocket.agentHwid === targetKey || (comp && (clientSocket.agentCode === comp.code || clientSocket.agentHwid === comp.hwid))) {
          activeAgentWs = clientSocket;
          if (comp) comp.agentWs = clientSocket;
          break;
        }
      }
    }
  }

  const isAgentOnline = isComputerOnline(comp);
  console.log(`[RELAY] [CLIENT CONNECTED] Target PC: ${targetKey}, Agent Online: ${isAgentOnline}`);

  // Send status immediately to client
  ws.send(JSON.stringify({
    type: 'agent_status',
    status: isAgentOnline ? 'online' : 'offline',
    computerName: comp?.name || 'ПК'
  }));

  // Ask the agent for an actual response. Do not fabricate a pong here: a
  // cached socket can be OPEN while the machine is no longer reachable.
  if (isAgentOnline) {
    if (comp?.lastTelemetry) {
      console.log(`[RELAY] [CLIENT FAST-START] Sending cached telemetry to client for ${targetKey}`);
      try {
        ws.send(JSON.stringify(comp.lastTelemetry));
      } catch {}
    }

    // Request instant fresh telemetry from desktop agent
    try {
      activeAgentWs.send(JSON.stringify({ type: 'health_check' }));
      activeAgentWs.send(JSON.stringify({ type: 'telemetry' }));
    } catch {}
  }

  // Відкрилася сесія — агент переходить на швидку телеметрію (1с).
  pushTelemetryRate(comp, targetKey, targetKey, activeAgentWs);

  ws.on('message', (msg, isBinary) => {
    const textMsg = isBinary ? '' : (typeof msg === 'string' ? msg : msg.toString('utf8'));
    let msgType = 'unknown';
    if (!isBinary) {
      try {
        const parsed = JSON.parse(textMsg);
        msgType = parsed.type || 'unknown';
      } catch {}
    }
    const cat = isBinary ? 'control' : trafficCategory(msgType);
    countTraffic(cat, isBinary ? (Buffer.isBuffer(msg) ? msg.length : Buffer.from(msg).length) : Buffer.byteLength(textMsg));

    if (!QUIET_LOG_TYPES.has(msgType)) {
      console.log(`[RELAY] [CLIENT -> AGENT] Target: ${targetKey}, Type: ${msgType}`);
    }

    let liveAgentWs = (comp?.agentWs && comp.agentWs.readyState === WebSocket.OPEN) ? comp.agentWs : activeAgentWs;
    if (!liveAgentWs || liveAgentWs.readyState !== WebSocket.OPEN) {
      for (const clientSocket of wss.clients) {
        if (clientSocket.readyState === WebSocket.OPEN && clientSocket.isAgent) {
          if (clientSocket.agentCode === targetKey || clientSocket.agentHwid === targetKey || (comp && (clientSocket.agentCode === comp.code || clientSocket.agentHwid === comp.hwid))) {
            liveAgentWs = clientSocket;
            if (comp) comp.agentWs = clientSocket;
            break;
          }
        }
      }
    }

    if (liveAgentWs && liveAgentWs.readyState === WebSocket.OPEN) {
      try {
        if (isBinary) {
          const bin = Buffer.isBuffer(msg) ? msg : Buffer.from(msg);
          liveAgentWs.send(bin, { binary: true });
          countTraffic(cat, bin.length);
        } else {
          liveAgentWs.send(textMsg);
          countTraffic(cat, Buffer.byteLength(textMsg));
        }
      } catch (err) {
        console.error(`[RELAY] Error sending command to agent: ${err.message}`);
      }
    } else {
      // Троттлінг: одна й та сама причина («агент офлайн») не повинна
      // спамити лог на кожну команду панелі — раз на 10 секунд на ціль.
      const _k = `unreach:${targetKey}`;
      if (Date.now() - (_unreachLogAt.get(_k) || 0) > 10000) {
        _unreachLogAt.set(_k, Date.now());
        console.warn(`[RELAY] [AGENT NOT REACHABLE] Cannot forward ${msgType} to ${targetKey}`);
      }
      ws.send(JSON.stringify({ type: 'agent_status', status: 'offline' }));
    }
  });

  ws.on('close', (codeNum) => {
    for (const [k, list] of webClients.entries()) {
      const idx = list.indexOf(ws);
      if (idx !== -1) list.splice(idx, 1);
    }
    console.log(`[RELAY] [CLIENT DISCONNECTED] Target PC: ${targetKey} (Code: ${codeNum})`);
    // Закрилася остання вкладка — агент повертається на повільну телеметрію (8с).
    const compAfter = findComputer(targetKey) || computersDb.get(targetKey);
    pushTelemetryRate(compAfter, targetKey, targetKey);
  });

  ws.on('error', (err) => {
    console.error(`[RELAY] [CLIENT WS ERROR] Target PC ${targetKey}: ${err.message}`);
  });
}

server.listen(PORT, () => {
  console.log(`[FluxControl] Relay server v5.5.0 running on port ${PORT}`);
  console.log(`[FluxControl] Cloudflare D1 database: ${CLOUDFLARE_D1_CONFIG.databaseId}`);
});
