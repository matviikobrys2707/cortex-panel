@echo off
chcp 65001 >nul
setlocal EnableExtensions
cd /d "%~dp0"
title FluxControl Deploy Manager v7.1

:MENU
cls
echo.
echo   ███████╗██╗     ██╗   ██╗██╗  ██╗
echo   ██╔════╝██║     ██║   ██║╚██╗██╔╝   FLUXCONTROL  DEPLOY  MANAGER
echo   █████╗  ██║     ██║   ██║ ╚███╔╝   єдиний скрипт · v7.1
echo   ██╔╝  ██║     ██║   ██║ ██╔██╗   без окремих ps1 - уся логіка тут
echo   ███████╗███████╗╚██████╔╝██╔╝ ██╗
echo   ╚══════╝╚══════╝ ╚═════╝ ╚═╝  ╚═╝
echo    %cd%
echo.
echo    [1] FULL DEPLOY          агент + сайт + сервер (все одразу)
echo    [2] Агент · компіляція   збірка exe без деплою
echo    [3] Агент · деплой       версія + changelog + публікація на сайт
echo    [4] Сайт · компіляція    npm run build без деплою
echo    [5] Сайт+Сервер · деплой Cloudflare Pages + Render
echo    [6] Сервер · перевірка   node --check server.js
echo    [7] Сервер · деплой      пуш у FluxControl-Backend (Render)
echo    [9] Changelog            опис версії у блокноті
echo    [0] Вихід
echo.
echo    npm install виконується автоматично. Репозиторії:
echo    сайт/оновлення matviikobrys2707/FluxControl · сервер FluxControl-Backend
echo.
set "choice="
set /p "choice=   Обери дію: "
if "%choice%"=="1" ( set "FLUX_ACTION=full" & goto RUNPS )
if "%choice%"=="2" ( set "FLUX_ACTION=agent-build" & goto RUNPS )
if "%choice%"=="3" ( set "FLUX_ACTION=agent-deploy" & goto RUNPS )
if "%choice%"=="4" ( set "FLUX_ACTION=web-build" & goto RUNPS )
if "%choice%"=="5" ( set "FLUX_ACTION=web-server-deploy" & goto RUNPS )
if "%choice%"=="6" ( set "FLUX_ACTION=server-check" & goto RUNPS )
if "%choice%"=="7" ( set "FLUX_ACTION=server-deploy" & goto RUNPS )
if "%choice%"=="9" goto CHANGELOG
if "%choice%"=="0" exit /b 0
goto MENU

:CHANGELOG
if not exist "changelog.md" break > "changelog.md"
start notepad "changelog.md"
goto MENU

:RUNPS
set "FLUX_BAT=%~f0"
set "FLUX_ROOT=%~dp0"
rem Фікс v7.1: маркер конструюється в рантаймі ([char]35+'@…'), щоб рядок
rem виклику НЕ містив літерального маркера — інакше IndexOf знаходить сам себе
rem і PowerShell виконує batch-рядки (помилка 'echo. is not recognized').
powershell -NoProfile -ExecutionPolicy Bypass -Command "$c=[IO.File]::ReadAllText($env:FLUX_BAT);$m=[char]35+'@FLUX-PS-BLOCK@';$i=$c.IndexOf($m);if($i -lt 0){Write-Host 'FLUX-ERROR: payload marker not found' -ForegroundColor Red;exit 1};$j=$c.IndexOf([char]10,$i);if($j -lt 0){Write-Host 'FLUX-ERROR: payload truncated' -ForegroundColor Red;exit 1};Invoke-Expression $c.Substring($j+1)"
echo.
pause
goto MENU

exit /b 0
#@FLUX-PS-BLOCK@
# ================= FLUXCONTROL DEPLOY CORE v7 (єдиний скрипт) =================
# Портовано з Auto-Deploy.ps1 v6 + Web-Deploy.ps1 v6.1. Працює на PS 5.1.
$ErrorActionPreference = 'Stop'
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch { }
try { $OutputEncoding = [System.Text.Encoding]::UTF8 } catch { }
Write-Host ''
Write-Host '  FLUXCONTROL DEPLOY CORE v7.1' -ForegroundColor Magenta

try {
    [Net.ServicePointManager]::SecurityProtocol =
        [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
} catch { }

$Root = (Get-Location).Path
if ($env:FLUX_ROOT) { $Root = $env:FLUX_ROOT.TrimEnd('\') }
$AgentDir   = $null; $WebDir = $null; $ServerDir = $null
foreach ($n in @('FluxControl Agent', 'FluxControl.Agent')) { $p = Join-Path $Root $n; if (Test-Path -LiteralPath $p) { $AgentDir = $p; break } }
foreach ($n in @('FluxControl Web', 'FluxControl.Web'))     { $p = Join-Path $Root $n; if (Test-Path -LiteralPath $p) { $WebDir = $p; break } }
foreach ($n in @('FluxControl Server', 'FluxControl.Server')) { $p = Join-Path $Root $n; if (Test-Path -LiteralPath $p) { $ServerDir = $p; break } }

$DeployDir     = Join-Path $Root '_deploy'
$FilesDir      = Join-Path $DeployDir 'files'
$PublishDir    = Join-Path $DeployDir '.publish'
$UserExe       = Join-Path $DeployDir 'FluxControl.exe'
$JsonOut       = Join-Path $DeployDir 'version.json'
$ChangelogFile  = Join-Path $Root 'changelog.md'
$ChangelogFile2 = Join-Path $Root 'changelog.txt'
$ChangelogsDir  = Join-Path $Root 'changelogs'

$Repo        = 'matviikobrys2707/FluxControl'
$BackendRepo = 'matviikobrys2707/FluxControl-Backend'
$SiteBase       = 'https://fluxcontrol.pages.dev'
$SiteExeUrl     = "$SiteBase/FluxControl.exe"
$SiteVersionUrl = "$SiteBase/version.json"
$ProxyVersionUrl = 'https://fluxcontrol-backend-bl3u.onrender.com/update/version.json'
$utf8NoBom      = New-Object System.Text.UTF8Encoding($false)

function Write-Step { param([string]$t) Write-Host ''; Write-Host "  $t" -ForegroundColor Cyan }
function Write-Ok   { param([string]$t) Write-Host "    [OK] $t" -ForegroundColor Green }
function Write-Fail { param([string]$t) Write-Host "    [X]  $t" -ForegroundColor Red }
function Write-Info { param([string]$t) Write-Host "    [i]  $t" -ForegroundColor Yellow }

function Get-NormalizedVersion([string]$raw) {
    if ($null -eq $raw) { $raw = '' }
    $v = ($raw -replace '[^0-9\.]', '')
    $parts = $v.Split('.')
    if ($parts.Length -gt 3) { $v = ($parts[0..2] -join '.') }
    return $v
}

function Get-NextVersion([string]$raw) {
    $v = Get-NormalizedVersion $raw
    $parts = $v.Split('.')
    if ($parts.Length -ne 3) { return '1.0.1' }
    $maj = 0; $min = 0; $pat = 0
    [void][int]::TryParse($parts[0], [ref]$maj)
    [void][int]::TryParse($parts[1], [ref]$min)
    [void][int]::TryParse($parts[2], [ref]$pat)
    if ($maj -eq 0 -and $min -eq 0 -and $pat -eq 0) { return '1.0.1' }
    return "$maj.$min.$($pat + 1)"
}

# --- git-виклики без NativeCommandError (stderr -> звичайний текст) ---
# Фікс v7.1: ПРОСТІ функції ($args) замість [Parameter(ValueFromRemainingArguments)].
# Advanced-функція падає на '-C'/'--depth'/'-b' ("A parameter cannot be found that
# matches parameter name 'C'") — усі git-прапорці тепер проходять наскрізь.
# '-C' розпізнається ЛИШЕ регістр-чутливо (малий '-c' = git config, це аргумент).
function Invoke-GitOut {
    $prev = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    $dir = $null
    $rest = @()
    if ($args.Count -ge 2 -and "$($args[0])" -ceq '-C') {
        $dir = "$($args[1])"
        if ($args.Count -gt 2) { $rest = @($args[2..($args.Count - 1)]) }
    } elseif ($args.Count -gt 0) {
        $rest = @($args)
    }
    if ($dir) { Push-Location -LiteralPath $dir }
    try {
        $out = & git @rest 2>&1
        $code = $LASTEXITCODE
        $lines = @($out | ForEach-Object { "$_" })
        return @{ code = $code; lines = $lines }
    } finally {
        if ($dir) { Pop-Location }
        $ErrorActionPreference = $prev
    }
}

function Invoke-Git {
    $r = Invoke-GitOut @args
    foreach ($l in $r.lines) { if ($l) { Write-Host "      git> $l" -ForegroundColor DarkGray } }
    return $r.code
}

function Ensure-GitRepo {
    param([string]$Dir, [string]$OriginUrl)
    if (-not (Test-Path (Join-Path $Dir '.git'))) {
        $null = Invoke-GitOut -C $Dir init -b main
        Write-Info "git init (новий репозиторій): $Dir"
    }
    $rem = Invoke-GitOut -C $Dir remote
    $names = @($rem.lines | ForEach-Object { ("$_").Trim() } | Where-Object { $_ })
    if ($names -contains 'origin') {
        $null = Invoke-GitOut -C $Dir remote set-url origin $OriginUrl
    } else {
        $null = Invoke-GitOut -C $Dir remote add origin $OriginUrl
    }
}

# --- авторизація GitHub: gh CLI -> GITHUB_TOKEN -> вручну ---
function Ensure-GitAuth {
    param([switch]$Interactive)
    if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
        Write-Fail 'git не знайдено — встанови Git for Windows (git-scm.com)'
        return 'none'
    }
    $prev = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
    try {
        $gh = Get-Command gh -ErrorAction SilentlyContinue
        if ($gh) {
            & gh auth status *>$null
            if ($LASTEXITCODE -ne 0 -and $Interactive) {
                Write-Host ''
                Write-Info 'gh не авторизовано. Зараз відкриється вхід у GitHub.'
                Write-Info 'Обери: GitHub.com -> HTTPS -> Login with a web browser.'
                & gh auth login --hostname github.com --git-protocol https --web
                & gh auth status *>$null
            }
            if ($LASTEXITCODE -eq 0) {
                & gh auth setup-git *>$null
                Write-Ok 'GitHub CLI готовий — повний автомат'
                return 'gh'
            }
        }
        if ($env:GITHUB_TOKEN) {
            Write-Ok 'GITHUB_TOKEN знайдено — публікація через git'
            return 'token'
        }
        return 'none'
    } finally { $ErrorActionPreference = $prev }
}

function Reset-DeployDir {
    $locked = @()
    foreach ($p in Get-Process -ErrorAction SilentlyContinue) {
        try {
            if ($p.MainModule -and $p.MainModule.FileName -and
                $p.MainModule.FileName.StartsWith($DeployDir, [StringComparison]::OrdinalIgnoreCase)) {
                $locked += $p
            }
        } catch { }
    }
    foreach ($p in $locked) {
        Write-Host "    [!] Завершую процес, що тримає файли _deploy: $($p.ProcessName) (pid $($p.Id))" -ForegroundColor Yellow
        try {
            $stopFile = Join-Path $env:APPDATA 'FluxControl\watchdog.stop'
            New-Item -ItemType Directory -Force -Path (Split-Path $stopFile) | Out-Null
            Set-Content -Path $stopFile -Value ([DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds().ToString()) -ErrorAction SilentlyContinue
        } catch { }
        try { Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue } catch { }
    }
    if ($locked.Count -gt 0) { Start-Sleep -Milliseconds 800 }
    New-Item -ItemType Directory -Force -Path $DeployDir | Out-Null
    for ($i = 1; $i -le 5; $i++) {
        $left = Get-ChildItem -LiteralPath $DeployDir -Force -ErrorAction SilentlyContinue
        if (-not $left) { return $true }
        foreach ($item in $left) { Remove-Item -LiteralPath $item.FullName -Recurse -Force -ErrorAction SilentlyContinue }
        Start-Sleep -Milliseconds (300 * $i)
    }
    $left = Get-ChildItem -LiteralPath $DeployDir -Force -ErrorAction SilentlyContinue
    if ($left) {
        Write-Fail 'Не вдалося очистити _deploy (файли зайняті). Закрий програми в _deploy і спробуй ще раз.'
        return $false
    }
    return $true
}

function Get-SiteVersion {
    $current = $null
    foreach ($u in @($SiteVersionUrl, $ProxyVersionUrl)) {
        for ($attempt = 1; $attempt -le 3; $attempt++) {
            try {
                $probe = $u + "?t=" + [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
                $resp  = Invoke-WebRequest -UseBasicParsing -Uri $probe -Headers @{ 'User-Agent' = 'FluxControl-Deploy' } -TimeoutSec 15
                $meta  = $resp.Content | ConvertFrom-Json
                $v = [string]$meta.latest_version
                if ($v) { $current = $v; break }
            } catch {
                $code = 0
                if ($_.Exception.Response -and $_.Exception.Response.StatusCode) {
                    $code = [int]$_.Exception.Response.StatusCode
                }
                if ($code -ne 404) {
                    Write-Host "    [i] $u недоступний (спроба $attempt/3)" -ForegroundColor Yellow
                    if ($attempt -lt 3) { Start-Sleep -Milliseconds 1500 }
                } else { break }
            }
        }
        if ($current) { break }
    }
    if ($current) { $current = Get-NormalizedVersion $current }

    # Фікс v7.1: МАКСИМУМ latest_version + УСІХ версій з versions.json.
    # Зірваний/частковий деплой міг опублікувати меншу latest_version (даунгрейд),
    # тоді підказка була б НИЖЧЕ за встановлену на ПК — самооновлення не спрацювало б.
    $all = @()
    if ($current) { $all += $current }
    foreach ($base2 in @($SiteBase, 'https://fluxcontrol-backend-bl3u.onrender.com/update')) {
      try {
        $probe2 = "$base2/versions.json?t=" + [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
        $resp2  = Invoke-WebRequest -UseBasicParsing -Uri $probe2 -Headers @{ 'User-Agent' = 'FluxControl-Deploy' } -TimeoutSec 15
        $idx = $resp2.Content | ConvertFrom-Json
        if ($idx.latest_version) { $all += (Get-NormalizedVersion "$($idx.latest_version)") }
        foreach ($v in @($idx.versions)) {
            if ($null -ne $v -and $v.version) { $all += (Get-NormalizedVersion "$($v.version)") }
        }
        break
      } catch { }
    }
    $valid = @($all | Where-Object { $_ -match '^\d+\.\d+\.\d+$' })
    if ($valid.Count -gt 0) {
        $top = $valid | Sort-Object -Property { [version]$_ } -Descending | Select-Object -First 1
        return "$top"
    }
    return $current
}

function Get-ChangelogText {
    $clSource = $null
    if (Test-Path -LiteralPath $ChangelogFile)  { $clSource = $ChangelogFile }
    elseif (Test-Path -LiteralPath $ChangelogFile2) { $clSource = $ChangelogFile2 }
    $text = ''
    if ($clSource) {
        try { $text = ([IO.File]::ReadAllText($clSource)).Trim() } catch { $text = '' }
    }
    if ($text.Length -eq 0) {
        $text = 'Виправлення та покращення стабільності.'
        Write-Info 'changelog.md порожній/відсутній — вкладаю стандартний текст.'
        Write-Host '        (напиши опис змін у changelog.md перед деплоєм — він поїде на сайт)' -ForegroundColor DarkGray
    } else {
        Write-Ok ("Changelog: {0} символів з changelog.md" -f $text.Length)
    }
    return @{ text = $text; source = $clSource }
}

function Invoke-AgentBuild([string]$Version) {
    # Повертає $true якщо exe готовий у $UserExe.
    if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
        Write-Fail 'dotnet SDK не знайдено (встанови .NET 8 SDK)'; return $false
    }
    if (-not (Reset-DeployDir)) { return $false }
    New-Item -ItemType Directory -Force -Path $FilesDir, $PublishDir | Out-Null
    $AgentCsproj = Join-Path $AgentDir 'FluxControl.Agent.csproj'
    Write-Step 'FluxControl.exe (framework-dependent single-file)'

    # Чистий білд: біті кеші obj/bin дають фантомні CS0246.
    Remove-Item -LiteralPath (Join-Path $AgentDir 'obj'), (Join-Path $AgentDir 'bin') `
        -Recurse -Force -ErrorAction SilentlyContinue

    $prev = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
    & dotnet publish $AgentCsproj -c Release -r win-x64 --self-contained false `
        -p:PublishSingleFile=true `
        -p:IncludeNativeLibrariesForSelfExtract=true `
        -p:DebugType=none -p:DebugSymbols=false `
        -p:EnableWindowsTargeting=true `
        -p:EnableCompressionInSingleFile=false `
        -p:Version=$Version `
        -o $PublishDir
    $code = $LASTEXITCODE
    $ErrorActionPreference = $prev
    if ($code -ne 0) { Write-Fail "dotnet publish завершився з кодом $code"; return $false }

    $builtExe = Join-Path $PublishDir 'FluxControl.exe'
    if (-not (Test-Path -LiteralPath $builtExe)) { Write-Fail 'FluxControl.exe не знайдено після publish'; return $false }
    Copy-Item -LiteralPath $builtExe -Destination $UserExe -Force
    Write-Ok ("FluxControl.exe: {0} МБ" -f [Math]::Round((Get-Item -LiteralPath $UserExe).Length / 1MB, 2))

    Copy-Item -LiteralPath $builtExe -Destination (Join-Path $FilesDir 'FluxControl.exe') -Force
    New-Item -ItemType Directory -Force -Path (Join-Path $FilesDir 'UI') | Out-Null
    Copy-Item (Join-Path $AgentDir 'UI\agent_ui.html') (Join-Path $FilesDir 'UI\agent_ui.html') -Force
    Copy-Item (Join-Path $AgentDir 'logo.ico') (Join-Path $FilesDir 'logo.ico') -Force
    Write-Ok 'files\: exe + UI\agent_ui.html + logo.ico'
    Remove-Item -LiteralPath $PublishDir -Recurse -Force -ErrorAction SilentlyContinue
    return $true
}

function New-Manifest([string]$Version, [string]$changelogText) {
    $filesList = @()
    foreach ($f in (Get-ChildItem -LiteralPath $FilesDir -File -Recurse)) {
        if ($f.Name -eq 'FluxControl.exe') { continue }
        $rel = [IO.Path]::GetFullPath($f.FullName).Substring([IO.Path]::GetFullPath($FilesDir).Length + 1).Replace('\', '/')
        $h = (Get-FileHash -LiteralPath $f.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
        $filesList += @{ name = $rel; sha256 = $h }
    }
    $exeSha = (Get-FileHash -LiteralPath $UserExe -Algorithm SHA256).Hash.ToLowerInvariant()
    $manifest = [ordered]@{
        latest_version = $Version
        files          = $filesList
        download_url   = $SiteExeUrl
        changelog      = $changelogText
        archive_url    = "$SiteBase/versions/$Version/FluxControl.exe"
        published_at   = [DateTimeOffset]::UtcNow.ToString('yyyy-MM-ddTHH:mm:ssZ')
    }
    $json = $manifest | ConvertTo-Json -Depth 4 -Compress
    [System.IO.File]::WriteAllText($JsonOut, $json + "`r`n", $utf8NoBom)
    Write-Ok "version.json (манифест): v$Version"
    return $exeSha
}

function Publish-SiteFiles([string]$Version, [string]$changelogText, [string]$cloneUrl) {
    $repoDir = Join-Path $DeployDir '.repo'
    if (Test-Path -LiteralPath $repoDir) { Remove-Item -LiteralPath $repoDir -Recurse -Force -ErrorAction SilentlyContinue }
    Write-Host '    [-] Клоную репозиторій сайту…'
    $r = Invoke-GitOut clone --depth 1 $cloneUrl $repoDir
    if ($r.code -ne 0) { throw "git clone не вдався ($Repo)" }

    Copy-Item -LiteralPath $UserExe -Destination (Join-Path $repoDir 'FluxControl.exe') -Force
    Copy-Item -LiteralPath $JsonOut -Destination (Join-Path $repoDir 'version.json') -Force
    New-Item -ItemType Directory -Force -Path (Join-Path $repoDir 'UI') | Out-Null
    Copy-Item (Join-Path $FilesDir 'UI\agent_ui.html') (Join-Path $repoDir 'UI\agent_ui.html') -Force
    Copy-Item (Join-Path $FilesDir 'logo.ico') (Join-Path $repoDir 'logo.ico') -Force

    # Архів версій: versions/<v>/exe + changelog + sha256 (для відкатів).
    $verDir = Join-Path $repoDir "versions\$Version"
    New-Item -ItemType Directory -Force -Path $verDir | Out-Null
    Copy-Item -LiteralPath $UserExe -Destination (Join-Path $verDir 'FluxControl.exe') -Force
    [IO.File]::WriteAllText((Join-Path $verDir 'changelog.md'), $changelogText + "`r`n", $utf8NoBom)
    $exeSha = (Get-FileHash -LiteralPath $UserExe -Algorithm SHA256).Hash.ToLowerInvariant()
    [IO.File]::WriteAllText((Join-Path $verDir 'sha256.txt'), "$exeSha  FluxControl.exe`r`n", $utf8NoBom)
    $sizeMb = [Math]::Round((Get-Item -LiteralPath $UserExe).Length / 1MB, 2)
    Write-Ok "Архів: versions\$Version\ ($sizeMb МБ) + changelog + sha256"

    # versions.json — append-only індекс, новіші зверху.
    $indexPath = Join-Path $repoDir 'versions.json'
    $versionsList = @()
    if (Test-Path -LiteralPath $indexPath) {
        try {
            $existing = Get-Content -LiteralPath $indexPath -Raw -Encoding UTF8 | ConvertFrom-Json
            foreach ($v in @($existing.versions)) {
                if ($null -ne $v -and $v.version -and "$($v.version)" -ne $Version) { $versionsList += $v }
            }
        } catch { }
    }
    $versionsList += [ordered]@{
        version   = $Version
        date      = [DateTimeOffset]::UtcNow.ToString('yyyy-MM-dd')
        sha256    = $exeSha
        sizeMb    = $sizeMb
        changelog = $changelogText
    }
    $sortable = foreach ($v in $versionsList) {
        $pv = "$($v.version)".Split('.')
        $k1 = 0; $k2 = 0; $k3 = 0
        if ($pv.Length -eq 3) {
            [void][int]::TryParse($pv[0], [ref]$k1)
            [void][int]::TryParse($pv[1], [ref]$k2)
            [void][int]::TryParse($pv[2], [ref]$k3)
        }
        [pscustomobject]@{
            version   = "$($v.version)"
            date      = "$($v.date)"
            sha256    = "$($v.sha256)"
            sizeMb    = "$($v.sizeMb)"
            changelog = "$($v.changelog)"
            sortKey   = '{0:D6}.{1:D6}.{2:D6}' -f $k1, $k2, $k3
        }
    }
    $sorted = $sortable | Sort-Object -Property sortKey -Descending
    $index = [ordered]@{
        latest_version = $Version
        updated_at     = [DateTimeOffset]::UtcNow.ToString('yyyy-MM-ddTHH:mm:ssZ')
        versions       = @($sorted)
    }
    [IO.File]::WriteAllText($indexPath, ($index | ConvertTo-Json -Depth 5) + "`r`n", $utf8NoBom)
    Write-Ok ("versions.json: {0} версій в індексі" -f @($sorted).Count)

    $null = Invoke-Git -C $repoDir add -A
    $null = Invoke-Git -C $repoDir -c user.name='FluxControl Deploy' -c user.email='deploy@users.noreply.github.com' commit -m "Release v$Version"
    $code = Invoke-Git -C $repoDir push origin HEAD:main
    if ($code -ne 0) { throw "git push не вдався ($Repo)" }
    Remove-Item -LiteralPath $repoDir -Recurse -Force -ErrorAction SilentlyContinue
    Write-Ok 'Сайт оновлено: exe + version.json + UI + logo + архів версій (Pages ~30с)'
}

function Invoke-AgentDeploy {
    if (-not $AgentDir) { Write-Fail "Не знайдено папку агента (FluxControl Agent)"; return $false }
    $AgentCsproj = Join-Path $AgentDir 'FluxControl.Agent.csproj'
    if (-not (Test-Path -LiteralPath $AgentCsproj)) { Write-Fail "Не знайдено $AgentCsproj"; return $false }

    Write-Step 'Крок 1/5 — поточна версія на сайті'
    $current = Get-SiteVersion
    if ($current) { Write-Ok "Поточна версія на сайті (макс з історії): v$current" }
    else { Write-Info 'version.json ще не існує — це перший деплой.' }

    Write-Step 'Крок 2/5 — версія (авто +0.0.1, формат 1.2.3)'
    $builtVersion = $null
    if (Test-Path -LiteralPath $UserExe) {
        try { $builtVersion = Get-NormalizedVersion (Get-Item -LiteralPath $UserExe).VersionInfo.FileVersion } catch { }
    }
    $baseForNext = $current; if (-not $baseForNext) { $baseForNext = $builtVersion }
    $suggested = '1.0.0'
    if ($baseForNext -match '^\d+\.\d+\.\d+$') { $suggested = Get-NextVersion $baseForNext }
    Write-Host '    Enter = автоматично НАСТУПНА версія (+0.0.1); або введи свій номер (1.2.3).' -ForegroundColor DarkGray
    $typed = Read-Host "    Версія [Enter = $suggested]"
    if ([string]::IsNullOrWhiteSpace($typed)) { $Version = $suggested } else { $Version = $typed.Trim() }
    $Version = Get-NormalizedVersion $Version
    if ($Version -notmatch '^\d+\.\d+\.\d+$') { Write-Fail "Невірний формат версії: '$Version'"; return $false }
    Write-Ok "Деплой: v$Version  (сайт: $(if ($current) { "v$current" } else { '-' }))"

    Write-Step 'Крок 2.5/5 — changelog цієї версії'
    $cl = Get-ChangelogText

    $reuse = $false
    if ($builtVersion -eq $Version -and (Test-Path -LiteralPath $UserExe) -and (Test-Path -LiteralPath $FilesDir)) {
        $reuse = $true
        Write-Ok "FluxControl.exe v$Version уже в _deploy — пересборка не потрібна"
    }
    if (-not $reuse) {
        $ok = Invoke-AgentBuild $Version
        if (-not $ok) { return $false }
    } else {
        New-Item -ItemType Directory -Force -Path (Join-Path $FilesDir 'UI') | Out-Null
        Copy-Item (Join-Path $AgentDir 'UI\agent_ui.html') (Join-Path $FilesDir 'UI\agent_ui.html') -Force
        Copy-Item (Join-Path $AgentDir 'logo.ico') (Join-Path $FilesDir 'logo.ico') -Force
    }

    Write-Step 'Крок 3.5/5 — манифест version.json'
    $exeSha = New-Manifest $Version $cl.text

    Write-Step 'Крок 4/5 — публікація на сайт (repo main -> Cloudflare Pages)'
    $mode = Ensure-GitAuth -Interactive
    if ($mode -eq 'gh') {
        try { Publish-SiteFiles $Version $cl.text "https://github.com/$Repo.git" }
        catch { Write-Fail $_.Exception.Message; Write-Fail 'Файли оновлення НЕ завантажено на сайт.'; return $false }
    } elseif ($mode -eq 'token') {
        try { Publish-SiteFiles $Version $cl.text "https://x-access-token:$($env:GITHUB_TOKEN)@github.com/$Repo.git" }
        catch { Write-Fail $_.Exception.Message; Write-Fail 'Файли оновлення НЕ завантажено на сайт.'; return $false }
    } else {
        Write-Host ''
        Write-Info 'Автодеплой недоступний (немає gh CLI і GITHUB_TOKEN).'
        Write-Info "Файли готові в _deploy: FluxControl.exe + version.json + files\"
        Write-Info "Завантаж їх у корінь main репо $Repo ('Add file -> Upload files')."
        Write-Info 'Щоб автоматизувати: winget install GitHub.cli  потім  gh auth login'
        return $false
    }

    Write-Step 'Крок 5/5 — локальний архів changelog'
    if ($cl.source) {
        try {
            New-Item -ItemType Directory -Force -Path $ChangelogsDir | Out-Null
            Move-Item -LiteralPath $cl.source -Destination (Join-Path $ChangelogsDir "$Version.md") -Force
            Write-Ok "Changelog збережено: changelogs\$Version.md"
        } catch { Write-Info 'Не вдалося перенести changelog — не критично.' }
    }

    Write-Host ''
    Write-Host '  ГОТОВО. Агент v' -NoNewline -ForegroundColor Green
    Write-Host $Version -NoNewline -ForegroundColor Green
    Write-Host ' опублікований на сайті.' -ForegroundColor Green
    Write-Host "    самооновлення : $SiteExeUrl" -ForegroundColor Green
    Write-Host "    манифест      : $SiteVersionUrl" -ForegroundColor Green
    Write-Host "    архів версій  : $SiteBase/versions/$Version/FluxControl.exe" -ForegroundColor Green
    return $true
}

function Invoke-WebBuild {
    if (-not $WebDir) { Write-Fail "Не знайдено папку сайту (FluxControl Web)"; return $false }
    if (-not (Get-Command npm -ErrorAction SilentlyContinue)) { Write-Fail 'npm не знайдено (встанови Node.js LTS)'; return $false }
    Write-Step 'Web: npm run build'
    if (-not (Test-Path (Join-Path $WebDir 'node_modules'))) {
        Write-Info 'node_modules відсутній — автоматично npm install...'
        $prev = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
        Push-Location $WebDir
        try { & npm install --no-fund --no-audit } finally { Pop-Location; $ErrorActionPreference = $prev }
        if ($LASTEXITCODE -ne 0) { Write-Fail 'npm install не вдався'; return $false }
        Write-Ok 'Залежності встановлено (авто)'
    }
    $prev = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
    Push-Location $WebDir
    try { & npm run build } finally { Pop-Location; $ErrorActionPreference = $prev }
    if ($LASTEXITCODE -ne 0) { Write-Fail 'Web build не вдався'; return $false }
    if (-not (Test-Path (Join-Path $WebDir 'dist'))) { Write-Fail 'Папка dist відсутня після білду'; return $false }
    Write-Ok 'Web зібрано'
    return $true
}

function Invoke-WebDeploy {
    $ok = Invoke-WebBuild
    if (-not $ok) { return $false }

    Write-Step 'Web: публікую dist у репозиторій сайту (Pages)'
    $mode = Ensure-GitAuth -Interactive
    if ($mode -eq 'none') {
        Write-Fail 'Немає gh CLI / GITHUB_TOKEN — автопуш неможливий. Виконай: gh auth login'
        return $false
    }
    $cloneUrl = "https://github.com/$Repo.git"
    if ($mode -eq 'token') { $cloneUrl = "https://x-access-token:$($env:GITHUB_TOKEN)@github.com/$Repo.git" }

    $distDir = Join-Path $WebDir 'dist'
    Ensure-GitRepo -Dir $distDir -OriginUrl "https://github.com/$Repo.git"
    $null = Invoke-GitOut -C $distDir fetch origin main
    # Веб-деплой НІКОЛИ не витирає файли оновлень агента + assets скримера.
    # Якщо origin/main недоступний — checkout просто тихо не спрацює.
    $restore = @('FluxControl.exe', 'version.json', 'versions.json', 'versions', 'UI', 'logo.ico', '_headers', 'assets')
    foreach ($item in $restore) {
        $r = Invoke-GitOut -C $distDir checkout origin/main -- $item
        if ($r.code -eq 0) { Write-Ok "Збережено з сайту: $item" }
    }
    $prev = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
    Push-Location $distDir
    try {
        git add -A
        $null = git -c user.name='FluxControl Deploy' -c user.email='deploy@users.noreply.github.com' commit -m 'Deploy Web' --allow-empty 2>&1
    } finally { Pop-Location; $ErrorActionPreference = $prev }
    $code = Invoke-Git -C $distDir push -u origin main --force
    if ($code -ne 0) { Write-Fail 'Web push не вдався (перевір git auth)'; return $false }
    Write-Ok 'Web live: https://fluxcontrol.pages.dev'
    Write-Ok 'Збережено: exe + version.json + versions\ + UI + logo.ico + _headers + assets\'
    return $true
}

function Invoke-ServerDeploy {
    if (-not $ServerDir) { Write-Info 'FluxControl Server відсутній — пропускаю.'; return $true }
    Write-Step 'Server: публікую в FluxControl-Backend.git (Render)'
    $mode = Ensure-GitAuth -Interactive
    if ($mode -eq 'none') { Write-Fail 'Немає gh CLI / GITHUB_TOKEN. Виконай: gh auth login'; return $false }
    $cloneUrl = "https://github.com/$BackendRepo.git"
    if ($mode -eq 'token') { $cloneUrl = "https://x-access-token:$($env:GITHUB_TOKEN)@github.com/$BackendRepo.git" }
    Ensure-GitRepo -Dir $ServerDir -OriginUrl $cloneUrl
    $prev = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
    Push-Location $ServerDir
    try {
        git add -A
        $null = git -c user.name='FluxControl Deploy' -c user.email='deploy@users.noreply.github.com' commit -m 'Deploy Server' --allow-empty 2>&1
    } finally { Pop-Location; $ErrorActionPreference = $prev }
    $code = Invoke-Git -C $ServerDir push -u origin main --force
    if ($code -ne 0) { Write-Fail 'Server push не вдався (перевір git auth)'; return $false }
    Write-Ok 'Server live: https://fluxcontrol-backend-bl3u.onrender.com'
    return $true
}

function Invoke-ServerCheck {
    if (-not $ServerDir) { Write-Fail 'Не знайдено папку сервера (FluxControl Server)'; return $false }
    $serverJs = Join-Path $ServerDir 'server.js'
    if (-not (Test-Path -LiteralPath $serverJs)) { Write-Fail "Не знайдено $serverJs"; return $false }
    Write-Step 'Server: перевірка server.js'
    if (Get-Command node -ErrorAction SilentlyContinue) {
        $prev = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
        & node --check $serverJs
        $code = $LASTEXITCODE
        $ErrorActionPreference = $prev
        if ($code -ne 0) { Write-Fail 'server.js містить синтаксичні помилки'; return $false }
        $lines = ([IO.File]::ReadAllLines($serverJs)).Count
        Write-Ok ("server.js: синтаксис OK ({0} рядків)" -f $lines)
    } else {
        Write-Info 'node не знайдено — пропускаю синтакс-перевірку.'
    }
    $pkg = Join-Path $ServerDir 'package.json'
    if (Test-Path -LiteralPath $pkg) {
        try {
            $p = Get-Content -LiteralPath $pkg -Raw | ConvertFrom-Json
            Write-Ok ("package.json: {0} залежностей, start = {1}" -f @($p.dependencies.PSObject.Properties).Count, $p.scripts.start)
        } catch { Write-Info 'package.json не читається — не критично.' }
    }
    return $true
}

# ============================== ДИСПЕТЧЕР ==============================
$action = $env:FLUX_ACTION
$ok = $false
try {
    switch ($action) {
        'agent-build' {
            $cur = Get-SiteVersion
            $sugg = '1.0.0'; if ($cur -match '^\d+\.\d+\.\d+$') { $sugg = Get-NextVersion $cur }
            Write-Host '    Enter = автоматична версія; або введи свій номер.' -ForegroundColor DarkGray
            $typed = Read-Host "    Версія збірки [Enter = $sugg]"
            if ([string]::IsNullOrWhiteSpace($typed)) { $v = $sugg } else { $v = $typed.Trim() }
            $v = Get-NormalizedVersion $v
            if ($v -notmatch '^\d+\.\d+\.\d+$') { Write-Fail "Невірний формат версії: '$v'" }
            else { $ok = Invoke-AgentBuild $v; if ($ok) { Write-Host ''; Write-Ok "Готово: _deploy\FluxControl.exe v$v (без деплою)" } }
        }
        'agent-deploy'   { $ok = Invoke-AgentDeploy }
        'web-build'      { $ok = Invoke-WebBuild }
        'web-server-deploy' {
            $w = Invoke-WebDeploy
            $s = Invoke-ServerDeploy
            $ok = ($w -and $s)
            if ($ok) { Write-Host ''; Write-Ok 'ГОТОВО: Web + Server опубліковано' }
        }
        'server-check'   { $ok = Invoke-ServerCheck }
        'server-deploy'  { $ok = Invoke-ServerDeploy; if ($ok) { Write-Host ''; Write-Ok 'ГОТОВО: Server опубліковано' } }
        'full' {
            Write-Host '  FULL DEPLOY: агент -> сайт -> сервер' -ForegroundColor Magenta
            $a = Invoke-AgentDeploy
            if (-not $a) { Write-Fail 'Агент-деплой не вдався — зупиняю FULL.' }
            else {
                $w = Invoke-WebDeploy
                $s = Invoke-ServerDeploy
                $ok = ($w -and $s)
                if ($ok) {
                    Write-Host ''
                    Write-Host '  ═════════════════════════════════════════════' -ForegroundColor Green
                    Write-Host '   FULL DEPLOY УСПІШНИЙ: агент + сайт + сервер' -ForegroundColor Green
                    Write-Host '   сайт    : https://fluxcontrol.pages.dev'     -ForegroundColor Green
                    Write-Host '   сервер  : https://fluxcontrol-backend-bl3u.onrender.com' -ForegroundColor Green
                    Write-Host '  ═════════════════════════════════════════════' -ForegroundColor Green
                }
            }
        }
        default { Write-Fail "Невідома дія: $action" }
    }
} catch {
    Write-Fail $_.Exception.Message
    $ok = $false
}
if (-not $ok) { exit 1 } else { exit 0 }
