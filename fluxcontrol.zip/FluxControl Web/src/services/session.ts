/**
 * Сесійна автентифікація веб-клієнта (Security Fix 2025-10).
 *
 * Сервер після логіну видає непрозорий sessionToken (crypto.randomBytes).
 * Далі клієнт доводить себе заголовком `Authorization: Bearer <token>` —
 * заголовок x-fc-user-id підробляється одним рядком у DevTools і для
 * сервера більше НЕ доказ особи.
 *
 * Токен живе в localStorage 30 днів (sliding на сервері). Функції
 * authHeaders()/authFetch() можна звати з будь-якого модуля поза React —
 * services, воркери, DeviceContext тощо.
 */

const TOKEN_KEY = 'fluxcontrol_session_token';

let cachedToken: string | null = (() => {
  try { return localStorage.getItem(TOKEN_KEY); } catch { return null; }
})();

/** Зберегти токен сесії (викликається AuthContext після логіну). */
export function setSessionToken(token: string | null | undefined) {
  cachedToken = token ? String(token) : null;
  try {
    if (cachedToken) localStorage.setItem(TOKEN_KEY, cachedToken);
    else localStorage.removeItem(TOKEN_KEY);
  } catch { /* приватний режим браузера — тримаємо в пам'яті */ }
}

/** Поточний токен (може бути null — тоді запити йдуть без Bearer). */
export function getSessionToken(): string | null {
  return cachedToken;
}

/** Заголовки автентифікації для fetch/RequestInit. */
export function authHeaders(extra: Record<string, string> = {}): Record<string, string> {
  return cachedToken
    ? { ...extra, Authorization: `Bearer ${cachedToken}` }
    : { ...extra };
}

/**
 * fetch із автоматичним Bearer-заголовком. Поведінка ідентична fetch.
 */
export function authFetch(url: string, init: RequestInit = {}): Promise<Response> {
  const headers = {
    ...(init.headers as Record<string, string> | undefined || {}),
    ...authHeaders(),
  };
  return fetch(url, { ...init, headers });
}

/** Вийти — забути токен (викликається з logout). */
export function clearSessionToken() {
  setSessionToken(null);
}
