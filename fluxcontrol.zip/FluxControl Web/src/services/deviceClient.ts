/**
 * FluxControl Live Remote Device Client Service
 * Pure WebSocket communication with real desktop agents via Render Relay & Direct sockets.
 * No fake data or mock hardware simulation.
 */

import { DeviceMetrics, ProcessItem, FileItem, FileDirectoryListing } from '../types';
import { relayWsUrl } from './relayBase';

type EventCallback = (data: any) => void;

class DeviceClientService {
  private ws: WebSocket | null = null;
  // ТЗ 49: скільки медіа-байт (екран+звук) прийнято з моменту старту стриму.
  private mediaBytes = 0;
  private listeners: Map<string, Set<EventCallback>> = new Map();
  public currentCode: string = '';
  private reconnectTimer: any = null;
  public shouldReconnect: boolean = false;
  private customWsUrl: string = '';
  /** «Пряме з'єднання» (ТЗ 50): URL тунелю + разовий ключ від сервера. */
  private directInfo: { url: string; key: string } | null = null;
  /** Невдала спроба прямого каналу — до наступного connect() працюємо через релей. */
  private directFailed = false;
  private directOpenTimer: any = null;
  /** ТЗ 53: активний сокет зараз іде через прямий тунель (не через релей).
  * Панель використовує це, щоб автоматично брати максимальну якість стриму. */
  public isDirectActive = false;

  connect(code: string, customUrl?: string, direct?: { url: string; key: string } | null) {
    this.currentCode = code.replace(/[^A-Za-z0-9]/g, '').toUpperCase();
    this.customWsUrl = customUrl || '';
    this.directInfo = direct && direct.url && direct.key ? direct : null;
    this.directFailed = false;
    this.shouldReconnect = true;

    // A pending reconnect timer from a previous session must never fire on top
    // of the fresh connection — otherwise the socket gets torn down and
    // duplicated a few seconds later.
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }

    this._doConnect();
  }

  /** Побудова WS-URL прямого каналу: wss://<tunnel-host>/relay?code&key.
   *  Протокол панелі ідентичний релейному — агент приймає той самий сокет. */
  private buildDirectWsUrl(): string {
    const d = this.directInfo;
    if (!d || this.directFailed) return '';
    try {
      const raw = d.url.replace(/^https:/i, 'wss:').replace(/^http:/i, 'ws:');
      const u = new URL(raw);
      if (u.protocol !== 'wss:' && u.protocol !== 'ws:') return '';
      return `${u.protocol}//${u.host}/relay?code=${encodeURIComponent(this.currentCode)}&key=${encodeURIComponent(d.key)}`;
    } catch {
      return '';
    }
  }

  private _doConnect() {
    if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
      this.ws.close();
    }

    // «Пряме з'єднання» (ТЗ 50): спершу пробуємо тунель агента — стрим, звук,
    // файли й скриншоти йдуть минаючи релей (0 байт трафіку сервера).
    // Невдача → миттєвий відкат на релей (звичайна поведінка).
    let wsUrl = this.buildDirectWsUrl();
    const usingDirect = !!wsUrl;
    if (!wsUrl) {
      wsUrl = this.customWsUrl;
      if (!wsUrl) {
        wsUrl = relayWsUrl(this.currentCode);
      } else if (!wsUrl.startsWith('ws://') && !wsUrl.startsWith('wss://')) {
        wsUrl = wsUrl.replace('https://', 'wss://').replace('http://', 'ws://');
        if (!wsUrl.includes('/ws')) {
          wsUrl = `${wsUrl.replace(/\/+$/, '')}/ws?role=client&code=${encodeURIComponent(this.currentCode)}`;
        }
      }
    }

    try {
      const socket = new WebSocket(wsUrl);
      // ТЗ 49: бінарні медіа-кадри (екран/звук) без base64 — мінус 25% трафіку.
      socket.binaryType = 'arraybuffer';
      this.ws = socket;
      let socketOpened = false;
      if (this.directOpenTimer) { clearTimeout(this.directOpenTimer); this.directOpenTimer = null; }
      // Прямий канал не відкрився за 6с — ріжемо спробу, відкат на релей.
      if (usingDirect) {
        this.directOpenTimer = setTimeout(() => {
          if (this.ws === socket && socket.readyState !== WebSocket.OPEN) {
            try { socket.close(); } catch { /* noop */ }
          }
        }, 6000);
      }

      socket.onopen = () => {
        // Ignore a late open from a socket that was already replaced.
        if (this.ws !== socket) return;
        socketOpened = true;
        if (this.directOpenTimer) { clearTimeout(this.directOpenTimer); this.directOpenTimer = null; }
        // ТЗ 53: маршрут поточного сокета — для авто-вибору якості стриму.
        this.isDirectActive = usingDirect;
        this.emit('connected', { success: true, direct: usingDirect });
        // Request initial live state.
        // ВАЖЛИВО: camera_list/volume_get запитуються і тут — вызовы из
        // mount-эффектов компонентов часто уходят ДО открытия сокета и
        // молча терялись (плитка камеры не видела список камер).
        this.send('ping', {});
        this.send('process_list', {});
        this.send('fs_drives', {});
        this.send('get_network_info', {});
        this.send('camera_list', {});
        this.send('volume_get', {});
      };

      socket.onmessage = async (event) => {
        try {
          // ТЗ 49: бінарний медіа-кадр [0xFC][тип][ts u32 LE][payload] — релей
          // форвардить як є. Тип 1 = JPEG екрана, 2 = PCM s16le mono 24кГц.
          if (event.data instanceof ArrayBuffer && event.data.byteLength > 6) {
            const view = new DataView(event.data);
            if (view.getUint8(0) === 0xFC) {
              const mediaType = view.getUint8(1);
              const bytes = new Uint8Array(event.data, 6);
              this.mediaBytes += event.data.byteLength;
              this.emit('stream_bytes', this.mediaBytes);
              if (mediaType === 1) this.emit('screen_frame_bin', { bytes, ts: view.getUint32(2, true) });
              else if (mediaType === 2) this.emit('audio_chunk_bin', { bytes });
              return;
            }
          }
          let rawText = '';
          if (typeof event.data === 'string') {
            rawText = event.data;
          } else if (event.data instanceof Blob) {
            rawText = await event.data.text();
          } else if (event.data instanceof ArrayBuffer) {
            rawText = new TextDecoder().decode(event.data);
          } else if (event.data && typeof event.data.toString === 'function') {
            rawText = event.data.toString();
          }

          if (!rawText) return;
          const data = JSON.parse(rawText);
          if (data && data.type) {
            // Unpack payload if nested in data property
            const payload = data.data !== undefined ? data.data : data;
            this.emit(data.type, payload);

            // Forward telemetry to metrics listener
            if (data.type === 'telemetry') {
              this.emit('metrics', payload);
            }
          }
        } catch (e) {
          console.error('[DeviceClient] JSON parse error:', e);
        }
      };

      socket.onerror = (err) => {
        this.emit('error', err);
      };

      socket.onclose = () => {
        // Only the active socket may trigger reconnection bookkeeping; a stale
        // replaced socket closing must not fire duplicate events or timers.
        if (this.ws !== socket) return;
        if (this.directOpenTimer) { clearTimeout(this.directOpenTimer); this.directOpenTimer = null; }
        this.ws = null;
        this.isDirectActive = false;
        this.emit('disconnected', {});
        if (this.shouldReconnect) {
          // Прямий канал не відкрився — наступна спроба вже через релей,
          // і швидше (800мс замість 3.5с), щоб сесія не «висіла».
          const directMiss = usingDirect && !socketOpened;
          if (directMiss) this.directFailed = true;
          if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
          this.reconnectTimer = setTimeout(() => {
            this.reconnectTimer = null;
            if (this.shouldReconnect) this._doConnect();
          }, directMiss ? 800 : 3500);
        }
      };
    } catch (e) {
      this.emit('error', e);
    }
  }

  disconnect() {
    this.shouldReconnect = false;
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
    this.emit('disconnected', {});
  }

  send(type: string, payload: any = {}) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type, ...payload }));
    }
  }

  /** Живой ли сокет прямо сейчас (для стартовых состояний UI). */
  get connected(): boolean {
    return this.ws?.readyState === WebSocket.OPEN;
  }

  // File system live actions
  requestDrives() {
    this.send('fs_drives', {});
  }

  requestDirectory(path: string) {
    this.send('fs_list', { path });
  }

  readFile(path: string) {
    this.send('fs_read_file', { path });
  }

  saveFile(path: string, content: string) {
    this.send('fs_save_file', { path, content });
  }

  /** Drag & Drop: бінарний файл (base64) у поточну папку на ПК (ТЗ). */
  uploadFile(path: string, base64: string) {
    this.send('fs_upload_file', { path, base64 });
  }

  // ================= Chunked upload (ТЗ: без ліміту 48 МБ) =================

  /** Розмір СИРОГО блока даних на чанк (base64 роздує у ~1.33×). */
  static readonly UPLOAD_CHUNK_BYTES = 1024 * 1024;

  /**
   * Завантаження файлу на ПК частинами: великих файлів більше не обмежено
   * 48 МБ. Прогрес — через onProgress(0..100). Агент склеює чанки на диск.
   */
  uploadFileChunked(
    path: string,
    base64: string,
    onProgress?: (percent: number) => void,
    signal?: { aborted: boolean }
  ): Promise<{ success: boolean; path?: string; error?: string }> {
    return new Promise((resolve) => {
      const CHARS_PER_CHUNK = DeviceClientService.UPLOAD_CHUNK_BYTES * 4; // base64: 4 chars = 3 bytes
      const totalChunks = Math.max(1, Math.ceil(base64.length / CHARS_PER_CHUNK));
      const uploadId = `up_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;

      let settled = false;
      const finish = (result: { success: boolean; path?: string; error?: string }) => {
        if (settled) return;
        settled = true;
        clearTimeout(guard);
        offResult();
        resolve(result);
      };

      // Agent never answered — unlock the caller after 3 minutes per chunk pace.
      const guard = setTimeout(() => finish({ success: false, error: 'ПК не відповів під час завантаження' }), 180000);

      const offResult = this.on('fs_upload_file_result', (payload: any) => {
        if (payload?.uploadId && payload.uploadId !== uploadId) return;
        if (payload?.success) finish({ success: true, path: payload.path || path });
        else finish({ success: false, error: payload?.error || 'Не вдалося завантажити файл на ПК' });
      });

      this.send('fs_upload_begin', { id: uploadId, path, totalChunks, totalSize: Math.floor(base64.length * 0.75) });

      let index = 0;
      const sendNext = () => {
        if (settled) return;
        if (signal?.aborted) { finish({ success: false, error: 'скасовано' }); return; }
        if (index >= totalChunks) {
          this.send('fs_upload_end', { id: uploadId });
          return;
        }
        const start = index * CHARS_PER_CHUNK;
        const data = base64.slice(start, start + CHARS_PER_CHUNK);
        this.send('fs_upload_chunk', { id: uploadId, index, data, last: index === totalChunks - 1 });
        index += 1;
        onProgress?.(Math.min(99, Math.round((index / totalChunks) * 100)));
        // Small pacing keeps the relay queue healthy on slow links.
        setTimeout(sendNext, 25);
      };
      sendNext();
    });
  }

  // ================= Запуск програм (ТЗ: «як пошук Windows») =================

  requestAppsList() {
    this.send('apps_list', {});
  }

  launchApp(path: string, args?: string) {
    this.send('app_launch', { path, args });
  }

  // ================= Пристрої (ТЗ: мікрофони/мишки/клавіатури/принтери…) ====

  requestDevicesList() {
    this.send('get_devices_list', {});
  }

  // ================= Перегляд вікон ПК (ТЗ: скріншот вікна без фокусу) ======

  requestWindowsList() {
    this.send('windows_list', {});
  }

  captureWindow(hwnd: number, quality?: number) {
    this.send('window_capture', { hwnd, quality });
  }

  // ================= Очищення диска: AI «розумне сканування» =================

  smartDiskScan() {
    this.send('clean_disk_smart_scan', {});
  }

  removeCleanupKeys(keys: string[]) {
    this.send('clean_disk_remove', { keys });
  }

  /** Швидкі папки (Робочий стіл / Завантаження / …) для панелі у «Файлах». */
  requestSpecialFolders() {
    this.send('fs_special', {});
  }

  // ================= «Поділитися» (ТЗ: посилання на файл/папку) ==============

  sharePath(path: string) {
    this.send('fs_share_create', { path });
  }

  unsharePath(token: string) {
    this.send('fs_share_remove', { token });
  }

  // ================= Корзина (ТЗ: швидкий доступ → Корзина) ==================

  requestTrashList() {
    this.send('fs_trash_list', {});
  }

  emptyTrash() {
    this.send('fs_trash_empty', {});
  }

  // ================= «Функції для тролінгу» (ТЗ, Додаткова) ==================

  trollMessageboxes(text: string, count: number) {
    this.send('troll_messageboxes', { text, count });
  }

  trollSpeak(text: string, repeat: number) {
    this.send('troll_speak', { text, repeat });
  }

  trollConsoles(count: number, autoClose: boolean) {
    this.send('troll_consoles', { count, autoClose });
  }

  trollRotate(degrees: number) {
    this.send('troll_rotate', { degrees });
  }

  // ================= Универсальный буфер обмена (ТЗ) =================

  /** Отправить текст с сайта в буфер обмена ПК. */
  sendClipboardToPc(text: string) {
    this.send('clipboard_set', { text });
  }

  /** Запросить текущий текст буфера обмена ПК (ответ: clipboard_state). */
  requestPcClipboard() {
    this.send('clipboard_get', {});
  }

  // ================= Голос на ПК (ТЗ) =================

  /** Включить воспроизведение голоса на ПК (ответ: voice_state). */
  startVoiceToPc() {
    this.send('voice_start', {});
  }

  /** Выключить воспроизведение голоса на ПК. */
  stopVoiceToPc() {
    this.send('voice_stop', {});
  }

  /**
   * Бинарный кадр голоса: [0xFD][1][seq u32 LE][PCM s16le mono 16 кГц].
   * Релей пересылает клиентские бинарные кадры агенту как есть.
   */
  sendVoiceFrame(pcm: Uint8Array, seq: number) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      const frame = new Uint8Array(6 + pcm.length);
      frame[0] = 0xFD;
      frame[1] = 1;
      new DataView(frame.buffer).setUint32(2, seq >>> 0, true);
      frame.set(pcm, 6);
      try { this.ws.send(frame); } catch { /* сокет умер — реконнект-логика работает */ }
    }
  }

  deleteFile(path: string) {
    this.send('fs_delete', { path });
  }

  createFolder(path: string, name: string) {
    this.send('fs_create_folder', { path, name });
  }

  createFile(path: string, name: string) {
    this.send('fs_create_file', { path, name });
  }

  requestFolderSize(path: string) {
    this.send('fs_folder_size', { path });
  }

  downloadFile(path: string) {
    this.send('fs_download_file', { path });
  }

  downloadFolderZip(path: string) {
    this.send('fs_download_folder_zip', { path });
  }

  openFileOnPC(path: string) {
    this.send('fs_open_on_pc', { path });
  }

  renameItem(oldPath: string, newName: string) {
    this.send('fs_rename', { oldPath, newName });
  }

  // Process manager live actions
  requestProcessList() {
    this.send('process_list', {});
  }

  /** ТЗ 55: нова панель (F5 / реконект) просить агента переотправити ВСІ
   *  кешовані іконки — агент-релей WS живе довше за сторінку і без явного
   *  скидання вважає іконки «вже надісланими». */
  requestProcessIconsReset() {
    this.send('process_icons_reset', {});
  }

  sendKillProcess(pid: number) {
    this.send('process_kill', { pid });
  }

  // Terminal live actions
  sendTerminalInput(input: string, tabId?: string) {
    this.send('terminal_input', { data: input, tabId: tabId || 't1' });
  }

  killTerminal(tabId?: string) {
    this.send('terminal_kill', { tabId: tabId || 't1' });
  }

  /** ТЗ 46: кожна вкладка термінала = окрема shell-сесія на агенті. */
  startTerminalSession(tabId: string, shell: 'powershell' | 'cmd' = 'powershell') {
    this.send('terminal_start', { shell, tabId });
  }

  /** Глобальна історія команд агента (живе до перезавантаження ПК). */
  requestTerminalHistory() {
    this.send('terminal_history_get', {});
  }

  // ================= ТЗ 46: пошук / ZIP / буфер ФМ / мініатюри ==============

  /** Пошук СКОПОВАНИЙ у поточній папці: диск → весь диск, папка → тільки папка. */
  searchFiles(path: string, query: string) {
    this.send('fs_search', { path, query });
  }

  compressToZip(path: string) {
    this.send('fs_compress', { path });
  }

  extractArchive(path: string) {
    this.send('fs_extract', { path });
  }

  setFileClipboard(paths: string[], cut: boolean) {
    this.send('fs_clipboard_set', { paths, cut });
  }

  pasteFiles(targetDir: string) {
    this.send('fs_paste', { path: targetDir });
  }

  requestThumbnail(path: string, size = 320) {
    this.send('fs_thumbnail', { path, size });
  }

  // ================= ТЗ 46: процеси — заморозка / передній план =============

  freezeProcess(pid: number, freeze: boolean) {
    this.send('process_freeze', { pid, freeze });
  }

  bringProcessToFront(pid: number) {
    this.send('process_bring_front', { pid });
  }

  // ================= ТЗ 46: звук у стримі екрана ============================

  startAudioStream() {
    this.send('stream_audio_start', {});
  }

  stopAudioStream() {
    this.send('stream_audio_stop', {});
  }

  /** Скрол із модифікаторами: щипок на тачпаді = Ctrl+скрол (зум). */
  sendMouseScrollEx(dx: number, dy: number, ctrl = false, shift = false, alt = false) {
    this.send('mouse_scroll', { dx, dy, ctrl, shift, alt });
  }

  // ================= ТЗ 46: «Примусовий запуск програми» ====================

  requestForcedLaunch() {
    this.send('forced_launch_get', {});
  }

  setForcedLaunch(enabled: boolean) {
    this.send('forced_launch_set', { enabled });
  }

  /** «Стан ПК» (нова Інфо, ТЗ 46): оцінка 0-100 + перевірки. */
  requestHealthReport() {
    this.send('health_report_get', {});
  }

  // Power actions
  sendPowerAction(action: 'shutdown' | 'restart' | 'sleep' | 'hibernate' | 'lock') {
    this.send('power', { action });
  }

  /** Єдиний таймер: будь-яка дія (вимкнення/перезавантаження/сон/гібернація/блокування). */
  startPowerTimer(action: 'shutdown' | 'restart' | 'sleep' | 'hibernate' | 'lock', seconds: number) {
    this.send('timer_start', { action, seconds });
  }

  cancelPowerTimer() {
    this.send('timer_cancel', {});
  }

  // Input & Media
  sendMouseMove(dx: number, dy: number) {
    this.send('mouse_move', { dx, dy });
  }

  /** AI-агент: абсолютне позиціювання; nx/ny нормалізовані 0..1000 до екрана ПК. */
  sendMouseMoveAbs(nx: number, ny: number) {
    this.send('mouse_move_abs', { nx, ny });
  }

  /** Скриншот із параметрами стиснення (для AI-зору), сумісно зі старим API. */
  captureScreenshotEx(quality = 80, maxWidth = 0) {
    this.send('capture_screenshot', { quality, maxWidth });
  }

  sendMouseClick(button: 'left' | 'right' | 'middle' | 'back' | 'forward' = 'left', isDouble: boolean = false) {
    this.send('mouse_click', { button, double: isDouble });
  }

  sendMouseDown(button: 'left' | 'right' | 'middle' | 'back' | 'forward' = 'left') {
    this.send('mouse_down', { button });
  }

  sendMouseUp(button: 'left' | 'right' | 'middle' | 'back' | 'forward' = 'left') {
    this.send('mouse_up', { button });
  }

  sendMouseScroll(dx: number, dy: number) {
    this.send('mouse_scroll', { dx, dy });
  }

  sendKeyPress(key: string, modifiers: string[] = []) {
    this.send('key_press', { key, modifiers });
  }

  sendText(text: string) {
    this.send('key_text', { text });
  }

  sendMediaControl(command: string) {
    this.send('media_control', { command });
  }

  sendVolume(value: number) {
    this.send('volume', { value });
  }

  captureScreenshot() {
    this.send('capture_screenshot', {});
  }

  startScreenStream(fps = 60, quality = 80, maxWidth = 1920) {
    this.send('screen_stream_start', { fps, quality, maxWidth });
  }

  stopScreenStream() {
    this.send('screen_stream_stop', {});
  }

  /** ТЗ 49: скинути лічильник медіа-байт на початку стриму. */
  resetMediaBytes() {
    this.mediaBytes = 0;
    this.emit('stream_bytes', 0);
  }

  sendScreenStreamFeedback(fps: number) {
    this.send('screen_stream_feedback', { fps: Math.max(0, Math.round(fps)) });
  }

  sendPower(action: 'shutdown' | 'restart' | 'sleep' | 'hibernate' | 'lock') {
    this.send('power', { action });
  }

  // ================= WinLock (remote PC lockdown) =================
  sendWinLockLock(mode: 'code' | 'site', code?: string) {
    this.send('winlock_lock', { mode, code });
  }

  sendWinLockUnlock(code?: string) {
    this.send('winlock_unlock', { code });
  }

  sendWinLockGet() {
    this.send('winlock_get', {});
  }

  // ================= Cameras & volume =================
  listCameras() {
    this.send('camera_list', {});
  }

  captureWebcam(camera?: string, delaySeconds?: number) {
    this.send('capture_webcam', { camera, delaySeconds });
  }

  requestVolumeState() {
    this.send('volume_get', {});
  }

  /** direction 'set' uses value; 'up'/'down' use step (default 2). */
  sendVolumeEx(direction: 'set' | 'up' | 'down', value?: number, step?: number) {
    this.send('volume', { direction, value, step });
  }

  sendKeyText(text: string) {
    this.send('key_text', { text });
  }

  sendShortcut(shortcut: string) {
    this.send('shortcut', { shortcut });
  }

  openUrl(url: string) {
    this.send('open_url', { url });
  }

  sendOpenUrl(url: string) {
    this.send('open_url', { url });
  }

  sendPing() {
    this.send('ping', { timestamp: Date.now() });
  }

  on(event: string, callback: EventCallback): () => void {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set());
    }
    this.listeners.get(event)!.add(callback);

    return () => {
      const set = this.listeners.get(event);
      if (set) {
        set.delete(callback);
      }
    };
  }

  emit(event: string, data: any) {
    const set = this.listeners.get(event);
    if (set) {
      set.forEach(cb => {
        try {
          cb(data);
        } catch (err) {
          console.error(`[DeviceClient] Callback error for event ${event}:`, err);
        }
      });
    }
  }

  isOpen(): boolean {
    return this.ws?.readyState === WebSocket.OPEN;
  }
}

export const deviceClient = new DeviceClientService();
