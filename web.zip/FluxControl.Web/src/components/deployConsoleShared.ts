/** Спільні константи деплой-консолі (сторінка + локальний міст). */

export const SITE_BASE = 'https://fluxcontrol.pages.dev';
export const RAW_SITE_BASE = 'https://raw.githubusercontent.com/matviikobrys2707/FluxControl/main';

export interface DeployVersionInfo {
  version: string;
  date?: string;
  sha256?: string;
  sizeMb?: number;
  changelog?: string;
}
