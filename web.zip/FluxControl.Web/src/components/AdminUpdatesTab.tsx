import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  Package,
  Download,
  Monitor,
  ChevronDown,
  ChevronUp,
  RefreshCw,
  Rocket,
  CircleCheck,
  History
} from 'lucide-react';
import { toast } from '../utils/toast';
import { relayBase } from '../services/relayBase';

const API_BASE = relayBase();
const SITE_BASE = 'https://fluxcontrol.pages.dev';
const RAW_BASE = 'https://raw.githubusercontent.com/matviikobrys2707/FluxControl/main';

export interface SiteVersionInfo {
  version: string;
  date?: string;
  sha256?: string;
  sizeMb?: number;
  changelog?: string;
}

interface AdminUpdatesTabProps {
  /** Список ПК з /api/admin/computers (тягне батьківський AdminPage). */
  computers: any[];
  onReloadComputers: () => void;
}

/** АДМІНСЬКА ВКЛАДКА «ОНОВЛЕННЯ» (ТЗ): список УСІХ версій з сайту,
 *  журнал змін для кожної, завантаження будь-якого exe і віддалена
 *  установка/відкат на вибраний пристрій. */
export const AdminUpdatesTab: React.FC<AdminUpdatesTabProps> = ({ computers, onReloadComputers }) => {
  const [versions, setVersions] = useState<SiteVersionInfo[] | null>(null);
  const [latest, setLatest] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [source, setSource] = useState<string>('');
  const [expanded, setExpanded] = useState<string | null>(null);
  const [pickFor, setPickFor] = useState<string | null>(null);
  const [installing, setInstalling] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    // Шлях 1: проксі нашого сервера (обходить CORS повністю).
    try {
      const r = await fetch(`${API_BASE}/api/updates/versions`).catch(() => null);
      if (r && r.ok) {
        const j = await r.json();
        if (j?.success && j?.index?.versions) {
          setVersions(j.index.versions);
          setLatest(String(j.index.latest_version || j.index.versions[0]?.version || ''));
          setSource('сервер');
          setLoading(false);
          return;
        }
      }
    } catch { }
    // Шлях 2: сайт напряму.
    try {
      const r = await fetch(`${SITE_BASE}/versions.json?t=${Date.now()}`, { cache: 'no-store' }).catch(() => null);
      if (r && r.ok) {
        const j = await r.json();
        if (j && Array.isArray(j.versions)) {
          setVersions(j.versions);
          setLatest(String(j.latest_version || j.versions[0]?.version || ''));
          setSource('сайт');
          setLoading(false);
          return;
        }
      }
    } catch { }
    // Шлях 3: raw того ж репозиторію (віддає CORS «*»).
    try {
      const r = await fetch(`${RAW_BASE}/versions.json?t=${Date.now()}`, { cache: 'no-store' }).catch(() => null);
      if (r && r.ok) {
        const j = await r.json();
        if (j && Array.isArray(j.versions)) {
          setVersions(j.versions);
          setLatest(String(j.latest_version || j.versions[0]?.version || ''));
          setSource('raw резерв');
          setLoading(false);
          return;
        }
      }
    } catch { }
    setVersions([]);
    setSource('');
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const sorted = useMemo(() => {
    const list = [...(versions || [])];
    const key = (v: string) => v.split('.').map(x => parseInt(x, 10) || 0);
    return list.sort((a, b) => {
      const ka = key(a.version || '0.0.0');
      const kb = key(b.version || '0.0.0');
      for (let i = 0; i < 3; i++) {
        const d = (kb[i] || 0) - (ka[i] || 0);
        if (d) return d;
      }
      return 0;
    });
  }, [versions]);

  const installTo = async (version: string, comp: any) => {
    setInstalling(version);
    try {
      const user = JSON.parse(localStorage.getItem('fluxcontrol_user') || 'null');
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (user?.id) headers['x-fc-user-id'] = user.id;
      const r = await fetch(`${API_BASE}/api/admin/updates/install`, {
        method: 'POST', headers,
        body: JSON.stringify({ target: comp.hwid || comp.id, version })
      }).catch(() => null);
      const j = r && r.ok ? await r.json() : null;
      if (j?.success) {
        toast.success(j.message || `Версію ${version} надіслано на «${comp.name}»`);
        setPickFor(null);
      } else {
        toast.error(j?.message || 'Не вдалося надіслати команду встановлення');
      }
    } finally {
      setInstalling(null);
    }
  };

  return (
    <div className="space-y-5">
      {/* Шапка вкладки */}
      <div className="glass-card flex flex-col gap-4 rounded-3xl border border-indigo-500/20 bg-[#090b14]/80 p-6 sm:flex-row sm:items-center">
        <div className="grid h-12 w-12 flex-none place-items-center rounded-2xl border border-indigo-500/30 bg-indigo-600/20 text-indigo-300">
          <Package className="h-6 w-6" />
        </div>
        <div className="min-w-0 flex-1">
          <h2 className="text-lg font-black text-white">Оновлення та архів версій</h2>
          <p className="mt-0.5 text-xs text-gray-400">
            Кожна випущена версія зберігається на сайті. Можна завантажити будь-який exe
            або віддалено встановити/відкотити версію на пристрої.
            {latest && <> Остання: <b className="text-emerald-400">v{latest}</b></>}
            {source && <span className="ml-1 text-gray-600">({source})</span>}
          </p>
        </div>
        <button
          onClick={load}
          disabled={loading}
          className="fc-btn fc-btn-primary flex-none disabled:opacity-50"
        >
          <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Оновити</span>
        </button>
      </div>

      {/* Список версій */}
      {loading && !versions ? (
        <div className="grid grid-cols-1 gap-2.5 md:grid-cols-2">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="h-24 animate-pulse rounded-2xl border border-white/5 bg-white/[.03]" />
          ))}
        </div>
      ) : sorted.length === 0 ? (
        <div className="glass-card rounded-3xl border border-white/10 bg-[#090b14]/80 p-10 text-center">
          <History className="mx-auto h-8 w-8 text-gray-600" />
          <p className="mt-3 text-xs text-gray-500">
            На сайті ще немає збережених версій. Вони з&apos;являться після першого деплою
            новим Auto-Deploy (v6): він автоматично кладе кожну версію в архів.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
          {sorted.map(v => {
            const isLatest = v.version === latest;
            const isOpen = expanded === v.version;
            return (
              <div
                key={v.version}
                className={`glass-card rounded-2xl border p-4 ${isLatest ? 'border-emerald-500/30 bg-emerald-950/10' : 'border-white/10 bg-[#090b14]/80'}`}
              >
                <div className="flex items-center gap-2">
                  <span className="font-mono text-sm font-black text-white">v{v.version}</span>
                  {isLatest && (
                    <span className="flex items-center gap-1 rounded-full border border-emerald-500/30 bg-emerald-500/15 px-2 py-0.5 text-[9px] font-black uppercase tracking-wider text-emerald-400">
                      <CircleCheck className="h-3 w-3" /> остання
                    </span>
                  )}
                  {v.date && <span className="ml-auto text-[10px] font-semibold text-gray-500">{String(v.date).slice(0, 10)}</span>}
                </div>
                {v.changelog && (
                  <>
                    <button
                      onClick={() => setExpanded(isOpen ? null : v.version)}
                      className="mt-2 flex items-center gap-1 text-[11px] font-bold text-indigo-300 hover:text-indigo-200 cursor-pointer"
                    >
                      {isOpen ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
                      Що змінилось
                    </button>
                    {isOpen && (
                      <p className="mt-1.5 whitespace-pre-wrap rounded-xl border border-white/5 bg-black/40 p-3 text-[11px] leading-relaxed text-gray-300">
                        {v.changelog}
                      </p>
                    )}
                  </>
                )}
                <div className="mt-3 flex flex-wrap items-center gap-2">
                  <a
                    href={`${SITE_BASE}/versions/${encodeURIComponent(v.version)}/FluxControl.exe`}
                    className="flex items-center gap-1.5 rounded-xl border border-white/10 bg-white/5 px-3 py-1.5 text-[11px] font-bold text-gray-200 transition-colors hover:bg-white/10 hover:text-white"
                    download
                  >
                    <Download className="h-3.5 w-3.5" /> Завантажити exe{v.sizeMb ? ` · ${Number(v.sizeMb).toFixed(1)} МБ` : ''}
                  </a>
                  <button
                    onClick={() => setPickFor(pickFor === v.version ? null : v.version)}
                    disabled={installing === v.version}
                    className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 px-3 py-1.5 text-[11px] font-bold text-white shadow-lg shadow-indigo-600/25 transition-all hover:brightness-110 disabled:opacity-50 cursor-pointer"
                  >
                    <Rocket className="h-3.5 w-3.5" />
                    {installing === v.version ? 'Надсилаю…' : 'Встановити на пристрій'}
                  </button>
                </div>
                {pickFor === v.version && (
                  <div className="mt-3 space-y-1.5 rounded-2xl border border-indigo-500/25 bg-indigo-950/30 p-2.5">
                    <p className="px-1 text-[10px] font-black uppercase tracking-wider text-indigo-300">Оберіть пристрій</p>
                    {computers.length === 0 ? (
                      <p className="px-1 py-2 text-[11px] text-gray-500">Список ПК ще не завантажено — відкрийте вкладку «ПК».</p>
                    ) : computers.map(c => (
                      <button
                        key={c.id || c.hwid}
                        onClick={() => installTo(v.version, c)}
                        className="flex w-full cursor-pointer items-center gap-2 rounded-xl px-2 py-1.5 text-left transition-colors hover:bg-white/5"
                      >
                        <Monitor className="h-3.5 w-3.5 flex-none text-gray-400" />
                        <span className="min-w-0 flex-1 truncate text-[11.5px] font-semibold text-gray-200">{c.name || c.hwid}</span>
                        <span className={`flex-none text-[9px] font-black uppercase ${c.isOnline ? 'text-emerald-400' : 'text-gray-600'}`}>
                          {c.isOnline ? 'online' : 'офлайн · після підключення'}
                        </span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
