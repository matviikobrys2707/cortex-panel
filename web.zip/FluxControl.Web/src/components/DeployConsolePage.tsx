import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Terminal,
  Hammer,
  Rocket,
  Globe,
  Zap,
  CircleCheck,
  CircleX,
  Loader2,
  RefreshCw,
  LockKeyhole,
  FileText,
  Cpu,
  GitBranch,
  PackageCheck,
  ArrowDownToLine
} from 'lucide-react';
import { SITE_BASE, RAW_SITE_BASE, DeployVersionInfo } from './deployConsoleShared';

/** Секретний ключ доступу до консолі. Зберігається у FluxControlDeploy.exe —
 *  сторінка «мертва» без нього (виглядає як звичайна помилка 404). */
const DEPLOY_KEY = 'FX-DEPLOY-7K2Q-9F3A';
const BRIDGE_BASE = 'http://127.0.0.1:7423';

interface LogLine { i: number; text: string; kind: 'out' | 'err' | 'sys' }
interface BridgeStatus {
  ok?: boolean;
  app?: string;
  busy?: boolean;
  running?: { mode?: string; startedAt?: number } | null;
  siteVersion?: string;
  deployVersion?: string;
  suggested?: string;
  changelog?: string;
  projectRoot?: string;
  tools?: Record<string, boolean>;
}

type RunMode = 'build' | 'publish' | 'web' | 'full';

/** ФАЙНИЙ «фальшивий 404» — таким сторінку бачить будь-хто без ключа (ТЗ:
 *  «складний URL, щоб звичайний користувач не міг зайти»). */
const FakeNotFound: React.FC = () => (
  <div className="flex min-h-screen items-center justify-center bg-[#050508] px-4">
    <div className="text-center">
      <p className="font-mono text-7xl font-black text-white/90">404</p>
      <p className="mt-2 text-sm text-gray-500">Ця сторінка не існує або була переміщена.</p>
      <a href="/" className="mt-6 inline-block text-xs font-bold text-indigo-400 hover:text-indigo-300">На головну</a>
    </div>
  </div>
);

export const DeployConsolePage: React.FC = () => {
  // Ключ перевіряємо з URL (?key=...) або sessionStorage після першого входу.
  const urlKey = new URLSearchParams(window.location.search).get('key') || '';
  const [unlocked, setUnlocked] = useState(() => {
    if (urlKey === DEPLOY_KEY) {
      try { sessionStorage.setItem('fc_deploy_key', urlKey); } catch { }
      return true;
    }
    try { return sessionStorage.getItem('fc_deploy_key') === DEPLOY_KEY; } catch { return false; }
  });

  if (!unlocked) return <FakeNotFound />;
  return <ConsoleUi />;
};

const ConsoleUi: React.FC = () => {
  const [st, setSt] = useState<BridgeStatus | null>(null);
  const [bridgeUp, setBridgeUp] = useState<boolean | null>(null);
  const [version, setVersion] = useState('');
  const [changelog, setChangelog] = useState('');
  const [log, setLog] = useState<LogLine[]>([]);
  const [busyMode, setBusyMode] = useState<string | null>(null);
  const [lastError, setLastError] = useState<string>('');
  const logOffset = useRef(0);
  const logBoxRef = useRef<HTMLDivElement>(null);
  const [versions, setVersions] = useState<DeployVersionInfo[]>([]);
  const [latest, setLatest] = useState('');

  const refreshStatus = useCallback(async () => {
    try {
      const r = await fetch(`${BRIDGE_BASE}/api/status`, { cache: 'no-store' });
      if (!r.ok) throw new Error('bad');
      const j: BridgeStatus = await r.json();
      setSt(j);
      setBridgeUp(true);
      setBusyMode(j.busy ? (j.running?.mode || 'задача') : null);
      setVersion(v => v || j.suggested || '');
      setChangelog(c => c || j.changelog || '');
      if (j.busy === false) setBusyMode(null);
    } catch {
      setBridgeUp(false);
      setBusyMode(null);
    }
  }, []);

  const pullLog = useCallback(async () => {
    try {
      const r = await fetch(`${BRIDGE_BASE}/api/log?since=${logOffset.current}`, { cache: 'no-store' });
      if (!r.ok) return;
      const j = await r.json();
      if (Array.isArray(j.lines) && j.lines.length > 0) {
        setLog(prev => [...prev, ...j.lines].slice(-800));
        logOffset.current = j.total || logOffset.current + j.lines.length;
        const box = logBoxRef.current;
        if (box) box.scrollTop = box.scrollHeight;
        // Показуємо останні помилки червоним банером (ТЗ: «показувалась поточна помилка»)
        const errLines = j.lines.filter((l: LogLine) => l.kind === 'err');
        if (errLines.length > 0) {
          const text = errLines.slice(-4).map((l: LogLine) => l.text).join('\n');
          if (/[Xx]\s|fail|помилк|error|невдал/i.test(text)) setLastError(text);
        }
      } else if (j.total && j.total < logOffset.current) {
        // новий запуск — лог скинуто
        logOffset.current = 0;
        setLog([]);
      }
    } catch { }
  }, []);

  useEffect(() => {
    refreshStatus();
    const t1 = setInterval(refreshStatus, 2500);
    const t2 = setInterval(pullLog, 1200);
    return () => { clearInterval(t1); clearInterval(t2); };
  }, [refreshStatus, pullLog]);

  const loadVersions = useCallback(async () => {
    try {
      const r = await fetch(`${SITE_BASE}/versions.json?t=${Date.now()}`, { cache: 'no-store' }).catch(() => null);
      if (r && r.ok) {
        const j = await r.json();
        if (Array.isArray(j.versions)) { setVersions(j.versions); setLatest(String(j.latest_version || '')); return; }
      }
      const r2 = await fetch(`${RAW_SITE_BASE}/versions.json?t=${Date.now()}`, { cache: 'no-store' }).catch(() => null);
      if (r2 && r2.ok) {
        const j2 = await r2.json();
        if (Array.isArray(j2.versions)) { setVersions(j2.versions); setLatest(String(j2.latest_version || '')); }
      }
    } catch { }
  }, []);
  useEffect(() => { loadVersions(); }, [loadVersions]);

  const saveChangelog = async (text: string) => {
    setChangelog(text);
    try {
      await fetch(`${BRIDGE_BASE}/api/changelog`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text })
      });
    } catch { }
  };

  const run = async (mode: RunMode) => {
    setLastError('');
    setLog([]);
    logOffset.current = 0;
    setBusyMode(mode);
    try {
      const r = await fetch(`${BRIDGE_BASE}/api/run`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mode, version: version.trim(), changelog })
      });
      const j = await r.json().catch(() => null);
      if (!j?.ok) {
        setLastError(j?.message || 'Не вдалося запустити задачу');
        setBusyMode(null);
      }
    } catch {
      setLastError('Програму FluxControlDeploy не запущено або міст недоступний');
      setBusyMode(null);
    }
  };

  const toolChips = st?.tools ? [
    { ok: st.tools.dotnet, label: 'dotnet SDK' },
    { ok: st.tools.git, label: 'git' },
    { ok: st.tools.gh, label: 'GitHub CLI' },
    { ok: st.tools.npm, label: 'node + npm' },
    { ok: st.tools.autod, label: 'Auto-Deploy.ps1' },
  ] : null;

  const MODES: { id: RunMode; title: string; desc: string; icon: React.ReactNode; accent: string }[] = [
    { id: 'build', title: 'Зібрати агента', desc: 'exe + файли, без публікації', icon: <Hammer className="h-5 w-5" />, accent: 'from-slate-600/80 to-slate-700/80 border-white/10' },
    { id: 'publish', title: 'Зібрати + опублікувати', desc: 'exe → сайт (оновлення для всіх)', icon: <Rocket className="h-5 w-5" />, accent: 'from-indigo-600/90 to-violet-600/90 border-indigo-400/30' },
    { id: 'web', title: 'Web + Server', desc: 'сайти pages.dev + render', icon: <Globe className="h-5 w-5" />, accent: 'from-cyan-600/80 to-sky-700/80 border-cyan-400/30' },
    { id: 'full', title: 'FULL DEPLOY', desc: 'агент + web + server одним рухом', icon: <Zap className="h-5 w-5" />, accent: 'from-amber-500/90 to-orange-600/90 border-amber-400/40' },
  ];

  return (
    <div className="min-h-screen bg-[#050508] px-4 py-8 text-gray-100 sm:px-8">
      <div className="pointer-events-none fixed left-1/4 top-0 -z-10 h-[420px] w-[420px] rounded-full bg-indigo-600/10 blur-[130px]" />
      <div className="pointer-events-none fixed bottom-0 right-1/4 -z-10 h-[500px] w-[500px] rounded-full bg-violet-600/10 blur-[150px]" />

      <div className="mx-auto max-w-5xl space-y-6">
        {/* Шапка */}
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
          <div className="grid h-14 w-14 place-items-center rounded-3xl border border-indigo-400/30 bg-gradient-to-br from-indigo-600/40 to-violet-600/30 text-indigo-200 shadow-lg shadow-indigo-600/20">
            <Terminal className="h-7 w-7" />
          </div>
          <div className="min-w-0 flex-1">
            <h1 className="text-2xl font-black tracking-tight text-white">FluxControl Deploy Console</h1>
            <p className="mt-0.5 text-xs text-gray-400">
              Приватна панель деплою · fluxcontrol.pages.dev
              {st?.projectRoot && <span className="ml-1 text-gray-600">· {st.projectRoot}</span>}
            </p>
          </div>
          <div className={`flex items-center gap-2 rounded-2xl border px-3.5 py-2 text-xs font-bold ${bridgeUp ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-300' : bridgeUp === false ? 'border-rose-500/30 bg-rose-500/10 text-rose-300' : 'border-white/10 bg-white/5 text-gray-400'}`}>
            {bridgeUp === true && <><CircleCheck className="h-4 w-4" /> Програма підключена</>}
            {bridgeUp === false && <><CircleX className="h-4 w-4" /> Запусти FluxControlDeploy.exe</>}
            {bridgeUp === null && <><Loader2 className="h-4 w-4 animate-spin" /> Шукаю програму…</>}
          </div>
        </div>

        {/* Статус версій + інструменти */}
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
          <div className="glass-card rounded-2xl border border-white/10 bg-[#090b14]/80 p-4">
            <p className="flex items-center gap-1.5 text-[10px] font-black uppercase tracking-wider text-gray-400"><Globe className="h-3.5 w-3.5" /> Версія на сайті</p>
            <p className="mt-1 font-mono text-xl font-black text-white">{st?.siteVersion ? `v${st.siteVersion}` : '—'}</p>
          </div>
          <div className="glass-card rounded-2xl border border-white/10 bg-[#090b14]/80 p-4">
            <p className="flex items-center gap-1.5 text-[10px] font-black uppercase tracking-wider text-gray-400"><PackageCheck className="h-3.5 w-3.5" /> Зібрано локально</p>
            <p className="mt-1 font-mono text-xl font-black text-white">{st?.deployVersion ? `v${st.deployVersion}` : '—'}</p>
          </div>
          <div className="glass-card rounded-2xl border border-white/10 bg-[#090b14]/80 p-4">
            <p className="flex items-center gap-1.5 text-[10px] font-black uppercase tracking-wider text-gray-400"><GitBranch className="h-3.5 w-3.5" /> Наступна версія</p>
            <p className="mt-1 font-mono text-xl font-black text-emerald-300">{st?.suggested ? `v${st.suggested}` : '—'}</p>
          </div>
        </div>

        {/* Інструменти */}
        {toolChips && (
          <div className="flex flex-wrap gap-2">
            {toolChips.map(t => (
              <span key={t.label} className={`flex items-center gap-1.5 rounded-full border px-3 py-1 text-[11px] font-bold ${t.ok ? 'border-emerald-500/25 bg-emerald-500/10 text-emerald-300' : 'border-rose-500/25 bg-rose-500/10 text-rose-300'}`}>
                {t.ok ? <CircleCheck className="h-3 w-3" /> : <CircleX className="h-3 w-3" />}
                {t.label}
              </span>
            ))}
          </div>
        )}

        {/* Кнопки дій */}
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {MODES.map(m => {
            const isBusy = busyMode !== null;
            const active = busyMode === m.id;
            return (
              <button
                key={m.id}
                onClick={() => run(m.id)}
                disabled={isBusy || !bridgeUp}
                title={isBusy && !active ? `Виконується: ${busyMode}` : undefined}
                className={`group relative overflow-hidden rounded-2xl border bg-gradient-to-br p-4 text-left transition-all disabled:cursor-not-allowed disabled:opacity-45 ${m.accent} ${active ? 'ring-2 ring-white/50' : 'hover:brightness-110 active:scale-[0.98]'} cursor-pointer`}
              >
                <div className="flex items-center justify-between">
                  {m.icon}
                  {active ? <Loader2 className="h-4 w-4 animate-spin text-white/90" /> : null}
                </div>
                <p className="mt-3 text-sm font-black text-white">{m.title}</p>
                <p className="mt-0.5 text-[11px] font-semibold text-white/70">{m.desc}</p>
              </button>
            );
          })}
        </div>

        {/* Версія + changelog */}
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
          <div className="glass-card rounded-3xl border border-white/10 bg-[#090b14]/80 p-5">
            <label className="text-[10px] font-black uppercase tracking-wider text-gray-400">Версія деплою</label>
            <input
              value={version}
              onChange={e => setVersion(e.target.value)}
              placeholder="1.2.9 — Enter = авто"
              className="mt-2 w-full rounded-xl border border-white/10 bg-black/60 px-3.5 py-2.5 font-mono text-sm font-bold text-white outline-none placeholder:text-gray-600 focus:border-indigo-500/50"
            />
            <p className="mt-2 text-[10.5px] leading-relaxed text-gray-500">
              Порожнє поле = автоматично <b className="text-gray-400">+0.0.1</b> до версії на сайті. Формат — рівно три цифри: <b className="text-gray-400">1.2.3</b>.
            </p>
            <div className="mt-3 flex items-center gap-2 rounded-xl border border-white/5 bg-black/40 px-3 py-2 text-[10.5px] text-gray-400">
              <LockKeyhole className="h-3.5 w-3.5 flex-none text-indigo-300" />
              Ключ консолі: <span className="font-mono font-bold text-gray-300">{DEPLOY_KEY}</span>
            </div>
          </div>
          <div className="glass-card rounded-3xl border border-white/10 bg-[#090b14]/80 p-5 lg:col-span-2">
            <label className="flex items-center gap-1.5 text-[10px] font-black uppercase tracking-wider text-gray-400">
              <FileText className="h-3.5 w-3.5" /> Changelog цієї версії (поїде на сайт разом з exe)
            </label>
            <textarea
              value={changelog}
              onChange={e => saveChangelog(e.target.value)}
              rows={6}
              placeholder={'Напиши, що змінилось у цій версії…\nНаприклад:\n• Фікс іконок процесів\n• Нова вкладка «Оновлення»'}
              className="mt-2 w-full resize-y rounded-xl border border-white/10 bg-black/60 px-3.5 py-2.5 text-xs leading-relaxed text-gray-200 outline-none placeholder:text-gray-600 focus:border-indigo-500/50"
            />
            <p className="mt-1.5 text-[10px] text-gray-500">Зберігається в Installer\changelog.md і автоматично вкладається у версію, яку ти деплоїш.</p>
          </div>
        </div>

        {/* Поточна помилка (ТЗ) */}
        {lastError && (
          <div className="rounded-2xl border border-rose-500/30 bg-rose-950/40 p-4">
            <p className="flex items-center gap-1.5 text-xs font-black uppercase tracking-wider text-rose-300"><CircleX className="h-4 w-4" /> Поточна помилка</p>
            <pre className="mt-2 whitespace-pre-wrap break-all font-mono text-[11px] leading-relaxed text-rose-200">{lastError}</pre>
          </div>
        )}

        {/* Живий лог */}
        <div className="glass-card overflow-hidden rounded-3xl border border-white/10 bg-[#090b14]/90">
          <div className="flex items-center gap-2 border-b border-white/5 px-5 py-3">
            <Cpu className="h-4 w-4 text-indigo-300" />
            <p className="text-xs font-black uppercase tracking-wider text-gray-300">Живий лог деплою</p>
            {busyMode && (
              <span className="ml-auto flex items-center gap-1.5 rounded-full border border-indigo-500/30 bg-indigo-500/15 px-2.5 py-0.5 text-[10px] font-black text-indigo-300">
                <Loader2 className="h-3 w-3 animate-spin" /> виконується: {busyMode}
              </span>
            )}
          </div>
          <div ref={logBoxRef} className="h-72 overflow-y-auto bg-black/70 px-5 py-4 font-mono text-[11px] leading-relaxed">
            {log.length === 0 ? (
              <p className="text-gray-600">Лог з&apos;явиться тут, коли запустиш задачу…</p>
            ) : (
              log.map(l => (
                <p key={l.i} className={`whitespace-pre-wrap break-all ${l.kind === 'err' ? 'text-rose-300' : l.kind === 'sys' ? 'text-indigo-300' : 'text-gray-300'}`}>
                  {l.text}
                </p>
              ))
            )}
          </div>
        </div>

        {/* Архів версій з сайту */}
        <div className="glass-card rounded-3xl border border-white/10 bg-[#090b14]/80 p-5">
          <div className="flex items-center gap-2">
            <PackageCheck className="h-4 w-4 text-emerald-300" />
            <p className="text-xs font-black uppercase tracking-wider text-gray-300">Архів версій на сайті</p>
            <button onClick={loadVersions} className="ml-auto cursor-pointer text-gray-500 hover:text-white"><RefreshCw className="h-3.5 w-3.5" /></button>
          </div>
          {versions.length === 0 ? (
            <p className="mt-3 text-[11px] text-gray-500">Ще немає збережених версій — вони з&apos;являться після першого деплою v6-скриптом.</p>
          ) : (
            <div className="mt-3 flex flex-wrap gap-2">
              {versions.map(v => (
                <a
                  key={v.version}
                  href={`${SITE_BASE}/versions/${encodeURIComponent(v.version)}/FluxControl.exe`}
                  download
                  className={`flex cursor-pointer items-center gap-1.5 rounded-xl border px-3 py-1.5 text-[11px] font-bold transition-colors ${v.version === latest ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-300' : 'border-white/10 bg-white/5 text-gray-300 hover:bg-white/10 hover:text-white'}`}
                >
                  <ArrowDownToLine className="h-3 w-3" /> v{v.version}
                </a>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
