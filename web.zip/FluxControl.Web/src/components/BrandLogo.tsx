import React from 'react';

/**
 * BrandLogo — офіційний бренд-знак FluxControl v2 (той самий, що в logo.ico
 * програми, favicon.svg сайту і нативному splash-екрані агента).
 *
 * ЗА ФІДБЕКОМ (ТЗ): біля напису «FluxControl» має стояти саме ІКОНКА
 * ПРОГРАМИ (штриховий градієнт-знак), а не намальована «гроза» з бібліотеки
 * іконок. Тому всюди в навігації використовуємо цей компонент.
 *
 * viewBox 512×512, той самий path, що в public/favicon.svg та MainWindow.xaml.
 */
export const BrandLogo: React.FC<{
  /** Розмір плитки в px (за замовчуванням 36). */
  size?: number;
  className?: string;
  /** Прибрати скляну плитку (коли знак малюється на власній плитці). */
  bare?: boolean;
}> = ({ size = 36, className = '', bare = false }) => {
  // Унікальні id градієнтів — щоб кілька інстансів на сторінці не конфліктували.
  const uid = React.useId().replace(/[:]/g, '');
  const gradId = `fcx-brand-grad-${uid}`;
  const boltId = `fcx-brand-bolt-${uid}`;

  if (bare) {
    return (
      <svg
        viewBox="0 0 512 512"
        width={size}
        height={size}
        className={className}
        aria-hidden="true"
        role="img"
      >
        <defs>
          <linearGradient id={gradId} x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#A78BFA" />
            <stop offset=".55" stopColor="#7C3AED" />
            <stop offset="1" stopColor="#4F46E5" />
          </linearGradient>
          <linearGradient id={boltId} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#FFFFFF" />
            <stop offset="1" stopColor="#DDE3FF" />
          </linearGradient>
        </defs>
        <path
          fill={`url(#${gradId})`}
          d="M256 20C126 20 20 126 20 256s106 236 236 236 236-106 236-236S386 20 256 20Zm0 44c106 0 192 86 192 192s-86 192-192 192S64 362 64 256 150 64 256 64Z"
        />
        <path
          fill={`url(#${boltId})`}
          d="M272 116Q190 190 143 287Q135 296 147 296L255 296Q266 296 263 307L245 388Q242 400 253 391Q300 340 378 232Q385 223 374 223L263 223Q252 223 255 212L274 130Q278 116 272 116Z"
        />
      </svg>
    );
  }

  return (
    <span
      className={`relative inline-flex items-center justify-center overflow-hidden rounded-[30%] shadow-lg shadow-indigo-600/30 ${className}`}
      style={{
        width: size,
        height: size,
        background: 'linear-gradient(135deg,#8B5CF6 0%,#6366F1 100%)',
      }}
      aria-hidden="true"
    >
      <svg viewBox="0 0 512 512" width={size * 0.66} height={size * 0.66}>
        <defs>
          <linearGradient id={boltId} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#FFFFFF" />
            <stop offset="1" stopColor="#DDE3FF" />
          </linearGradient>
        </defs>
        <path
          fill={`url(#${boltId})`}
          d="M272 116Q190 190 143 287Q135 296 147 296L255 296Q266 296 263 307L245 388Q242 400 253 391Q300 340 378 232Q385 223 374 223L263 223Q252 223 255 212L274 130Q278 116 272 116Z"
        />
      </svg>
    </span>
  );
};

BrandLogo.displayName = 'BrandLogo';
