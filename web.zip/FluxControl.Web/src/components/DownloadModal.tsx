import React, { useState, useEffect } from 'react';
import { 
  Download, 
  X, 
  Check, 
  ShieldCheck, 
  Laptop, 
  FileCode, 
  Sparkles,
  AlertCircle,
  RefreshCw
} from 'lucide-react';

interface DownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

// Маніфест оновлень — той самий, яким користується сама програма
// (UpdateService/BootstrapService читають version.json з офіційного сайту).
const MANIFEST_URLS = ['/version.json', 'https://fluxcontrol.pages.dev/version.json'];
// Резервна пряма адреса клієнта, якщо манифест недоступний.
const FALLBACK_EXE_URL = 'https://raw.githubusercontent.com/matviikobrys2707/FluxControl_Release/main/files/FluxControl.exe';

interface ClientInfo {
  version: string | null;
  sizeBytes: number | null;
  downloadUrl: string;
  manifestOk: boolean;
}

export const DownloadModal: React.FC<DownloadModalProps> = ({ isOpen, onClose }) => {
  const [info, setInfo] = useState<ClientInfo | null>(null);
  const [loading, setLoading] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [downloaded, setDownloaded] = useState(false);

  // Реальні дані клієнта: читаємо манифест version.json (та сама адреса,
  // якою оновлюється програма) і HEAD-запитом дізнаємось справжній розмір.
  useEffect(() => {
    if (!isOpen) return;
    let cancelled = false;

    const load = async () => {
      setLoading(true);
      setDownloaded(false);
      let version: string | null = null;
      let downloadUrl = FALLBACK_EXE_URL;
      let manifestOk = false;

      for (const url of MANIFEST_URLS) {
        try {
          const res = await fetch(url, { cache: 'no-store' });
          if (!res.ok) continue;
          const data = await res.json();
          if (data && (data.download_url || data.latest_version)) {
            version = typeof data.latest_version === 'string' ? data.latest_version : null;
            if (typeof data.download_url === 'string' && data.download_url.startsWith('http')) {
              downloadUrl = data.download_url;
            }
            manifestOk = true;
            break;
          }
        } catch { /* наступне джерело */ }
      }

      let sizeBytes: number | null = null;
      try {
        const head = await fetch(downloadUrl, { method: 'HEAD' });
        const len = head.headers.get('content-length');
        if (len && Number(len) > 0) sizeBytes = Number(len);
      } catch { /* розмір недоступний — покажемо «—» */ }

      if (!cancelled) {
        setInfo({ version, sizeBytes, downloadUrl, manifestOk });
        setLoading(false);
      }
    };

    load();
    return () => { cancelled = true; };
  }, [isOpen]);

  if (!isOpen) return null;

  const fileName = info ? (info.downloadUrl.split('/').pop() || 'FluxControl.exe') : 'FluxControl.exe';
  const sizeText = loading
    ? '…'
    : info?.sizeBytes
      ? `${(info.sizeBytes / 1048576).toFixed(1).replace('.', ',')} МБ`
      : '—';

  // РЕАЛЬНЕ завантаження: клік по прямому посиланню з манифеста оновлень.
  // Той самий файл, який сама програма качає під час оновлення.
  const handleStartDownload = () => {
    if (!info) return;
    setDownloading(true);
    try {
      const element = document.createElement('a');
      element.href = info.downloadUrl;
      element.rel = 'noopener';
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);
      setDownloaded(true);
      setTimeout(() => setDownloaded(false), 6000);
    } finally {
      setTimeout(() => setDownloading(false), 800);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
      <div className="glass-panel w-full max-w-lg rounded-3xl p-6 sm:p-8 border border-white/15 bg-[#090b14] shadow-2xl relative space-y-6">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-indigo-600/20 border border-indigo-500/30 rounded-2xl text-indigo-300">
              <Laptop className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg sm:text-xl font-black text-white">
                Завантажити FluxControl.exe
              </h3>
              <p className="text-xs text-indigo-300/80 font-mono">
                Офіційний агент для Windows 10 / 11 (64-bit)
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-gray-400 hover:text-white rounded-xl hover:bg-white/5 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Download file details card — реальні версія і розмір з манифеста */}
        <div className="p-5 rounded-2xl bg-black/50 border border-white/10 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <FileCode className="w-5 h-5 text-indigo-400" />
              <div>
                <span className="font-bold text-white text-sm">{fileName}</span>
                <span className="text-[11px] text-gray-400 block font-mono">
                  {loading
                    ? 'Читаю дані з сервера оновлень…'
                    : info?.version
                      ? `Остання версія v${info.version}`
                      : 'Версія: дані з сервера оновлень'}
                </span>
              </div>
            </div>
            <span className="text-xs font-mono font-bold text-emerald-400">{sizeText}</span>
          </div>

          <div className="pt-2 border-t border-white/10 flex flex-wrap items-center gap-4 text-xs text-gray-400">
            <span className="flex items-center gap-1.5 text-emerald-400">
              <ShieldCheck className="w-4 h-4" />
              <span>Та сама збірка, яку качає програма під час оновлення</span>
            </span>
          </div>
        </div>

        {/* Setup steps overview */}
        <div className="space-y-2 text-xs text-gray-300">
          <p className="font-bold text-white mb-1 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
            <span>Як запустити:</span>
          </p>
          <div className="space-y-1.5 pl-2 border-l-2 border-indigo-500/30">
            <p>1. Збережіть файл <span className="text-indigo-300 font-semibold font-mono">{fileName}</span> на комп'ютер.</p>
            <p>2. Запустіть програму — у вікні згенерується ваш унікальний код.</p>
            <p>3. Введіть цей код на вкладці <span className="text-white font-semibold">«Пристрої»</span> для миттєвого доступу.</p>
          </div>
        </div>

        {downloaded && (
          <div className="p-3 bg-emerald-500/15 border border-emerald-500/30 rounded-xl text-emerald-300 text-xs flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            <span>Завантаження почалось! Якщо браузер не почав качати — дозвольте завантаження файлів для цього сайту.</span>
          </div>
        )}

        {!loading && info && !info.manifestOk && (
          <div className="p-3 bg-amber-500/10 border border-amber-500/25 rounded-xl text-amber-300/90 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-amber-400 flex-shrink-0" />
            <span>Маніфест недоступний — завантажуємо напряму з офіційного сховища релізів.</span>
          </div>
        )}

        {/* Action button */}
        <div className="flex items-center gap-3 pt-2">
          <button
            onClick={onClose}
            className="px-5 py-3 text-xs font-semibold text-gray-400 hover:text-white transition-colors cursor-pointer"
          >
            Закрити
          </button>

          <button
            id="modal-confirm-download-btn"
            onClick={handleStartDownload}
            disabled={downloading || loading || !info}
            className="flex-1 flex items-center justify-center gap-2 py-3 bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white rounded-2xl font-black text-xs transition-all shadow-xl shadow-indigo-600/30 cursor-pointer disabled:opacity-50"
          >
            {loading
              ? <RefreshCw className="w-4 h-4 animate-spin" />
              : <Download className="w-4 h-4" />}
            <span>{loading ? 'Готую дані…' : downloading ? 'Завантаження почалось…' : `Завантажити ${fileName}`}</span>
          </button>
        </div>

      </div>
    </div>
  );
};
