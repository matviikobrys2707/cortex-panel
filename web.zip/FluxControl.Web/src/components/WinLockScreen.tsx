import React, { useEffect, useRef, useState } from 'react';
import { Lock, ShieldAlert, Monitor } from 'lucide-react';
import { BrandLogo } from './BrandLogo';

/**
 * WinLockScreen — СТОРІНКА БЛОКУВАННЯ ПК (/winlock).
 *
 * Ця сторінка грузиться у WEBVIEW2 нативного LockWindow агента (ТЗ: «дизайн
 * блокування зробити через WebView2, з URL на сайті, а не кодом C#»).
 * Тут повноцінний веб-дизайн: скляні картки, пульсуючі кільця, світіння,
 * анімації — все оновлюється разом із сайтом без перезбірки програми.
 *
 * Протокол зв'язку з хостом (postMessage):
 *   сторінка → хост:  { type: 'winlock_try',  code }       — спроба розблокувати
 *   сторінка → хост:  { type: 'winlock_ready' }            — сторінка готова
 *   хост → сторінка:  { type: 'winlock_unlock_result', ok: false } — невірний код
 *   хост → сторінка:  { type: 'winlock_state', mode, lockedAt, pc }
 *
 * Параметри URL: ?mode=code|site&lockedAt=<unix-ms>&pc=<MachineName>
 * Якщо сторінку відкрито у ЗВИЧАЙНОМУ браузері (поза WebView2) — показуємо
 * інформаційний режим («це сторінка блокування, вона працює на заблокованому ПК»).
 */

const isWebView2 = (): boolean =>
  typeof window !== 'undefined' &&
  Boolean((window as any).chrome && (window as any).chrome.webview);

const postToHost = (payload: Record<string, unknown>) => {
  try {
    (window as any).chrome?.webview?.postMessage(JSON.stringify(payload));
  } catch { }
};

export const WinLockScreen: React.FC = () => {
  const params = new URLSearchParams(window.location.search);
  const urlMode = params.get('mode') === 'site' ? 'site' : 'code';
  const lockedAtParam = Number(params.get('lockedAt') || 0);
  const pcParam = params.get('pc') || '';

  const [inHost] = useState<boolean>(isWebView2);
  const [mode, setMode] = useState<'code' | 'site'>(urlMode);
  const [pc, setPc] = useState<string>(pcParam);
  const [lockedAt, setLockedAt] = useState<number>(lockedAtParam);
  const [code, setCode] = useState('');
  const [error, setError] = useState(false);
  const [checking, setChecking] = useState(false);
  const [unlocked, setUnlocked] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const errorTimer = useRef<number | null>(null);

  useEffect(() => {
    postToHost({ type: 'winlock_ready' });
    if (inHost && urlMode === 'code') {
      setTimeout(() => inputRef.current?.focus(), 350);
    }
    if (!inHost || !(window as any).chrome?.webview) return;

    const onMessage = (event: any) => {
      try {
        const raw = event.data || (typeof event === 'string' ? JSON.parse(event) : event);
        const msg = typeof raw === 'string' ? JSON.parse(raw) : raw;
        if (!msg) return;
        if (msg.type === 'winlock_unlock_result') {
          setChecking(false);
          if (msg.ok) {
            setUnlocked(true);
          } else {
            setError(true);
            setCode('');
            setTimeout(() => inputRef.current?.focus(), 60);
            if (errorTimer.current) window.clearTimeout(errorTimer.current);
            errorTimer.current = window.setTimeout(() => setError(false), 900);
          }
        } else if (msg.type === 'winlock_state') {
          if (msg.mode === 'site' || msg.mode === 'code') setMode(msg.mode);
          if (typeof msg.lockedAt === 'number' && msg.lockedAt > 0) setLockedAt(msg.lockedAt);
          if (typeof msg.pc === 'string' && msg.pc) setPc(msg.pc);
        }
      } catch { }
    };
    (window as any).chrome.webview.addEventListener('message', onMessage);
    return () => (window as any).chrome?.webview?.removeEventListener('message', onMessage);
  }, [inHost, urlMode]);

  const submit = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (checking || unlocked) return;
    if (!code.trim()) return;
    setChecking(true);
    postToHost({ type: 'winlock_try', code });
    // Хост відповідає winlock_unlock_result; страховий таймер на випадок моргу.
    window.setTimeout(() => setChecking(false), 2500);
  };

  const lockedTime = lockedAt > 0
    ? new Date(lockedAt).toLocaleTimeString('uk-UA', { hour: '2-digit', minute: '2-digit' })
    : '';

  return (
    <div className="relative min-h-screen overflow-hidden bg-[#050508] font-sans text-white">
      {/* ambient glows */}
      <div className="pointer-events-none absolute -top-40 left-1/2 h-[420px] w-[720px] -translate-x-1/2 rounded-full bg-violet-700/20 blur-[130px]" />
      <div className="pointer-events-none absolute -bottom-48 right-[8%] h-[380px] w-[520px] rounded-full bg-indigo-700/15 blur-[140px]" />
      <div className="pointer-events-none absolute left-[6%] top-[30%] h-[260px] w-[260px] rounded-full bg-fuchsia-700/10 blur-[120px]" />

      {/*grid texture */}
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.35]"
        style={{
          backgroundImage:
            'linear-gradient(rgba(255,255,255,.025) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.025) 1px, transparent 1px)',
          backgroundSize: '44px 44px',
        }}
      />

      <div className="relative z-10 flex min-h-screen flex-col items-center justify-center px-5 py-10">
        {/* Верхній бренд-рядок — та сама іконка програми */}
        <div className="mb-9 flex items-center gap-2.5 opacity-90">
          <BrandLogo size={34} />
          <span className="text-base font-extrabold tracking-tight">
            Flux<span className="text-indigo-300">Control</span>
          </span>
        </div>

        {unlocked ? (
          <div className="fcx-win-card fcx-win-pop flex w-full max-w-md flex-col items-center gap-4 rounded-3xl border border-emerald-500/30 bg-emerald-950/20 p-9 text-center backdrop-blur-2xl">
            <div className="grid h-20 w-20 place-items-center rounded-full border border-emerald-400/40 bg-emerald-500/15 text-emerald-300">
              <Lock className="h-9 w-9" />
            </div>
            <h1 className="text-2xl font-black">Розблоковано</h1>
            <p className="text-sm text-emerald-200/80">Вікно блокування зараз закриється…</p>
          </div>
        ) : (
          <div className="fcx-win-pop w-full max-w-md">
            {/* Пульсуючі кільця навколо замка */}
            <div className="relative mx-auto mb-8 h-32 w-32">
              <span className="fcx-win-ring absolute inset-[-10px] rounded-full border-2 border-violet-500/40" />
              <span className="fcx-win-ring fcx-win-ring-late absolute inset-[-10px] rounded-full border-2 border-indigo-500/30" />
              <div className="fcx-win-breathe relative grid h-32 w-32 place-items-center rounded-full border border-violet-500/30 bg-gradient-to-br from-violet-950/80 to-indigo-950/60 shadow-[0_20px_60px_-18px_rgba(124,58,237,.75)] backdrop-blur-xl">
                <Lock className="h-14 w-14 text-violet-200" strokeWidth={1.7} />
              </div>
            </div>

            <div className="rounded-3xl border border-white/10 bg-white/[0.045] p-7 text-center shadow-2xl backdrop-blur-2xl sm:p-8">
              <h1 className="text-3xl font-black tracking-tight text-white">ПК заблоковано</h1>
              <p className="mt-2.5 text-sm leading-relaxed text-zinc-400">
                Комп&apos;ютер заблоковано адміністратором через FluxControl
              </p>

              {(pc || lockedTime) && (
                <div className="mt-5 flex flex-wrap items-center justify-center gap-2">
                  {pc && (
                    <span className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-black/50 px-3 py-1.5 text-xs font-bold text-zinc-200">
                      <Monitor className="h-3.5 w-3.5 text-indigo-300" />
                      {pc}
                    </span>
                  )}
                  {lockedTime && (
                    <span className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-black/50 px-3 py-1.5 text-xs font-bold text-zinc-300">
                      <ShieldAlert className="h-3.5 w-3.5 text-amber-300" />
                      Заблоковано о {lockedTime}
                    </span>
                  )}
                </div>
              )}

              {mode === 'code' ? (
                <form onSubmit={submit} className="mt-7">
                  <input
                    ref={inputRef}
                    type="text"
                    value={code}
                    onChange={(e) => { setCode(e.target.value); setError(false); }}
                    placeholder="Код розблокування"
                    autoComplete="off"
                    spellCheck={false}
                    maxLength={32}
                    className={`fcx-win-input w-full rounded-2xl border bg-black/50 px-5 py-4 text-center text-lg font-bold tracking-[0.18em] text-white placeholder:tracking-normal placeholder:text-zinc-600 outline-none transition-all ${
                      error
                        ? 'border-rose-500/60 shadow-[0_0_0_4px_rgba(244,63,94,.12)]'
                        : 'border-white/12 focus:border-violet-400/60 focus:shadow-[0_0_0_4px_rgba(124,58,237,.16)]'
                    } ${error ? 'fcx-win-shake' : ''}`}
                  />
                  {error && (
                    <p className="mt-2.5 text-xs font-bold text-rose-400">Неправильний код — спробуйте ще раз</p>
                  )}
                  <button
                    type="submit"
                    disabled={checking}
                    className="fcx-win-btn mt-4 w-full rounded-2xl bg-gradient-to-br from-violet-600 via-violet-600 to-indigo-700 px-5 py-4 text-base font-extrabold text-white shadow-[0_16px_40px_-12px_rgba(124,58,237,.9)] transition-all hover:brightness-110 active:scale-[.98] disabled:cursor-not-allowed disabled:opacity-60"
                  >
                    {checking ? 'Перевірка…' : 'Розблокувати'}
                  </button>
                  <p className="mt-4 text-[11px] leading-relaxed text-zinc-500">
                    Введіть код розблокування, який встановив власник ПК
                  </p>
                </form>
              ) : (
                <div className="mt-7 rounded-2xl border border-white/10 bg-black/40 p-5">
                  <p className="text-base font-bold text-zinc-100">Розблокування можливе лише з сайту власника</p>
                  <p className="mt-2 text-xs leading-relaxed text-zinc-500">
                    Ваш адміністратор знає, як це зробити
                  </p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Інформаційний режим (звичайний браузер) */}
        {!inHost && (
          <div className="mt-8 max-w-md rounded-2xl border border-amber-500/25 bg-amber-950/20 px-5 py-4 text-center text-xs leading-relaxed text-amber-200/90 backdrop-blur-xl">
            Це сторінка екрана блокування FluxControl. Вона автоматично відкривається
            на заблокованому комп&apos;ютері у вікні програми — саме там вводиться код
            розблокування.
          </div>
        )}

        <p className="mt-9 flex items-center gap-2 text-[11px] text-zinc-600">
          <Lock className="h-3 w-3" />
          Захищений режим блокування · FluxControl
        </p>
      </div>

      {/* локальні стилі анімацій (не ліземо в глобальний index.css) */}
      <style>{`
        @keyframes fcxWinPop { from { opacity:0; transform:scale(.92) translateY(18px); } to { opacity:1; transform:none; } }
        .fcx-win-pop { animation: fcxWinPop .5s cubic-bezier(.22,1,.36,1) both; }
        @keyframes fcxWinRing { 0% { transform:scale(.82); opacity:.65; } 100% { transform:scale(1.5); opacity:0; } }
        .fcx-win-ring { animation: fcxWinRing 2.2s ease-out infinite; }
        .fcx-win-ring-late { animation-delay: 1.1s; }
        @keyframes fcxWinBreathe { 0%,100% { box-shadow:0 20px 60px -18px rgba(124,58,237,.75); } 50% { box-shadow:0 20px 70px -12px rgba(139,92,246,.95); } }
        .fcx-win-breathe { animation: fcxWinBreathe 2.6s ease-in-out infinite; }
        @keyframes fcxWinShake { 0%,100% { transform:translateX(0); } 20% { transform:translateX(-8px); } 40% { transform:translateX(8px); } 60% { transform:translateX(-5px); } 80% { transform:translateX(5px); } }
        .fcx-win-shake { animation: fcxWinShake .5s ease; }
        .fcx-win-btn { position:relative; overflow:hidden; }
        .fcx-win-btn::after { content:''; position:absolute; top:0; bottom:0; left:-40%; width:30%;
          background:linear-gradient(100deg,transparent,rgba(255,255,255,.35),transparent);
          transform:skewX(-18deg); animation:fcxWinShine 3.2s ease-in-out infinite; }
        @keyframes fcxWinShine { 0%,55% { left:-40%; } 85%,100% { left:130%; } }
      `}</style>
    </div>
  );
};

export default WinLockScreen;
