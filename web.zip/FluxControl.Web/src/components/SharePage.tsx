import React, { useEffect, useState } from 'react';
import { Folder, File as FileIcon, Download, Loader2, ShieldAlert, Clock } from 'lucide-react';
import { relayUrl } from '../services/relayBase';

/**
 * «Поділитися» (ТЗ): публічна сторінка за посиланням /s/<token>.
 * Друг бачить назву файла (або папки → ZIP) і кнопку «Скачати».
 * Посилання живе, поки на ПК власника працює програма-агент (сеансове
 * життя на сервері-релеї): перезапуск агента або видалення файла робить
 * сторінку неактивною.
 */
export const SharePage: React.FC = () => {
  const [state, setState] = useState<'loading' | 'ready' | 'expired' | 'offline' | 'error'>('loading');
  const [info, setInfo] = useState<{ name: string; isDir: boolean; sizeBytes: number; deviceName?: string } | null>(null);
  const [downloading, setDownloading] = useState(false);
  const [errMsg, setErrMsg] = useState('');

  const token = window.location.pathname.split('/').filter(Boolean)[1] || '';

  useEffect(() => {
    let dead = false;
    (async () => {
      if (!token) {
        setState('expired');
        return;
      }
      try {
        const res = await fetch(relayUrl(`/api/share/info?token=${encodeURIComponent(token)}`), {
          signal: AbortSignal.timeout(15000)
        });
        const data = await res.json().catch(() => null);
        if (dead) return;
        if (data?.success) {
          setInfo({ name: data.name, isDir: Boolean(data.isDir), sizeBytes: Number(data.sizeBytes) || 0, deviceName: data.deviceName });
          setState('ready');
        } else if (data?.reason === 'offline') {
          setErrMsg(String(data.error || ''));
          setState('offline');
        } else {
          setErrMsg(String(data?.error || ''));
          setState('expired');
        }
      } catch (e: any) {
        if (!dead) {
          setErrMsg(String(e?.message || e));
          setState('error');
        }
      }
    })();
    return () => { dead = true; };
  }, [token]);

  const fmtSize = (b: number): string => {
    if (!b || b <= 0) return '';
    if (b >= 1024 ** 3) return `${(b / 1024 ** 3).toFixed(b >= 10 * 1024 ** 3 ? 1 : 2)} ГБ`;
    if (b >= 1024 ** 2) return `${(b / 1024 ** 2).toFixed(b >= 10 * 1024 ** 2 ? 0 : 1)} МБ`;
    if (b >= 1024) return `${Math.round(b / 1024)} КБ`;
    return `${b} Б`;
  };

  const startDownload = () => {
    if (downloading) return;
    setDownloading(true);
    // Прямий перехід на стрім релея — браузер сам покаже завантаження.
    window.location.href = relayUrl(`/api/share/download?token=${encodeURIComponent(token)}`);
    // Якщо сервер повернув помилку (JSON), сторінка перезавантажиться JSON-ом;
    // для дружнього UX повертаємось через 3с, якщо завантаження не почалось.
    setTimeout(() => setDownloading(false), 3000);
  };

  return (
    <div className="relative flex min-h-screen flex-col items-center justify-center bg-[#050508] p-6 font-sans text-gray-100">
      <div className="pointer-events-none fixed -top-40 left-1/2 h-[420px] w-[720px] -translate-x-1/2 rounded-full bg-violet-700/15 blur-[130px]" />
      <div className="pointer-events-none fixed bottom-[-190px] right-[8%] h-[380px] w-[520px] rounded-full bg-indigo-700/15 blur-[130px]" />

      <div className="relative z-10 w-full max-w-md">
        {/* Лого (ТЗ) */}
        <div className="mb-8 flex items-center justify-center gap-2.5">
          <svg viewBox="0 0 24 24" fill="none" stroke="url(#lg-share)" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" className="h-7 w-7">
            <defs>
              <linearGradient id="lg-share" x1="0" y1="0" x2="24" y2="24">
                <stop stopColor="#818cf8" />
                <stop offset="1" stopColor="#c084fc" />
              </linearGradient>
            </defs>
            <path d="M2 12 L7 3 L12 12 L17 3 L22 12" />
          </svg>
          <span className="text-lg font-extrabold tracking-tight">
            Flux<span className="text-indigo-300">Control</span>
          </span>
        </div>

        <div className="rounded-3xl border border-white/10 bg-white/[.045] p-7 text-center shadow-[0_25px_60px_-20px_rgba(0,0,0,.8)]">
          {state === 'loading' && (
            <div className="flex flex-col items-center gap-4 py-6">
              <Loader2 className="h-8 w-8 animate-spin text-violet-300" />
              <p className="text-sm font-semibold text-zinc-300">Перевіряю посилання…</p>
            </div>
          )}

          {state === 'ready' && info && (
            <>
              <div className="mx-auto grid h-20 w-20 place-items-center rounded-3xl border border-indigo-400/25 bg-indigo-500/15">
                {info.isDir
                  ? <Folder className="h-9 w-9 text-indigo-300" />
                  : <FileIcon className="h-9 w-9 text-indigo-300" />}
              </div>
              <h1 className="mt-5 break-all text-lg font-extrabold leading-snug text-white">{info.name}</h1>
              <p className="mt-1.5 text-xs text-zinc-400">
                {info.isDir ? 'Папка буде завантажена як ZIP-архів' : 'Файл з ПК власника'}
                {info.sizeBytes > 0 ? ` · ${fmtSize(info.sizeBytes)}` : ''}
              </p>
              <button
                type="button"
                onClick={startDownload}
                disabled={downloading}
                className="relative mt-6 w-full cursor-pointer overflow-hidden rounded-2xl bg-gradient-to-br from-violet-600 via-purple-600 to-indigo-600 px-5 py-4 text-base font-extrabold text-white shadow-[0_16px_40px_-12px_rgba(124,58,237,.9)] transition-all hover:brightness-110 active:scale-[.98] disabled:opacity-60"
              >
                {downloading ? (
                  <span className="inline-flex items-center gap-2"><Loader2 className="h-4 w-4 animate-spin" /> Завантаження…</span>
                ) : (
                  <span className="inline-flex items-center gap-2"><Download className="h-5 w-5" /> Скачати</span>
                )}
              </button>
              {info.deviceName && (
                <p className="mt-4 flex items-center justify-center gap-1.5 text-[11px] text-zinc-500">
                  <Clock className="h-3 w-3" />
                  З ПК «{info.deviceName}» · працює поки програма запущена
                </p>
              )}
            </>
          )}

          {(state === 'expired' || state === 'offline' || state === 'error') && (
            <>
              <div className="mx-auto grid h-20 w-20 place-items-center rounded-3xl border border-rose-400/25 bg-rose-500/10">
                <ShieldAlert className="h-9 w-9 text-rose-300" />
              </div>
              <h1 className="mt-5 text-lg font-extrabold text-white">
                {state === 'offline' ? 'ПК зараз офлайн' : 'Посилання не дійсне'}
              </h1>
              <p className="mt-2 break-words text-xs leading-relaxed text-zinc-400">
                {errMsg || 'Посилання працює лише поки на ПК власника запущена програма, і перестає діяти після її перезапуску або видалення файла.'}
              </p>
            </>
          )}
        </div>

        <p className="mt-6 text-center text-[11px] text-zinc-600">Захищена передача файлів · FluxControl</p>
      </div>
    </div>
  );
};
