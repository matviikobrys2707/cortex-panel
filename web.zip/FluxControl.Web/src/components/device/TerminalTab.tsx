import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Check, Copy, Eraser, FolderOpen, Loader2, Plus, SendHorizonal, ShieldCheck, Terminal as TerminalIcon, X } from 'lucide-react';
import { Device } from '../../types';
import { deviceClient } from '../../services/deviceClient';
import { displayCwd } from './fcHelpers';
import { toast } from '../../utils/toast';

interface TerminalTabProps {
  device: Device;
}

type ShellKind = 'powershell' | 'cmd';

interface TTab {
  id: string;
  shell: ShellKind;
}

interface TLine {
  id: number;
  kind: 'cmd' | 'out' | 'sys';
  text: string;
  /** cwd captured at the moment the command was submitted (for echo lines). */
  cwd?: string;
  /** sys-рядок «шлях змінився» — малюємо пілюлею з іконкою папки. */
  cwdChange?: boolean;
}

const MAX_LINES = 2000;
const HISTORY_LIMIT = 200;
/** Маркер шляху шукаємо В ЛЮБОМУ місці рядка: оболонки іноді клеять його
 *  разом з виводом/відлунням — старий full-line regex такі рядки губив. */
const MARKER_RE = /FLUX_CWD::(.+?)(?:::END|>)/;
const MARKER_STRIP_RE = /FLUX_CWD::.*?(::END|>)/g;
/** ТЗ 46 «підсвітка помилок»: помилка — червона, попередження — бурштинова. */
const ERROR_LINE_RE = /(error|exception|fatal|failed|failure|denied|not recognized|не є внутрішньою|не является внутренней|помилка|непередбачена|непріпустимо|invalid|cannot find|не вдалося|не удалось|access is denied|відмовлено в доступі)/i;
const WARN_LINE_RE = /(warning|warn|увага|попередження|deprecated|not found|не знайдено|не найдено)/i;

/** Автодоповнення (ТЗ 46): популярні команди PowerShell/CMD + шляхи. */
const BUILTIN_COMMANDS = [
  'Get-ChildItem', 'Get-Process', 'Get-Content', 'Set-Location', 'Copy-Item', 'Move-Item',
  'Remove-Item', 'New-Item', 'Get-Service', 'Stop-Process', 'Start-Process', 'Get-ComputerInfo',
  'ipconfig', 'ipconfig /all', 'ipconfig /flushdns', 'ping', 'tracert', 'netstat -ano',
  'tasklist', 'taskkill /f /im', 'systeminfo', 'whoami', 'sfc /scannow', 'chkdsk',
  'shutdown /s /t 0', 'shutdown /r /t 0', 'net user', 'netstat', 'nslookup', 'curl',
  'dir', 'cd', 'cls', 'echo', 'type', 'del', 'mkdir', 'rmdir', 'robocopy', 'tree',
  'winget', 'winget upgrade', 'git status', 'git pull', 'npm run', 'node -v', 'python --version'
];

interface SessionState {
  lines: TLine[];
  cwd: string;
  starting: boolean;
  sawOutput: boolean;
  resent: boolean;
  exited: boolean;
  lastSent: string;
}

const newSession = (): SessionState => ({
  lines: [], cwd: '', starting: true, sawOutput: false, resent: false, exited: false, lastSent: '',
});

let TAB_SEQ = 1;

export const TerminalTab: React.FC<TerminalTabProps> = ({ device }) => {
  const [tabs, setTabs] = useState<TTab[]>(() => [{ id: `t${TAB_SEQ}`, shell: 'powershell' }]);
  const [activeId, setActiveId] = useState<string>(() => `t${TAB_SEQ}`);
  const [sessions, setSessions] = useState<Record<string, SessionState>>(() => ({ [`t${TAB_SEQ}`]: newSession() }));
  const [command, setCommand] = useState('');
  const [copied, setCopied] = useState(false);
  const [isAdmin, setIsAdmin] = useState<boolean | null>(null);
  // Автодоповнення: відкритий підказник + індекс підсвіченого варіанту.
  const [suggestIdx, setSuggestIdx] = useState(-1);

  const idRef = useRef(1);
  const tabsRef = useRef<TTab[]>(tabs);
  const activeRef = useRef<string>(activeId);
  const sessionsRef = useRef<Record<string, SessionState>>(sessions);
  const agentHistoryRef = useRef<string[]>([]);
  const localHistoryRef = useRef<string[]>([]);
  const histIdxRef = useRef(-1);
  const resendTimersRef = useRef<Record<string, number>>({});
  const scrollRef = useRef<HTMLDivElement>(null);
  const atBottomRef = useRef(true);
  const inputRef = useRef<HTMLInputElement>(null);

  TAB_SEQ = Math.max(TAB_SEQ, 1);

  const setSession = useCallback((tabId: string, patch: Partial<SessionState> | ((prev: SessionState) => Partial<SessionState>)) => {
    setSessions((prev) => {
      const cur = prev[tabId] ?? newSession();
      const p = typeof patch === 'function' ? patch(cur) : patch;
      sessionsRef.current = { ...prev, [tabId]: { ...cur, ...p } };
      return sessionsRef.current;
    });
  }, []);

  const pushLines = useCallback((tabId: string, incoming: Array<Omit<TLine, 'id'>>) => {
    if (!incoming.length) return;
    const withIds = incoming.map((l) => ({ ...l, id: (idRef.current += 1) }));
    setSessions((prev) => {
      const cur = prev[tabId] ?? newSession();
      const next = cur.lines.concat(withIds);
      const trimmed = next.length > MAX_LINES ? next.slice(next.length - MAX_LINES) : next;
      sessionsRef.current = { ...prev, [tabId]: { ...cur, lines: trimmed } };
      return sessionsRef.current;
    });
  }, []);

  // ================= Перемикання вкладок =================

  useEffect(() => { tabsRef.current = tabs; }, [tabs]);
  useEffect(() => {
    activeRef.current = activeId;
    atBottomRef.current = true;
    // фокус у поле активної вкладки
    const t = window.setTimeout(() => inputRef.current?.focus(), 30);
    return () => window.clearTimeout(t);
  }, [activeId]);

  const beginSession = useCallback((tabId: string, shell: ShellKind) => {
    setSession(tabId, (prev) => ({
      ...newSession(),
      lines: [
        { id: (idRef.current += 1), kind: 'sys', text: `Запуск ${shell === 'powershell' ? 'PowerShell' : 'CMD'} на «${device.name}»…` },
      ],
      starting: true,
    }));
    deviceClient.startTerminalSession(tabId, shell);
    if (resendTimersRef.current[tabId]) window.clearTimeout(resendTimersRef.current[tabId]);
    resendTimersRef.current[tabId] = window.setTimeout(() => {
      const s = sessionsRef.current[tabId];
      if (s && !s.sawOutput && !s.resent) {
        setSession(tabId, { resent: true });
        deviceClient.startTerminalSession(tabId, shell);
      }
    }, 2500);
  }, [device.name, setSession]);

  // Глобальна історія агента (живе до перезавантаження ПК) + бейдж ADMIN.
  useEffect(() => {
    deviceClient.requestTerminalHistory();
    const off = deviceClient.on('terminal_history_data', (payload: any) => {
      const items = Array.isArray(payload?.items) ? payload.items : Array.isArray(payload) ? payload : [];
      agentHistoryRef.current = items.map((x: any) => String(x)).slice(-HISTORY_LIMIT);
      if (typeof payload?.isAdmin === 'boolean') setIsAdmin(payload.isAdmin);
    });
    const offStarted = deviceClient.on('terminal_started', (payload: any) => {
      if (typeof payload?.isAdmin === 'boolean') setIsAdmin(payload.isAdmin);
    });
    return () => { off(); offStarted(); };
  }, []);

  // Mount: стартуємо першу вкладку. Unmount: гасимо ВСІ сесії.
  useEffect(() => {
    const first = tabsRef.current[0];
    if (first) beginSession(first.id, first.shell);

    const offConnected = deviceClient.on('connected', () => {
      for (const t of tabsRef.current) {
        const s = sessionsRef.current[t.id];
        if (s && !s.sawOutput && !s.resent) {
          setSession(t.id, { resent: true });
          deviceClient.startTerminalSession(t.id, t.shell);
        }
      }
    });

    return () => {
      offConnected();
      for (const id of Object.keys(resendTimersRef.current)) window.clearTimeout(resendTimersRef.current[id]);
      deviceClient.killTerminal('*');
      // Старі агенти без tabId глушать єдину сесію на будь-який kill —
      // надсилаємо на кожну вкладку на всяк випадок.
      for (const t of tabsRef.current) deviceClient.killTerminal(t.id);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ================= Output stream (routing по вкладках) =================

  useEffect(() => {
    const off = deviceClient.on('terminal_output', (payload: any) => {
      // Старі агенти шлють рядок без tabId — такий вивід іде в активну вкладку.
      const text = typeof payload === 'string'
        ? payload
        : String(payload?.data ?? payload?.output ?? payload?.text ?? '');
      const tabId = typeof payload === 'object' && payload?.tabId ? String(payload.tabId) : activeRef.current;
      if (!text) return;

      const s = sessionsRef.current[tabId];
      if (s && !s.sawOutput) {
        setSession(tabId, { sawOutput: true, starting: false });
      }

      const rawLines = text.replace(/\r/g, '').split('\n');
      if (rawLines.length && rawLines[rawLines.length - 1] === '') rawLines.pop();

      const outs: Array<Omit<TLine, 'id'>> = [];
      let markerCwd: string | null = null;
      const cwdNow = sessionsRef.current[tabId]?.cwd ?? '';

      for (const raw of rawLines) {
        const m = raw.match(MARKER_RE);
        if (m) markerCwd = m[1].trim();
        const cleaned = raw.replace(MARKER_STRIP_RE, '').trimEnd();
        const t = cleaned.trim();
        if (!t) {
          if (!m && outs.length) outs.push({ kind: 'out', text: '' });
          continue;
        }
        const lc = t.toLowerCase();
        const cwdLc = cwdNow.toLowerCase();
        const sentLc = (sessionsRef.current[tabId]?.lastSent ?? '').toLowerCase();
        if (cwdLc && (lc === `${cwdLc}>` || lc === `ps ${cwdLc}>`)) continue;
        if (sentLc && cwdLc && (lc === `${cwdLc}> ${sentLc}` || lc === `ps ${cwdLc}> ${sentLc}`)) continue;
        outs.push({ kind: 'out', text: cleaned });
      }

      if (markerCwd !== null && markerCwd.toLowerCase() !== cwdNow.toLowerCase()) {
        setSession(tabId, { cwd: markerCwd });
        if (outs.length && outs[outs.length - 1].text === '') outs.pop();
        outs.push({ kind: 'sys', text: displayCwd(markerCwd) || markerCwd, cwdChange: true });
      }

      pushLines(tabId, outs);
    });

    const offExit = deviceClient.on('terminal_exit', (payload: any) => {
      const tabId = typeof payload === 'object' && payload?.tabId ? String(payload.tabId) : null;
      if (!tabId) return;
      setSession(tabId, { exited: true });
      pushLines(tabId, [{ kind: 'sys', text: 'Оболонку закрито. Наступна команда запустить нову сесію.' }]);
    });

    return () => { off(); offExit(); };
  }, [pushLines, setSession]);

  // Stick-to-bottom: follow the stream only when the user is already there.
  const activeSession = sessions[activeId] ?? newSession();
  useEffect(() => {
    const el = scrollRef.current;
    if (el && atBottomRef.current) el.scrollTop = el.scrollHeight;
  }, [activeSession.lines.length, activeId]);

  const handleScroll = useCallback(() => {
    const el = scrollRef.current;
    if (!el) return;
    atBottomRef.current = el.scrollHeight - el.scrollTop - el.clientHeight < 48;
  }, []);

  // ================= Автодоповнення =================

  const suggestions = useMemo(() => {
    const q = command.trim().toLowerCase();
    if (!q || q.length < 1) return [];
    const seen = new Set<string>();
    const pool = [...localHistoryRef.current].reverse().concat(agentHistoryRef.current.slice().reverse(), BUILTIN_COMMANDS);
    const out: string[] = [];
    for (const c of pool) {
      const cl = c.toLowerCase();
      if (cl.startsWith(q) && !seen.has(cl)) {
        seen.add(cl);
        out.push(c);
        if (out.length >= 6) break;
      }
    }
    return out;
  }, [command]);

  useEffect(() => { setSuggestIdx(-1); }, [command]);

  // ================= Input =================

  const submit = useCallback((raw?: string) => {
    const text = (raw !== undefined ? raw : command).trim();
    setCommand('');
    setSuggestIdx(-1);
    histIdxRef.current = -1;
    if (!text) return;
    const tabId = activeRef.current;
    const s = sessionsRef.current[tabId];
    // Сесію закрили (exit) — тихо перезапускаємо, команда не загубиться.
    if (s?.exited) beginSession(tabId, tabsRef.current.find((t) => t.id === tabId)?.shell ?? 'powershell');
    pushLines(tabId, [{ kind: 'cmd', text, cwd: sessionsRef.current[tabId]?.cwd ?? '' }]);
    // ТЗ 55: автовизначення оболонки. Набрав "powershell" у CMD-консолі —
    // вкладка сама переключає режим на PowerShell (і навпаки). Сесію НЕ
    // перезапускаємо: вкладена оболонка вже працює всередині тієї ж консолі.
    const shellDet = /^(powershell|pwsh|cmd)(\.exe)?\s*$/i.exec(text);
    if (shellDet) {
      const kind: ShellKind = shellDet[1].toLowerCase().startsWith('p') ? 'powershell' : 'cmd';
      const tab = tabsRef.current.find((t) => t.id === tabId);
      if (tab && tab.shell !== kind) {
        setTabs((prev) => {
          const nxt = prev.map((t) => (t.id === tabId ? { ...t, shell: kind } : t));
          tabsRef.current = nxt;
          return nxt;
        });
        pushLines(tabId, [{
          kind: 'sys',
          text: `Режим визначено автоматично: ${kind === 'powershell' ? 'PowerShell' : 'CMD'}. Кнопки вгорі праворуч переключають оболонку вручну.`,
        }]);
      }
    }
    localHistoryRef.current.push(text);
    if (localHistoryRef.current.length > HISTORY_LIMIT) localHistoryRef.current.shift();
    setSession(tabId, { lastSent: text });
    deviceClient.sendTerminalInput(text, tabId);
    atBottomRef.current = true;
    inputRef.current?.focus();
  }, [beginSession, command, pushLines, setSession]);

  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent<HTMLInputElement>) => {
      // Автодоповнення відкрите → керуємо ним перш за все.
      if (suggestions.length > 0) {
        if (e.key === 'Tab' || (e.key === 'ArrowRight' && suggestIdx >= 0)) {
          e.preventDefault();
          const pick = suggestIdx >= 0 ? suggestions[suggestIdx] : suggestions[0];
          setCommand(pick);
          setSuggestIdx(-1);
          return;
        }
        if (e.key === 'ArrowDown' && suggestIdx < suggestions.length - 1) {
          e.preventDefault();
          setSuggestIdx((i) => i + 1);
          return;
        }
        if (e.key === 'ArrowUp' && suggestIdx >= 0) {
          e.preventDefault();
          setSuggestIdx((i) => (i <= 0 ? -1 : i - 1));
          return;
        }
        if (e.key === 'Escape') {
          e.preventDefault();
          setSuggestIdx(-1);
          return;
        }
      }

      if (e.key === 'ArrowUp') {
        e.preventDefault();
        const h = localHistoryRef.current;
        if (!h.length) return;
        const idx = histIdxRef.current === -1 ? h.length - 1 : Math.max(0, histIdxRef.current - 1);
        histIdxRef.current = idx;
        setCommand(h[idx]);
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        if (histIdxRef.current === -1) return;
        const idx = histIdxRef.current + 1;
        if (idx >= localHistoryRef.current.length) {
          histIdxRef.current = -1;
          setCommand('');
        } else {
          histIdxRef.current = idx;
          setCommand(localHistoryRef.current[idx]);
        }
      }
    },
    [suggestIdx, suggestions]
  );

  // ================= Вкладки: створення/закриття =================

  const openTab = useCallback((shell: ShellKind) => {
    TAB_SEQ += 1;
    const id = `t${TAB_SEQ}`;
    setTabs((prev) => {
      tabsRef.current = [...prev, { id, shell }];
      return tabsRef.current;
    });
    setSessions((prev) => {
      sessionsRef.current = { ...prev, [id]: newSession() };
      return sessionsRef.current;
    });
    setActiveId(id);
    beginSession(id, shell);
  }, [beginSession]);

  const closeTab = useCallback((tabId: string) => {
    deviceClient.killTerminal(tabId);
    setTabs((prev) => {
      const next = prev.filter((t) => t.id !== tabId);
      tabsRef.current = next;
      if (next.length === 0) {
        // Останню вкладку не закриваємо — відкриваємо свіжу PowerShell.
        TAB_SEQ += 1;
        const id = `t${TAB_SEQ}`;
        const fresh = [{ id, shell: 'powershell' as ShellKind }];
        tabsRef.current = fresh;
        setSessions((sprev) => {
          sessionsRef.current = { [id]: newSession() };
          return sessionsRef.current;
        });
        setActiveId(id);
        beginSession(id, 'powershell');
        return fresh;
      }
      if (activeRef.current === tabId) {
        const fallback = next[next.length - 1];
        setActiveId(fallback.id);
      }
      return next;
    });
    setSessions((prev) => {
      const nextS = { ...prev };
      delete nextS[tabId];
      sessionsRef.current = nextS;
      return nextS;
    });
  }, [beginSession]);

  const switchShellOfActive = useCallback((next: ShellKind) => {
    const tabId = activeRef.current;
    const tab = tabsRef.current.find((t) => t.id === tabId);
    if (!tab || tab.shell === next) return;
    setTabs((prev) => {
      const nxt = prev.map((t) => (t.id === tabId ? { ...t, shell: next } : t));
      tabsRef.current = nxt;
      return nxt;
    });
    beginSession(tabId, next);
    pushLines(tabId, [{ kind: 'sys', text: `Оболонку змінено на ${next === 'powershell' ? 'PowerShell' : 'CMD'}.` }]);
  }, [beginSession, pushLines]);

  const clearScreen = useCallback(() => {
    const tabId = activeRef.current;
    setSession(tabId, (prev) => ({
      lines: [{ id: (idRef.current += 1), kind: 'sys', text: 'Консоль очищено (лише локально). Робоча папка незмінна.' }],
      cwd: prev.cwd,
    }));
    atBottomRef.current = true;
    inputRef.current?.focus();
  }, [setSession]);

  const copyAll = useCallback(async () => {
    const s = sessionsRef.current[activeRef.current];
    const cwd = s?.cwd ?? '';
    const text = (s?.lines ?? [])
      .map((l) => (l.kind === 'cmd' ? `${displayCwd(l.cwd || cwd)}> ${l.text}` : l.text))
      .join('\n');
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      toast.warn('Не вдалося скопіювати вивід');
    }
  }, []);

  // ================= Render =================

  const promptCwd = displayCwd(activeSession.cwd);
  const activeShell = tabs.find((t) => t.id === activeId)?.shell ?? 'powershell';

  return (
    <div className="fc-card-static flex h-[calc(100vh-15rem)] min-h-[30rem] flex-col overflow-hidden">
      {/* ===== Стрічка вкладок у стилі Windows 11 (ТЗ 46) ===== */}
      <div className="flex shrink-0 items-center gap-1 border-b border-white/10 bg-zinc-950/90 px-2 pt-1.5">
        <div className="flex min-w-0 flex-1 items-end gap-1 overflow-x-auto pb-0">
          {tabs.map((t) => {
            const active = t.id === activeId;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => setActiveId(t.id)}
                className={`group flex min-w-0 max-w-[13rem] flex-none items-center gap-2 rounded-t-xl border-x border-t px-3 py-1.5 text-[11px] font-bold transition-all ${
                  active
                    ? 'border-white/10 bg-black text-white shadow-[inset_0_2px_0_0_rgb(139_92_246)]'
                    : 'border-transparent bg-white/[0.03] text-zinc-400 hover:bg-white/[0.06] hover:text-zinc-200'
                }`}
                title={t.shell === 'powershell' ? 'PowerShell' : 'CMD'}
              >
                <TerminalIcon className={`h-3 w-3 flex-none ${t.shell === 'powershell' ? 'text-sky-400' : 'text-amber-400'}`} />
                <span className="truncate">
                  {t.shell === 'powershell' ? 'PowerShell' : 'CMD'}
                  {tabs.length > 1 ? ` · ${t.id.replace('t', '')}` : ''}
                </span>
                <span
                  role="button"
                  aria-label={`Закрити вкладку ${t.id}`}
                  onClick={(e) => {
                    e.stopPropagation();
                    closeTab(t.id);
                  }}
                  className={`grid h-4 w-4 flex-none place-items-center rounded transition-colors ${
                    active ? 'hover:bg-white/15 text-zinc-400 hover:text-white' : 'hover:bg-white/10 text-zinc-600 hover:text-zinc-300'
                  }`}
                >
                  <X className="h-3 w-3" />
                </span>
              </button>
            );
          })}
          <div className="relative flex-none pb-1">
            {/* ТЗ 55: «+» більше не відкриває меню вибору — нова вкладка
                відкривається в поточному режимі консолі. Режим змінюють
                закріплені кнопки CMD / PowerShell праворуч вгорі. */}
            <button
              type="button"
              onClick={() => openTab(activeShell)}
              aria-label={`Нова вкладка ${activeShell === 'cmd' ? 'CMD' : 'PowerShell'}`}
              title={`Нова вкладка (${activeShell === 'cmd' ? 'CMD' : 'PowerShell'})`}
              className="grid h-7 w-7 place-items-center rounded-lg border border-white/10 bg-white/5 text-zinc-300 transition-colors hover:bg-white/10 hover:text-white"
            >
              <Plus className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>

        {/* Бейдж ADMIN + утиліти. ПЕРЕМИКАЧ РЕЖИМУ CMD / PowerShell —
            закріплений праворуч вгорі (ТЗ 55). */}
        <div className="flex flex-none items-center gap-1.5 pb-1.5">
          <div
            className="flex flex-none items-center rounded-lg border border-white/10 bg-white/5 p-0.5"
            role="group"
            aria-label="Режим консолі"
            title="Переключити оболонку активної консолі (сесія перезапуститься)">
            <button
              type="button"
              onClick={() => switchShellOfActive('cmd')}
              aria-pressed={activeShell === 'cmd'}
              className={`rounded-md px-2.5 py-1 text-[10px] font-black tracking-wide transition-all ${
                activeShell === 'cmd'
                  ? 'bg-amber-500/25 text-amber-200 shadow-[inset_0_0_0_1px_rgba(251,191,36,.35)]'
                  : 'text-zinc-500 hover:text-zinc-200'
              }`}
            >
              CMD
            </button>
            <button
              type="button"
              onClick={() => switchShellOfActive('powershell')}
              aria-pressed={activeShell === 'powershell'}
              className={`rounded-md px-2.5 py-1 text-[10px] font-black tracking-wide transition-all ${
                activeShell === 'powershell'
                  ? 'bg-sky-500/25 text-sky-200 shadow-[inset_0_0_0_1px_rgba(56,189,248,.35)]'
                  : 'text-zinc-500 hover:text-zinc-200'
              }`}
            >
              PowerShell
            </button>
          </div>
          {isAdmin === true && (
            <span
              className="flex items-center gap-1 rounded-lg border border-emerald-400/30 bg-emerald-500/15 px-2 py-1 text-[10px] font-black text-emerald-300"
              title="Консоль запущено з правами адміністратора (успадковує права агента)"
            >
              <ShieldCheck className="h-3 w-3" /> ADMIN
            </span>
          )}
          {isAdmin === false && (
            <span
              className="flex items-center gap-1 rounded-lg border border-amber-400/30 bg-amber-500/10 px-2 py-1 text-[10px] font-black text-amber-300"
              title="Агент запущено БЕЗ прав адміністратора — частина команд буде заблокована системою"
            >
              <ShieldCheck className="h-3 w-3" /> user
            </span>
          )}
          {activeSession.starting && (
            <span className="flex items-center gap-1.5 text-[10px] font-semibold text-violet-300">
              <Loader2 className="h-3 w-3 animate-spin" />
              запуск…
            </span>
          )}
          <button
            type="button"
            onClick={copyAll}
            title="Скопіювати вивід"
            aria-label="Скопіювати вивід"
            className="grid h-8 w-8 place-items-center rounded-lg border border-white/10 bg-white/5 text-zinc-400 transition-colors hover:bg-white/10 hover:text-white"
          >
            {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
          </button>
          <button
            type="button"
            onClick={clearScreen}
            title="Очистити консоль"
            aria-label="Очистити консоль"
            className="grid h-8 w-8 place-items-center rounded-lg border border-white/10 bg-white/5 text-zinc-400 transition-colors hover:bg-white/10 hover:text-white"
          >
            <Eraser className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {/* Output */}
      <div
        ref={scrollRef}
        onScroll={handleScroll}
        onClick={() => inputRef.current?.focus()}
        className="flex-1 cursor-text space-y-0.5 overflow-y-auto bg-black px-3.5 py-3 font-mono text-[12px] leading-[1.55]"
        aria-live="polite"
      >
        {activeSession.lines.length === 0 && !activeSession.starting && (
          <div className="text-zinc-600">Готово до введення команд.</div>
        )}
        {activeSession.lines.map((l) => {
          if (l.kind === 'cmd') {
            return (
              <div key={l.id} className="break-all whitespace-pre-wrap">
                <span className="font-bold text-violet-400">{displayCwd(l.cwd || activeSession.cwd) || '…'}&gt;&nbsp;</span>
                <span className="text-white">{l.text}</span>
              </div>
            );
          }
          if (l.kind === 'sys') {
            if (l.cwdChange) {
              return (
                <div key={l.id} className="mt-1">
                  <span className="line-cwd-change">
                    <FolderOpen />
                    {l.text}
                  </span>
                </div>
              );
            }
            return (
              <div key={l.id} className="whitespace-pre-wrap break-words italic text-violet-300/60">
                {l.text}
              </div>
            );
          }
          const isErr = ERROR_LINE_RE.test(l.text);
          const isWarn = !isErr && WARN_LINE_RE.test(l.text);
          return (
            <div
              key={l.id}
              className={`whitespace-pre-wrap break-words rounded px-1 -mx-1 ${
                isErr
                  ? 'bg-rose-500/10 text-rose-300'
                  : isWarn
                    ? 'text-amber-300/90'
                    : 'text-zinc-300'
              }`}
            >
              {l.text || '\u00A0'}
            </div>
          );
        })}
      </div>

      {/* Автодоповнення (ТЗ 46): історія ПК + популярні команди */}
      {suggestions.length > 0 && (
        <div className="shrink-0 border-t border-white/5 bg-zinc-950/95 px-3 py-1.5">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-[9px] font-black uppercase tracking-wider text-zinc-600">Tab — підказати</span>
            {suggestions.map((s, i) => (
              <button
                key={s}
                type="button"
                onMouseDown={(e) => {
                  e.preventDefault();
                  setCommand(s);
                  setSuggestIdx(-1);
                  inputRef.current?.focus();
                }}
                className={`max-w-full truncate rounded-lg border px-2 py-0.5 font-mono text-[11px] transition-colors ${
                  i === suggestIdx
                    ? 'border-violet-400/60 bg-violet-600/30 text-white'
                    : 'border-white/10 bg-white/5 text-zinc-300 hover:bg-white/10 hover:text-white'
                }`}
                title={s}
              >
                {s}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Input row — шлях показуємо ТУТ (ТЗ: прибрати з верху) */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          submit();
        }}
        className="flex shrink-0 items-center gap-2 border-t border-white/10 bg-black/90 px-3.5 py-2.5"
      >
        <span className="flex max-w-[45%] shrink-0 items-center gap-1 truncate font-mono text-[12px] font-bold text-violet-400" title={promptCwd}>
          <FolderOpen className="h-3 w-3 flex-none opacity-70" />
          {promptCwd ? `${promptCwd}>` : `${activeShell === 'cmd' ? 'C:\\>' : 'PS>'}`}
        </span>
        <input
          ref={inputRef}
          value={command}
          onChange={(e) => setCommand(e.target.value)}
          onKeyDown={handleKeyDown}
          autoFocus
          spellCheck={false}
          autoComplete="off"
          aria-label="Команда терміналу"
          placeholder="Введіть команду… (Tab — автодоповнення)"
          className="min-w-0 flex-1 border-none bg-transparent font-mono text-[12px] text-white placeholder:text-zinc-600 focus:outline-none"
        />
        <button
          type="submit"
          aria-label="Виконати команду"
          title="Виконати (Enter)"
          className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-gradient-to-r from-violet-600 to-indigo-600 text-white shadow transition-all hover:brightness-110"
        >
          <SendHorizonal className="h-3.5 w-3.5" />
        </button>
      </form>
    </div>
  );
};
