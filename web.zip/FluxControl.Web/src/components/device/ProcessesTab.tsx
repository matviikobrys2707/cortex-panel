import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Activity,
  ArrowDown,
  ArrowUp,
  ArrowDownUp,
  Cpu,
  Hand,
  Loader2,
  MemoryStick,
  MoreVertical,
  Pause,
  Play,
  Search,
  Snowflake,
  XCircle,
} from 'lucide-react';
import { Device } from '../../types';
import { deviceClient } from '../../services/deviceClient';
import { toast } from '../../utils/toast';
import { ProcInfo, formatMemoryMb } from './fcHelpers';
import { FcConfirmModal } from './fcModals';

interface ProcessesTabProps {
  device: Device;
}

// ТЗ «як у Windows у програми без іконки»: білий прямокутник (сторінка)
// з блакитним прямокутником у центрі. SVG data-URL — нуль мережі.
const NO_ICON_URL =
  'data:image/svg+xml;utf8,' +
  encodeURIComponent(
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48">` +
      `<rect x="5" y="3" width="38" height="42" rx="6" fill="#f6f8fb" stroke="#bac4d0" stroke-width="2"/>` +
      `<rect x="14" y="17" width="20" height="14" rx="3" fill="#5aa2e8" stroke="#3880c2" stroke-width="1.4"/>` +
      `</svg>`
  );

// ================= ТЗ 55: кеш іконок у localStorage =================
// Іконки тепер ПЕРЕЖИВАЮТЬ перезавантаження сторінки: зберігаємо мапу
// exePath → dataURL у localStorage і миттєво малюємо при відкритті таба.
// Кеш скидається коли: (1) змінився binStamp агента (програма оновилась),
// (2) змінилась схема кеша (оновилась веб-панель), (3) перевищено ліміт.
const ICON_CACHE_KEY = 'fc_proc_icons_v2';
const ICON_CACHE_SCHEMA = 1;
const ICON_CACHE_MAX = 250;

interface IconCacheShape {
  schema: number;
  binStamp: string;
  icons: Record<string, string>;
}

function loadIconCache(): { icons: Record<string, string>; binStamp: string } {
  try {
    const raw = localStorage.getItem(ICON_CACHE_KEY);
    if (!raw) return { icons: {}, binStamp: '' };
    const parsed = JSON.parse(raw) as IconCacheShape;
    if (parsed && parsed.schema === ICON_CACHE_SCHEMA && parsed.icons && typeof parsed.icons === 'object') {
      return { icons: parsed.icons, binStamp: String(parsed.binStamp || '') };
    }
    localStorage.removeItem(ICON_CACHE_KEY);
  } catch { /* пошкоджений запис — починаємо з нуля */ }
  return { icons: {}, binStamp: '' };
}

function saveIconCache(icons: Record<string, string>, binStamp: string) {
  try {
    const keys = Object.keys(icons);
    let trimmed = icons;
    if (keys.length > ICON_CACHE_MAX) {
      // Вставний порядок об'єкта зберігається — обрізаємо найстаріші записи.
      trimmed = {};
      for (const k of keys.slice(keys.length - ICON_CACHE_MAX)) trimmed[k] = icons[k];
    }
    const payload: IconCacheShape = { schema: ICON_CACHE_SCHEMA, binStamp, icons: trimmed };
    localStorage.setItem(ICON_CACHE_KEY, JSON.stringify(payload));
  } catch { /* переповнений localStorage — просто не зберігаємо */ }
}

// Task-Manager-like grouping. ЗА УМОЛЧАННЯМ — «Програми»: юзер відкриває таб,
// щоб побачити свої програми, а не 200 системних процесів.
type ProcCategory = 'all' | 'app' | 'background' | 'system';

const CATEGORY_META: { id: ProcCategory; label: string }[] = [
  { id: 'app', label: 'Програми' },
  { id: 'background', label: 'Фонові' },
  { id: 'system', label: 'Системні' },
  { id: 'all', label: 'Усі' },
];

type SortKey = 'cpu' | 'memory' | 'name' | 'pid';

function cpuColor(v: number): string {
  if (v >= 50) return 'text-rose-400';
  if (v >= 15) return 'text-amber-300';
  if (v > 0) return 'text-emerald-300';
  return 'text-zinc-500';
}

// ================= Memoized process row =================

interface ProcRowProps {
  proc: ProcInfo;
  icon: string | undefined;
  onKill: (proc: ProcInfo) => void;
  onMenu: (proc: ProcInfo, x: number, y: number) => void;
  onFront: (proc: ProcInfo) => void;
}

const ProcRowView = React.memo<ProcRowProps>(({ proc, icon, onKill, onMenu, onFront }) => {
  const hung = proc.responding === false;
  const frozen = !!proc.frozen;
  const longPress = useRef<number | null>(null);

  const startLongPress = (x: number, y: number) => {
    if (longPress.current) window.clearTimeout(longPress.current);
    longPress.current = window.setTimeout(() => {
      longPress.current = null;
      onMenu(proc, x, y);
    }, 480);
  };
  const cancelLongPress = () => {
    if (longPress.current) {
      window.clearTimeout(longPress.current);
      longPress.current = null;
    }
  };

  return (
    <div
      className={`proc-card ${hung ? 'proc-hung' : ''} ${frozen ? 'proc-frozen' : ''}`}
      onContextMenu={(e) => {
        e.preventDefault();
        onMenu(proc, e.clientX, e.clientY);
      }}
      onTouchStart={(e) => {
        const t = e.touches[0];
        if (t) startLongPress(t.clientX, t.clientY);
      }}
      onTouchMove={cancelLongPress}
      onTouchEnd={cancelLongPress}
      onClick={() => onFront(proc)}
      role="button"
      tabIndex={0}
      aria-label={`Процес ${proc.name}. Лівий клік — на передній план, правий — меню`}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') onFront(proc);
      }}
    >
      {icon ? (
        <img
          src={icon}
          alt=""
          loading="lazy"
          className="h-9 w-9 shrink-0 rounded-xl border border-white/10 bg-black/40 object-contain p-1"
        />
      ) : (
        // ТЗ: без літер-аватарів — замість них стандартна «безіконкова» іконка Windows.
        <img
          src={NO_ICON_URL}
          alt=""
          loading="lazy"
          className="h-9 w-9 shrink-0 rounded-xl border border-white/10 bg-black/40 object-contain p-0.5"
        />
      )}
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-1.5">
          <span className="truncate text-xs font-bold text-zinc-100">{proc.title || proc.name}</span>
          {frozen && (
            <span className="flex flex-none items-center gap-0.5 rounded-md border border-sky-400/40 bg-sky-500/15 px-1 py-px text-[9px] font-black text-sky-300" title="Процес заморожено (постав на паузу)">
              <Snowflake className="h-2.5 w-2.5" /> заморожено
            </span>
          )}
          {hung && (
            <span className="flex flex-none items-center gap-0.5 rounded-md border border-rose-400/50 bg-rose-500/20 px-1 py-px text-[9px] font-black text-rose-300">
              не відповідає
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          {proc.exePath && <span className="hidden truncate font-mono text-[10px] text-zinc-500 sm:block">{proc.exePath}</span>}
          {hung && <span className="block truncate font-mono text-[10px] text-rose-400/80 sm:hidden">не відповідає</span>}
        </div>
        {/* Міні-індикатор CPU — стильна смужка під назвою (ТЗ 46: стильний дизайн) */}
        <div className="mt-1 flex items-center gap-1.5">
          <div className="h-1 w-16 overflow-hidden rounded-full bg-white/5">
            <div
              className={`h-full rounded-full transition-all ${
                (proc.cpuPercent ?? 0) >= 50 ? 'bg-rose-500' : (proc.cpuPercent ?? 0) >= 15 ? 'bg-amber-400' : 'bg-emerald-500/80'
              }`}
              style={{ width: `${Math.min(100, Math.max(3, proc.cpuPercent ?? 0))}%`, opacity: (proc.cpuPercent ?? 0) > 0 ? 1 : 0.25 }}
            />
          </div>
          <span className="font-mono text-[9px] text-zinc-600">{formatMemoryMb(proc.memoryMb)}</span>
        </div>
      </div>
      <span className="hidden w-14 shrink-0 text-right font-mono text-[11px] text-violet-300/80 sm:block">
        {proc.pid}
      </span>
      <span className={`w-14 shrink-0 text-right font-mono text-[11px] font-semibold ${cpuColor(proc.cpuPercent ?? 0)}`}>
        {(proc.cpuPercent ?? 0) > 0 ? `${(proc.cpuPercent ?? 0).toFixed(1)}%` : '0%'}
      </span>
      <span className="w-20 shrink-0 text-right font-mono text-[11px] text-zinc-300">
        {formatMemoryMb(proc.memoryMb)}
      </span>
      <button
        type="button"
        title="Дії з процесом (ПКМ)"
        aria-label={`Меню процесу ${proc.name}`}
        onClick={(e) => {
          e.stopPropagation();
          const r = (e.target as HTMLElement).getBoundingClientRect();
          onMenu(proc, r.left, r.bottom + 4);
        }}
        className="proc-kill !bg-transparent !text-zinc-500 hover:!text-white"
      >
        <MoreVertical className="h-4 w-4" />
      </button>
      <button
        type="button"
        title="Завершити процес"
        aria-label={`Завершити процес ${proc.name}`}
        onClick={(e) => {
          e.stopPropagation();
          onKill(proc);
        }}
        className="proc-kill"
      >
        <XCircle className="h-4 w-4" />
      </button>
    </div>
  );
});
ProcRowView.displayName = 'ProcRowView';

// ================= ProcessesTab =================

export const ProcessesTab: React.FC<ProcessesTabProps> = ({ device }) => {
  const [processes, setProcesses] = useState<ProcInfo[]>([]);
  const [loading, setLoading] = useState(true);
  const [, setRefreshing] = useState(false);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState<ProcCategory>('app');
  // ТЗ: сортування ЗА ЗАМОВЧУВАННЯМ — за назвою (алфавіт А→Я), у всіх категоріях.
  const [sortKey, setSortKey] = useState<SortKey>('name');
  const [sortDesc, setSortDesc] = useState(false);
  const [killTarget, setKillTarget] = useState<ProcInfo | null>(null);
  const [menu, setMenu] = useState<{ proc: ProcInfo; x: number; y: number } | null>(null);
  // bump кожного разу, коли приходять нові іконки, щоб рядки перечитали кеш
  const [iconsBump, setIconsBump] = useState(0);

  // Icons arrive PARTIALLY (only newly extracted ones) — accumulate across
  // events in a ref, keyed by exePath (lowercase) or process name.
  const iconsRef = useRef<Record<string, string>>({});
  const gotListRef = useRef(false);
  // The very first list after agent start has no CPU baseline yet (all 0) —
  // ONE silent follow-up request 1.3s later fills the real deltas.
  const cpuRetryDoneRef = useRef(false);
  const cpuRetryTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  // ТЗ 55: гідратація localStorage-кеша + захист від паралельних запитів.
  const cacheHydratedRef = useRef(false);
  const binStampRef = useRef('');
  const pendingListRef = useRef(false);
  const lastReqAtRef = useRef(0);

  const mergeIcons = useCallback((icons: Record<string, string> | undefined) => {
    if (icons && typeof icons === 'object' && Object.keys(icons).length) {
      Object.assign(iconsRef.current, icons);
      setIconsBump((b) => b + 1);
    }
  }, []);

  // ТЗ 55: тихий запит списку без скелетона (для автооновлення та дій).
  const silentRefresh = useCallback(() => {
    // Страховка від зависання: відповіді немає > 8с — дозволяємо новий запит.
    if (pendingListRef.current && Date.now() - lastReqAtRef.current > 8000) {
      pendingListRef.current = false;
    }
    if (pendingListRef.current) return;
    pendingListRef.current = true;
    lastReqAtRef.current = Date.now();
    setRefreshing(true);
    deviceClient.requestProcessList();
  }, []);

  const refresh = useCallback(() => {
    setLoading(true);
    silentRefresh();
  }, [silentRefresh]);

  // ТЗ 55: іконки з попередніх сесій (localStorage) — миттєвий малюнок після F5.
  useEffect(() => {
    if (cacheHydratedRef.current) return;
    cacheHydratedRef.current = true;
    const loaded = loadIconCache();
    Object.assign(iconsRef.current, loaded.icons);
    binStampRef.current = loaded.binStamp;
  }, []);

  // ТЗ 55: дебаунс-збереження іконок у localStorage після кожної нової партії.
  useEffect(() => {
    if (!iconsBump) return;
    const t = window.setTimeout(() => saveIconCache(iconsRef.current, binStampRef.current), 1200);
    return () => window.clearTimeout(t);
  }, [iconsBump]);

  // ТЗ: автооновлення ЗАВЖДИ (без кнопки «Авто») кожні 5с, поки сторінка видима.
  useEffect(() => {
    const iv = window.setInterval(() => {
      if (typeof document !== 'undefined' && document.visibilityState !== 'visible') return;
      silentRefresh();
    }, 5000);
    return () => window.clearInterval(iv);
  }, [silentRefresh]);

  useEffect(() => {
    const offList = deviceClient.on('process_list', (payload: any) => {
      // Backward compat: a bare array payload means no icons.
      const data = Array.isArray(payload) ? { processes: payload, icons: {} } : payload;
      const list = data && Array.isArray(data.processes)
        ? data.processes
        : data && Array.isArray(data.list)
          ? data.list
          : null;
      if (!list) {
        setLoading(false);
        return;
      }
      gotListRef.current = true;
      pendingListRef.current = false;
      setRefreshing(false);
      // ТЗ 55: binStamp агента — програма оновилась → кеш іконок скидається,
      // бо іконки могли витягуватись старою логікою/старими exe.
      const binStamp = String((data as any)?.binStamp ?? '');
      if (binStamp && binStampRef.current && binStamp !== binStampRef.current) {
        iconsRef.current = {};
        try { localStorage.removeItem(ICON_CACHE_KEY); } catch { /* ignore */ }
      }
      if (binStamp) binStampRef.current = binStamp;
      mergeIcons(data.icons);
      const mapped: ProcInfo[] = list.map((p: any) => ({
        pid: Number(p?.pid ?? p?.id ?? 0) || 0,
        name: String(p?.name ?? p?.processName ?? 'process'),
        title: p?.title ? String(p.title) : undefined,
        exePath: p?.exePath ? String(p.exePath) : undefined,
        memoryMb: Number(p?.memoryMb ?? 0) || 0,
        cpuPercent: Number(p?.cpuPercent ?? 0) || 0,
        category: typeof p?.category === 'string' ? p.category : 'background',
        responding: typeof p?.responding === 'boolean' ? p.responding : null,
        frozen: !!p?.frozen,
        hasWindow: !!p?.hasWindow,
      }));
      // ОПТИМІЗАЦІЯ ЛАГІВ (ТЗ): повторно використовуємо об'єкти рядків, які НЕ
      // змінились — memoized ProcRowView пропускає ре-рендер, список не «мигає».
      setProcesses((prev) => {
        if (prev.length !== mapped.length) return mapped;
        const merged = new Array<ProcInfo>(mapped.length);
        let changed = false;
        for (let i = 0; i < mapped.length; i += 1) {
          const a = prev[i];
          const b = mapped[i];
          if (
            a.pid === b.pid && a.name === b.name && a.title === b.title &&
            a.exePath === b.exePath && a.memoryMb === b.memoryMb &&
            a.cpuPercent === b.cpuPercent && a.category === b.category &&
            a.responding === b.responding && a.frozen === b.frozen && a.hasWindow === b.hasWindow
          ) {
            merged[i] = a;
          } else {
            merged[i] = b;
            changed = true;
          }
        }
        return changed ? merged : prev; // все ідентичне → жодного ре-рендера
      });
      setLoading(false);

      // One silent re-request so per-process CPU% (a delta between two
      // samples) has real values instead of the initial zeros.
      if (!cpuRetryDoneRef.current && mapped.length > 0) {
        cpuRetryDoneRef.current = true;
        const hasCpu = mapped.some((p) => (p.cpuPercent ?? 0) > 0);
        if (!hasCpu) {
          if (cpuRetryTimer.current) clearTimeout(cpuRetryTimer.current);
          cpuRetryTimer.current = setTimeout(() => {
            if (gotListRef.current) deviceClient.requestProcessList();
          }, 1300);
        }
      }
    });

    // Фоновий потік іконок від агента (партіями по N штук).
    const offIcons = deviceClient.on('process_icons', (payload: any) => {
      const icons = payload && typeof payload === 'object' && !Array.isArray(payload)
        ? (payload.icons ?? payload)
        : null;
      mergeIcons(icons);
    });

    const offKill = deviceClient.on('process_kill_result', (payload: any) => {
      if (payload?.success) toast.success(`Процес (PID ${payload.pid}) завершено`, { title: 'Процес зупинено' });
      else toast.error(payload?.error || `Не вдалося завершити процес (PID ${payload?.pid ?? '?'})`);
    });

    const offFreeze = deviceClient.on('process_freeze_result', (payload: any) => {
      if (payload?.success) {
        toast.success(
          payload.frozen ? `Процес (PID ${payload.pid}) заморожено — поставлено на паузу` : `Процес (PID ${payload.pid}) розморожено`,
          { title: payload.frozen ? 'Заморожено' : 'Розморожено' }
        );
      } else {
        toast.error(payload?.error || `Не вдалося змінити стан процесу (PID ${payload?.pid ?? '?'})`);
      }
      deviceClient.requestProcessList();
    });

    const offFront = deviceClient.on('process_bring_front_result', (payload: any) => {
      if (payload?.success) toast.success(`Вікно відкрито на ПК (PID ${payload.pid})`, { title: 'На передньому плані' });
      else toast.warn(payload?.error || 'Не вдалося витягнути вікно на передній план');
    });

    // Request once on mount; the tab also asks the agent to RE-SEND all
    // cached icons (ТЗ 55): агент-релей WS живе довше за сторінку, тому після
    // F5 без явного скидання іконки більше не надсилались.
    refresh();
    deviceClient.requestProcessIconsReset();

    // The tab may mount before the relay socket is open (the first request is
    // then dropped) — retry once when the connection comes up.
    const offConnected = deviceClient.on('connected', () => {
      if (!gotListRef.current) refresh();
      deviceClient.requestProcessIconsReset();
    });

    return () => {
      offList();
      offIcons();
      offKill();
      offFreeze();
      offFront();
      offConnected();
      if (cpuRetryTimer.current) clearTimeout(cpuRetryTimer.current);
    };
  }, [refresh, mergeIcons]);

  // Закриття контекст-меню: клік поза ним / Esc.
  useEffect(() => {
    if (!menu) return;
    const close = () => setMenu(null);
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') setMenu(null); };
    window.addEventListener('click', close);
    window.addEventListener('resize', close);
    window.addEventListener('keydown', onKey);
    return () => {
      window.removeEventListener('click', close);
      window.removeEventListener('resize', close);
      window.removeEventListener('keydown', onKey);
    };
  }, [menu]);

  const getIcon = useCallback((proc: ProcInfo): string | undefined => {
    void iconsBump; // зависимость, чтобы строки перечитывали кеш после новых иконок
    const map = iconsRef.current;
    if (proc.exePath) {
      const byPath = map[proc.exePath.toLowerCase()];
      if (byPath) return byPath;
    }
    return map[proc.name.toLowerCase()];
  }, [iconsBump]);

  const requestKill = useCallback((proc: ProcInfo) => setKillTarget(proc), []);

  const confirmKill = useCallback(() => {
    const target = killTarget;
    setKillTarget(null);
    if (!target) return;
    deviceClient.sendKillProcess(target.pid);
  }, [killTarget]);

  /** ТЗ 46: лівий клік = витягнути вікно процесу на передній план ПК. */
  const bringFront = useCallback((proc: ProcInfo) => {
    if (proc.category !== 'app') return;
    deviceClient.bringProcessToFront(proc.pid);
  }, []);

  const toggleFreeze = useCallback((proc: ProcInfo) => {
    setMenu(null);
    deviceClient.freezeProcess(proc.pid, !proc.frozen);
  }, []);

  // Counts per category for the segmented control.
  const counts = useMemo(() => {
    const c = { all: processes.length, app: 0, background: 0, system: 0 } as Record<ProcCategory, number>;
    for (const p of processes) {
      const cat = (p.category as ProcCategory) ?? 'background';
      if (cat === 'app' || cat === 'background' || cat === 'system') c[cat] += 1;
    }
    return c;
  }, [processes]);

  // Сводка по ТЕКУЩЕЙ категории: суммарный CPU и память.
  const summary = useMemo(() => {
    let cpu = 0;
    let ram = 0;
    let hung = 0;
    let frozen = 0;
    for (const p of processes) {
      const cat = (p.category as ProcCategory) ?? 'background';
      if (p.responding === false) hung += 1;
      if (p.frozen) frozen += 1;
      if (category !== 'all' && cat !== category) continue;
      cpu += p.cpuPercent ?? 0;
      ram += p.memoryMb;
    }
    return { cpu: Math.min(100, Math.round(cpu)), ram, hung, frozen };
  }, [processes, category]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    let list = processes;
    if (category !== 'all') list = list.filter((p) => (p.category ?? 'background') === category);
    if (q) list = list.filter((p) => p.name.toLowerCase().includes(q) || String(p.pid).includes(q) || (p.exePath ?? '').toLowerCase().includes(q) || (p.title ?? '').toLowerCase().includes(q));

    const dir = sortDesc ? -1 : 1;
    const sorted = [...list].sort((a, b) => {
      switch (sortKey) {
        case 'cpu': return ((a.cpuPercent ?? 0) - (b.cpuPercent ?? 0)) * dir;
        case 'memory': return (a.memoryMb - b.memoryMb) * dir;
        case 'name': return a.name.localeCompare(b.name, 'uk', { numeric: true }) * dir;
        case 'pid': return (a.pid - b.pid) * dir;
        default: return 0;
      }
    });
    return sorted;
  }, [processes, search, category, sortKey, sortDesc]);

  const applySort = useCallback((key: SortKey) => {
    setSortKey((prev) => {
      if (prev === key) {
        setSortDesc((d) => !d);
        return prev;
      }
      setSortDesc(true);
      return key;
    });
  }, []);

  const SortHeader: React.FC<{ id: SortKey; label: string; className?: string }> = ({ id, label, className }) => (
    <button type="button" onClick={() => applySort(id)} className={`sort-th ${sortKey === id ? 'on' : ''} ${className ?? ''}`}>
      {label}
      {sortKey === id && (sortDesc ? <ArrowDown /> : <ArrowUp />)}
    </button>
  );

  // Позиція меню з урахуванням країв екрана (на мобільному довге тап-меню).
  const menuStyle = useMemo(() => {
    if (!menu) return {};
    const w = 232;
    const h = 172;
    const x = Math.min(menu.x, window.innerWidth - w - 12);
    const y = Math.min(menu.y, window.innerHeight - h - 12);
    return { left: Math.max(8, x), top: Math.max(8, y) };
  }, [menu]);

  return (
    <div className="space-y-4">
      {/* Header + toolbar */}
      <section className="fc-card-static p-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="fc-section-head">
            <span className="fc-section-icon">
              <Activity className="h-5 w-5" />
            </span>
            <div className="min-w-0">
              <h3>Процеси</h3>
              <p className="truncate">
                {device.name}
                {summary.hung > 0 && <span className="ml-1 font-bold text-rose-400">· {summary.hung} не відповідає</span>}
                {summary.frozen > 0 && <span className="ml-1 font-bold text-sky-300">· {summary.frozen} заморожено</span>}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="fc-badge fc-badge-info"><Cpu className="h-3 w-3" /> {summary.cpu}% ЦП</span>
            <span className="fc-badge fc-badge-info"><MemoryStick className="h-3 w-3" /> {formatMemoryMb(summary.ram)}</span>
          </div>
        </div>
        <div className="relative mt-3.5">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500" />
          <input
            className="fc-input fc-has-icon"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Пошук за назвою, вікном або PID…"
            aria-label="Пошук процесу"
          />
        </div>

        {/* Category segmented control — за замовчуванням «Програми» */}
        <div className="seg-tabs mt-3" role="tablist" aria-label="Категорії процесів">
          {CATEGORY_META.map((c) => (
            <button
              key={c.id}
              role="tab"
              aria-selected={category === c.id}
              onClick={() => setCategory(c.id)}
              className={`seg-tab ${category === c.id ? 'active' : ''}`}
            >
              <span>{c.label}</span>
              <span className="seg-count">{counts[c.id]}</span>
            </button>
          ))}
        </div>
      </section>

      {/* Process list */}
      <section className="fc-card-static overflow-hidden">
        <div className="hidden items-center gap-3 border-b border-white/5 bg-black/30 px-4 py-2 sm:flex">
          <span className="h-9 w-9 shrink-0" />
          <SortHeader id="name" label="Процес" className="flex-1 !justify-start" />
          <SortHeader id="pid" label="PID" className="w-14" />
          <SortHeader id="cpu" label="ЦП" className="w-14" />
          <SortHeader id="memory" label="Пам'ять" className="w-20" />
          <span className="h-9 w-8 shrink-0" />
          <span className="h-9 w-8 shrink-0" />
        </div>

        {/* Mobile sort chips (columns are hidden on phones) */}
        <div className="flex items-center gap-1.5 overflow-x-auto border-b border-white/5 bg-black/30 px-3 py-2 text-[11px] text-zinc-500 sm:hidden">
          <ArrowDownUp className="h-3.5 w-3.5 flex-none" />
          {([
            { id: 'memory', label: "Пам'ять" },
            { id: 'cpu', label: 'ЦП' },
            { id: 'name', label: "Ім'я" },
            { id: 'pid', label: 'PID' },
          ] as { id: SortKey; label: string }[]).map((s) => (
            <button
              key={s.id}
              onClick={() => applySort(s.id)}
              aria-pressed={sortKey === s.id}
              className={`flex-none rounded-lg border px-2.5 py-1 font-bold transition-all ${
                sortKey === s.id
                  ? 'border-violet-400/50 bg-violet-600/25 text-white'
                  : 'border-white/10 bg-white/[0.03] text-zinc-400'
              }`}
            >
              {s.label}
              {sortKey === s.id && <span className="ml-1">{sortDesc ? '↓' : '↑'}</span>}
            </button>
          ))}
        </div>

        {loading && processes.length === 0 ? (
          <div className="divide-y divide-white/[0.04]">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="flex animate-pulse items-center gap-3 px-4 py-3">
                <div className="h-9 w-9 rounded-xl bg-white/5" />
                <div className="h-3 max-w-[35%] flex-1 rounded bg-white/5" />
                <div className="h-3 w-12 rounded bg-white/5" />
                <div className="h-3 w-10 rounded bg-white/5" />
                <div className="h-3 w-12 rounded bg-white/5" />
              </div>
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center gap-3 px-6 py-14 text-center">
            <span className="grid h-12 w-12 place-items-center rounded-2xl border border-white/10 bg-black/40 text-zinc-500">
              <Activity className="h-6 w-6" />
            </span>
            <p className="text-xs font-semibold text-zinc-400">
              {processes.length === 0
                ? 'Список процесів порожній або ПК не відповідає'
                : category !== 'all' && !search.trim()
                  ? `У категорії «${CATEGORY_META.find((c) => c.id === category)?.label}» нічого немає — переключіть фільтр`
                  : `Нічого не знайдено за запитом «${search.trim()}»`}
            </p>
            {processes.length === 0 && (
              <Loader2 className="h-4 w-4 animate-spin text-violet-300" />
            )}
          </div>
        ) : (
          <div className="max-h-[32rem] space-y-1 overflow-y-auto p-2">
            {filtered.map((proc) => (
              <ProcRowView
                key={`${proc.pid}|${proc.name}`}
                proc={proc}
                icon={getIcon(proc)}
                onKill={requestKill}
                onMenu={(p, x, y) => setMenu({ proc: p, x, y })}
                onFront={bringFront}
              />
            ))}
          </div>
        )}
      </section>

      {/* Контекст-меню процесу (ПКМ на ПК / довгий тап на телефоні) — ТЗ 46 */}
      {menu && (
        <div
          className="fixed z-50 w-58 overflow-hidden rounded-2xl border border-white/10 bg-zinc-900/95 py-1 shadow-2xl backdrop-blur"
          style={menuStyle}
          onClick={(e) => e.stopPropagation()}
          role="menu"
        >
          <div className="truncate px-3 py-1.5 text-[10px] font-black uppercase tracking-wider text-zinc-500">
            {menu.proc.name} · PID {menu.proc.pid}
          </div>
          {menu.proc.category === 'app' && (
            <button
              type="button"
              role="menuitem"
              onClick={() => {
                setMenu(null);
                bringFront(menu.proc);
              }}
              className="flex w-full items-center gap-2.5 px-3 py-2 text-left text-xs font-semibold text-zinc-200 hover:bg-white/10"
            >
              <Hand className="h-3.5 w-3.5 text-violet-300" />
              На передній план ПК
            </button>
          )}
          <button
            type="button"
            role="menuitem"
            onClick={() => toggleFreeze(menu.proc)}
            className="flex w-full items-center gap-2.5 px-3 py-2 text-left text-xs font-semibold text-zinc-200 hover:bg-white/10"
          >
            {menu.proc.frozen ? (
              <>
                <Play className="h-3.5 w-3.5 text-emerald-300" />
                Розморозити
              </>
            ) : (
              <>
                <Pause className="h-3.5 w-3.5 text-sky-300" />
                Заморозити (пауза)
              </>
            )}
          </button>
          <div className="my-1 border-t border-white/5" />
          <button
            type="button"
            role="menuitem"
            onClick={() => {
              const p = menu.proc;
              setMenu(null);
              requestKill(p);
            }}
            className="flex w-full items-center gap-2.5 px-3 py-2 text-left text-xs font-semibold text-rose-300 hover:bg-rose-500/15"
          >
            <XCircle className="h-3.5 w-3.5" />
            Завершити процес
          </button>
        </div>
      )}

      {/* Kill confirmation */}
      <FcConfirmModal
        open={!!killTarget}
        title="Завершити процес?"
        message={
          killTarget
            ? `Процес «${killTarget.name}» (PID ${killTarget.pid}) буде примусово завершено на віддаленому ПК.`
            : ''
        }
        confirmLabel="Завершити"
        onConfirm={confirmKill}
        onCancel={() => setKillTarget(null)}
      />
    </div>
  );
};
