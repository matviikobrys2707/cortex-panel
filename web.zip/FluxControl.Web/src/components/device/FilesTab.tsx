import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Archive,
  ArrowDown,
  ArrowUp,
  ArrowUpDown,
  Check,
  ChevronRight,
  Clipboard,
  Copy,
  Download,
  ExternalLink,
  File,
  FileCode2,
  FilePlus,
  FileQuestion,
  FileText,
  Folder,
  FolderOpen,
  FolderPlus,
  HardDrive,
  Image as ImageIcon,
  LayoutGrid,
  List,
  Loader2,
  Monitor,
  MoreVertical,
  Music2,
  Network,
  PackageOpen,
  Pencil,
  Scissors,
  Search,
  Share2,
  Trash2,
  UploadCloud,
  Usb,
  Video,
  X,
} from 'lucide-react';
import { Device } from '../../types';
import { deviceClient } from '../../services/deviceClient';
import { toast } from '../../utils/toast';
import {
  ARCHIVE_EXTS,
  AUDIO_EXTS,
  DriveCardInfo,
  FsItem,
  IMAGE_EXTS,
  TEXT_EXTS,
  TEXT_PREVIEW_LIMIT,
  VIDEO_EXTS,
  base64ToBlob,
  extOf,
  formatBytes,
  formatDateUk,
  formatGb,
  joinWinPath,
  mediaKindOf,
  mimeFor,
  parentOf,
  pathCrumbs,
  samePath,
  saveBlobAs,
  winNormalize,
  type MediaKind,
} from './fcHelpers';
import { FcConfirmModal, FcModal, FcPromptModal } from './fcModals';

// ТЗ 49 (економія трафіку): кеш мініатюр на всю сесію вкладки. Повторний
// вхід у папку / повернення з галереї більше НЕ перекачує прев'ю через
// релей Render (до 60 штук на папку по 10-40КБ — відчутна економія).
const thumbCache = new Map<string, string>();
const THUMB_CACHE_MAX = 600;
function cacheThumb(key: string, dataUrl: string) {
  if (thumbCache.has(key)) thumbCache.delete(key);
  thumbCache.set(key, dataUrl);
  if (thumbCache.size > THUMB_CACHE_MAX) {
    const oldest = thumbCache.keys().next().value;
    if (oldest !== undefined) thumbCache.delete(oldest);
  }
}

// ================= ТЗ: кеш вмісту папок (швидкий доступ) =================
// Робочий стіл / Завантаження / Документи та будь-яка папка показуються
// МИТТЄВО з кеша (localStorage), а свіжі дані довантажуються фоном
// (stale-while-revalidate). Кеш не показуємо, якщо він старший за TTL.
const LISTING_CACHE_KEY = 'fc_files_listing_cache_v1';
const LISTING_CACHE_MAX = 30;
const LISTING_TTL_MS = 10 * 60 * 1000;

interface ListingCacheEntry { items: FsItem[]; ts: number }
type ListingCacheShape = Record<string, ListingCacheEntry>;

function loadListingCache(): ListingCacheShape {
  try {
    const raw = localStorage.getItem(LISTING_CACHE_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' ? parsed as ListingCacheShape : {};
  } catch { return {}; }
}

function saveListingEntry(path: string, items: FsItem[]) {
  try {
    const cache = loadListingCache();
    cache[path.toLowerCase()] = { items, ts: Date.now() };
    const keys = Object.keys(cache);
    if (keys.length > LISTING_CACHE_MAX) {
      keys.sort((a, b) => (cache[a]?.ts ?? 0) - (cache[b]?.ts ?? 0));
      for (const k of keys.slice(0, keys.length - LISTING_CACHE_MAX)) delete cache[k];
    }
    localStorage.setItem(LISTING_CACHE_KEY, JSON.stringify(cache));
  } catch { /* переповнений localStorage — пропускаємо */ }
}

// Кеш ПАНЕЛІ швидкого доступу (шляхи спеціальних папок — статичні для ПК).
const SPECIALS_CACHE_KEY = 'fc_specials_v2';

function loadSpecialsCache(code: string): { key: string; label: string; path: string }[] {
  try {
    const raw = localStorage.getItem(SPECIALS_CACHE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (parsed?.code === code && Array.isArray(parsed.list)) return parsed.list;
  } catch { /* ignore */ }
  return [];
}

interface FilesTabProps {
  device: Device;
}

type EditorState = {
  item: FsItem;
  path: string;
  content: string;
  original: string;
  loading: boolean;
  loadError: string | null;
  saving: boolean;
  closeArmed: boolean;
};

type PreviewState = {
  item: FsItem;
  path: string;
  kind: MediaKind;
  url: string | null;
  blob: Blob | null;
  loading: boolean;
  error: string | null;
};

type UnsupportedState = { item: FsItem; reason: 'type' | 'big' } | null;
type MenuState = { item: FsItem; x: number; y: number } | null;

const INITIAL_REVEAL = 60;
const REVEAL_STEP = 60;

// ================= Icon per file type =================

function iconFor(item: FsItem): React.ReactNode {
  const cls = 'h-[1.15rem] w-[1.15rem]';
  if (item.isDirectory) return <Folder className={`${cls} fill-amber-400/70 text-amber-300`} />;
  const e = extOf(item.name);
  if (IMAGE_EXTS.has(e)) return <ImageIcon className={`${cls} text-sky-400`} />;
  if (VIDEO_EXTS.has(e)) return <Video className={`${cls} text-violet-400`} />;
  if (AUDIO_EXTS.has(e)) return <Music2 className={`${cls} text-pink-400`} />;
  if (ARCHIVE_EXTS.has(e)) return <Archive className={`${cls} text-amber-300`} />;
  if (TEXT_EXTS.has(e)) return <FileCode2 className={`${cls} text-emerald-400`} />;
  return <File className={`${cls} text-zinc-400`} />;
}

// ================= Memoized file row =================

interface FileRowProps {
  item: FsItem;
  modified: string;
  sizeLabel: string;
  metaLabel?: string;
  onOpen: (item: FsItem) => void;
  onDownload: (item: FsItem) => void;
  onMenu: (item: FsItem, x: number, y: number) => void;
  onTouchStart: (item: FsItem, e: React.TouchEvent) => void;
  onTouchCancel: () => void;
}

const FileRow = React.memo<FileRowProps>(({
  item,
  modified,
  sizeLabel,
  metaLabel,
  onOpen,
  onDownload,
  onMenu,
  onTouchStart,
  onTouchCancel,
}) => (
  <div
    tabIndex={0}
    onClick={() => onOpen(item)}
    onKeyDown={(e) => {
      if (e.key === 'Enter') onOpen(item);
    }}
    onContextMenu={(e) => {
      e.preventDefault();
      onMenu(item, e.clientX, e.clientY);
    }}
    onTouchStart={(e) => onTouchStart(item, e)}
    onTouchEnd={onTouchCancel}
    onTouchMove={onTouchCancel}
    className={`group flex cursor-pointer select-none items-center gap-3 px-3 py-2.5 transition-colors hover:bg-violet-500/[0.07] focus:bg-violet-500/[0.07] focus:outline-none ${
      item.isHidden ? 'opacity-55' : ''
    }`}
  >
    <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl border border-white/5 bg-black/40">
      {iconFor(item)}
    </span>
    <span className="min-w-0 flex-1">
      <span className="block truncate text-xs font-semibold text-zinc-100 group-hover:text-white">{item.name}</span>
      <span className="block truncate text-[10px] text-zinc-500 md:hidden">
        {modified} • {sizeLabel}
      </span>
    </span>
    <span className="hidden w-40 shrink-0 truncate text-[11px] text-zinc-500 md:block">{modified}</span>
    <span className="hidden w-24 shrink-0 text-right font-mono text-[11px] text-zinc-400 sm:block">
      {metaLabel ?? sizeLabel}
      {metaLabel && <span className="ml-1 block text-[9px] leading-none text-zinc-600">{sizeLabel}</span>}
    </span>
    <span className="flex shrink-0 items-center gap-1 opacity-0 transition-opacity group-hover:opacity-100 group-focus:opacity-100 max-md:opacity-100">
      <button
        type="button"
        title="Завантажити"
        aria-label={`Завантажити ${item.name}`}
        onClick={(e) => {
          e.stopPropagation();
          onDownload(item);
        }}
        className="grid h-8 w-8 place-items-center rounded-lg text-zinc-400 transition-colors hover:bg-violet-500/15 hover:text-violet-300"
      >
        <Download className="h-4 w-4" />
      </button>
      <button
        type="button"
        title="Дії"
        aria-label={`Дії для ${item.name}`}
        onClick={(e) => {
          e.stopPropagation();
          onMenu(item, e.clientX, e.clientY);
        }}
        className="grid h-8 w-8 place-items-center rounded-lg text-zinc-400 transition-colors hover:bg-white/10 hover:text-white"
      >
        <MoreVertical className="h-4 w-4" />
      </button>
    </span>
  </div>
));
FileRow.displayName = 'FileRow';

// ================= Memoized drive card =================

const DriveCard = React.memo<{ drive: DriveCardInfo; active: boolean; onClick: () => void }>(({
  drive,
  active,
  onClick,
}) => {
  const Icon = drive.driveType === 'removable' ? Usb : drive.driveType === 'network' ? Network : HardDrive;
  const letter = (drive.name || '').replace(/[\\:]/g, '');
  const used = drive.usedGb ?? Math.max(0, drive.totalGb - drive.freeGb);
  const pct = Math.min(100, Math.max(0, Math.round(drive.percentUsed || (drive.totalGb ? (used / drive.totalGb) * 100 : 0))));
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={`Відкрити диск ${letter}`}
      className={`fc-card p-3.5 text-left transition-all hover:-translate-y-0.5 ${
        active
          ? 'border-violet-500/70 bg-violet-500/[0.07] shadow-[0_0_0_1px_rgba(139,92,246,.35),0_12px_32px_-14px_rgba(139,92,246,.45)]'
          : ''
      }`}
    >
      <div className="flex items-center gap-3">
        <span
          className={`grid h-9 w-9 shrink-0 place-items-center rounded-xl border ${
            active
              ? 'border-violet-400/40 bg-violet-500/15 text-violet-300'
              : 'border-white/10 bg-black/40 text-zinc-400'
          }`}
        >
          <Icon className="h-[1.1rem] w-[1.1rem]" />
        </span>
        <span className="min-w-0 flex-1">
          <span className="block truncate text-sm font-extrabold text-white">
            {letter}
            {drive.label ? <span className="text-xs font-semibold text-zinc-400"> — {drive.label}</span> : null}
          </span>
          <span className="mt-0.5 block truncate text-[11px] text-zinc-500">
            {formatGb(drive.totalGb)} • використано {formatGb(used)} ({pct}%)
          </span>
        </span>
      </div>
      <div className="fc-progress mt-3">
        <i style={{ width: `${pct}%` }} />
      </div>
    </button>
  );
});
DriveCard.displayName = 'DriveCard';

// ================= FilesTab =================

export const FilesTab: React.FC<FilesTabProps> = ({ device }) => {
  const [drives, setDrives] = useState<DriveCardInfo[]>([]);
  const [currentPath, setCurrentPath] = useState('');
  const [parentPath, setParentPath] = useState<string | null>(null);
  const [items, setItems] = useState<FsItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('');
  // ТЗ: файли з'являються ПОСТУПОВО (перші папки одразу, решта догружається
  // порціями) — без важкого одномоментного рендера всього каталогу.
  const [revealCount, setRevealCount] = useState(INITIAL_REVEAL);
  // ТЗ: спінер на чипі швидкого доступу, який зараз відкривається.
  const [pendingChip, setPendingChip] = useState<string | null>(null);

  // Сортування як у Windows (ТЗ): клік по заголовку «Назва»/«Змінено»/«Розмір».
  type SortKey = 'name' | 'modified' | 'size';
  const [sortKey, setSortKey] = useState<SortKey>('name');
  const [sortAsc, setSortAsc] = useState(true);
  // Сигнатура останнього списку — для ТЗ-автооновлення «лише якщо змінилось».
  const listSigRef = useRef('');
  const trashSigRef = useRef('');

  // Розміри папок (ТЗ: «папки теж мали б показувати розмір»): агент дозаповнює
  // метадані фоновими fs_dir_meta подіями (шлях → {sizeBytes, fileCount}).
  const dirMetaRef = useRef<Record<string, { sizeBytes: number; fileCount: number }>>({});
  const [dirMetaBump, setDirMetaBump] = useState(0);

  // Панель швидкого доступу (ТЗ): Робочий стіл/Завантаження/… від агента.
  const [specials, setSpecials] = useState<{ key: string; label: string; path: string }[]>([]);

  // Завантаження файлів на ПК (ТЗ: кнопка у списку файлів + Drag&Drop, без ліміту 48 МБ).
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploadProgress, setUploadProgress] = useState<{ name: string; percent: number } | null>(null);

  const [menu, setMenu] = useState<MenuState>(null);
  const [renameTarget, setRenameTarget] = useState<FsItem | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<FsItem | null>(null);
  const [createKind, setCreateKind] = useState<'file' | 'folder' | null>(null);
  const [editor, setEditor] = useState<EditorState | null>(null);
  const [preview, setPreview] = useState<PreviewState | null>(null);
  const [unsupported, setUnsupported] = useState<UnsupportedState>(null);

  // Корзина (ТЗ: швидкий доступ → Корзина) + режим перегляду кошика.
  const [trashMode, setTrashMode] = useState(false);
  const [trashEmptying, setTrashEmptying] = useState(false);
  // «Поділитися» (ТЗ): згенероване посилання показуємо в модалці.
  const [shareLink, setShareLink] = useState<{ name: string; isDir: boolean; url: string } | null>(null);
  const [shareWaiting, setShareWaiting] = useState(false);

  // Drag & Drop завантаження (ТЗ): перетягнути файли з ПК → вони з'являться у поточній папці
  const [dragActive, setDragActive] = useState(false);
  const [uploadingName, setUploadingName] = useState<string | null>(null);
  // Поле шляху з автопідсказками (ТЗ: «клік у поле путя → вводиш свій шлях,
  // буква → список папок/файлів, Enter на файлі → перегляд»)
  const [pathEditOpen, setPathEditOpen] = useState(false);
  const [pathEditValue, setPathEditValue] = useState('');
  // Активна підказка для навігації ←/↓ + Enter (ТЗ: краща підказка файлів).
  const [sugIdx, setSugIdx] = useState(-1);

  // ТЗ 46: глибокий пошук СКОПОВАНИЙ у поточній папці (диск → весь диск,
  // папка Ігри → тільки Ігри). Enter у полі фільтра запускає глибокий пошук.
  const [searchMode, setSearchMode] = useState(false);
  const [searchItems, setSearchItems] = useState<FsItem[]>([]);
  const [searchTruncated, setSearchTruncated] = useState(false);
  const [searchBusy, setSearching] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  // ТЗ 46: галерея фото/відео з мініатюрами (без скачування).
  const [viewMode, setViewMode] = useState<'list' | 'gallery'>('list');
  const [thumbs, setThumbs] = useState<Record<string, string>>({});
  // ТЗ 46: буфер «Копіювати/Вирізати → Вставити» (агентський, системний ФМ).
  const [clip, setClip] = useState<{ has: boolean; cut: boolean }>({ has: false, cut: false });

  // Refs mirrored from state so socket handlers never read stale values.
  const currentPathRef = useRef('');
  const lastRequestedRef = useRef<string | null>(null);
  const loadingRef = useRef(false);
  const drivesReceivedRef = useRef(false);
  const listedRef = useRef(false);
  const pendingMediaRef = useRef<{ path: string; name: string } | null>(null);
  const holdTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const suppressClickRef = useRef(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const previewUrlRef = useRef<string | null>(null);
  const searchSeqRef = useRef(0);
  const thumbReqRef = useRef<Set<string>>(new Set());
  // Зеркала станів для інтервалу автооновлення (щоб не перетворювати його на stale-зчитувач).
  const searchModeRef = useRef(false);
  const trashModeRef = useRef(false);

  const readPathParam = useCallback((): string | null => {
    try {
      return new URLSearchParams(window.location.search).get('path');
    } catch {
      return null;
    }
  }, []);

  const syncUrl = useCallback(
    (dir: string) => {
      try {
        const code = device.code || device.id;
        window.history.replaceState(
          window.history.state,
          '',
          `/device/${encodeURIComponent(code)}/files?path=${encodeURIComponent(dir)}`
        );
      } catch {
        /* URL sync is best-effort */
      }
    },
    [device]
  );

  const loadDirectory = useCallback((rawPath: string, opts?: { force?: boolean }) => {
    const path = winNormalize(String(rawPath || '').trim());
    if (!path) return;
    // Вихід із режиму корзини при звичайній навігації.
    setTrashMode(false);
    // One fs_list per navigation: skip when this directory is already the
    // in-flight/loaded one (the refresh button passes force).
    if (!opts?.force && lastRequestedRef.current && samePath(path, lastRequestedRef.current)) return;
    lastRequestedRef.current = path;
    loadingRef.current = true;
    setLoading(true);

    // ТЗ КЕШ: якщо вміст папки вже в кеші (свіжий) — малюємо МИТТЄВО, а
    // свіжі дані все одно довантажуємо фоном (stale-while-revalidate).
    if (!opts?.force) {
      const cached = loadListingCache()[path.toLowerCase()];
      if (cached && Array.isArray(cached.items) && Date.now() - cached.ts < LISTING_TTL_MS) {
        setItems(cached.items);
        setCurrentPath(path);
        currentPathRef.current = path;
        setParentPath(parentOf(path));
        setRevealCount(INITIAL_REVEAL);
        setLoading(false);
        loadingRef.current = false;
        listedRef.current = true;
        setMenu(null);
        syncUrl(path);
      }
    }
    deviceClient.requestDirectory(path);
  }, []);

  const navigateTo = useCallback(
    (rawPath: string) => {
      const path = winNormalize(String(rawPath || '').trim());
      if (!path) return;
      if (!samePath(path, currentPathRef.current)) setFilter('');
      setPendingChip(null);
      loadDirectory(path);
    },
    [loadDirectory]
  );

  // ТЗ: кнопки «Оновити» більше немає — список оновлюється САМ (диф 7с),
  // але force-перезавантаження лишилось для дій (після збереження/видалення).

  // ================= Drag & Drop upload (ТЗ) =================

  const readFileAsBase64 = (file: File): Promise<string> =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const dataUrl = String(reader.result || '');
        const comma = dataUrl.indexOf(',');
        resolve(comma >= 0 ? dataUrl.slice(comma + 1) : dataUrl);
      };
      reader.onerror = () => reject(new Error('Не вдалося прочитати файл'));
      reader.readAsDataURL(file);
    });

  const uploadFiles = useCallback(
    async (files: FileList | File[]) => {
      const list = Array.from(files || []);
      if (list.length === 0) return;
      const dir = currentPathRef.current;
      if (!dir) {
        toast.warn('Спочатку відкрийте папку', { title: 'Завантаження' });
        return;
      }
      for (const f of list) {
        // ТЗ: ліміт 48 МБ знято — файл іде частинами (chunked upload).
        setUploadingName(f.name);
        setUploadProgress({ name: f.name, percent: 0 });
        try {
          const b64 = await readFileAsBase64(f);
          const res = await deviceClient.uploadFileChunked(
            joinWinPath(dir, f.name),
            b64,
            (percent) => setUploadProgress({ name: f.name, percent })
          );
          if (!res.success) {
            toast.error(res.error || `Не вдалося завантажити «${f.name}»`, { title: 'Завантаження' });
          } else {
            toast.success(`«${f.name}» завантажено на ПК`, { title: 'Завантаження' });
          }
        } catch {
          toast.error(`Не вдалося прочитати «${f.name}»`, { title: 'Завантаження' });
        } finally {
          setUploadingName(null);
          setUploadProgress(null);
        }
      }
      loadDirectory(currentPathRef.current, { force: true });
    },
    [loadDirectory]
  );

  const onDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer?.types?.includes('Files')) setDragActive(true);
  }, []);

  const onDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    if (e.currentTarget.contains(e.relatedTarget as Node)) return;
    setDragActive(false);
  }, []);

  const onDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setDragActive(false);
      if (e.dataTransfer?.files?.length) void uploadFiles(e.dataTransfer.files);
    },
    [uploadFiles]
  );

  // ================= Поле шляху з автопідсказками (ТЗ) =================

  const openPathEdit = useCallback(() => {
    setPathEditValue(currentPathRef.current);
    setPathEditOpen(true);
    setSugIdx(-1);
  }, []);

  const closePathEdit = useCallback(() => setPathEditOpen(false), []);

  // ================= Open / preview routing =================

  const openPreview = useCallback((item: FsItem) => {
    const kind = mediaKindOf(item.name);
    const path = item.path || joinWinPath(currentPathRef.current, item.name);
    if (kind) {
      // Media: download from the agent and render from the base64 blob.
      pendingMediaRef.current = { path, name: item.name };
      setPreview({ item, path, kind, url: null, blob: null, loading: true, error: null });
      deviceClient.downloadFile(path);
      return;
    }
    if (TEXT_EXTS.has(extOf(item.name))) {
      if (typeof item.size === 'number' && item.size > TEXT_PREVIEW_LIMIT) {
        setUnsupported({ item, reason: 'big' });
        return;
      }
      setEditor({ item, path, content: '', original: '', loading: true, loadError: null, saving: false, closeArmed: false });
      deviceClient.readFile(path);
      return;
    }
    setUnsupported({ item, reason: 'type' });
  }, []);

  /** Підсказки: останній сегмент шляху → фільтр у поточній папці (ТЗ: «буква → список»). */
  const pathSuggestions = useMemo(() => {
    const value = pathEditValue.trim();
    if (!value || !items.length) return [] as FsItem[];
    const lower = value.toLowerCase().replace(/[\\/]+$/, '');
    const tail = lower.split(/[\\/]/).pop() || '';
    if (!tail) return [] as FsItem[];
    return items
      .filter(it => it.name.toLowerCase().includes(tail))
      .slice(0, 8);
  }, [pathEditValue, items]);

  const commitPathEdit = useCallback(() => {
    const raw = pathEditValue.trim();
    if (!raw) { setPathEditOpen(false); return; }
    const path = winNormalize(raw);
    // Точний збіг з файлом у поточній папці → перегляд (ТЗ: «Enter на файлі → перегляд»).
    const segments = path.toLowerCase().split(/[\\/]/).filter(Boolean);
    const fileName = segments[segments.length - 1] || '';
    const exactFile = items.find(
      it => !it.isDirectory && it.name.toLowerCase() === fileName &&
        samePath(path, joinWinPath(currentPathRef.current, it.name))
    );
    if (exactFile) {
      setPathEditOpen(false);
      openPreview({ ...exactFile, path: joinWinPath(currentPathRef.current, exactFile.name) });
      return;
    }
    setPathEditOpen(false);
    navigateTo(path);
  }, [pathEditValue, items, navigateTo, openPreview]);

  const suggestionClick = useCallback(
    (item: FsItem) => {
      const baseDir = winNormalize(pathEditValue.slice(0, Math.max(0, pathEditValue.lastIndexOf(item.name))));
      if (item.isDirectory) {
        setPathEditOpen(false);
        navigateTo(joinWinPath(baseDir || currentPathRef.current, item.name));
      } else {
        // Файл: перегляд одразу (ТЗ)
        setPathEditOpen(false);
        openPreview({ ...item, path: joinWinPath(baseDir || currentPathRef.current, item.name) });
      }
    },
    [pathEditValue, navigateTo, openPreview]
  );

  const handleOpen = useCallback(
    (item: FsItem) => {
      // Swallow the synthetic click that iOS fires right after a long-press.
      if (suppressClickRef.current) {
        suppressClickRef.current = false;
        return;
      }
      if (item.isDirectory) navigateTo(item.path || joinWinPath(currentPathRef.current, item.name));
      else openPreview(item);
    },
    [navigateTo, openPreview]
  );

  const requestDownload = useCallback((item: FsItem) => {
    const path = item.path || joinWinPath(currentPathRef.current, item.name);
    if (item.isDirectory) {
      toast.info('Архівація папки…', { title: 'Завантаження' });
      deviceClient.downloadFolderZip(path);
    } else {
      deviceClient.downloadFile(path);
    }
  }, []);

  const openOnPc = useCallback((item: FsItem) => {
    deviceClient.openFileOnPC(item.path || joinWinPath(currentPathRef.current, item.name));
  }, []);

  const showMenu = useCallback((item: FsItem, x: number, y: number) => {
    setMenu({
      item,
      x: Math.max(8, Math.min(x, window.innerWidth - 232)),
      y: Math.max(8, Math.min(y, window.innerHeight - 290)),
    });
  }, []);

  const cancelHold = useCallback(() => {
    if (holdTimerRef.current) {
      clearTimeout(holdTimerRef.current);
      holdTimerRef.current = null;
    }
  }, []);

  const handleTouchStart = useCallback(
    (item: FsItem, e: React.TouchEvent) => {
      const touch = e.touches[0];
      if (!touch) return;
      cancelHold();
      holdTimerRef.current = setTimeout(() => {
        // The tap that follows a long-press must not leak into rows below.
        suppressClickRef.current = true;
        showMenu(item, touch.clientX, touch.clientY);
      }, 550);
    },
    [cancelHold, showMenu]
  );

  // ================= Socket subscriptions =================

  useEffect(() => {
    const subs = [
      deviceClient.on('fs_drives', (payload: any) => {
        const arr = Array.isArray(payload)
          ? payload
          : Array.isArray(payload?.data)
            ? payload.data
            : Array.isArray(payload?.drives)
              ? payload.drives
              : [];
        const cards: DriveCardInfo[] = arr
          .map((d: any) => ({
            name: String(d?.name || d?.letter || '').trim(),
            label: d?.label || d?.volumeLabel || '',
            totalGb: Number(d?.totalGb ?? (d?.totalBytes ? d.totalBytes / 1024 ** 3 : 0)) || 0,
            freeGb: Number(d?.freeGb ?? (d?.freeBytes ? d.freeBytes / 1024 ** 3 : 0)) || 0,
            usedGb: d?.usedGb != null ? Number(d.usedGb) : undefined,
            percentUsed: Number(d?.percentUsed ?? 0) || 0,
            driveType: d?.driveType || (d?.isRemovable ? 'removable' : 'fixed'),
          }))
          .filter((d: DriveCardInfo) => d.name);
        setDrives(cards);
        drivesReceivedRef.current = true;
        // Without a ?path= deep link, open the first drive once.
        if (!listedRef.current && !lastRequestedRef.current && cards.length) {
          navigateTo(cards[0].name);
        }
      }),

      deviceClient.on('fs_list', (payload: any) => {
        let d: any = null;
        if (Array.isArray(payload)) {
          d = { currentPath: lastRequestedRef.current || '', parentPath: null, items: payload };
        } else if (payload && Array.isArray(payload.items)) {
          d = payload;
        } else if (payload?.data && Array.isArray(payload.data.items)) {
          d = payload.data;
        }
        if (!d) return;
        const confirmed = winNormalize(String(d.currentPath || ''));
        // A late answer for an abandoned navigation must not overwrite the UI.
        if (lastRequestedRef.current && confirmed && !samePath(confirmed, lastRequestedRef.current)) return;
        loadingRef.current = false;
        setLoading(false);
        setPendingChip(null);
        listedRef.current = true;
        const resolved = confirmed || lastRequestedRef.current || '';
        lastRequestedRef.current = resolved;
        const list: FsItem[] = (d.items || []).map((it: any) => {
          const name = String(it?.name ?? '');
          return {
            name,
            path: String(it?.path || joinWinPath(resolved, name)),
            isDirectory: !!it?.isDirectory,
            size: typeof it?.size === 'number' ? it.size : undefined,
            lastModified: it?.lastModified || it?.modified || it?.modifiedAt || undefined,
            extension: it?.extension || it?.ext || undefined,
            isHidden: !!it?.isHidden,
          };
        });
        // ТЗ «оновлювати лише якщо ЩОСЬ змінилось»: сигнатура списку;
        // ідентичний список НЕ тригає ре-рендер (без миготіння і лагів).
        const sig = list
          .map((i) => `${i.name}|${i.isDirectory ? 1 : 0}|${i.size ?? ''}|${i.lastModified ?? ''}`)
          .join('\u0001');
        const unchanged =
          !loadingRef.current &&
          samePath(resolved, currentPathRef.current) &&
          sig === listSigRef.current;
        listSigRef.current = sig;
        saveListingEntry(resolved, list); // ТЗ: кеш вмісту папок
        if (unchanged) return;
        setItems(list);
        setCurrentPath(resolved);
        currentPathRef.current = resolved;
        setParentPath(typeof d.parentPath === 'string' && d.parentPath ? d.parentPath : parentOf(resolved));
        setRevealCount(INITIAL_REVEAL);
        setMenu(null);
        if (resolved) syncUrl(resolved);
      }),

      deviceClient.on('fs_error', (payload: any) => {
        // ТЗ: ТИХІ автооновлення не смутять тостами — помилка показується
        // лише для явно ініційованого користувачем переходу.
        const userInitiated = loadingRef.current;
        loadingRef.current = false;
        setLoading(false);
        setPendingChip(null);
        if (userInitiated) {
          lastRequestedRef.current = null; // allow retrying the failed directory
        }
        if (pendingMediaRef.current) {
          const p = pendingMediaRef.current;
          pendingMediaRef.current = null;
          setPreview((prev) => (prev && samePath(prev.path, p.path) ? { ...prev, loading: false, error: payload?.message || 'Не вдалося завантажити файл' } : prev));
        }
        if (userInitiated) toast.error(payload?.message || 'Не вдалося відкрити папку');
      }),

      deviceClient.on('fs_read_file_result', (payload: any) => {
        if (!payload || typeof payload !== 'object') return;
        if (!payload.success) {
          setEditor((prev) => (prev ? { ...prev, loading: false, loadError: payload.error || 'Не вдалося завантажити файл' } : prev));
          toast.error(payload.error || 'Не вдалося завантажити файл');
          return;
        }
        setEditor((prev) =>
          prev && (!payload.path || samePath(prev.path, payload.path))
            ? { ...prev, content: String(payload.content ?? ''), original: String(payload.content ?? ''), loading: false, loadError: null }
            : prev
        );
      }),

      deviceClient.on('fs_save_file_result', (payload: any) => {
        if (payload?.success) {
          toast.success('Файл збережено');
          setEditor(null);
          loadDirectory(currentPathRef.current, { force: true });
        } else {
          setEditor((prev) => (prev ? { ...prev, saving: false } : prev));
          toast.error(payload?.error || 'Не вдалося зберегти файл');
        }
      }),

      deviceClient.on('fs_create_file_result', (payload: any) => {
        if (payload?.success) {
          toast.success('Файл створено');
          loadDirectory(currentPathRef.current, { force: true });
        } else toast.error(payload?.error || 'Не вдалося створити файл');
      }),

      deviceClient.on('fs_create_folder_result', (payload: any) => {
        if (payload?.success) {
          toast.success('Папку створено');
          loadDirectory(currentPathRef.current, { force: true });
        } else toast.error(payload?.error || 'Не вдалося створити папку');
      }),

      deviceClient.on('fs_rename_result', (payload: any) => {
        if (payload?.success) {
          toast.success('Назву змінено');
          loadDirectory(currentPathRef.current, { force: true });
        } else toast.error(payload?.error || 'Не вдалося перейменувати');
      }),

      // Drag & Drop / кнопка завантаження: результат. Для чанкових завантажень
      // (uploadId) тост і refresh робить промайс uploadFileChunked — тут не дублюємо.
      deviceClient.on('fs_upload_file_result', (payload: any) => {
        if (payload?.uploadId) return;
        if (payload?.success) {
          toast.success(`Файл завантажено на ПК: ${payload.path?.split(/[\\/]/).pop() || ''}`, { title: 'Drag & Drop' });
          loadDirectory(currentPathRef.current, { force: true });
        } else {
          toast.error(payload?.error || 'Не вдалося завантажити файл на ПК', { title: 'Drag & Drop' });
        }
      }),

      // Метадані папок (ТЗ: розмір/к-ть файлів у папках) — фонові партії від агента.
      deviceClient.on('fs_dir_meta', (payload: any) => {
        const d = payload?.data ?? payload;
        const arr = Array.isArray(d?.dirs) ? d.dirs : [];
        if (!arr.length) return;
        for (const m of arr) {
          if (!m?.path) continue;
          dirMetaRef.current[String(m.path).toLowerCase()] = {
            sizeBytes: Number(m.sizeBytes || 0),
            fileCount: Number(m.fileCount || 0),
          };
        }
        setDirMetaBump(b => b + 1);
      }),

      // Швидкі папки для панелі зліва (ТЗ: Робочий стіл / Завантаження / …)
      // + КОШИК (ТЗ) — віртуальна папка,список агент повертає окремо.
      deviceClient.on('fs_special_result', (payload: any) => {
        const d = payload?.data ?? payload;
        const map: { key: string; label: string; path?: string }[] = [
          { key: 'desktop', label: 'Робочий стіл', path: d?.desktop },
          { key: 'downloads', label: 'Завантаження', path: d?.downloads },
          { key: 'documents', label: 'Документи', path: d?.documents },
          { key: 'pictures', label: 'Зображення', path: d?.pictures },
          { key: 'music', label: 'Музика', path: d?.music },
          { key: 'videos', label: 'Відео', path: d?.videos },
        ];
        const list = map.filter(m => m.path && String(m.path).length > 3)
          .map(m => ({ key: m.key, label: m.label, path: String(m.path) }));
        list.push({ key: 'trash', label: 'Корзина', path: 'shell:RecycleBin' });
        setSpecials(list);
        // ТЗ КЕШ: шляхи спеціальних папок статичні — запам'ятовуємо на ПК.
        try {
          localStorage.setItem(SPECIALS_CACHE_KEY, JSON.stringify({ code: device.code || device.id, list }));
        } catch { /* ignore */ }
      }),

      // Корзина: список вмісту (ТЗ). Оновлюємо UI ЛИШЕ якщо вміст змінився
      // І користувач досі в режимі корзини (відкладена відповідь не переб'є
      // навігацію, яка вже пішла в іншу папку).
      deviceClient.on('fs_trash_list_result', (payload: any) => {
        if (!trashModeRef.current) return;
        const d = payload?.data ?? payload;
        const arr = Array.isArray(d?.items) ? d.items : [];
        const mapped: FsItem[] = arr.map((t: any) => ({
          name: String(t?.name ?? 'об’єкт'),
          path: String(t?.path ?? ''),
          isDirectory: false,
          size: Number(t?.sizeBytes ?? 0) || 0,
          lastModified: t?.deletedAt ? String(t.deletedAt) : undefined,
          extension: 'trash',
        }));
        const sig = mapped.map((i) => `${i.name}|${i.path}|${i.size ?? ''}|${i.lastModified ?? ''}`).join('\u0001');
        const unchanged = sig === trashSigRef.current;
        trashSigRef.current = sig;
        setTrashMode(true);
        setPendingChip(null);
        setLoading(false);
        if (unchanged) return;
        setItems(mapped);
        setRevealCount(INITIAL_REVEAL);
      }),

      // Кошик очищено (ТЗ).
      deviceClient.on('fs_trash_empty_result', (payload: any) => {
        setTrashEmptying(false);
        if (payload?.success) {
          toast.success('Корзину очищено');
          openTrash();
        } else toast.error(payload?.error || 'Не вдалося очистити корзину');
      }),

      // «Поділитися» (ТЗ): агент створив токен → показуємо посилання.
      deviceClient.on('fs_share_result', (payload: any) => {
        setShareWaiting(false);
        const d = payload?.data ?? payload;
        if (d?.ok && d?.token) {
          const url = `${window.location.origin}/s/${d.token}`;
          setShareLink({ name: String(d.name || 'об’єкт'), isDir: Boolean(d.isDir), url });
        } else {
          toast.error(d?.error || 'Не вдалося створити посилання');
        }
      }),

      deviceClient.on('fs_delete_result', (payload: any) => {
        if (payload?.success) {
          toast.success('Видалено');
          loadDirectory(currentPathRef.current, { force: true });
        } else toast.error(payload?.error || 'Не вдалося видалити');
      }),

      // ===== ТЗ 46: пошук / ZIP / буфер ФМ / мініатюри =====
      deviceClient.on('fs_search_result', (payload: any) => {
        const seq = Number(payload?.seq ?? -1);
        if (seq >= 0 && seq !== searchSeqRef.current) return; // застаріла відповідь
        setSearching(false);
        if (!payload?.success) {
          toast.error(payload?.error || 'Пошук не вдався');
          return;
        }
        const d = payload?.data ?? payload;
        const arr = Array.isArray(d) ? d : Array.isArray(payload?.items) ? payload.items : [];
        setSearchItems(arr.map((it: any) => ({
          name: String(it?.name ?? ''),
          path: String(it?.path ?? ''),
          isDirectory: !!it?.isDirectory,
          size: typeof it?.size === 'number' ? it.size : undefined,
          lastModified: it?.lastModified || undefined,
          extension: it?.extension || undefined,
          isHidden: !!it?.isHidden,
        })));
        setSearchTruncated(!!payload?.truncated);
        setSearchQuery(String(payload?.query ?? ''));
        setSearchMode(true);
      }),

      deviceClient.on('fs_compress_result', (payload: any) => {
        if (payload?.success) {
          toast.success(`Створено ${String(payload.zipPath || '').split('\\').pop() || 'ZIP-архів'}`);
          loadDirectory(currentPathRef.current, { force: true });
        } else toast.error(payload?.error || 'Не вдалося стиснути в ZIP');
      }),

      deviceClient.on('fs_extract_result', (payload: any) => {
        if (payload?.success) {
          toast.success(`Розпаковано у «${String(payload.dir || '').split('\\').pop() || 'папку'}»`);
          loadDirectory(currentPathRef.current, { force: true });
        } else toast.error(payload?.error || 'Не вдалося розпакувати архів');
      }),

      deviceClient.on('fs_clipboard_set_result', (payload: any) => {
        if (payload?.success) setClip({ has: (payload.count ?? 0) > 0, cut: !!payload.cut });
      }),

      deviceClient.on('fs_clipboard_state', (payload: any) => {
        setClip({ has: !!payload?.hasItems, cut: false });
      }),

      deviceClient.on('fs_paste_result', (payload: any) => {
        if (payload?.success) {
          toast.success(`Вставлено ${payload.count ?? 0} об'єкт(ів)`);
          setClip({ has: false, cut: false });
          loadDirectory(currentPathRef.current, { force: true });
        } else toast.error(payload?.error || 'Не вдалося вставити');
      }),

      deviceClient.on('fs_thumbnail_result', (payload: any) => {
        if (payload?.path && payload?.dataUrl) {
          const key = String(payload.path).toLowerCase();
          setThumbs((prev) => (prev[key] === payload.dataUrl ? prev : { ...prev, [key]: payload.dataUrl }));
          cacheThumb(key, payload.dataUrl);
        }
      }),

      deviceClient.on('fs_open_on_pc_result', (payload: any) => {
        if (payload?.success) toast.success('Відкрито на ПК');
        else toast.error(payload?.error || 'Не вдалося відкрити на ПК');
      }),

      deviceClient.on('fs_download_file_result', (payload: any) => {
        const d = payload || {};
        if (!d.success || !d.base64) {
          if (pendingMediaRef.current) {
            const p = pendingMediaRef.current;
            pendingMediaRef.current = null;
            setPreview((prev) => (prev && samePath(prev.path, p.path) ? { ...prev, loading: false, error: d.error || 'Не вдалося завантажити файл' } : prev));
          }
          toast.error(d.error || 'Не вдалося завантажити');
          return;
        }
        const pending = pendingMediaRef.current;
        if (pending && (!d.path || samePath(d.path, pending.path))) {
          // The result belongs to an open media preview — render it inline.
          pendingMediaRef.current = null;
          const blob = base64ToBlob(d.base64, mimeFor(pending.name));
          const url = URL.createObjectURL(blob);
          setPreview((prev) => (prev && samePath(prev.path, pending.path) ? { ...prev, url, blob, loading: false } : prev));
          return;
        }
        const name = String(d.name || 'download');
        const isZip = d.isZip === true || name.toLowerCase().endsWith('.zip');
        const blob = base64ToBlob(d.base64, isZip ? 'application/zip' : mimeFor(name));
        saveBlobAs(name, blob);
        if (isZip) toast.success('Папку завантажено');
        else toast.success(`«${name}» завантажено`);
      }),
    ];

    // Deep link: /device/<code>/files?path=... opens that directory directly
    // (drives are still requested for the switcher). Otherwise wait for the
    // drive list and auto-open the first disk.
    const p0 = readPathParam();
    if (p0) loadDirectory(p0);
    else deviceClient.requestDrives();
    // Панель швидкого доступу (ТЗ): шляхи спеціальних папок від агента
    // + миттєва гідратація з кеша, поки агент відповідає.
    const cachedSpecials = loadSpecialsCache(device.code || device.id);
    if (cachedSpecials.length > 0) setSpecials(cachedSpecials);
    deviceClient.requestSpecialFolders();

    // ТЗ АВТООНОВЛЕННЯ (без кнопки «Оновити»): щось змінилось у папці
    // (файл додали/видалили/перейменували) → список оновиться САМ;
    // нічого не змінилось → UI НЕ чіпаємо (диф за сигнатурою списку).
    const autoIv = window.setInterval(() => {
      if (typeof document !== 'undefined' && document.visibilityState !== 'visible') return;
      if (searchModeRef.current) return;
      if (trashModeRef.current) {
        deviceClient.requestTrashList();
      } else if (currentPathRef.current) {
        deviceClient.requestDirectory(currentPathRef.current);
      }
    }, 7000);

    // The tab mounts while the session is still connecting — the very first
    // requests can be dropped by the closed socket. When the relay socket
    // (re)opens and NO listing has arrived yet, re-issue the initial load.
    const offConnected = deviceClient.on('connected', () => {
      if (listedRef.current) return;
      const p = readPathParam();
      if (p) {
        loadDirectory(p, { force: true });
        return;
      }
      if (!drivesReceivedRef.current) deviceClient.requestDrives();
    });

    // Back/Forward navigation re-reads the ?path param.
    const onPopState = () => {
      const p = readPathParam();
      if (p && !samePath(p, currentPathRef.current)) {
        setFilter('');
        loadDirectory(p);
      }
    };
    window.addEventListener('popstate', onPopState);

    return () => {
      subs.forEach((unsub) => unsub());
      offConnected();
      window.clearInterval(autoIv);
      window.removeEventListener('popstate', onPopState);
    };
  }, [loadDirectory, navigateTo, readPathParam, syncUrl, device.code, device.id]);

  // Context menu: close on outside interaction / Escape / scroll.
  useEffect(() => {
    if (!menu) return undefined;
    const onOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setMenu(null);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setMenu(null);
    };
    const onScroll = () => setMenu(null);
    window.addEventListener('mousedown', onOutside);
    window.addEventListener('keydown', onKey);
    window.addEventListener('wheel', onScroll, { passive: true });
    return () => {
      window.removeEventListener('mousedown', onOutside);
      window.removeEventListener('keydown', onKey);
      window.removeEventListener('wheel', onScroll);
    };
  }, [menu]);

  // Keep the latest preview URL reachable for the unmount cleanup.
  useEffect(() => {
    previewUrlRef.current = preview?.url ?? null;
  }, [preview]);

  // Синхронізація зеркал режимів для автооновлення.
  useEffect(() => { searchModeRef.current = searchMode; }, [searchMode]);
  useEffect(() => { trashModeRef.current = trashMode; }, [trashMode]);

  // Unmount: clear long-press timer, revoke any open preview object URL.
  useEffect(
    () => () => {
      if (holdTimerRef.current) clearTimeout(holdTimerRef.current);
      if (previewUrlRef.current) URL.revokeObjectURL(previewUrlRef.current);
    },
    []
  );

  // ================= Derived =================

  const crumbs = useMemo(() => pathCrumbs(currentPath), [currentPath]);
  const atRoot = useMemo(() => {
    if (parentPath) return samePath(parentPath, currentPath);
    return crumbs.length <= 1;
  }, [parentPath, currentPath, crumbs.length]);

  const filtered = useMemo(() => {
    const q = filter.trim().toLowerCase();
    if (!q) return items;
    return items.filter((i) => i.name.toLowerCase().includes(q));
  }, [items, filter]);

  // Сортування як у Провіднику Windows (ТЗ): папки завжди вище, потім за
  // обраним стовпцем і напрямом; клік по заголовку перемикає.
  const sorted = useMemo(() => {
    void dirMetaBump; // перераховувати, коли доїхали нові розміри папок
    const meta = dirMetaRef.current;
    const dir = sortAsc ? 1 : -1;
    const list = [...filtered];
    list.sort((a, b) => {
      if (a.isDirectory !== b.isDirectory) return a.isDirectory ? -1 : 1;
      switch (sortKey) {
        case 'modified': {
          const ta = a.lastModified ? new Date(a.lastModified).getTime() || 0 : 0;
          const tb = b.lastModified ? new Date(b.lastModified).getTime() || 0 : 0;
          return (ta - tb) * dir;
        }
        case 'size': {
          const sa = a.isDirectory ? (meta[a.path.toLowerCase()]?.sizeBytes ?? 0) : (a.size ?? 0);
          const sb = b.isDirectory ? (meta[b.path.toLowerCase()]?.sizeBytes ?? 0) : (b.size ?? 0);
          return (sa - sb) * dir;
        }
        default:
          return a.name.localeCompare(b.name, 'uk', { numeric: true }) * dir;
      }
    });
    return list;
  }, [filtered, sortKey, sortAsc, dirMetaBump]);

  /** Мітка для папки (ТЗ: «щоб папки теж писали свій розмір/к-ть файлів»). */
  const dirMetaLabel = useCallback((item: FsItem): string | undefined => {
    if (!item.isDirectory) return undefined;
    const m = dirMetaRef.current[item.path.toLowerCase()];
    if (!m) return undefined;
    if (m.sizeBytes > 0) return `${formatBytes(m.sizeBytes)}`;
    if (m.fileCount > 0) return `${m.fileCount} ел.`;
    return undefined;
  }, [dirMetaBump]);

  const visible = useMemo(() => sorted.slice(0, revealCount), [sorted, revealCount]);

  // ТЗ: ПОСТУПОВА поява файлів — порції по 60 рядків кожні ~70мс, поки
  // список не довантажиться повністю (без «важкого» одного рендера).
  useEffect(() => {
    const total = searchMode ? searchItems.length : sorted.length;
    if (revealCount >= total) return;
    const t = window.setTimeout(
      () => setRevealCount((c) => Math.min(total, c + REVEAL_STEP)),
      70
    );
    return () => window.clearTimeout(t);
  }, [revealCount, sorted.length, searchMode, searchItems.length]);

  // ТЗ 46: у режимі галереї тягнемо мініатюри фото/відео з агента (кеш Windows).
  useEffect(() => {
    if (viewMode !== 'gallery' || searchMode) return;
    let cancelled = false;
    const batch = visible
      .filter((it) => {
        if (it.isDirectory) return false;
        const e = extOf(it.name);
        return (IMAGE_EXTS.has(e) || VIDEO_EXTS.has(e));
      })
      .slice(0, 60)
      .filter((it) => {
        const key = it.path.toLowerCase();
        if (thumbs[key] || thumbReqRef.current.has(key)) return false;
        const cached = thumbCache.get(key);
        if (cached) {
          // ТЗ 49: прев'ю вже в кеші сесії — підтягуємо без запиту через релей.
          queueMicrotask(() => setThumbs((prev) => (prev[key] ? prev : { ...prev, [key]: cached })));
          return false;
        }
        return true;
      });
    if (batch.length === 0) return;
    (async () => {
      for (const it of batch) {
        if (cancelled) return;
        const key = it.path.toLowerCase();
        thumbReqRef.current.add(key);
        deviceClient.requestThumbnail(it.path, 320);
        await new Promise((r) => setTimeout(r, 90)); // не завалюємо релей потоком
      }
    })();
    return () => { cancelled = true; };
  }, [viewMode, searchMode, visible, thumbs]);

  const applySortClick = useCallback((key: SortKey) => {
    setSortKey(prev => {
      if (prev === key) { setSortAsc(v => !v); return prev; }
      setSortAsc(key === 'modified' ? false : true); // «Змінено» — свіжі зверху
      return key;
    });
  }, []);

  const upPath = atRoot ? null : parentPath || parentOf(currentPath);

  // ================= Handlers =================

  const closePreview = useCallback(() => {
    if (preview?.url) URL.revokeObjectURL(preview.url);
    setPreview(null);
    pendingMediaRef.current = null;
  }, [preview]);

  // Two-step close keeps unsaved edits from being lost by a single click.
  const requestEditorClose = useCallback(() => {
    if (!editor) return;
    if (editor.content !== editor.original && !editor.closeArmed) {
      setEditor({ ...editor, closeArmed: true });
      return;
    }
    setEditor(null);
  }, [editor]);

  const saveEditor = useCallback(() => {
    if (!editor || editor.loading || editor.saving || editor.loadError) return;
    setEditor({ ...editor, saving: true });
    deviceClient.saveFile(editor.path, editor.content);
  }, [editor]);

  const submitRename = useCallback(
    (value: string) => {
      const target = renameTarget;
      setRenameTarget(null);
      if (!target) return;
      if (value === target.name) return;
      deviceClient.renameItem(target.path || joinWinPath(currentPathRef.current, target.name), value);
    },
    [renameTarget]
  );

  const submitCreate = useCallback((value: string) => {
    const kind = createKind;
    setCreateKind(null);
    if (!kind) return;
    if (kind === 'folder') deviceClient.createFolder(currentPathRef.current, value);
    else deviceClient.createFile(currentPathRef.current, value);
  }, [createKind]);

  const confirmDelete = useCallback(() => {
    const target = deleteTarget;
    setDeleteTarget(null);
    if (!target) return;
    deviceClient.deleteFile(target.path || joinWinPath(currentPathRef.current, target.name));
  }, [deleteTarget]);

  const menuAction = (action: 'open' | 'rename' | 'download' | 'delete' | 'openPc' | 'share' | 'zip' | 'extract' | 'copy' | 'cut') => {
    if (!menu) return;
    const item = menu.item;
    setMenu(null);
    if (action === 'open') handleOpen(item);
    else if (action === 'rename') setRenameTarget(item);
    else if (action === 'download') requestDownload(item);
    else if (action === 'delete') setDeleteTarget(item);
    else if (action === 'openPc') openOnPc(item);
    else if (action === 'share') {
      // «Поділитися» (ТЗ): генеруємо сеансове посилання на файл/папку.
      setShareWaiting(true);
      deviceClient.sharePath(item.path);
    } else if (action === 'zip') {
      // ТЗ 46: «сжать папку в ZIP» прямо з контекст-меню.
      toast.info('Стискаю в архів…', { title: 'ZIP' });
      deviceClient.compressToZip(item.path || joinWinPath(currentPathRef.current, item.name));
    } else if (action === 'extract') {
      // ТЗ 46: «распаковать, если это ZIP или RAR».
      toast.info('Розпаковую архів…', { title: 'Архів' });
      deviceClient.extractArchive(item.path || joinWinPath(currentPathRef.current, item.name));
    } else if (action === 'copy' || action === 'cut') {
      // ТЗ 46: копіювати/вирізати → потім «Вставити» в іншій папці.
      deviceClient.setFileClipboard([item.path || joinWinPath(currentPathRef.current, item.name)], action === 'cut');
      setClip({ has: true, cut: action === 'cut' });
      toast.info(action === 'cut' ? 'Вирізано — відкрийте потрібну папку і натисніть «Вставити»' : 'Скопійовано — відкрийте потрібну папку і натисніть «Вставити»');
    }
  };

  // ================= ТЗ 46: глибокий скопований пошук =================

  const runScopedSearch = useCallback(() => {
    const q = filter.trim();
    if (q.length < 1 || !currentPathRef.current) return;
    setSearching(true);
    setSearchMode(false);
    deviceClient.searchFiles(currentPathRef.current, q);
  }, [filter]);

  const cancelSearch = useCallback(() => {
    setSearchMode(false);
    setSearchItems([]);
    setSearching(false);
  }, []);

  const pasteIntoCurrent = useCallback(() => {
    if (!currentPathRef.current) return;
    deviceClient.pasteFiles(currentPathRef.current);
  }, []);

  // Корзина (ТЗ): відкрити віртуальний список вмісту кошика.
  const openTrash = useCallback(() => {
    setTrashMode(true);
    setLoading(true);
    setPendingChip('trash'); // ТЗ: спінер прямо на чипі «Корзина», поки грузиться
    setFilter('');
    deviceClient.requestTrashList();
  }, []);

  // ================= Render =================

  return (
    <div className="space-y-4">
      {/* Toolbar card */}
      <section className="fc-card-static space-y-3.5 p-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="fc-section-head">
            <span className="fc-section-icon">
              <HardDrive className="h-5 w-5" />
            </span>
            <div className="min-w-0">
              <h3>Файли</h3>
              <p className="truncate">
                {device.name}
                {items.length > 0 ? ` • ${items.length} об'єктів` : ''}
              </p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {clip.has && (
              <button
                type="button"
                className={`fc-btn fc-btn-sm border ${clip.cut ? 'border-amber-400/40 bg-amber-500/15 !text-amber-200' : 'border-sky-400/40 bg-sky-500/15 !text-sky-200'}`}
                onClick={pasteIntoCurrent}
                title={clip.cut ? 'Вставити вирізані файли у поточну папку' : 'Вставити скопійовані файли у поточну папку'}
              >
                <Clipboard className="h-3.5 w-3.5" />
                Вставити ({clip.cut ? 'вирізано' : 'копія'})
              </button>
            )}
            <button type="button" className="fc-btn fc-btn-primary fc-btn-sm" onClick={() => fileInputRef.current?.click()} title="Завантажити файл з цього пристрою у поточну папку на ПК">
              <UploadCloud className="h-3.5 w-3.5" />
              Вивантажити файл на ПК
            </button>
            <input
              ref={fileInputRef}
              type="file"
              multiple
              className="hidden"
              onChange={(e) => {
                const files = e.target.files;
                if (files && files.length) void uploadFiles(files);
                e.currentTarget.value = ''; // дозволяє вибрати той самий файл повторно
              }}
            />
            <button type="button" className="fc-btn fc-btn-ghost fc-btn-sm" onClick={() => setCreateKind('folder')}>
              <FolderPlus className="h-3.5 w-3.5" />
              Нова папка
            </button>
            <button type="button" className="fc-btn fc-btn-ghost fc-btn-sm" onClick={() => setCreateKind('file')}>
              <FilePlus className="h-3.5 w-3.5" />
              Новий файл
            </button>
          </div>
        </div>

        {/* Breadcrumbs + up + редагування шляху (ТЗ: поле пути с подсказками) */}
        <div className="relative">
          {pathEditOpen ? (
            <div className="flex items-center gap-1.5 rounded-xl border border-violet-500/50 bg-black/70 px-2 py-1.5 shadow-[0_0_0_3px_rgba(124,58,237,.12)]">
              <FolderOpen className="h-3.5 w-3.5 shrink-0 text-violet-300" />
              <input
                autoFocus
                value={pathEditValue}
                onChange={(e) => { setPathEditValue(e.target.value); setSugIdx(-1); }}
                onKeyDown={(e) => {
                  if (e.key === 'ArrowDown') {
                    e.preventDefault();
                    setSugIdx(i => Math.min(pathSuggestions.length - 1, i + 1));
                  } else if (e.key === 'ArrowUp') {
                    e.preventDefault();
                    setSugIdx(i => Math.max(-1, i - 1));
                  } else if (e.key === 'Enter') {
                    e.preventDefault();
                    if (sugIdx >= 0 && pathSuggestions[sugIdx]) suggestionClick(pathSuggestions[sugIdx]);
                    else commitPathEdit();
                  } else if (e.key === 'Escape') {
                    e.preventDefault(); closePathEdit();
                  }
                }}
                placeholder="C:\Users\...\Desktop або перші літери файлу"
                aria-label="Шлях на ПК"
                className="min-w-0 flex-1 bg-transparent font-mono text-xs text-white outline-none placeholder:text-zinc-600"
              />
              <span className="hidden flex-none rounded-md border border-white/10 bg-white/5 px-1.5 py-0.5 text-[9px] font-bold text-zinc-500 sm:block">
                ↑↓ підказки · Enter
              </span>
              <button
                type="button"
                onClick={commitPathEdit}
                title="Перейти / відкрити"
                className="grid h-6 w-6 shrink-0 cursor-pointer place-items-center rounded-md text-emerald-300 hover:bg-emerald-500/15"
              >
                <Check className="h-3.5 w-3.5" />
              </button>
              <button
                type="button"
                onClick={closePathEdit}
                title="Скасувати"
                className="grid h-6 w-6 shrink-0 cursor-pointer place-items-center rounded-md text-zinc-500 hover:bg-white/10"
              >
                <X className="h-3.5 w-3.5" />
              </button>
              {/* Автопідсказки: буква → папки/файли поточної папки (ТЗ: кращий дизайн) */}
              {pathSuggestions.length > 0 && (
                <div className="absolute left-0 right-0 top-full z-30 mt-1.5 overflow-hidden rounded-xl border border-white/12 bg-[#0d0b1c]/97 shadow-[0_28px_70px_rgba(0,0,0,.75),0_0_40px_-14px_rgba(124,58,237,.5)] backdrop-blur-xl">
                  <div className="flex items-center gap-2 border-b border-white/8 px-3 py-1.5 text-[9px] font-extrabold uppercase tracking-wider text-zinc-500">
                    <Search className="h-3 w-3" />
                    Збіги в поточній папці — {pathSuggestions.length}
                  </div>
                  <div className="max-h-64 overflow-y-auto p-1">
                    {pathSuggestions.map((s, i) => {
                      const active = i === sugIdx;
                      const tail = (pathEditValue.trim().toLowerCase().split(/[\\/]/).pop() || '').trim();
                      const name = s.name;
                      const hitIdx = tail ? name.toLowerCase().indexOf(tail) : -1;
                      return (
                        <button
                          key={s.name + s.path}
                          type="button"
                          onMouseDown={(e) => { e.preventDefault(); suggestionClick(s); }}
                          onMouseEnter={() => setSugIdx(i)}
                          className={`flex w-full cursor-pointer items-center gap-2.5 rounded-lg px-2.5 py-2 text-left transition-colors ${
                            active ? 'bg-violet-500/20 ring-1 ring-inset ring-violet-400/40' : 'hover:bg-white/[.05]'
                          }`}
                        >
                          <span className={`grid h-7 w-7 flex-none place-items-center rounded-lg border ${s.isDirectory ? 'border-violet-500/30 bg-violet-500/10 text-violet-300' : 'border-white/10 bg-white/5 text-zinc-400'}`}>
                            {s.isDirectory ? <FolderOpen className="h-3.5 w-3.5" /> : <FileText className="h-3.5 w-3.5" />}
                          </span>
                          <span className="min-w-0 flex-1">
                            <span className="block truncate text-xs font-bold text-zinc-100">
                              {hitIdx >= 0 ? (
                                <>
                                  {name.slice(0, hitIdx)}
                                  <mark className="rounded bg-violet-500/30 px-0.5 text-violet-200">{name.slice(hitIdx, hitIdx + tail.length)}</mark>
                                  {name.slice(hitIdx + tail.length)}
                                </>
                              ) : name}
                            </span>
                            <span className="block truncate font-mono text-[9.5px] text-zinc-500">{s.isDirectory ? s.path : `${formatBytes(s.size)} · ${s.path}`}</span>
                          </span>
                          <span className={`flex-none rounded-full border px-2 py-0.5 text-[9px] font-bold uppercase tracking-wide ${s.isDirectory ? 'border-violet-400/25 bg-violet-500/10 text-violet-300' : 'border-white/10 bg-white/5 text-zinc-400'}`}>
                            {s.isDirectory ? 'папка · Enter' : 'файл · перегляд'}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="flex items-center gap-1 overflow-x-auto rounded-xl border border-white/10 bg-black/40 px-1.5 py-1.5 text-xs">
              <button
                type="button"
                onClick={() => upPath && navigateTo(upPath)}
                disabled={!upPath || loading}
                aria-label="На рівень вище"
                title="На рівень вище"
                className="grid h-7 w-7 shrink-0 place-items-center rounded-lg text-violet-300 transition-colors hover:bg-violet-500/15 disabled:opacity-30"
              >
                <ArrowUp className="h-3.5 w-3.5" />
              </button>
              <button
                type="button"
                onClick={openPathEdit}
                aria-label="Ввести свій шлях"
                title="Ввести свій шлях (з підсказками)"
                className="grid h-7 w-7 shrink-0 place-items-center rounded-lg text-zinc-400 transition-colors hover:bg-white/10 hover:text-white"
              >
                <Pencil className="h-3 w-3" />
              </button>
              {crumbs.length === 0 ? (
                <span className="px-2 font-mono text-[11px] text-zinc-500">…</span>
              ) : (
                <div
                  className="flex min-w-0 flex-1 items-center gap-0.5 overflow-x-auto text-left"
                  onClick={(e) => {
                    // ТЗ: клік по ПУСТОМУ місцю breadcrumbs — поле вводу шляху.
                    if (e.target === e.currentTarget) openPathEdit();
                  }}
                  title="Клік по папці — перейти; клік по пустому місцю — ввести шлях"
                >
                  {crumbs.map((c, i) => (
                    <React.Fragment key={c.path}>
                      {i > 0 && <ChevronRight className="h-3 w-3 shrink-0 text-zinc-600" />}
                      <button
                        type="button"
                        onClick={() => (i === crumbs.length - 1 ? undefined : navigateTo(c.path))}
                        aria-label={`Перейти до ${c.name}`}
                        className={`whitespace-nowrap rounded-lg px-2 py-1 font-mono text-[11px] transition-colors ${
                          i === crumbs.length - 1
                            ? 'cursor-default bg-violet-500/15 font-bold text-violet-200'
                            : 'cursor-pointer text-zinc-400 hover:bg-white/[.06] hover:text-white'
                        }`}
                        title={i === crumbs.length - 1 ? c.path : `Перейти до ${c.path}`}
                      >
                        {c.name}
                      </button>
                    </React.Fragment>
                  ))}
                  {/* Пусте місце правіше крошек — клік відкриває поле вводу шляху */}
                  <span
                    className="h-6 min-w-6 flex-1 cursor-text"
                    onClick={openPathEdit}
                    aria-hidden="true"
                  />
                </div>
              )}
              {loading && <Loader2 className="ml-auto h-3.5 w-3.5 shrink-0 animate-spin text-violet-300" />}
            </div>
          )}
        </div>

        {/* Search inside the current folder + ТЗ 46: Enter = глибокий скопований пошук */}
        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500" />
          <input
            className="fc-input fc-has-icon pr-24"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                runScopedSearch();
              }
            }}
            placeholder="Фільтр у папці… Enter — пошук по всіх вкладених папках"
            aria-label="Пошук у цій папці або глибокий пошук"
          />
          <div className="absolute right-1.5 top-1/2 flex -translate-y-1/2 items-center gap-1">
            {searchBusy && <Loader2 className="h-3.5 w-3.5 animate-spin text-violet-300" />}
            <button
              type="button"
              onClick={runScopedSearch}
              disabled={searchBusy || !filter.trim() || !currentPath}
              className="rounded-lg border border-violet-400/40 bg-violet-600/25 px-2 py-1 text-[10px] font-black text-violet-100 transition-all hover:bg-violet-600/40 disabled:opacity-40"
              title="Пошук у цій папці та всіх вкладених (диск → весь диск, папка → тільки папка)"
            >
              Знайти тут
            </button>
          </div>
        </div>
      </section>

      {/* Диски + список файлів (зліва — панель швидкого доступу, ТЗ) */}
      <div className="lg:grid lg:grid-cols-[196px_minmax(0,1fr)] lg:items-start lg:gap-4">

        {/* Швидкий доступ (ТЗ): Робочий стіл / Завантаження / Документи / …
            На телефоні — горизонтальна стрічка чипів, на десктопі — панель зліва. */}
        <aside className="lg:sticky lg:top-28">
          <h4 className="hidden px-1 pb-2 text-[10px] font-bold uppercase tracking-wider text-zinc-500 lg:flex lg:items-center lg:gap-1.5">
            <ArrowUpDown className="h-3 w-3" /> Швидкий доступ
          </h4>
          {specials.length === 0 ? (
            <p className="hidden px-1 text-[10px] leading-relaxed text-zinc-600 lg:block">
              Папки з&apos;являться, коли агент поверне шляхи (Робочий стіл, Завантаження…)
            </p>
          ) : (
            <nav className="flex gap-1.5 overflow-x-auto pb-1 lg:flex-col lg:overflow-visible lg:pb-0" aria-label="Швидкий доступ">
              {specials.map((s) => {
                const icon =
                  s.key === 'desktop' ? <Monitor className="h-4 w-4" /> :
                  s.key === 'downloads' ? <Download className="h-4 w-4" /> :
                  s.key === 'documents' ? <FileText className="h-4 w-4" /> :
                  s.key === 'pictures' ? <ImageIcon className="h-4 w-4" /> :
                  s.key === 'music' ? <Music2 className="h-4 w-4" /> :
                  s.key === 'trash' ? <Trash2 className="h-4 w-4" /> :
                  <Video className="h-4 w-4" />;
                const active = trashMode
                  ? s.key === 'trash' // ТЗ-ФІКС «підсвічені дві вкладки»: активний ЛИШЕ один чип — у режимі корзини всі інші неактивні
                  : s.key !== 'trash' && samePath(currentPath, s.path);
                const busy = pendingChip === s.key; // ТЗ: «процес завантаження» видно одразу
                return (
                  <button
                    key={s.key}
                    type="button"
                    onClick={() => (s.key === 'trash' ? openTrash() : navigateTo(s.path))}
                    className={`flex flex-none items-center gap-2.5 rounded-xl border px-3 py-2 text-left text-[11px] font-bold transition-all lg:w-full ${
                      active
                        ? 'border-violet-500/50 bg-violet-500/15 text-white'
                        : 'border-white/8 bg-white/[.03] text-zinc-300 hover:border-violet-400/40 hover:bg-violet-500/10 hover:text-white'
                    }`}
                    title={s.key === 'trash' ? 'Вміст корзини на ПК' : s.path}
                  >
                    <span className={active ? 'text-violet-300' : 'text-zinc-500'}>{icon}</span>
                    <span className="whitespace-nowrap lg:truncate">{s.label}</span>
                    {busy && <Loader2 className="ml-auto h-3.5 w-3.5 flex-none animate-spin text-violet-300" />}
                  </button>
                );
              })}
            </nav>
          )}
        </aside>

        <div className="space-y-4 min-w-0">
      {/* Корзина: банер режиму з кнопкою очищення (ТЗ) */}
      {trashMode && (
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-amber-400/25 bg-gradient-to-r from-amber-500/[.08] to-transparent px-4 py-3">
          <div className="flex items-center gap-2.5">
            <Trash2 className="h-4 w-4 text-amber-300" />
            <div>
              <p className="text-xs font-bold text-white">Корзина ПК</p>
              <p className="text-[11px] text-zinc-500">Файли можна скачати звідси, поки вони не очищені</p>
            </div>
          </div>
          <div className="flex gap-2">
            <button
              type="button"
              className="fc-btn fc-btn-ghost fc-btn-sm"
              onClick={() => { setTrashMode(false); deviceClient.requestDrives(); }}
            >
              <FolderOpen className="h-3.5 w-3.5" />
              До дисків
            </button>
            <button
              type="button"
              className="fc-btn fc-btn-sm border border-rose-400/30 bg-rose-500/15 !text-rose-200 hover:bg-rose-500/25"
              disabled={trashEmptying}
              onClick={() => { setTrashEmptying(true); deviceClient.emptyTrash(); }}
            >
              <Trash2 className={`h-3.5 w-3.5 ${trashEmptying ? 'animate-pulse' : ''}`} />
              Очистити корзину
            </button>
          </div>
        </div>
      )}
      {/* ТЗ 46: банер режиму результатів скопованого пошуку */}
      {searchMode && (
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-violet-400/25 bg-gradient-to-r from-violet-500/[.09] to-transparent px-4 py-3">
          <div className="flex items-center gap-2.5">
            <Search className="h-4 w-4 text-violet-300" />
            <div>
              <p className="text-xs font-bold text-white">
                Пошук «{searchQuery}» — знайдено {searchItems.length}{searchTruncated ? '+' : ''}
              </p>
              <p className="text-[11px] text-zinc-500">Шукали у: {currentPath} та всіх вкладених папках</p>
            </div>
          </div>
          <button
            type="button"
            className="fc-btn fc-btn-ghost fc-btn-sm"
            onClick={cancelSearch}
          >
            <X className="h-3.5 w-3.5" />
            Скасувати пошук
          </button>
        </div>
      )}
      {/* Drive switcher */}
      {drives.length > 0 && (
        <section className="space-y-2">
          <h4 className="px-1 text-[10px] font-bold uppercase tracking-wider text-zinc-500">Диски</h4>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {drives.map((d) => (
              <DriveCard
                key={d.name}
                drive={d}
                active={currentPath.toLowerCase().startsWith(d.name.replace(/\\+$/, '').toLowerCase())}
                onClick={() => navigateTo(d.name)}
              />
            ))}
          </div>
        </section>
      )}

      {/* File list (Drag & Drop зона — ТЗ) */}
      <section
        className={`fc-card-static relative overflow-hidden transition-colors ${dragActive ? 'border-2 border-dashed border-violet-400/60 bg-violet-500/[.06]' : ''}`}
        onDragOver={onDragOver}
        onDragLeave={onDragLeave}
        onDrop={onDrop}
      >
        {dragActive && (
          <div className="pointer-events-none absolute inset-0 z-40 flex flex-col items-center justify-center gap-2 bg-black/55 backdrop-blur-[2px]">
            <UploadCloud className="h-10 w-10 text-violet-300" />
            <p className="text-sm font-extrabold text-white">Відпустіть файли тут</p>
            <p className="text-xs text-zinc-400">Будуть завантажені у поточну папку на ПК — будь-якого розміру</p>
          </div>
        )}
        {(uploadingName || uploadProgress) && (
          <div className="absolute right-3 top-3 z-40 min-w-[180px] rounded-xl border border-violet-500/40 bg-black/85 px-3 py-2 text-xs text-violet-200 shadow-lg">
            <div className="flex items-center gap-2">
              <Loader2 className="h-3.5 w-3.5 flex-none animate-spin" />
              <span className="truncate font-semibold">{uploadingName ?? uploadProgress?.name}</span>
            </div>
            {uploadProgress && (
              <div className="mt-1.5 h-1 w-full overflow-hidden rounded-full bg-white/10">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-violet-500 to-indigo-400 transition-all duration-200"
                  style={{ width: `${uploadProgress.percent}%` }}
                />
              </div>
            )}
          </div>
        )}
        {/* Header row (desktop) — сортування + МАЛЕНЬКИЙ перемикач Галерея/Список (ТЗ) */}
        <div className="hidden items-center gap-3 border-b border-white/5 bg-black/30 px-3 py-2 text-[10px] font-bold uppercase tracking-wider text-zinc-500 md:flex">
          <span className="h-9 w-9 shrink-0" />
          <button type="button" onClick={() => applySortClick('name')} className={`flex flex-1 cursor-pointer items-center gap-1 text-left transition-colors hover:text-violet-200 ${sortKey === 'name' ? '!text-violet-300' : ''}`}>
            Назва {sortKey === 'name' && (sortAsc ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />)}
          </button>
          <button type="button" onClick={() => applySortClick('modified')} className={`flex w-40 shrink-0 cursor-pointer items-center gap-1 transition-colors hover:text-violet-200 ${sortKey === 'modified' ? '!text-violet-300' : ''}`}>
            Змінено {sortKey === 'modified' && (sortAsc ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />)}
          </button>
          <button type="button" onClick={() => applySortClick('size')} className={`flex w-24 shrink-0 cursor-pointer items-center justify-end gap-1 transition-colors hover:text-violet-200 ${sortKey === 'size' ? '!text-violet-300' : ''}`}>
            Розмір {sortKey === 'size' && (sortAsc ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />)}
          </button>
          <button
            type="button"
            onClick={() => setViewMode((v) => (v === 'list' ? 'gallery' : 'list'))}
            title={viewMode === 'list' ? 'Галерея фото/відео з мініатюрами' : 'Список'}
            aria-label={viewMode === 'list' ? 'Увімкнути галерею' : 'Увімкнути список'}
            className={`grid h-7 w-7 shrink-0 cursor-pointer place-items-center rounded-lg border transition-all ${
              viewMode === 'gallery'
                ? 'border-violet-400/50 bg-violet-600/25 text-white'
                : 'border-white/10 bg-white/[.03] text-zinc-400 hover:text-white'
            }`}
          >
            {viewMode === 'list' ? <LayoutGrid className="h-3.5 w-3.5" /> : <List className="h-3.5 w-3.5" />}
          </button>
        </div>

        {/* Mobile sort chips + маленький перемикач Галерея/Список (ТЗ) */}
        <div className="flex items-center gap-1.5 overflow-x-auto border-b border-white/5 bg-black/30 px-3 py-2 text-[10px] font-bold uppercase tracking-wider text-zinc-500 md:hidden">
          <ArrowUpDown className="h-3.5 w-3.5 flex-none" />
          {([
            { id: 'name', label: 'Назва' },
            { id: 'modified', label: 'Змінено' },
            { id: 'size', label: 'Розмір' },
          ] as { id: SortKey; label: string }[]).map((s) => (
            <button
              key={s.id}
              onClick={() => applySortClick(s.id)}
              aria-pressed={sortKey === s.id}
              className={`flex-none rounded-lg border px-2.5 py-1 font-bold normal-case tracking-normal transition-all ${
                sortKey === s.id
                  ? 'border-violet-400/50 bg-violet-600/25 text-white'
                  : 'border-white/10 bg-white/[0.03] text-zinc-400'
              }`}
            >
              {s.label}
              {sortKey === s.id && <span className="ml-1">{sortAsc ? '↑' : '↓'}</span>}
            </button>
          ))}
          <button
            type="button"
            onClick={() => setViewMode((v) => (v === 'list' ? 'gallery' : 'list'))}
            title={viewMode === 'list' ? 'Галерея фото/відео з мініатюрами' : 'Список'}
            aria-label={viewMode === 'list' ? 'Увімкнути галерею' : 'Увімкнути список'}
            className={`ml-auto grid h-7 w-7 flex-none place-items-center rounded-lg border transition-all ${
              viewMode === 'gallery'
                ? 'border-violet-400/50 bg-violet-600/25 text-white'
                : 'border-white/10 bg-white/[.03] text-zinc-400'
            }`}
          >
            {viewMode === 'list' ? <LayoutGrid className="h-3.5 w-3.5" /> : <List className="h-3.5 w-3.5" />}
          </button>
        </div>

        {/* ТЗ: чіткий індикатор «ГРУЗИТЬСЯ» — список затемнюється + пігулка зверху */}
        {loading && items.length > 0 && !searchMode && (
          <div className="pointer-events-none absolute inset-x-0 top-0 z-30 flex justify-center pt-2">
            <span className="flex items-center gap-2 rounded-full border border-violet-500/40 bg-black/85 px-3 py-1.5 text-[11px] font-bold text-violet-200 shadow-lg">
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
              Завантаження…
            </span>
          </div>
        )}

        {loading && items.length === 0 && !searchMode ? (
          <div className="divide-y divide-white/[0.04]">
            {Array.from({ length: 9 }).map((_, i) => (
              <div key={i} className="flex animate-pulse items-center gap-3 px-3 py-3">
                <div className="h-9 w-9 rounded-xl bg-white/5" />
                <div className="h-3 max-w-[40%] flex-1 rounded bg-white/5" />
                <div className="hidden h-3 w-24 rounded bg-white/5 md:block" />
                <div className="h-3 w-14 rounded bg-white/5" />
              </div>
            ))}
          </div>
        ) : searchMode ? (
          searchItems.length === 0 ? (
            <div className="flex flex-col items-center gap-3 px-6 py-14 text-center">
              <span className="grid h-12 w-12 place-items-center rounded-2xl border border-white/10 bg-black/40 text-zinc-500">
                <Search className="h-6 w-6" />
              </span>
              <p className="text-xs font-semibold text-zinc-400">Нічого не знайдено у цій гілці папок</p>
            </div>
          ) : (
            <div className="divide-y divide-white/[0.04]">
              {searchItems.map((item) => (
                <FileRow
                  key={`s|${item.path}`}
                  item={item}
                  modified={formatDateUk(item.lastModified)}
                  sizeLabel={item.isDirectory ? 'Папка' : formatBytes(item.size)}
                  onOpen={handleOpen}
                  onDownload={requestDownload}
                  onMenu={showMenu}
                  onTouchStart={handleTouchStart}
                  onTouchCancel={cancelHold}
                />
              ))}
            </div>
          )
        ) : sorted.length === 0 ? (
          <div className="flex flex-col items-center gap-3 px-6 py-14 text-center">
            <span className="grid h-12 w-12 place-items-center rounded-2xl border border-white/10 bg-black/40 text-zinc-500">
              {items.length === 0 ? <FolderOpen className="h-6 w-6" /> : <Search className="h-6 w-6" />}
            </span>
            <p className="text-xs font-semibold text-zinc-400">
              {items.length === 0 ? 'Ця папка порожня' : `Нічого не знайдено за запитом «${filter.trim()}»`}
            </p>
          </div>
        ) : viewMode === 'gallery' ? (
          /* ТЗ: галерея — БІЛЬШІ плитки (було 3/4/5/6 у ряд, стало 2/3/4/5) */
          <div className={`grid grid-cols-2 gap-2 p-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 ${loading ? 'opacity-60 transition-opacity' : ''}`}>
            {visible.map((item) => {
              const e = extOf(item.name);
              const isVid = VIDEO_EXTS.has(e);
              const isImg = IMAGE_EXTS.has(e);
              const thumb = thumbs[item.path.toLowerCase()];
              return (
                <button
                  key={`g|${item.path}`}
                  type="button"
                  onClick={() => handleOpen(item)}
                  onContextMenu={(ev) => {
                    ev.preventDefault();
                    showMenu(item, ev.clientX, ev.clientY);
                  }}
                  onTouchStart={(ev) => handleTouchStart(item, ev)}
                  onTouchEnd={cancelHold}
                  onTouchMove={cancelHold}
                  className={`group relative aspect-square overflow-hidden rounded-xl border border-white/10 bg-black/40 transition-all hover:border-violet-400/50 ${item.isHidden ? 'opacity-60' : ''}`}
                  title={item.name}
                >
                  {thumb ? (
                    <img src={thumb} alt={item.name} loading="lazy" className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.06]" />
                  ) : (
                    <span className={`grid h-full w-full place-items-center ${isImg || isVid ? 'text-zinc-600' : 'text-zinc-500'}`}>
                      {iconFor(item)}
                    </span>
                  )}
                  {isVid && (
                    <span className="absolute left-1.5 top-1.5 flex items-center gap-1 rounded-md bg-black/70 px-1.5 py-0.5 text-[9px] font-black text-white">
                      <Video className="h-2.5 w-2.5" /> відео
                    </span>
                  )}
                  <span className="absolute inset-x-0 bottom-0 truncate bg-gradient-to-t from-black/90 via-black/50 to-transparent px-1.5 pb-1 pt-5 text-left text-[10px] font-semibold text-white">
                    {item.name}
                  </span>
                </button>
              );
            })}
          </div>
        ) : (
          <div className={`divide-y divide-white/[0.04] transition-opacity ${loading ? 'opacity-60' : ''}`}>
            {visible.map((item) => (
              <FileRow
                key={`${item.path}|${item.name}`}
                item={item}
                modified={formatDateUk(item.lastModified)}
                sizeLabel={item.isDirectory ? 'Папка' : formatBytes(item.size)}
                metaLabel={dirMetaLabel(item)}
                onOpen={handleOpen}
                onDownload={requestDownload}
                onMenu={showMenu}
                onTouchStart={handleTouchStart}
                onTouchCancel={cancelHold}
              />
            ))}
          </div>
        )}
      </section>
        </div>
      </div>

      {/* Context menu */}
      {menu && (
        <div
          ref={menuRef}
          style={{ position: 'fixed', left: menu.x, top: menu.y }}
          className="z-[9500] w-56 rounded-2xl border border-white/10 bg-[#12101f]/95 p-1.5 shadow-[0_24px_60px_rgba(0,0,0,.7)] backdrop-blur-xl"
          role="menu"
        >
          {menu.item.isDirectory ? (
            <button type="button" className="menu-item" onClick={() => menuAction('open')}>
              <FolderOpen className="h-4 w-4 text-violet-300" />
              Відкрити
            </button>
          ) : (
            <button type="button" className="menu-item" onClick={() => menuAction('open')}>
              <Search className="h-4 w-4 text-violet-300" />
              Попередній перегляд
            </button>
          )}
          <button type="button" className="menu-item" onClick={() => menuAction('openPc')}>
            <ExternalLink className="h-4 w-4 text-zinc-400" />
            Відкрити на ПК
          </button>
          <button type="button" className="menu-item" onClick={() => menuAction('rename')}>
            <Pencil className="h-4 w-4 text-zinc-400" />
            Перейменувати
          </button>
          <button type="button" className="menu-item" onClick={() => menuAction('download')}>
            <Download className="h-4 w-4 text-zinc-400" />
            Завантажити
          </button>

          {/* ТЗ 46: архіви + копіювання у контекст-меню */}
          <button type="button" className="menu-item" onClick={() => menuAction('zip')}>
            <Archive className="h-4 w-4 text-amber-300" />
            Стиснути в ZIP
          </button>
          {!menu.item.isDirectory && ARCHIVE_EXTS.has(extOf(menu.item.name)) && (
            <button type="button" className="menu-item" onClick={() => menuAction('extract')}>
              <PackageOpen className="h-4 w-4 text-emerald-300" />
              Розпакувати тут
            </button>
          )}
          <button type="button" className="menu-item" onClick={() => menuAction('copy')}>
            <Copy className="h-4 w-4 text-zinc-400" />
            Копіювати
          </button>
          <button type="button" className="menu-item" onClick={() => menuAction('cut')}>
            <Scissors className="h-4 w-4 text-zinc-400" />
            Вирізати
          </button>
          <button type="button" className="menu-item" onClick={() => menuAction('share')}>
            <Share2 className="h-4 w-4 text-indigo-300" />
            Поділитися (посилання)
          </button>
          <button type="button" className="menu-item text-rose-300 hover:text-rose-200" onClick={() => menuAction('delete')}>
            <Trash2 className="h-4 w-4" />
            Видалити
          </button>
        </div>
      )}

      {/* Delete confirmation */}
      <FcConfirmModal
        open={!!deleteTarget}
        title={deleteTarget?.isDirectory ? 'Видалити папку?' : 'Видалити?'}
        message={deleteTarget ? `Видалити «${deleteTarget.name}»? Дію не можна скасувати.` : ''}
        confirmLabel="Видалити"
        onConfirm={confirmDelete}
        onCancel={() => setDeleteTarget(null)}
      />

      {/* «Поділитися» (ТЗ): сеансове посилання для друга */}
      {(shareLink || shareWaiting) && (
        <FcModal
          title={shareWaiting ? 'Створюю посилання…' : 'Посилання готове'}
          onClose={() => { setShareLink(null); setShareWaiting(false); }}
          width={30}
        >
          {shareWaiting ? (
            <div className="flex items-center gap-3 py-2 text-sm text-zinc-300">
              <Loader2 className="h-4 w-4 animate-spin text-violet-300" />
              Генерую спеціальне посилання на ПК…
            </div>
          ) : shareLink && (
            <div className="space-y-4">
              <div className="flex items-center gap-3 rounded-xl border border-white/10 bg-black/40 p-3">
                <span className="grid h-10 w-10 flex-none place-items-center rounded-xl border border-indigo-400/30 bg-indigo-500/15 text-indigo-300">
                  {shareLink.isDir ? <Folder className="h-5 w-5" /> : <File className="h-5 w-5" />}
                </span>
                <div className="min-w-0">
                  <p className="truncate text-sm font-bold text-white">{shareLink.name}</p>
                  <p className="text-[11px] text-zinc-500">{shareLink.isDir ? 'Друг отримає ZIP-архів папки' : 'Друг зможе скачати цей файл'}</p>
                </div>
              </div>
              <div className="rounded-xl border border-white/10 bg-black/40 p-3">
                <p className="break-all font-mono text-[11px] leading-relaxed text-indigo-200">{shareLink.url}</p>
              </div>
              <p className="text-[11px] leading-relaxed text-zinc-500">
                Посилання працює, поки на ПК запущена програма FluxControl, і перестає діяти після її перезапуску або видалення файлу.
              </p>
              <div className="flex gap-2">
                <button
                  type="button"
                  className="fc-btn fc-btn-primary flex-1"
                  onClick={async () => {
                    try {
                      await navigator.clipboard.writeText(shareLink.url);
                      toast.success('Посилання скопійовано — можеш відправити другу');
                    } catch {
                      toast.warn('Не вдалося скопіювати — виділи текст вручну');
                    }
                  }}
                >
                  <Check className="h-4 w-4" />
                  <span>Копіювати</span>
                </button>
                <button type="button" className="fc-btn fc-btn-ghost" onClick={() => { setShareLink(null); }}>
                  <X className="h-4 w-4" />
                </button>
              </div>
            </div>
          )}
        </FcModal>
      )}

      {/* Rename */}
      <FcPromptModal
        open={!!renameTarget}
        title="Перейменувати"
        label="Нова назва"
        initialValue={renameTarget?.name || ''}
        placeholder="Введіть нову назву"
        confirmLabel="ОК"
        onSubmit={submitRename}
        onCancel={() => setRenameTarget(null)}
      />

      {/* Create file / folder */}
      <FcPromptModal
        open={!!createKind}
        title={createKind === 'file' ? 'Створити файл' : 'Нова папка'}
        label={createKind === 'file' ? 'Назва файлу (з розширенням)' : 'Назва папки'}
        initialValue=""
        placeholder={createKind === 'file' ? 'наприклад notes.txt' : 'наприклад Звіти'}
        confirmLabel="Створити"
        onSubmit={submitCreate}
        onCancel={() => setCreateKind(null)}
      />

      {/* Unsupported / too-big file */}
      {unsupported && (
        <FcModal title="Попередній перегляд недоступний" onClose={() => setUnsupported(null)} width={26}>
          <div className="mx-auto mb-4 grid h-14 w-14 place-items-center rounded-2xl border border-white/10 bg-black/40 text-zinc-400">
            <FileQuestion className="h-7 w-7" />
          </div>
          <p className="break-words text-center text-xs leading-relaxed text-zinc-300">
            {unsupported.reason === 'big'
              ? `«${unsupported.item.name}» завеликий для перегляду (${formatBytes(unsupported.item.size)}).`
              : `Цей тип файлу не можна переглянути${extOf(unsupported.item.name) ? ` (.${extOf(unsupported.item.name)})` : ''}.`}
          </p>
          <p className="mt-2 text-center text-[11px] text-zinc-500">
            Завантажте файл або відкрийте його безпосередньо на ПК.
          </p>
          <div className="mt-6 flex flex-wrap justify-end gap-2">
            <button type="button" className="fc-btn fc-btn-ghost" onClick={() => setUnsupported(null)}>
              Скасувати
            </button>
            <button
              type="button"
              className="fc-btn fc-btn-ghost"
              onClick={() => {
                openOnPc(unsupported.item);
                setUnsupported(null);
              }}
            >
              <ExternalLink className="h-3.5 w-3.5" />
              Відкрити на ПК
            </button>
            <button
              type="button"
              className="fc-btn fc-btn-primary"
              onClick={() => {
                requestDownload(unsupported.item);
                setUnsupported(null);
              }}
            >
              <Download className="h-3.5 w-3.5" />
              Завантажити
            </button>
          </div>
        </FcModal>
      )}

      {/* Media preview */}
      {preview && (
        <FcModal
          title={preview.item.name}
          subtitle={`${preview.kind === 'image' ? 'Зображення' : preview.kind === 'video' ? 'Відео' : 'Аудіо'} • ${formatBytes(preview.item.size)}`}
          width={40}
          onClose={closePreview}
        >
          {preview.loading && (
            <div className="flex h-52 flex-col items-center justify-center gap-3 text-violet-300">
              <Loader2 className="h-7 w-7 animate-spin" />
              <span className="text-xs font-semibold">Завантаження з ПК…</span>
            </div>
          )}
          {!preview.loading && preview.error && (
            <div className="flex h-32 flex-col items-center justify-center gap-2 text-center">
              <FileQuestion className="h-8 w-8 text-rose-400" />
              <p className="text-xs text-rose-300">{preview.error}</p>
            </div>
          )}
          {!preview.loading && !preview.error && preview.url && preview.kind === 'image' && (
            <img src={preview.url} alt={preview.item.name} className="mx-auto max-h-[56vh] rounded-xl border border-white/10 bg-black/60 object-contain" />
          )}
          {!preview.loading && !preview.error && preview.url && preview.kind === 'video' && (
            <video src={preview.url} controls autoPlay playsInline className="mx-auto max-h-[56vh] w-full rounded-xl border border-white/10 bg-black" />
          )}
          {!preview.loading && !preview.error && preview.url && preview.kind === 'audio' && (
            <div className="flex flex-col items-center gap-4 py-8">
              <span className="grid h-16 w-16 place-items-center rounded-2xl border border-pink-400/30 bg-pink-500/10 text-pink-300">
                <Music2 className="h-8 w-8" />
              </span>
              <audio src={preview.url} controls autoPlay className="w-full" />
            </div>
          )}
          <div className="mt-5 flex justify-end gap-2">
            <button type="button" className="fc-btn fc-btn-ghost" onClick={closePreview}>
              Закрити
            </button>
            {preview.blob && (
              <button
                type="button"
                className="fc-btn fc-btn-primary"
                onClick={() => preview.blob && saveBlobAs(preview.item.name, preview.blob)}
              >
                <Download className="h-3.5 w-3.5" />
                Завантажити
              </button>
            )}
          </div>
        </FcModal>
      )}

      {/* Text editor */}
      {editor && (
        <FcModal title={editor.item.name} subtitle={editor.path} width={46} onClose={requestEditorClose}>
          {editor.loading ? (
            <div className="flex h-52 flex-col items-center justify-center gap-3 text-violet-300">
              <Loader2 className="h-7 w-7 animate-spin" />
              <span className="text-xs font-semibold">Читання файлу…</span>
            </div>
          ) : editor.loadError ? (
            <div className="flex h-32 flex-col items-center justify-center gap-2 text-center">
              <FileQuestion className="h-8 w-8 text-rose-400" />
              <p className="text-xs text-rose-300">{editor.loadError}</p>
            </div>
          ) : (
            <>
              <div className="mb-2 flex items-center justify-between gap-2">
                <span className="text-[10px] text-zinc-500">
                  {formatBytes(editor.item.size)} • редагування тексту
                </span>
                {editor.content !== editor.original && (
                  <span className="fc-badge fc-badge-warn">Є незбережені зміни</span>
                )}
              </div>
              <textarea
                value={editor.content}
                onChange={(e) =>
                  setEditor((prev) =>
                    prev ? { ...prev, content: e.target.value, closeArmed: false } : prev
                  )
                }
                spellCheck={false}
                className="fc-input min-h-[46vh] resize-y font-mono text-xs leading-5"
                aria-label={`Редагування ${editor.item.name}`}
              />
              {editor.closeArmed && (
                <p className="mt-2 text-[11px] font-semibold text-amber-300">
                  Зміни не збережено. Натисніть ще раз, щоб закрити без збереження.
                </p>
              )}
            </>
          )}
          <div className="mt-4 flex flex-wrap justify-end gap-2">
            <button type="button" className={`fc-btn ${editor.content !== editor.original && !editor.closeArmed && !editor.loading ? 'fc-btn-warn' : 'fc-btn-ghost'}`} onClick={requestEditorClose}>
              {editor.closeArmed ? 'Закрити без збереження' : 'Закрити'}
            </button>
            <button
              type="button"
              className="fc-btn fc-btn-primary"
              disabled={editor.loading || editor.saving || editor.loadError != null}
              onClick={saveEditor}
            >
              {editor.saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : null}
              Зберегти
            </button>
          </div>
        </FcModal>
      )}
    </div>
  );
};
