import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  HardDrive,
  Trash2,
  Lock,
  Unlock,
  AlertTriangle,
  ScanLine,
  Sparkles,
  X,
  Check,
  Loader2,
  MessageSquare,
  Volume2,
  TerminalSquare,
  RotateCw,
  Info,
  ShieldCheck,
  TriangleAlert,
} from 'lucide-react';
import { Device } from '../../types';
import { deviceClient } from '../../services/deviceClient';
import { toast } from '../../utils/toast';
import { relayUrl } from '../../services/relayBase';

/** Розмір у людському вигляді: 12.4 ГБ / 340 МБ / 12 КБ. */
const formatBytes = (bytes?: number): string => {
  if (!bytes || bytes <= 0) return '0 Б';
  if (bytes >= 1024 ** 3) return `${(bytes / 1024 ** 3).toFixed(bytes >= 10 * 1024 ** 3 ? 1 : 2)} ГБ`;
  if (bytes >= 1024 ** 2) return `${(bytes / 1024 ** 2).toFixed(bytes >= 10 * 1024 ** 2 ? 0 : 1)} МБ`;
  if (bytes >= 1024) return `${Math.round(bytes / 1024)} КБ`;
  return `${bytes} Б`;
};

/* ================================================================
   Очистка диска: мінімалістична рамка + «Умна очистка» через ШІ
   (ТЗ: ШІ вивчає структуру ПК, шукає що можна видалити і ПИТАЄ
   користувача «видалити цю програму/папку? Вона важить X»).
   ================================================================ */
interface CleanupCategory {
  key: string;
  title: string;
  description: string;
  path: string;
  sizeBytes: number;
  fileCount: number;
  defaultSelected: boolean;
  fromAi?: boolean;
}

interface AiSuggestion {
  name: string;
  path: string;
  sizeBytes: number;
  reason: string;
  question: string;
}

const sameCleanPath = (a?: string, b?: string): boolean =>
  Boolean(a && b) && String(a).replace(/[\\/]+$/, '').toLowerCase() === String(b).replace(/[\\/]+$/, '').toLowerCase();

const DiskCleanupCard: React.FC = React.memo(() => {
  const [categories, setCategories] = useState<CleanupCategory[] | null>(null);
  const [scanning, setScanning] = useState(false);
  const [cleaning, setCleaning] = useState(false);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [lastFreed, setLastFreed] = useState<number | null>(null);

  // «Умна очистка» (ТЗ): огляд ПК → ШІ → питання → застосування.
  type AiStage = null | 'gathering' | 'thinking' | 'asking';
  const [aiStage, setAiStage] = useState<AiStage>(null);
  const [aiSuggestions, setAiSuggestions] = useState<AiSuggestion[]>([]);
  const [aiAskedCount, setAiAskedCount] = useState(0);
  const aiSugRef = useRef<AiSuggestion[]>([]);
  aiSugRef.current = aiSuggestions;
  const aiAcceptedRef = useRef<AiSuggestion[]>([]);

  useEffect(() => {
    let alive = true;

    const offReport = deviceClient.on('clean_disk_report', (raw: any) => {
      if (!alive) return;
      const d = raw?.data ?? raw;
      setScanning(false);
      if (d?.error) {
        toast.error(`Скан не вдався: ${d.error}`, { title: 'Очистка диска' });
        return;
      }
      const cats: CleanupCategory[] = Array.isArray(d?.categories) ? d.categories : [];
      setCategories(prev => {
        const aiKept = (prev ?? []).filter(c => c.fromAi);
        const merged = [...cats, ...aiKept];
        setSelected(new Set(merged.filter(c => c.defaultSelected && c.sizeBytes > 0).map(c => c.key)));
        return merged.sort((a, b) => b.sizeBytes - a.sizeBytes);
      });
    });

    const offResult = deviceClient.on('clean_disk_result', (raw: any) => {
      if (!alive) return;
      const d = raw?.data ?? raw;
      setCleaning(false);
      if (d?.error && !d?.results) {
        toast.error(`Очищення не вдалося: ${d.error}`, { title: 'Очистка диска' });
        return;
      }
      const freed = Number(d?.freedBytes || 0);
      setLastFreed(freed);
      const errs = (d?.results || []).filter((r: any) => r?.error);
      if (errs.length) toast.warn(`Звільнено ${formatBytes(freed)}. Пропущено: ${errs.length}`, { title: 'Очистка диска' });
      else toast.success(`Звільнено ${formatBytes(freed)}!`, { title: 'Очистка диска' });
      setScanning(true);
      deviceClient.send('clean_disk_scan', {});
    });

    // 1) Огриж ПК від агента → формуємо запит до ШІ.
    const offOverview = deviceClient.on('ai_cleanup_overview', async (raw: any) => {
      if (!alive) return;
      const d = raw?.data ?? raw;
      if (d?.error) {
        setAiStage(null);
        toast.error(`Огляд ПК не вдався: ${d.error}`, { title: 'Умна очистка' });
        return;
      }
      setAiStage('thinking');
      try {
        const system = 'Ти — асистент очищення диска Windows. Тобі дають огляд ПК: диски, великі папки профілю, важкі програми. ' +
          'ПРОАНАЛІЗУЙ і знайди до 6 кандидатів на видалення: кеші, тимчасові дані, старі інсталятори, скачані архіви, залишки видалених програм. ' +
          'НЕ пропонуй системні папки (Windows, Program Files у цілому), документи, фото, робочі дані. ' +
          'Відповідай ЛИШЕ валідним JSON без markdown: {"items":[{"name":"коротка назва","path":"шлях з огляду","sizeBytes":123,"reason":"чому можна видалити","question":"питання для власника (укр.)"}]}. ' +
          'path бери ТІЛЬКИ зі списку огляду. Якщо кандидатів немає — {"items":[]}.';
        const user = JSON.stringify(d);
        const res = await fetch(relayUrl('/api/ai/chat'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ messages: [{ role: 'user', text: user }], system }),
          signal: AbortSignal.timeout(90000)
        });
        const data = await res.json().catch(() => null);
        if (!alive) return;
        if (!data?.success || typeof data.text !== 'string') {
          throw new Error(String(data?.error || `HTTP ${res.status}`));
        }
        const text = data.text;
        const m = text.match(/\{[\s\S]*\}/);
        const parsed = m ? JSON.parse(m[0]) : null;
        const items: AiSuggestion[] = Array.isArray(parsed?.items) ? parsed.items : [];
        const valid = items
          .filter(i => i && typeof i.path === 'string' && i.path.length > 3)
          .slice(0, 6)
          .map(i => ({ ...i, sizeBytes: Number(i.sizeBytes) || 0 }));
        setAiSuggestions(valid);
        setAiAskedCount(0);
        aiAcceptedRef.current = [];
        if (valid.length === 0) {
          setAiStage(null);
          toast.info('ШІ не знайшов очевидного сміття — диск уже охайний', { title: 'Умна очистка' });
        } else {
          setAiStage('asking');
        }
      } catch (e: any) {
        if (!alive) return;
        setAiStage(null);
        toast.error(`ШІ-аналіз не вдався: ${String(e?.message || e)}`, { title: 'Умна очистка' });
      }
    });

    // 3) Затверджені пункти → у список очищення.
    const offApply = deviceClient.on('ai_cleanup_apply_result', (raw: any) => {
      if (!alive) return;
      const d = raw?.data ?? raw;
      const added: CleanupCategory[] = Array.isArray(d?.categories) ? d.categories : [];
      if (added.length > 0) {
        setCategories(prev => {
          const base = (prev ?? []).filter(c => !added.some(a => a.key === c.key || sameCleanPath(a.path, c.path)));
          const merged = [...base, ...added];
          setSelected(prevSel => new Set([...prevSel, ...added.filter(a => a.sizeBytes > 0).map(a => a.key)]));
          return merged.sort((a, b) => b.sizeBytes - a.sizeBytes);
        });
        toast.success(`ШІ додав ${added.length} пункт(ів) у список очищення`, { title: 'Умна очистка' });
      } else {
        toast.info('ШІ: нічого нового додати (усе вже в списку)', { title: 'Умна очистка' });
      }
      setAiStage(null);
      setAiSuggestions([]);
    });

    setScanning(true);
    deviceClient.send('clean_disk_scan', {});
    return () => {
      alive = false;
      offReport(); offResult(); offOverview(); offApply();
    };
  }, []);

  const total = (categories || []).reduce((a, c) => a + Math.max(0, c.sizeBytes), 0);
  const selectedTotal = (categories || []).filter(c => selected.has(c.key)).reduce((a, c) => a + Math.max(0, c.sizeBytes), 0);

  const toggle = (key: string) => {
    setSelected(prev => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key); else next.add(key);
      return next;
    });
  };

  const startClean = () => {
    if (cleaning || selected.size === 0) return;
    setCleaning(true);
    deviceClient.send('clean_disk_run', { keys: Array.from(selected) });
  };

  /** Крок питання: Так → зберігаємо; Ні → пропускаємо. Після останнього — apply. */
  const answerAi = (accept: boolean) => {
    const list = aiSugRef.current;
    const idx = aiAskedCount;
    if (accept && list[idx]) aiAcceptedRef.current.push(list[idx]);
    const nextIdx = idx + 1;
    if (nextIdx < list.length) {
      setAiAskedCount(nextIdx);
      return;
    }
    setAiStage('thinking');
    deviceClient.send('ai_cleanup_apply', {
      items: aiAcceptedRef.current.map(a => ({ title: a.name, path: a.path }))
    });
  };

  /** Прибрати AI-елемент зі списку (ТЗ: хрестик — і він більше не повернеться). */
  const removeAiItem = (c: CleanupCategory) => {
    setCategories(prev => (prev ?? []).filter(x => x.key !== c.key));
    setSelected(prev => {
      const next = new Set(prev);
      next.delete(c.key);
      return next;
    });
    deviceClient.removeCleanupKeys([c.key]);
    toast.info(`«${c.title}» прибрано зі списку`, { title: 'Умна очистка' });
  };

  const currentSug: AiSuggestion | null = aiStage === 'asking' && aiSuggestions[aiAskedCount] ? aiSuggestions[aiAskedCount] : null;

  return (
    <div className="fc-card rounded-2xl p-5">
      <div className="flex flex-wrap items-center justify-between gap-2.5">
        <div className="fc-section-head">
          <div className="fc-section-icon"><HardDrive className="h-5 w-5" /></div>
          <div className="min-w-0">
            <h3>Очистка диска</h3>
            <p>
              Корзина · temp · кеші програм
              {categories && total > 0 ? ` · знайдено ${formatBytes(total)}` : ''}
            </p>
          </div>
        </div>
        <div className="ml-auto flex items-center gap-2">
          <button
            onClick={() => { setAiStage('gathering'); setAiSuggestions([]); deviceClient.send('ai_cleanup_gather', {}); }}
            disabled={aiStage !== null}
            title="ШІ вивчить структуру ПК, знайде зайве і запитає, що видаляти"
            className="flex cursor-pointer items-center gap-1.5 rounded-full border border-violet-400/30 bg-violet-500/10 px-3 py-1.5 text-[11px] font-bold text-violet-300 transition-all hover:bg-violet-500/20 disabled:opacity-40"
          >
            {aiStage ? <Loader2 className="h-3 w-3 animate-spin" /> : <Sparkles className="h-3 w-3" />}
            Умна очистка (ШІ)
          </button>
          <button
            onClick={() => { setScanning(true); setLastFreed(null); deviceClient.send('clean_disk_scan', {}); }}
            disabled={scanning}
            className="flex cursor-pointer items-center gap-1.5 rounded-full border border-white/10 px-3 py-1.5 text-[11px] font-semibold text-zinc-400 transition-colors hover:border-white/20 hover:text-white disabled:opacity-40"
          >
            {scanning ? <Loader2 className="h-3 w-3 animate-spin" /> : <ScanLine className="h-3 w-3" />}
            Сканувати
          </button>
        </div>
      </div>

      {aiStage === 'gathering' && (
        <div className="mt-3 flex items-center gap-2 rounded-xl border border-violet-400/25 bg-violet-500/[.08] px-3 py-2.5 text-[11px] text-violet-200">
          <Sparkles className="h-3.5 w-3.5 animate-pulse flex-none" />
          Вивчаю структуру ПК: диски, великі папки, програми…
        </div>
      )}
      {aiStage === 'thinking' && (
        <div className="mt-3 flex items-center gap-2 rounded-xl border border-violet-400/25 bg-violet-500/[.08] px-3 py-2.5 text-[11px] text-violet-200">
          <Sparkles className="h-3.5 w-3.5 animate-pulse flex-none" />
          ШІ аналізує, що можна безболісно видалити…
        </div>
      )}

      {/* Питання ШІ (ТЗ: «питає у користувача: можна видалити цю програму? Вона важить X») */}
      {currentSug && (
        <div className="mt-3 rounded-xl border border-violet-400/30 bg-violet-500/[.07] p-3.5">
          <div className="flex items-center gap-1.5 text-[10px] font-black uppercase tracking-wider text-violet-300">
            <Sparkles className="h-3 w-3" />
            Питання ШІ {aiAskedCount + 1} з {aiSuggestions.length}
          </div>
          <p className="mt-2 text-xs font-bold leading-snug text-white">{currentSug.question || `Видалити «${currentSug.name}»?`}</p>
          <p className="mt-1 break-all font-mono text-[10px] text-zinc-500">{currentSug.path}</p>
          <div className="mt-2 flex flex-wrap items-center gap-2 text-[11px]">
            {currentSug.sizeBytes > 0 && (
              <span className="rounded-full border border-white/10 bg-black/40 px-2 py-0.5 font-bold text-zinc-300">
                важить {formatBytes(currentSug.sizeBytes)}
              </span>
            )}
            {currentSug.reason && <span className="text-zinc-500">{currentSug.reason}</span>}
          </div>
          <div className="mt-3 flex gap-2">
            <button
              onClick={() => answerAi(true)}
              className="flex flex-1 cursor-pointer items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 py-2 text-xs font-bold text-white transition-all hover:from-emerald-500 hover:to-teal-500 active:scale-[0.98]"
            >
              <Check className="h-3.5 w-3.5" /> Так, у список
            </button>
            <button
              onClick={() => answerAi(false)}
              className="flex flex-1 cursor-pointer items-center justify-center gap-1.5 rounded-xl border border-white/10 bg-white/[.03] py-2 text-xs font-bold text-zinc-300 transition-colors hover:bg-white/[.07]"
            >
              <X className="h-3.5 w-3.5" /> Ні, лишити
            </button>
          </div>
        </div>
      )}

      {lastFreed !== null && (
        <p className="mt-3 rounded-xl border border-emerald-500/25 bg-emerald-500/10 px-3 py-2 text-xs font-semibold text-emerald-300">
          Останнє очищення звільнило {formatBytes(lastFreed)} місця
        </p>
      )}

      {scanning && categories === null ? (
        <p className="mt-3 flex items-center gap-2 text-xs text-zinc-500">
          <Loader2 className="h-3.5 w-3.5 animate-spin" /> Рахую розміри категорій на ПК (до ~30 с)…
        </p>
      ) : categories && categories.length > 0 ? (
        <div className="mt-3 space-y-1.5">
          {categories.map((c) => {
            const empty = c.sizeBytes <= 0;
            const checked = selected.has(c.key);
            return (
              <div
                key={c.key}
                className={`flex items-center gap-3 rounded-xl border px-3 py-2 transition-all ${
                  empty ? 'border-white/5 bg-white/[.01] opacity-45'
                    : checked ? 'border-emerald-500/40 bg-emerald-500/[.07]'
                    : 'border-white/5 bg-white/[.02]'
                }`}
              >
                {!empty && (
                  <button
                    type="button"
                    onClick={() => toggle(c.key)}
                    aria-label={checked ? 'Прибрати з вибору' : 'Вибрати для очищення'}
                    className={`grid h-5 w-5 flex-none cursor-pointer place-items-center rounded-md border ${checked ? 'border-emerald-400/60 bg-emerald-500/25 text-emerald-300' : 'border-white/15 bg-black/40 text-transparent hover:border-white/30'}`}
                  >
                    <Check className="h-3 w-3" />
                  </button>
                )}
                <button type="button" onClick={() => !empty && toggle(c.key)} disabled={empty} className="min-w-0 flex-1 text-left">
                  <span className="flex items-center gap-1.5">
                    {c.fromAi && (
                      <span className="flex flex-none items-center gap-0.5 rounded-full border border-violet-400/30 bg-violet-500/15 px-1.5 py-0.5 text-[8px] font-black uppercase tracking-wide text-violet-300">
                        <Sparkles className="h-2 w-2" /> ШІ
                      </span>
                    )}
                    <span className="truncate text-xs font-bold text-zinc-100">{c.title}</span>
                  </span>
                  <span className="block truncate text-[10.5px] text-zinc-500">{c.description}</span>
                </button>
                {c.fromAi && (
                  <button
                    type="button"
                    onClick={() => removeAiItem(c)}
                    title="Прибрати зі списку (запам'ятається)"
                    aria-label={`Прибрати ${c.title} зі списку`}
                    className="grid h-6 w-6 flex-none cursor-pointer place-items-center rounded-md text-zinc-600 transition-colors hover:bg-rose-500/15 hover:text-rose-300"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                )}
                <span className={`flex-none font-mono text-xs font-bold ${empty ? 'text-zinc-600' : 'text-zinc-300'}`}>
                  {formatBytes(c.sizeBytes)}
                </span>
              </div>
            );
          })}

          <button
            onClick={startClean}
            disabled={cleaning || selected.size === 0}
            className="flex w-full cursor-pointer items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 py-2.5 text-xs font-bold text-white shadow-lg shadow-emerald-600/25 transition-all hover:from-emerald-500 hover:to-teal-500 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-40"
          >
            {cleaning ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Trash2 className="h-3.5 w-3.5" />}
            <span>Очистити вибране{selectedTotal > 0 ? ` (≈ ${formatBytes(selectedTotal)})` : ''}</span>
          </button>
        </div>
      ) : categories && categories.length === 0 ? (
        <p className="mt-3 text-xs text-zinc-500">Все вже чисто — нічого зайвого не знайдено.</p>
      ) : null}
    </div>
  );
});
DiskCleanupCard.displayName = 'DiskCleanupCard';

/* ================================================================
   Функції для тролінгу (ТЗ): вікна з текстом, озвучка, консолі,
   переворот екрана. Окрема рамка у «Додатковому».
   ================================================================ */
const TrollCard: React.FC = React.memo(() => {
  const [msgText, setMsgText] = useState('Привіт від FluxControl 😄');
  const [msgCount, setMsgCount] = useState(10);
  const [speakText, setSpeakText] = useState('Ха-ха, твій компʼютер керують здалеку');
  const [speakCount, setSpeakCount] = useState(2);
  const [consoleCount, setConsoleCount] = useState(10);
  const [consoleAutoClose, setConsoleAutoClose] = useState(true);
  const [rotating, setRotating] = useState(false);

  useEffect(() => {
    const off = deviceClient.on('troll_result', (raw: any) => {
      const d = raw?.data ?? raw;
      if (d?.success) toast.success('Команду виконано на ПК', { title: 'Функції для тролінгу' });
      else toast.error(d?.error || 'Не вдалося виконати', { title: 'Функції для тролінгу' });
    });
    return off;
  }, []);

  return (
    <div className="fc-card rounded-2xl p-5">
      <div className="fc-section-head mb-4">
        <div className="fc-section-icon"><TerminalSquare className="h-5 w-5" /></div>
        <div>
          <h3>Функції для тролінгу</h3>
          <p>Жарти з тим, хто сидить за ПК — все робиться миттєво</p>
        </div>
      </div>

      {/* ТЗ B6: чиста сітка 2×2 — кожна дія у власній підпанелі з іконкою і описом */}
      <div className="grid gap-3 lg:grid-cols-2">
        {/* Вспливчі вікна (ТЗ: до 100, кожне у власній позиції) */}
        <div className="flex flex-col rounded-2xl border border-white/10 bg-black/30 p-3.5 transition-colors hover:border-indigo-400/30">
          <div className="flex items-center gap-2.5">
            <div className="grid h-8 w-8 flex-none place-items-center rounded-lg border border-indigo-400/25 bg-indigo-500/15 text-indigo-300">
              <MessageSquare className="h-4 w-4" />
            </div>
            <div className="min-w-0">
              <p className="text-xs font-bold text-white">Спливаючі вікна</p>
              <p className="text-[10px] leading-snug text-zinc-500">До 100 вікон з вашим текстом — у різних місцях екрана</p>
            </div>
          </div>
          <input
            value={msgText}
            onChange={(e) => setMsgText(e.target.value)}
            placeholder="Текст у вікнах"
            maxLength={400}
            className="mt-2.5 w-full rounded-lg border border-white/10 bg-black/40 px-2.5 py-1.5 text-[11px] text-white placeholder-zinc-600 outline-none focus:border-indigo-500/50"
          />
          <div className="mt-auto flex items-center gap-2 pt-2">
            <input
              type="number"
              min={1}
              max={100}
              value={msgCount}
              onChange={(e) => setMsgCount(Math.max(1, Math.min(100, Number(e.target.value) || 1)))}
              className="w-16 rounded-lg border border-white/10 bg-black/40 px-2 py-1.5 text-[11px] text-white outline-none focus:border-indigo-500/50"
              aria-label="Кількість вікон"
            />
            <span className="text-[10px] text-zinc-500">шт. (до 100, у різних місцях)</span>
            <button
              onClick={() => deviceClient.trollMessageboxes(msgText, msgCount)}
              className="fc-btn fc-btn-primary fc-btn-sm ml-auto"
            >
              Відкрити
            </button>
          </div>
        </div>

        {/* Озвучити (фікс: працює, скрипт через EncodedCommand) */}
        <div className="flex flex-col rounded-2xl border border-white/10 bg-black/30 p-3.5 transition-colors hover:border-violet-400/30">
          <div className="flex items-center gap-2.5">
            <div className="grid h-8 w-8 flex-none place-items-center rounded-lg border border-violet-400/25 bg-violet-500/15 text-violet-300">
              <Volume2 className="h-4 w-4" />
            </div>
            <div className="min-w-0">
              <p className="text-xs font-bold text-white">Озвучити текст (на ПК)</p>
              <p className="text-[10px] leading-snug text-zinc-500">Синтез мовлення Windows прочитає текст уголос</p>
            </div>
          </div>
          <input
            value={speakText}
            onChange={(e) => setSpeakText(e.target.value)}
            placeholder="Що сказати голосом ПК"
            maxLength={400}
            className="mt-2.5 w-full rounded-lg border border-white/10 bg-black/40 px-2.5 py-1.5 text-[11px] text-white placeholder-zinc-600 outline-none focus:border-violet-500/50"
          />
          <div className="mt-auto flex items-center gap-2 pt-2">
            <input
              type="number"
              min={1}
              max={50}
              value={speakCount}
              onChange={(e) => setSpeakCount(Math.max(1, Math.min(50, Number(e.target.value) || 1)))}
              className="w-16 rounded-lg border border-white/10 bg-black/40 px-2 py-1.5 text-[11px] text-white outline-none focus:border-violet-500/50"
              aria-label="Скільки разів озвучити"
            />
            <span className="text-[10px] text-zinc-500">раз(ів)</span>
            <button
              onClick={() => deviceClient.trollSpeak(speakText, speakCount)}
              className="fc-btn fc-btn-primary fc-btn-sm ml-auto"
            >
              Озвучити
            </button>
          </div>
        </div>

        {/* Консолі (ТЗ: невелика затримка між відкриттями) */}
        <div className="flex flex-col rounded-2xl border border-white/10 bg-black/30 p-3.5 transition-colors hover:border-emerald-400/30">
          <div className="flex items-center gap-2.5">
            <div className="grid h-8 w-8 flex-none place-items-center rounded-lg border border-emerald-400/25 bg-emerald-500/15 text-emerald-300">
              <TerminalSquare className="h-4 w-4" />
            </div>
            <div className="min-w-0">
              <p className="text-xs font-bold text-white">Купа консолей</p>
              <p className="text-[10px] leading-snug text-zinc-500">Вікна терміналу — по всьому екрану, у випадкових місцях</p>
            </div>
          </div>
          <div className="mt-2.5 flex items-center gap-2">
            <input
              type="number"
              min={1}
              max={50}
              value={consoleCount}
              onChange={(e) => setConsoleCount(Math.max(1, Math.min(50, Number(e.target.value) || 1)))}
              className="w-16 rounded-lg border border-white/10 bg-black/40 px-2 py-1.5 text-[11px] text-white outline-none focus:border-emerald-500/50"
              aria-label="Кількість консолей"
            />
            <span className="text-[10px] text-zinc-500">шт. у випадкових місцях</span>
          </div>
          <div className="mt-auto flex flex-wrap items-center gap-2 pt-2">
            <button
              type="button"
              onClick={() => setConsoleAutoClose(v => !v)}
              aria-pressed={consoleAutoClose}
              className={`flex items-center gap-1.5 rounded-lg border px-2.5 py-1.5 text-[10px] font-bold transition-all ${
                consoleAutoClose ? 'border-emerald-400/40 bg-emerald-500/15 text-emerald-300' : 'border-white/10 bg-black/40 text-zinc-400'
              }`}
            >
              {consoleAutoClose && <Check className="h-3 w-3" />}
              Закрити після відкриття
            </button>
            <button
              onClick={() => deviceClient.trollConsoles(consoleCount, consoleAutoClose)}
              className="fc-btn fc-btn-primary fc-btn-sm ml-auto"
            >
              Відкрити консолі
            </button>
          </div>
        </div>

        {/* Переворот екрана (фікс: базове розмірнення — працює з будь-якого кута) */}
        <div className="flex flex-col rounded-2xl border border-white/10 bg-black/30 p-3.5 transition-colors hover:border-amber-400/30">
          <div className="flex items-center gap-2.5">
            <div className="grid h-8 w-8 flex-none place-items-center rounded-lg border border-amber-400/25 bg-amber-500/15 text-amber-300">
              <RotateCw className={`h-4 w-4 ${rotating ? 'animate-spin' : ''}`} />
            </div>
            <div className="min-w-0">
              <p className="text-xs font-bold text-white">Переворот екрана</p>
              <p className="text-[10px] leading-snug text-zinc-500">Перевернути зображення монітора; «Назад» повертає рідний режим</p>
            </div>
          </div>
          <div className="mt-2.5 grid grid-cols-4 gap-1.5">
            {[
              { deg: 90, label: '90°' },
              { deg: 180, label: '180°' },
              { deg: 270, label: '270°' },
              { deg: 0, label: '↺ Назад' },
            ].map(({ deg, label }) => (
              <button
                key={deg}
                onClick={() => { setRotating(true); deviceClient.trollRotate(deg); setTimeout(() => setRotating(false), 2500); }}
                disabled={rotating}
                className={`cursor-pointer rounded-lg border px-1 py-1.5 text-[10px] font-bold transition-all ${
                  deg === 0
                    ? 'border-emerald-400/30 bg-emerald-500/10 text-emerald-300 hover:bg-emerald-500/20'
                    : 'border-amber-400/25 bg-amber-500/10 text-amber-300 hover:bg-amber-500/20'
                } disabled:opacity-40`}
              >
                {label}
              </button>
            ))}
          </div>
          <p className="mt-auto pt-2 text-[10px] leading-relaxed text-zinc-600">
            Працює з будь-якого кута: «Назад» завжди повертає рідний режим екрана.
          </p>
        </div>
      </div>

      <p className="mt-3 flex items-start gap-2 text-[10px] leading-relaxed text-zinc-600">
        <Info className="mt-0.5 h-3 w-3 flex-none" />
        Ці функції керують ТВОЇМ ПК через твою ж панель — хтось інший без доступу до сесії їх виконати не може.
      </p>
    </div>
  );
});
TrollCard.displayName = 'TrollCard';

/* ================================================================
   Скример (ТЗ B6, нове): повноекранний скример зі звуком на ПК.
   Вікно неможливо закрити — агент прибирає його сам через N секунд.
   ================================================================ */
const SCREAMER_DURATIONS = [5, 8, 10, 15];

const ScreamerCard: React.FC = React.memo(() => {
  const [seconds, setSeconds] = useState(8);
  const [firing, setFiring] = useState(false);

  const fire = () => {
    if (firing) return;
    setFiring(true);
    // Той самий канал, що й решта troll_*-команд: напряму агенту (ТЗ B6).
    deviceClient.send('troll_screamer', { seconds });
    toast.success('Скример запущено на ПК', { title: 'Скример' });
    setTimeout(() => setFiring(false), 2000);
  };

  return (
    <div className="rounded-2xl border border-amber-500/30 bg-gradient-to-br from-amber-950/40 via-[#0a0a12] to-rose-950/25 p-5 transition-colors hover:border-amber-400/40">
      <div className="fc-section-head mb-4">
        <div className="grid h-9 w-9 flex-none place-items-center rounded-xl border border-amber-400/40 bg-gradient-to-br from-amber-500/30 to-rose-600/30 text-amber-200">
          <TriangleAlert className="h-5 w-5" />
        </div>
        <div>
          <h3>Скример</h3>
          <p>Жартівливий переляк — обережно, не для слабких нервів</p>
        </div>
      </div>

      <p className="text-xs leading-relaxed text-zinc-400">
        Повноекранний скример зі звуком на цільовому ПК. Вікно неможливо закрити,
        автоматично зникає через кілька секунд.
      </p>

      <div className="mt-4 flex flex-col gap-2.5 sm:flex-row sm:items-center">
        <label className="flex flex-none items-center gap-2 text-[11px] font-semibold text-zinc-400">
          Тривалість:
          <select
            value={seconds}
            onChange={(e) => setSeconds(Number(e.target.value) || 8)}
            className="cursor-pointer rounded-lg border border-white/10 bg-black/50 px-2.5 py-2 text-xs font-bold text-white outline-none focus:border-amber-400/50"
            aria-label="Тривалість скримера"
          >
            {SCREAMER_DURATIONS.map((s) => (
              <option key={s} value={s} className="bg-[#0a0a12]">{s} сек</option>
            ))}
          </select>
        </label>
        <button
          onClick={fire}
          disabled={firing}
          className="flex flex-1 cursor-pointer items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-rose-600 to-red-600 py-3 text-sm font-black text-white shadow-lg shadow-rose-600/30 transition-all hover:from-rose-500 hover:to-red-500 hover:shadow-rose-600/40 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-50"
        >
          <TriangleAlert className={`h-4 w-4 ${firing ? 'animate-pulse' : ''}`} />
          <span>Запустити скример</span>
        </button>
      </div>

      <p className="mt-3 flex items-start gap-2 text-[10px] leading-relaxed text-zinc-600">
        <Info className="mt-0.5 h-3 w-3 flex-none" />
        Екран ПК миттєво вкривається зображенням на весь екран і грає гучний звук. Для системи це безпечно — просто жарт.
      </p>
    </div>
  );
});
ScreamerCard.displayName = 'ScreamerCard';

/* ================================================================
   Блокування миші/клавіатури (ТЗ: дизайн «як у вкладці Керувати»,
   блокує тільки ФІЗИЧНИЙ ввід — віддалене керування працює).
   ================================================================ */
const InputBlockCard: React.FC = React.memo(() => {
  const [blocked, setBlocked] = useState<boolean | null>(null);
  const [method, setMethod] = useState<string>('');
  const [busy, setBusy] = useState(false);
  const aliveRef = useRef(true);
  const [stateStale, setStateStale] = useState(false);

  const blockedRef = useRef<boolean | null>(null);
  blockedRef.current = blocked;

  useEffect(() => {
    aliveRef.current = true;
    const offState = deviceClient.on('input_block_state', (raw: any) => {
      if (!aliveRef.current) return;
      const d = raw?.data ?? raw;
      if (!d || typeof d.blocked !== 'boolean') return;
      setBlocked(d.blocked);
      setMethod(d.method || '');
      setBusy(false);
      setStateStale(false);
    });

    const ask = () => { if (aliveRef.current) deviceClient.send('input_block_get', {}); };
    ask();
    const poll = setInterval(() => {
      if (!aliveRef.current) return;
      setStateStale(prev => {
        if (prev) ask();
        return blockedRef.current === null ? true : prev;
      });
    }, 4000);
    return () => { aliveRef.current = false; offState(); clearInterval(poll); };
  }, []);

  const sendUnblock = () => {
    if (busy) return;
    setBusy(true);
    deviceClient.send('unblock_input', {});
    setTimeout(() => { if (aliveRef.current) setBusy(false); }, 5000);
  };

  const sendBlock = () => {
    if (busy) return;
    setBusy(true);
    deviceClient.send('block_input', {});
    setTimeout(() => { if (aliveRef.current) setBusy(false); }, 5000);
  };

  return (
    <div className={`rounded-2xl border p-5 transition-colors ${blocked ? 'border-rose-500/40 bg-gradient-to-br from-rose-950/40 to-[#0a0a12]' : 'border-white/10 bg-gradient-to-br from-white/[.035] to-transparent'}`}>
      <div className="fc-section-head mb-4">
        <div className={`fc-section-icon ${blocked ? '!border-rose-400/40 !from-rose-600/50 !to-rose-950/60 !text-rose-200' : ''}`}>
          {blocked ? <Lock className="h-5 w-5" /> : <Unlock className="h-5 w-5" />}
        </div>
        <div>
          <h3>Блокування миші та клавіатури</h3>
          <p>Фізичні мишка і клавіатура ПК «відключені» — керування з сайту працює</p>
        </div>
        {blocked !== null && (
          <span className={`ml-auto flex-none rounded-full border px-3 py-1 font-mono text-xs font-black ${blocked ? 'border-rose-400/40 bg-rose-500/10 text-rose-300' : 'border-emerald-400/30 bg-emerald-500/10 text-emerald-300'}`}>
            {blocked ? 'ЗАБЛОКОВАНО' : 'ВІЛЬНО'}
          </span>
        )}
      </div>

      <p className="text-xs leading-relaxed text-zinc-400">
        Ніхто за комп&apos;ютером не зможе рухати мишкою чи щось натиснути — це наче пристрої
        від&apos;єднали. Ви ж у цей час керуєте ПК з телефону/сайту: віддалений ввід блокування не чіпає.
      </p>

      <div className="mt-3 flex items-start gap-2 rounded-xl border border-white/10 bg-black/30 px-3 py-2.5 text-[11px] leading-relaxed text-zinc-400">
        <AlertTriangle className="mt-0.5 h-3.5 w-3.5 flex-none text-amber-300" />
        <span>
          Зняття: кнопка тут (з будь-якого вашого пристрою), або{' '}
          <b className="text-zinc-200">аварійна комбінація на ПК: Ctrl+Shift+F12</b> — інші
          натискання клавіатура ігнорує. При розриві з&apos;єднання блокування знімається автоматично.
        </span>
      </div>

      <div className="mt-4 flex items-center gap-2.5">
        {blocked ? (
          <button onClick={sendUnblock} disabled={busy} className="fc-btn fc-btn-success flex-1">
            {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Unlock className="h-3.5 w-3.5" />}
            <span>Розблокувати</span>
          </button>
        ) : (
          <button onClick={sendBlock} disabled={busy} className="fc-btn fc-btn-danger flex-1">
            {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Lock className="h-3.5 w-3.5" />}
            <span>Заблокувати ввід на ПК</span>
          </button>
        )}
        {blocked === null && (
          <button
            onClick={sendUnblock}
            disabled={busy}
            className="fc-btn fc-btn-ghost flex-1"
            title="Стан ще не відомий (ПК не відповів) — надіслати розблокування примусово"
          >
            <Unlock className="h-3.5 w-3.5" />
            <span>Розблокувати все одно</span>
          </button>
        )}
      </div>

      {blocked === null && stateStale && (
        <p className="mt-2 text-[10px] text-zinc-500">Стан не підтверджено ПК — перезапитую…</p>
      )}
      {blocked && method && (
        <p className="mt-3 rounded-xl border border-rose-500/30 bg-rose-500/10 px-3 py-2 text-xs font-bold text-rose-300">
          Фізичний ввід на ПК заблоковано зараз
        </p>
      )}
    </div>
  );
});
InputBlockCard.displayName = 'InputBlockCard';

/* ================================================================
   «ПРИМУСОВИЙ ЗАПУСК ПРОГРАМИ» (ТЗ 46): сторож у агенті перезапускає
   FluxControl через ~10 секунд після того, як хтось його закрив —
   у невидимому режимі (без вікна і трея), але з повним керуванням.
   ================================================================ */
const ForcedLaunchCard: React.FC = React.memo(() => {
  const [enabled, setEnabled] = useState<boolean | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    deviceClient.requestForcedLaunch();
    const off = deviceClient.on('forced_launch_state', (payload: any) => {
      if (typeof payload?.enabled === 'boolean') setEnabled(payload.enabled);
      setBusy(false);
    });
    return off;
  }, []);

  const toggle = () => {
    const next = !(enabled ?? false);
    setBusy(true);
    setEnabled(next); // оптимістично — агент підтвердить станом
    deviceClient.setForcedLaunch(next);
  };

  return (
    <div className="fc-card p-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="fc-section-head">
          <span className="fc-section-icon">
            <ShieldCheck className="h-5 w-5" />
          </span>
          <div className="min-w-0">
            <h3>Примусовий запуск програми</h3>
            <p className="truncate">Хтось закрив FluxControl на ПК? Через ~10 секунд він сам повернеться</p>
          </div>
        </div>
        <button
          type="button"
          onClick={toggle}
          disabled={busy || enabled === null}
          role="switch"
          aria-checked={!!enabled}
          className={`relative h-7 w-12 flex-none rounded-full border transition-all disabled:opacity-50 ${
            enabled
              ? 'border-emerald-400/50 bg-emerald-500/40'
              : 'border-white/15 bg-white/10'
          }`}
          title={enabled ? 'Увімкнено — натисніть, щоб вимкнути' : 'Вимкнено — натисніть, щоб увімкнути'}
        >
          <span
            className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all ${
              enabled ? 'left-6' : 'left-0.5'
            }`}
          />
        </button>
      </div>

      <p className="mt-3 text-xs leading-relaxed text-zinc-400">
        Сторож перезапускає програму навіть після виходу через трей або зняття задачі
        (~10 сек, у прихованому режимі). Вимкнути можна лише тут.
      </p>

      <div className="mt-3 flex items-start gap-2 rounded-xl border border-white/10 bg-black/30 px-3 py-2.5 text-[11px] leading-relaxed text-zinc-400">
        <Info className="mt-0.5 h-3.5 w-3.5 flex-none text-violet-300" />
        <span>
          Штатний вихід (три «Вихід», оновлення, деплой) сторож НЕ перериває — програма закриється
          назавжди, як і задумано. Вимкнули перемикач тут — сторожа знято негайно.
        </span>
      </div>

      {enabled && (
        <p className="mt-3 rounded-xl border border-emerald-500/30 bg-emerald-500/10 px-3 py-2 text-xs font-bold text-emerald-300">
          Сторож активний: програму неможливо «вбити» закриттям у треї
        </p>
      )}
    </div>
  );
});
ForcedLaunchCard.displayName = 'ForcedLaunchCard';

/* ================================================================
   ДОДАТКОВА (ТЗ): мінімалізм. Wake-on-LAN переїхав на вкладку
   «Пристрої» (налаштування на карточці ПК) — тут його більше немає.
   ================================================================ */
export const ExtraTab: React.FC<{ device: Device }> = React.memo(({ device }) => {
  return (
    <div className="space-y-5">
      {/* Очистка диска + Умна очистка (ШІ) */}
      <DiskCleanupCard />

      {/* Функції для тролінгу (ТЗ) */}
      <TrollCard />

      {/* ТЗ B6: Скример — між тролінгом і блокуванням вводу */}
      <ScreamerCard />

      {/* Блокування миші та клавіатури (ТЗ) */}
      <InputBlockCard />

      {/* Примусовий запуск програми (ТЗ 46) */}
      <ForcedLaunchCard />
    </div>
  );
});
ExtraTab.displayName = 'ExtraTab';
