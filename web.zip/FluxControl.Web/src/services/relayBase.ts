/**
 * Єдина база релей-сервера (ТЗ: «перепідключи все на новий сервер»).
 *
 * Порядок пріоритетів:
 *   1) localStorage `fluxcontrol_relay_url` — dev/діагностика (mock-стенд),
 *      потрібно повне походження: `http://localhost:8901`;
 *   2) змінна оточення Vite VITE_RELAY_BASE (bake на білді);
 *   3) продакшн Deno Deploy за замовчуванням.
 *
 * relayBase — http(s) походження без слеша в кінці; relayWs — ws(s://)/ws.
 */

const DEFAULT_BASE = 'https://fluxcontrol-backend-bl3u.onrender.com';

function readOverride(): string {
  try {
    const raw = localStorage.getItem('fluxcontrol_relay_url') || '';
    const clean = raw.trim().replace(/\/+$/, '');
    return clean.startsWith('http://') || clean.startsWith('https://') ? clean : '';
  } catch {
    return '';
  }
}

let cachedBase: string | null = null;

export function relayBase(): string {
  if (cachedBase === null) {
    const env = (import.meta as any)?.env?.VITE_RELAY_BASE || '';
    cachedBase = readOverride() || String(env).trim().replace(/\/+$/, '') || DEFAULT_BASE;
  }
  return cachedBase;
}

export function relayWsUrl(code: string): string {
  return `${relayBase().replace(/^http/, 'ws')}/ws?role=client&code=${encodeURIComponent(code)}`;
}

/** Зручний URL для REST-ендпоінтів релея: relayUrl('/api/wol'). */
export function relayUrl(path: string): string {
  return `${relayBase()}${path.startsWith('/') ? path : `/${path}`}`;
}
