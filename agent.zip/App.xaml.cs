﻿using System;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;

namespace FluxControl.Agent;

public partial class App : System.Windows.Application
{
    private static Mutex? _singleInstanceMutex;

    /// <summary>
    /// Канал «покажи вікно» між екземплярами (ТЗ «макс 1 вікно»): повторний
    /// запуск більше НЕ показує повідомлення «вже запущено у трее» — він
    /// сигналить цю подію, а перший екземпляр піднімає своє вікно.
    /// </summary>
    private const string ShowWindowEventName = "Local\\FluxControl.ShowWindow_Event";
    private static EventWaitHandle? _showWindowEvent;

    protected override void OnStartup(System.Windows.StartupEventArgs e)
    {
        // Log FIRST, before anything can fail — every launch attempt must leave
        // a trace in %AppData%\FluxControl\agent.log so invisible startups are debuggable.
        try { Log($"App.OnStartup args=[{string.Join(" ", e.Args)}]"); } catch { }

        // Сторож «Примусового запуску» (ТЗ 46): режим --watchdog ПОВИНЕН бути
        // оброблений ДО м'ютекса/три/WPF — сторож є другим процесом того ж exe.
        try
        {
            if (Services.WatchdogService.RunWatchdogIfRequested(e.Args ?? Array.Empty<string>()))
            {
                return; // сторож живе в цьому процесі вічно; WPF не потрібен
            }
        }
        catch { }

        try
        {
            // Прогрів WebView2 для миттєвого WinLock-дизайну (ТЗ: «одразу WebView,
            // без старого C#-дизайну»). Фоновий Task — не блокує старт.
            Services.LockWindow.PreWarmWebView2();

            const string mutexName = "FluxControl_SingleInstance_Mutex_Blazix";
            var waitForUpdate = e.Args?.Any(a => a.Equals("--waitForUpdate", StringComparison.OrdinalIgnoreCase)) == true;
            _singleInstanceMutex = new Mutex(true, mutexName, out bool isNewInstance);

            if (!isNewInstance && waitForUpdate)
            {
                // Запуск після оновлення: попередній процес ще тримає м'ютекс
                // (він завершується на ~600мс пізніше). Раніше новий екземпляр
                // тут одразу виходив → «програму закрило, а нова не запустилась».
                // Тепер ЧЕКАЄМО звільнення (до ~30с) і продовжуємо старт.
                var acquired = isNewInstance;
                for (int i = 0; i < 60 && !acquired; i++)
                {
                    try { _singleInstanceMutex.ReleaseMutex(); } catch { }
                    try { _singleInstanceMutex.Dispose(); } catch { }
                    Thread.Sleep(500);
                    try { _singleInstanceMutex = new Mutex(true, mutexName, out acquired); }
                    catch { acquired = false; }
                }
                Log($"Update relaunch: single-instance mutex acquired after wait ({(acquired ? "ok" : "timeout")}).");
                if (!acquired)
                {
                    Log("Update relaunch: mutex still busy after 30s — exiting.");
                    Shutdown(0);
                    return;
                }
                isNewInstance = true;
            }

            if (!isNewInstance)
            {
                // Вже працює інший екземпляр (можливо, згорнутий у трей).
                // ТЗ: ніяких діалогів «вже запущено» — просто показуємо ЙОГО вікно
                // і тихо виходимо (макс 1 вікно програми).
                try
                {
                    using var evt = EventWaitHandle.OpenExisting(ShowWindowEventName);
                    evt.Set();
                    Log("Second launch: signaled first instance to show its window — exiting.");
                }
                catch (Exception ex)
                {
                    Log($"Second launch: could not signal first instance ({ex.Message}) — exiting.");
                }
                Shutdown(0);
                return;
            }

            // Перший екземпляр: створює канал і слухає його — повторний запуск
            // з ярлика розгорне вікно вже працюючої програми.
            _showWindowEvent = new EventWaitHandle(false, EventResetMode.AutoReset, ShowWindowEventName);
            GC.KeepAlive(_singleInstanceMutex);
        }
        catch (Exception ex)
        {
            // Abandoned/broken mutex must never block the app from starting.
            try { Log($"Mutex check failed (continuing anyway): {ex.Message}"); } catch { }
        }

        // Surface ANY startup failure (XAML parse error, constructor crash, missing
        // runtime piece) as a visible dialog + log entry instead of a silent death.
        HookGlobalExceptionHandlers();

        try
        {
            base.OnStartup(e);
        }
        catch (Exception ex)
        {
            try { Log($"FATAL startup exception: {ex}"); } catch { }
            System.Windows.MessageBox.Show(
                "FluxControl не зміг запуститися. Деталі:\r\n\r\n" + ex,
                "FluxControl — помилка запуску", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Error);
            Shutdown(-1);
            return;
        }

        // Запуск програми: спочатку bootstrap-встановлення (красивий
        // інсталятор довантажує відсутні файли з GitHub Releases),
        // потім головне вікно.
        StartAppAsync(e.Args);
    }

    private async void StartAppAsync(string[]? launchArgs)
    {
        // Чистка залишків старого kernel-драйвера WinRing0 (LibreHardwareMonitor):
        // старі збірки витягали WinRing0x64.sys/.dll у %TEMP%, і Windows Defender
        // прапорив сам ФАЙЛ як VulnerableDriver:WinNT/Wiring0 («Критический»).
        // Тепер програма повністю user-mode — прибираємо те, що лишили старі збірки.
        try
        {
            var tmp = System.IO.Path.GetTempPath();
            foreach (var name in new[] { "WinRing0x64.sys", "WinRing0x64.dll", "WinRing0.sys", "WinRing0.dll", "WinRing0x32.sys", "WinRing0x32.dll" })
            {
                var f = System.IO.Path.Combine(tmp, name);
                if (System.IO.File.Exists(f))
                {
                    try { System.IO.File.Delete(f); Log($"Cleanup: removed driver remnant {name}"); } catch { }
                }
            }
        }
        catch { }

        // Бекап попередньої версії після rename-swap оновлення (ТЗ «старий файл
        // має бути ВИДАЛЕНИМ, а не лежати як FluxControl.old.exe»): видалити
        // запущений exe неможливо, тому оновлювач лише перейменовує його, а
        // НОВИЙ процес добиває видалення — файл звільняється, щойно старий
        // процес вийде, тож пробуємо з ретраями до ~48 секунд.
        CleanupOldExeWithRetry();

        // Самодостатній EXE (ТЗ): інтерфейс і іконка вбудовані в збірку —
        // витягуємо їх у сховище %AppData%\FluxControl (WebView2 читає html
        // з диска; exe може лежати де завгодно і нічого поруч не створює).
        try { Services.RuntimeFiles.EnsureRuntimeFiles(); }
        catch (Exception ex) { try { Log($"RuntimeFiles failed: {ex.Message}"); } catch { } }

        // Журнал дій (ТЗ): %AppData%\FluxControl\activity.log — усі дії в програмі.
        Services.ActivityLogger.Init();
        try
        {
            var ver = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version?.ToString() ?? "?";
            var autoRun = launchArgs?.Any(a => a.Equals("--minimized", StringComparison.OrdinalIgnoreCase)) == true;
            Services.ActivityLogger.Log("APP", "Програму запущено", $"v{ver}" + (autoRun ? " (автозапуск Windows — старт у трей)" : ""));
        }
        catch { }

        // Ярлик на робочому столі (ТЗ: «убери створення ярлика — я не просив»):
        // більше НЕ створюємо. Якщо попередні збірки автостворили його
        // (маркер shortcut.marker) — тихо прибираємо; свій ярлик користувача
        // (без маркера) програма ніколи не чіпає.
        try { Services.BootstrapService.RemoveAutoCreatedDesktopShortcut(); }
        catch (Exception ex) { try { Log($"Shortcut cleanup step failed: {ex.Message}"); } catch { } }

        // Bootstrap (ТЗ користувача): при відкритті програма ПЕРЕВІРЯЄ всі
        // файли; якщо якихось бракує — показує вікно відновлення (витягує
        // вбудовані файли з самої збірки, без мережі).
        try
        {
            var missing = Services.BootstrapService.FindMissingFiles();
            if (missing.Count > 0)
            {
                Log($"Bootstrap: missing {missing.Count} file(s): {string.Join(", ", missing)}");
                var installer = new Services.InstallerWindow(Services.InstallerWindow.InstallerMode.Install);
                var ok = await installer.RunInstallAsync(missing);
                if (!ok)
                {
                    Log("Bootstrap cancelled or failed — exiting.");
                    Shutdown();
                    return;
                }
            }
        }
        catch (Exception ex)
        {
            try { Log($"Bootstrap step failed (continuing startup): {ex.Message}"); } catch { }
        }

        // Фонова синхронізація робочих файлів з манифестом version.json
        // (офіційний сайт fluxcontrol.pages.dev): UI/іконку можна оновити без
        // пересборки exe — звіряється sha256 і довантажуються змінені.
        _ = Task.Run(Services.BootstrapService.SyncExtraFilesFromManifest);

        // Вікно створюється вручну (StartupUri прибрано з App.xaml) — саме це
        // дає --minimized (автозапуск Windows) стартувати повністю невидимо.
        // MainWindow сам керує приховуванням (Opacity=0 + minimized + без
        // кнопки на панелі завдань), але проганяє весь стартовий пайплайн
        // у Loaded (WebView2, WebSocket-сервер на 5080, релей, FFmpeg).
        try
        {
            var window = new MainWindow();
            MainWindow = window;
            window.Show(); // при --minimized жодного кадру не буде видно
        }
        catch (Exception ex)
        {
            try { Log($"FATAL window creation exception: {ex}"); } catch { }
            System.Windows.MessageBox.Show(
                "FluxControl не зміг запуститися. Деталі:\r\n\r\n" + ex,
                "FluxControl — помилка запуску", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Error);
            Shutdown(-1);
        }

        // Слухач сигналу «покажи вікно» від повторних запусків ярлика.
        StartShowWindowListener();
    }

    /// <summary>
    /// Фонова очистка FluxControl.old.exe з ретраями: старий процес тримає
    /// файл до виходу, тому перші спроби можуть падати — продовжуємо, поки
    /// файл не зник (максимум ~48с; якщо не вийшло — наступний запуск).
    /// </summary>
    private static void CleanupOldExeWithRetry()
    {
        _ = Task.Run(async () =>
        {
            try
            {
                var curExe = System.Diagnostics.Process.GetCurrentProcess().MainModule?.FileName;
                if (string.IsNullOrEmpty(curExe)) return;
                var dir = System.IO.Path.GetDirectoryName(curExe)!;

                // Кандидати на видалення: видимий .old поруч (легасі) +
                // stale-копії запущеного exe, перенесені у %TEMP% оновлювачем.
                var victims = new List<string>
                {
                    System.IO.Path.Combine(dir, "FluxControl.old.exe")
                };
                try
                {
                    var temp = System.IO.Path.GetTempPath();
                    foreach (var f in System.IO.Directory.EnumerateFiles(temp, "FluxControl.stale-*.exe"))
                        victims.Add(f);
                }
                catch { }

                var pending = victims.Where(v => System.IO.File.Exists(v)).ToList();
                if (pending.Count == 0) return;

                for (int attempt = 1; attempt <= 24 && pending.Count > 0; attempt++)
                {
                    for (int i = pending.Count - 1; i >= 0; i--)
                    {
                        try
                        {
                            System.IO.File.SetAttributes(pending[i], System.IO.FileAttributes.Normal);
                            System.IO.File.Delete(pending[i]);
                            Log($"Cleanup: старий файл видалено ({System.IO.Path.GetFileName(pending[i])}, спроба {attempt})");
                            pending.RemoveAt(i);
                        }
                        catch { }
                    }
                    if (pending.Count > 0) await Task.Delay(2000);
                }
                if (pending.Count > 0)
                    Log("Cleanup: не вдалося видалити старі файли за 48с — спроба буде при наступному запуску.");
            }
            catch (Exception ex)
            {
                try { Log($"Cleanup old exe failed: {ex.Message}"); } catch { }
            }
        });
    }

    /// <summary>
    /// Слухає подію «покажи вікно» (повторний запуск ярлика): кожен сигнал
    /// розгортає й активує головне вікно працюючого екземпляра (макс 1 вікно).
    /// </summary>
    private static void StartShowWindowListener()
    {
        var evt = _showWindowEvent;
        if (evt == null) return;
        _ = Task.Run(() =>
        {
            try
            {
                while (evt.WaitOne(Timeout.InfiniteTimeSpan))
                {
                    Log("Show-window signal received — activating MainWindow.");
                    var app = System.Windows.Application.Current;
                    if (app != null)
                    {
                        app.Dispatcher.Invoke(() =>
                        {
                            (app.MainWindow as MainWindow)?.ShowAndActivate();
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                try { Log($"Show-window listener stopped: {ex.Message}"); } catch { }
            }
        });
    }

    private void HookGlobalExceptionHandlers()
    {
        // UI-thread + async void crashes (e.g. WebView2 init in MainWindow_Loaded).
        DispatcherUnhandledException += (s, args) =>
        {
            try { Log($"Dispatcher exception: {args.Exception}"); } catch { }
            try
            {
                System.Windows.MessageBox.Show(
                    "Помилка в інтерфейсі FluxControl:\r\n\r\n" + args.Exception.Message +
                    "\r\n\r\n(повний текст у %AppData%\\FluxControl\\agent.log)",
                    "FluxControl", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Error);
            }
            catch { }
            args.Handled = true; // keep the app alive instead of vanishing
            if (MainWindow == null)
            {
                // Startup failed before any window was created (e.g. XAML parse error)
                // — a headless zombie process would be useless. Exit with the dialog above shown.
                try { Log("No MainWindow after dispatcher exception — shutting down."); } catch { }
                Shutdown(-1);
            }
        };

        // Background-thread fatal crashes — process is terminating, but leave a trace + visible reason.
        AppDomain.CurrentDomain.UnhandledException += (s, args) =>
        {
            try { Log($"AppDomain UNHANDLED (terminating={args.IsTerminating}): {args.ExceptionObject}"); } catch { }
            if (args.IsTerminating)
            {
                try
                {
                    System.Windows.MessageBox.Show(
                        "FluxControl аварійно завершився:\r\n\r\n" + args.ExceptionObject,
                        "FluxControl", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Error);
                }
                catch { }
            }
        };

        // Unobserved task faults are logged only (finalizer thread — no dialogs here).
        System.Threading.Tasks.TaskScheduler.UnobservedTaskException += (s, args) =>
        {
            try { Log($"Unobserved task exception: {args.Exception}"); } catch { }
            args.SetObserved();
        };
    }

    protected override void OnExit(ExitEventArgs e)
    {
        try { Log($"App.OnExit code={e.ApplicationExitCode}"); } catch { }
        try { Services.ActivityLogger.Log("APP", "Програму закрито", $"код {e.ApplicationExitCode}"); } catch { }
        base.OnExit(e);
    }

    public static void Log(string message)
    {
        try
        {
            var logDir = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FluxControl");
            System.IO.Directory.CreateDirectory(logDir);
            var logFile = System.IO.Path.Combine(logDir, "agent.log");
            System.IO.File.AppendAllText(logFile, $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss.fff}] {message}\r\n");
        }
        catch { }
        System.Diagnostics.Debug.WriteLine($"[{DateTime.Now:HH:mm:ss}] {message}");
    }
}
