using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;

namespace FluxControl.Agent.Services;

/// <summary>
/// «Стан ПК» (новий концепт вкладки Інфо, ТЗ 46): одне число-оцінка 0-100 +
/// конкретні перевірки з чесними статусами (ок/увага/погано) і підказками,
/// що робити. Жодних графіків-заставок — лише те, що реально корисно
/// власнику віддаленого ПК: вільне місце, навантаження, аптайм, захист,
/// сміття, кошик, оновлення, батарея.
/// </summary>
public class SystemHealthService
{
    public class HealthCheck
    {
        public string Key { get; set; } = "";
        public string Title { get; set; } = "";
        public string Status { get; set; } = "ok";   // ok | warn | bad | info
        public string Value { get; set; } = "";      // людське значення («412 ГБ вільно з 1 ТБ»)
        public string Detail { get; set; } = "";     // підказка / пояснення
        public int Weight { get; set; } = 10;        // вага в загальній оцінці
        public double PenaltyFactor { get; set; }    // 0..1 — скільки ваги забрати при warn/bad
        public string? Action { get; set; }          // підказка дії для веба (clean | trash | reboot | speedtest)
    }

    public class HealthReport
    {
        public int Score { get; set; }
        public string Verdict { get; set; } = "";
        public List<HealthCheck> Checks { get; set; } = new();
        public DateTime GeneratedAt { get; set; } = DateTime.UtcNow;
        public long UptimeSeconds { get; set; }
        public int CpuLoadPercent { get; set; }
        public int RamUsedPercent { get; set; }
    }

    public HealthReport GetReport()
    {
        var report = new HealthReport();
        var checks = new List<HealthCheck>();

        // ---------- Диски: вільне місце ----------
        try
        {
            foreach (var drive in DriveInfo.GetDrives().Where(d => d.IsReady && d.DriveType == DriveType.Fixed).Take(6))
            {
                double totalGb = drive.TotalSize / 1073741824.0;
                double freeGb = drive.AvailableFreeSpace / 1073741824.0;
                double freePct = totalGb > 0 ? freeGb / totalGb * 100.0 : 0;

                var status = freePct >= 15 ? "ok" : freePct >= 5 ? "warn" : "bad";
                checks.Add(new HealthCheck
                {
                    Key = $"disk_{drive.Name.TrimEnd(':','\\').ToLowerInvariant()}",
                    Title = $"Диск {drive.Name} «{(string.IsNullOrWhiteSpace(drive.VolumeLabel) ? "Локальний" : drive.VolumeLabel)}»",
                    Status = status,
                    Value = $"{freeGb:0} ГБ вільно з {totalGb:0} ГБ",
                    Detail = freePct < 15
                        ? "Мало вільного місця — Windows гальмує, оновлення можуть не ставитися. Запустіть розумну очистку у «Додатковому»."
                        : "З вільним місцем усе гаразд.",
                    Weight = 25,
                    PenaltyFactor = freePct >= 15 ? 0 : freePct >= 5 ? 0.55 : 1,
                    Action = freePct < 15 ? "clean" : null
                });
            }
        }
        catch { }

        // ---------- Оперативна пам'ять ----------
        try
        {
            var totalKb = 0L;
            var availKb = 0L;
            using (var searcher = new System.Management.ManagementObjectSearcher("SELECT TotalVisibleMemorySize, FreePhysicalMemory FROM Win32_OperatingSystem"))
            {
                foreach (var o in searcher.Get())
                {
                    totalKb = Convert.ToInt64(o["TotalVisibleMemorySize"]);
                    availKb = Convert.ToInt64(o["FreePhysicalMemory"]);
                    break;
                }
            }
            if (totalKb > 0)
            {
                double usedPct = 100.0 - (availKb / (double)totalKb * 100.0);
                report.RamUsedPercent = (int)Math.Round(usedPct);
                var status = usedPct < 85 ? "ok" : usedPct < 95 ? "warn" : "bad";
                checks.Add(new HealthCheck
                {
                    Key = "ram",
                    Title = "Оперативна пам'ять",
                    Status = status,
                    Value = $"Зайнято {usedPct:0}% ({(totalKb - availKb) / 1048576.0:0.0} з {totalKb / 1048576.0:0.0} ГБ)",
                    Detail = usedPct >= 85
                        ? "Пам'ять майже вичерпана — варто закрити важкі програми або перезавантажити ПК."
                        : "Пам'яті достатньо для комфортної роботи.",
                    Weight = 20,
                    PenaltyFactor = usedPct < 85 ? 0 : usedPct < 95 ? 0.5 : 1
                });
            }
        }
        catch { }

        // ---------- ЦП ----------
        try
        {
            float cpu = 0;
            using (var searcher = new System.Management.ManagementObjectSearcher("SELECT LoadPercentage FROM Win32_Processor"))
            {
                foreach (var o in searcher.Get())
                {
                    cpu = Convert.ToSingle(o["LoadPercentage"]);
                    break;
                }
            }
            report.CpuLoadPercent = (int)Math.Round(cpu);
            var status = cpu < 80 ? "ok" : cpu < 95 ? "warn" : "bad";
            checks.Add(new HealthCheck
            {
                Key = "cpu",
                Title = "Процесор",
                Status = status,
                Value = $"Навантаження {cpu:0}%",
                Detail = cpu >= 80 ? "ЦП працює майже на межі — перевірте список процесів." : "Процесор спокійний.",
                Weight = 10,
                PenaltyFactor = cpu < 80 ? 0 : cpu < 95 ? 0.4 : 0.8
            });
        }
        catch { }

        // ---------- Аптайм ----------
        try
        {
            long uptimeSec = 0;
            try
            {
                using var searcher = new System.Management.ManagementObjectSearcher("SELECT LastBootUpTime FROM Win32_OperatingSystem");
                foreach (var o in searcher.Get())
                {
                    var boot = System.Management.ManagementDateTimeConverter.ToDateTime(o["LastBootUpTime"]?.ToString());
                    uptimeSec = (long)(DateTime.Now - boot).TotalSeconds;
                    break;
                }
            }
            catch { }

            if (uptimeSec <= 0)
            {
                try { uptimeSec = (long)(DateTime.Now - Process.GetCurrentProcess().StartTime).TotalSeconds; } catch { }
            }

            report.UptimeSeconds = uptimeSec;
            var days = uptimeSec / 86400;
            var status = days < 7 ? "ok" : days < 30 ? "warn" : "bad";
            var uptimeText = days >= 1 ? $"{days} дн. {uptimeSec % 86400 / 3600} год." : $"{uptimeSec / 3600} год. {uptimeSec % 3600 / 60} хв.";
            checks.Add(new HealthCheck
            {
                Key = "uptime",
                Title = "Час роботи без перезавантаження",
                Status = status,
                Value = uptimeText,
                Detail = days >= 7 ? "Довгий аптайм накопичує глюки пам'яті — корисно перезавантажитись." : "Нормально.",
                Weight = 10,
                PenaltyFactor = days < 7 ? 0 : days < 30 ? 0.4 : 0.8,
                Action = days >= 7 ? "reboot" : null
            });
        }
        catch { }

        // ---------- Захисник Windows ----------
        try
        {
            var av = WmiString("root\\SecurityCenter2", "SELECT displayName, productState FROM AntiVirusProduct");
            var (avName, avEnabled) = av.Count > 0 ? av[0] : ("Захисник Windows", true);
            checks.Add(new HealthCheck
            {
                Key = "defender",
                Title = "Антивірус",
                Status = avEnabled ? "ok" : "bad",
                Value = avName,
                Detail = avEnabled ? "Захист у реальному часі активний." : "Антивірус ВИМКНЕНИЙ — ПК уразливий.",
                Weight = 15,
                PenaltyFactor = avEnabled ? 0 : 1
            });
        }
        catch
        {
            checks.Add(new HealthCheck
            {
                Key = "defender", Title = "Антивірус", Status = "info",
                Value = "Немає даних", Detail = "Статус антивіруса не вдалося перевірити на цьому ПК.", Weight = 0
            });
        }

        // ---------- Брандмауер ----------
        try
        {
            var fw = WmiString("root\\SecurityCenter2", "SELECT displayName, productState FROM FirewallProduct");
            var fwEnabled = fw.Count == 0 || fw.Any(x => x.enabled);
            checks.Add(new HealthCheck
            {
                Key = "firewall",
                Title = "Брандмауер",
                Status = fwEnabled ? "ok" : "warn",
                Value = fw.Count > 0 ? fw[0].name : "Брандмауер Windows",
                Detail = fwEnabled ? "Мережа захищена." : "Брандмауер вимкнено — ризик для віддаленого доступу.",
                Weight = 10,
                PenaltyFactor = fwEnabled ? 0 : 0.6
            });
        }
        catch
        {
            checks.Add(new HealthCheck { Key = "firewall", Title = "Брандмауер", Status = "info", Value = "Немає даних", Detail = "Статус брандмауера не вдалося перевірити.", Weight = 0 });
        }

        // ---------- Тимчасові файли (швидка оцінка без повного скана) ----------
        try
        {
            long tempBytes = 0;
            try
            {
                tempBytes += DirSize(new DirectoryInfo(Path.GetTempPath()));
                var winTemp = new DirectoryInfo(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), @"..\Temp"));
                if (winTemp.Exists) tempBytes += DirSize(winTemp);
            }
            catch { }

            long trashBytes = EstimateRecycleBin();

            if (tempBytes > 256 * 1024 * 1024)
            {
                var gb = tempBytes / 1073741824.0;
                var status = gb < 2 ? "ok" : gb < 10 ? "warn" : "bad";
                checks.Add(new HealthCheck
                {
                    Key = "temp",
                    Title = "Тимчасові файли",
                    Status = status,
                    Value = FormatBytes(tempBytes),
                    Detail = gb >= 2 ? "Сміття можна звільнити розумною очисткою у «Додатковому»." : "Сміття небагато.",
                    Weight = 10,
                    PenaltyFactor = gb < 2 ? 0 : gb < 10 ? 0.35 : 0.7,
                    Action = gb >= 2 ? "clean" : null
                });
            }

            if (trashBytes > 512 * 1024 * 1024)
            {
                checks.Add(new HealthCheck
                {
                    Key = "trash",
                    Title = "Кошик",
                    Status = "warn",
                    Value = FormatBytes(trashBytes),
                    Detail = "Кошик великий — його можна очистити у «Файлах» → Корзина.",
                    Weight = 5,
                    PenaltyFactor = 0.3,
                    Action = "trash"
                });
            }
        }
        catch { }

        // ---------- Оновлення Windows ----------
        try
        {
            var pendingReboot = RegistryPendingReboot();
            checks.Add(new HealthCheck
            {
                Key = "updates",
                Title = "Оновлення Windows",
                Status = pendingReboot ? "warn" : "ok",
                Value = pendingReboot ? "Чекає перезавантаження" : "Актуальні",
                Detail = pendingReboot ? "Встановлені оновлення вимагають перезавантаження ПК." : "Перезавантаження не потрібне.",
                Weight = 5,
                PenaltyFactor = pendingReboot ? 0.3 : 0,
                Action = pendingReboot ? "reboot" : null
            });
        }
        catch { }

        // ---------- Батарея (лише ноутбуки) ----------
        try
        {
            using var ps = new System.Diagnostics.Process();
            var hasBattery = System.Windows.Forms.SystemInformation.PowerStatus.BatteryChargeStatus != System.Windows.Forms.BatteryChargeStatus.NoSystemBattery;
            if (hasBattery)
            {
                var ps2 = System.Windows.Forms.SystemInformation.PowerStatus;
                var pct = (int)Math.Round(ps2.BatteryLifePercent * 100f);
                var charging = ps2.PowerLineStatus == System.Windows.Forms.PowerLineStatus.Online;
                checks.Add(new HealthCheck
                {
                    Key = "battery",
                    Title = "Батарея",
                    Status = pct >= 20 || charging ? "ok" : "warn",
                    Value = $"{pct}%{(charging ? " · заряджається" : "")}",
                    Detail = pct < 20 && !charging ? "Батарея розряджається — підключіть живлення." : "Нормально.",
                    Weight = 5,
                    PenaltyFactor = pct >= 20 || charging ? 0 : 0.3
                });
            }
        }
        catch { }

        // ---------- Підрахунок оцінки ----------
        double maxWeight = checks.Sum(c => c.Weight);
        double lost = checks.Sum(c => c.Weight * Math.Clamp(c.PenaltyFactor, 0, 1));
        int score = maxWeight > 0 ? (int)Math.Round((1.0 - lost / maxWeight) * 100.0) : 100;
        score = Math.Clamp(score, 3, 100);
        report.Score = score;
        report.Verdict = score >= 85 ? "ПК у чудовому стані" : score >= 65 ? "Усе працює, але є що покращити" : score >= 40 ? "ПК потребує уваги" : "ПК потребує ОБСЛУГОВУВАННЯ";
        report.Checks = checks;
        return report;
    }

    private static string FormatBytes(long b)
    {
        if (b >= 1073741824L) return $"{b / 1073741824.0:0.0} ГБ";
        if (b >= 1048576L) return $"{b / 1048576.0:0} МБ";
        return $"{b / 1024.0:0} КБ";
    }

    private static List<(string name, bool enabled)> WmiString(string ns, string query)
    {
        var list = new List<(string, bool)>();
        using var searcher = new System.Management.ManagementObjectSearcher(ns, query);
        foreach (var o in searcher.Get())
        {
            var name = o["displayName"]?.ToString() ?? "Антивірус";
            // productState: bit 0x1000 = enabled (стан 266144/266160 типово)
            var state = Convert.ToInt32(o["productState"]);
            bool enabled = ((state >> 12) & 0xF) != 0;
            list.Add((name, enabled));
        }
        return list;
    }

    private static bool RegistryPendingReboot()
    {
        try
        {
            using var key = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending");
            if (key != null) return true;
            using var key2 = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired");
            if (key2 != null) return true;
        }
        catch { }
        return false;
    }

    private static long DirSize(DirectoryInfo dir)
    {
        long total = 0;
        try
        {
            foreach (var f in dir.EnumerateFiles()) { try { total += f.Length; } catch { } }
            foreach (var d in dir.EnumerateDirectories())
            {
                try { if ((d.Attributes & FileAttributes.ReparsePoint) == 0) total += DirSize(d); } catch { }
            }
        }
        catch { }
        return total;
    }

    private static long EstimateRecycleBin()
    {
        long total = 0;
        try
        {
            var profile = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            var driveRoot = Path.GetPathRoot(profile) ?? "C:\\";
            var bin = Path.Combine(driveRoot, "$Recycle.Bin");
            if (Directory.Exists(bin))
            {
                var di = new DirectoryInfo(bin);
                foreach (var f in di.EnumerateFiles("*", SearchOption.AllDirectories))
                {
                    try { total += f.Length; } catch { }
                }
            }
        }
        catch { }
        return total;
    }
}
