using System.Collections.Concurrent;
using System.IO;
using System.IO.Compression;
using System.Runtime.InteropServices;

namespace FluxControl.Agent.Services;

/// <summary>
/// «Поділитися» (ТЗ): у контекстному меню файлу/папки на сайті генерується
/// СПЕЦІАЛЬНЕ ПОСИЛАННЯ. Друг відкриває його на телефоні → бачить назву файла
/// і кнопку «Скачати»; папка автоматично пакується в ZIP.
///
/// ЖИТТЯ ПОСИЛАННЯ (ТЗ): поки працює програма-агент. Токени живуть у пам'яті
/// (перезапуск агента → посилання мертві) і не діють, якщо файл видалено.
/// Реєстрація токенів на сервері повторюється при кожному реконекті агента.
///
/// Потік даних: сервер шле share_stream_begin → агент читає файл (або пакує
/// папку в тимчасовий ZIP) і шле share_chunk (base64, ~384КБ) → сервер
/// проксує байти у HTTP-відповідь друга.
/// </summary>
public class ShareService
{
    public sealed class ShareEntry
    {
        public string Token = string.Empty;
        public string Path = string.Empty;
        public string Name = string.Empty;
        public bool IsDir;
        public long SizeBytes;
        public DateTime CreatedAt = DateTime.UtcNow;
    }

    // token → запис (пам'ять процесу = сеансове життя посилань, ТЗ).
    private readonly ConcurrentDictionary<string, ShareEntry> _shares = new();

    // Активні стріми: streamId → флаг скасування.
    private readonly ConcurrentDictionary<string, bool> _cancelStreams = new();

    // 256 КБ сирого файлу -> ~341 КБ base64: безпечно вміщається у bind-параметр
    // D1 (ліміт ~1 МБ) для крос-ізолятного стріму через share_chunks.
    public const int ChunkBytes = 256 * 1024;

    public ShareEntry? Create(string path)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(path)) return null;
            bool isDir = Directory.Exists(path);
            bool isFile = File.Exists(path);
            if (!isDir && !isFile) return null; // видалені шляхи не шеремо (ТЗ)

            var entry = new ShareEntry
            {
                Token = Guid.NewGuid().ToString("N"), // 32 hex — довге «спеціальне» посилання
                Path = path,
                Name = Path.GetFileName(path.TrimEnd(Path.DirectorySeparatorChar)),
                IsDir = isDir,
                SizeBytes = isDir ? 0 : new FileInfo(path).Length
            };
            if (string.IsNullOrEmpty(entry.Name)) entry.Name = "share";
            _shares[entry.Token] = entry;

            // Гігієна: не більше 50 активних посилань — старіші прибираємо.
            if (_shares.Count > 50)
            {
                foreach (var oldest in _shares.Values.OrderBy(s => s.CreatedAt).Take(_shares.Count - 50).ToList())
                {
                    _shares.TryRemove(oldest.Token, out _);
                }
            }
            return entry;
        }
        catch { return null; }
    }

    public bool Remove(string token) => !string.IsNullOrEmpty(token) && _shares.TryRemove(token, out _);

    public ShareEntry? Get(string token) =>
        !string.IsNullOrEmpty(token) && _shares.TryGetValue(token, out var e) ? e : null;

    /// <summary>Усі активні токени (для реєстрації на сервері після реконекту).</summary>
    public List<ShareEntry> All() => _shares.Values.ToList();

    public void CancelStream(string streamId) =>
        _cancelStreams[streamId] = true;

    /// <summary>
    /// Потік файлу/папки-у-ZIP: шле base64-частини через send(). Повертає false,
    /// якщо стрім скасовано або джерело зникло.
    /// </summary>
    public async Task<bool> StreamAsync(string token, string streamId,
        Func<object, Task> send, CancellationToken ct)
    {
        var entry = Get(token);
        if (entry == null) return false;
        _cancelStreams[streamId] = false;

        string? tempZip = null;
        try
        {
            string sourcePath = entry.Path;
            long declaredTotal = 0;

            if (entry.IsDir)
            {
                // Папка → тимчасовий ZIP (ТЗ: «папка автоматично пакується»).
                tempZip = Path.Combine(Path.GetTempPath(), $"fluxshare_{Guid.NewGuid():N}.zip");
                declaredTotal = await Task.Run(() => ZipDirectory(entry.Path, tempZip), ct);
                sourcePath = tempZip;
            }
            else
            {
                if (!File.Exists(sourcePath)) return false; // файл видалили → посилання мертве (ТЗ)
                declaredTotal = new FileInfo(sourcePath).Length;
            }

            await send(new { type = "share_stream_meta", data = new { streamId, totalBytes = declaredTotal } });

            var buffer = new byte[ChunkBytes];
            long sentBytes = 0;
            using (var fs = new FileStream(sourcePath, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                int read;
                int seq = 0;
                while ((read = await fs.ReadAsync(buffer.AsMemory(0, buffer.Length), ct)) > 0)
                {
                    if (_cancelStreams.TryGetValue(streamId, out var cancelled) && cancelled) return false;
                    ct.ThrowIfCancellationRequested();

                    var chunk = new byte[read];
                    Buffer.BlockCopy(buffer, 0, chunk, 0, read);
                    await send(new
                    {
                        type = "share_chunk",
                        data = new
                        {
                            streamId,
                            seq,
                            data = Convert.ToBase64String(chunk),
                            sentBytes = sentBytes + read,
                            totalBytes = declaredTotal,
                            last = fs.Position >= fs.Length
                        }
                    });
                    sentBytes += read;
                    seq++;
                    // Мікропауза, щоб не затопити WS-чергу (на повільних каналах).
                    await Task.Delay(15, ct);
                }
            }

            await send(new { type = "share_chunk_end", data = new { streamId, ok = true } });
            return true;
        }
        catch (Exception ex)
        {
            try { await send(new { type = "share_chunk_end", data = new { streamId, ok = false, error = ex.Message } }); } catch { }
            return false;
        }
        finally
        {
            _cancelStreams.TryRemove(streamId, out _);
            if (tempZip != null)
            {
                try { File.Delete(tempZip); } catch { }
            }
        }
    }

    /// <summary>Пакує папку в ZIP (best-effort; повертає розмір архіву).</summary>
    private static long ZipDirectory(string dir, string zipPath)
    {
        // zipPath ще не існує → create.
        using (var archive = ZipFile.Open(zipPath, ZipArchiveMode.Create))
        {
            var root = new DirectoryInfo(dir);
            foreach (var f in root.EnumerateFiles("*", SearchOption.AllDirectories))
            {
                try
                {
                    var rel = Path.GetRelativePath(root.FullName, f.FullName);
                    archive.CreateEntryFromFile(f.FullName, rel, CompressionLevel.Fastest);
                }
                catch { /* locked/permission — пропускаємо файл */ }
            }
        }
        return new FileInfo(zipPath).Length;
    }

    // ================= КОШИК (ТЗ: швидкий доступ → Корзина) =================

    /// <summary>
    /// Вміст Корзини через Shell.Application (NameSpace(0xA)): кожен елемент
    /// має Name, Path (реальний $R-файл на диску!) і «відновлено з». По $R-шляху
    /// можна навіть скачати файл стандартним fs_download_file.
    /// </summary>
    public List<object> ListTrash()
    {
        var list = new List<object>();
        try
        {
            var shellType = Type.GetTypeFromProgID("Shell.Application");
            if (shellType == null) return list;
            dynamic? shell = Activator.CreateInstance(shellType);
            if (shell == null) return list;
            dynamic? folder = shell!.NameSpace(0xA); // ssfBITBUCKET
            if (folder == null) return list;

            foreach (var item in folder!.Items())
            {
                try
                {
                    string name = (string)item.Name;
                    string path = (string)item.Path; // C:\$Recycle.Bin\SID\$Rxxxx
                    long size = 0;
                    DateTime deleted = DateTime.MinValue;
                    string from = string.Empty;
                    try { deleted = (DateTime)folder.GetDetailsOf(item, 2); } catch { }
                    try { from = (string)folder.GetDetailsOf(item, 1); } catch { }
                    try { if (File.Exists(path)) size = new FileInfo(path).Length; } catch { }
                    list.Add(new
                    {
                        name = string.IsNullOrEmpty(name) ? Path.GetFileName(path) : name,
                        path,
                        originalLocation = from,
                        deletedAt = deleted == DateTime.MinValue ? null : (DateTime?)deleted,
                        sizeBytes = size
                    });
                }
                catch { }
            }
        }
        catch (Exception ex)
        {
            App.Log($"[Share] trash list failed: {ex.Message}");
        }
        return list;
    }

    /// <summary>Очистити Корзину (SHEmptyRecycleBin).</summary>
    public (bool ok, string error) EmptyTrash()
    {
        try
        {
            // SHERB_NOCONFIRMATION | SHERB_NOPROGRESSUI | SHERB_NOSOUND
            var res = SHEmptyRecycleBin(IntPtr.Zero, null, 0x00000001 | 0x00000002 | 0x00000004);
            return res == 0 || res == unchecked((int)0xFFFFFFFF) // 0 or E_UNEXPECTED(empty)
                ? (true, string.Empty)
                : (false, $"Код помилки: 0x{res:X}");
        }
        catch (Exception ex)
        {
            return (false, ex.Message);
        }
    }

    [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
    private static extern int SHEmptyRecycleBin(IntPtr hwnd, string? rootPath, uint flags);
}
