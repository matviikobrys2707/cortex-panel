using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FluxControl.Agent.Services;

/// <summary>
/// Тихий оновлювач програми (спільна логіка для всіх шляхів оновлення).
///
/// Основний шлях — БЕЗ cmd/bat-скриптів (taskkill-цикли + самовидаляючийся
/// .cmd — класичний тригер AV-евристики). Використовується особливість
/// Windows: ЗАПУЩЕНИЙ exe не можна видалити/записати, але можна
/// ПЕРЕЙМЕНУВАТИ/ПЕРЕНЕСТИ. Потік (ТЗ: «старий мусор не має бути видно»):
///   1) поточний запущений exe ПЕРЕНОСИМО у %TEMP% як
///      FluxControl.stale-&lt;pid&gt;.exe (той самий том → миттєво; файл
///      ніхто не бачить на робочому столі, новий процес його дочистить);
///      якщо TEMP на іншому томі — перейменування поруч у FluxControl.old.exe
///      + атрибут Hidden, щоб він не світився на робочому столі;
///   2) завантажений новий exe → FluxControl.exe (copy);
///   3) старт нового процесу з --waitForUpdate: він ЧЕКАЄ, поки цей процес
///      вийде і звільнить single-instance м'ютекс (раніше новий екземпляр
///      бачив зайнятий м'ютекс, сигнал «покажи вікно» — і одразу виходив:
///      «програма закрилась, нічого не запустилось»).
/// Видалення .old/stale робить НОВИЙ процес (App.CleanupOldExeWithRetry)
/// з ретраями до ~48с. Ніяких залишків не лишається.
/// Якщо перенос/копіювання не вдався — резервний легасі cmd-шлях.
/// </summary>
public static class UpdateInstaller
{
    /// <summary>
    /// Запускає оновлення (move-swap) і повертає керування одразу.
    /// extraArgs (ТЗ 53) — аргументи, які успадковує НОВИЙ процес: "--minimized"
    /// (автозапуск Windows → після оновлення знову старт у трей, без GUI) або
    /// порожній рядок (вікно було відкритим → після оновлення показати GUI).
    /// </summary>
    public static void Launch(string newExePath, string? extraArgs = null)
    {
        try
        {
            var target = AppContext.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
            var exeName = "FluxControl.exe";
            try
            {
                var main = System.Diagnostics.Process.GetCurrentProcess().MainModule?.FileName;
                if (!string.IsNullOrEmpty(main)) exeName = Path.GetFileName(main);
            }
            catch { }

            var currentExe = Path.Combine(target, exeName);
            var dotnetRoot = Environment.GetEnvironmentVariable("DOTNET_ROOT") ?? string.Empty;

            // 0) стара спроба могла лишити видимий .old поруч — прибираємо одразу
            try
            {
                var staleOld = Path.Combine(target, "FluxControl.old.exe");
                if (File.Exists(staleOld))
                {
                    File.SetAttributes(staleOld, FileAttributes.Normal);
                    File.Delete(staleOld);
                }
            }
            catch { }

            // 1) прибираємо запущений exe ГЕТЬ з теки програми: перенос у %TEMP%
            //    (той самий том → миттєве перейменування; видалити запущений
            //    неможливо, але перемістити — можна). Фолбек: перейменування
            //    поруч + Hidden — на робочому столі він більше НЕ з'явиться.
            var staleTemp = Path.Combine(Path.GetTempPath(), $"FluxControl.stale-{Environment.ProcessId}.exe");
            try { File.Delete(staleTemp); } catch { }
            try
            {
                File.Move(currentExe, staleTemp);
                App.Log($"Update: running exe moved out of app dir → {staleTemp}");
            }
            catch (Exception moveEx)
            {
                // різні томи (TEMP на іншому диску) — ховаємо поруч як .old
                var oldExe = Path.Combine(target, "FluxControl.old.exe");
                File.Move(currentExe, oldExe, overwrite: true);
                try { File.SetAttributes(oldExe, FileAttributes.Hidden | FileAttributes.System); } catch { }
                App.Log($"Update: move to TEMP failed ({moveEx.Message}) — hidden .old.exe fallback");
            }

            // 2) новий exe на місце поточного
            File.Copy(newExePath, currentExe, overwrite: true);

            // 3) старт нового процесу з --waitForUpdate (успадковує env;
            //    DOTNET_ROOT переносимо явно). Новий екземпляр чекає звільнення
            //    м'ютекса замість миттєвого виходу — фікс «стару закрило,
            //    нову не запустило».
            var psi = new System.Diagnostics.ProcessStartInfo
            {
                FileName = currentExe,
                UseShellExecute = false,
                WorkingDirectory = target,
                Arguments = string.IsNullOrWhiteSpace(extraArgs) ? "--waitForUpdate" : $"--waitForUpdate {extraArgs.Trim()}"
            };
            if (!string.IsNullOrEmpty(dotnetRoot))
                psi.EnvironmentVariables["DOTNET_ROOT"] = dotnetRoot;
            System.Diagnostics.Process.Start(psi);

            try { File.Delete(newExePath); } catch { }
            App.Log($"Update: move-swap done newExe={newExePath} target={target} exe={exeName} dotnetRoot={dotnetRoot}");
        }
        catch (Exception ex)
        {
            App.Log($"Update: move-swap failed ({ex.Message}) — fallback to legacy cmd updater");
            LaunchLegacyCmdUpdater(newExePath, extraArgs);
        }
    }

    /// <summary>
    /// Резервний легасі-шлях (лише якщо rename-swap не вдався): автономний
    /// cmd-скрипт у %TEMP% чекає завершення процесу, підмінює exe, стартує.
    /// Аргументи: &lt;newExe&gt; &lt;targetDir&gt; &lt;mainPid&gt; [dotnetRoot] [exeName]
    /// </summary>
    private const string UpdaterScript =
@"@echo off
rem FluxControl silent updater (single-file exe swap). Args: <newExe> <targetDir> <mainPid> [dotnetRoot] [exeName]
setlocal EnableExtensions EnableDelayedExpansion
set ""NEW=%~1""
set ""DST=%~2""
set ""APP_PID=%~3""
set ""LOCAL_DOTNET=%~4""
if not ""%LOCAL_DOTNET%""=="""" set ""DOTNET_ROOT=%LOCAL_DOTNET%""
set ""APP=%DST%\FluxControl.exe""
if not ""%~5""=="""" set ""APP=%DST%\%~5""

set /a N=0
:waitloop
tasklist /FI ""PID eq %APP_PID%"" 2>nul | find /I ""%APP_PID%"" >nul
if errorlevel 1 goto donewait
set /a N+=1
if !N! GEQ 12 (
  taskkill /F /PID %APP_PID% >nul 2>&1
  goto donewait
)
ping -n 2 127.0.0.1 >nul
goto waitloop
:donewait
ping -n 3 127.0.0.1 >nul
if exist ""%DST%\FluxControl.old.exe"" attrib -h -s ""%DST%\FluxControl.old.exe"" >nul 2>&1
if exist ""%DST%\FluxControl.old.exe"" del /F /Q ""%DST%\FluxControl.old.exe"" >nul 2>&1
move /y ""%APP%"" ""%DST%\FluxControl.old.exe"" >nul 2>&1
if exist ""%DST%\FluxControl.old.exe"" attrib +h ""%DST%\FluxControl.old.exe"" >nul 2>&1
copy /y ""%NEW%"" ""%APP%"" >nul 2>&1
if exist ""%APP%"" (
  attrib -h -s ""%DST%\FluxControl.old.exe"" >nul 2>&1
  del /F /Q ""%DST%\FluxControl.old.exe"" >nul 2>&1
) else (
  if exist ""%DST%\FluxControl.old.exe"" attrib -h -s ""%DST%\FluxControl.old.exe"" >nul 2>&1
  if exist ""%DST%\FluxControl.old.exe"" move /y ""%DST%\FluxControl.old.exe"" ""%APP%"" >nul 2>&1
)
del /F /Q ""%NEW%"" >nul 2>&1
start """" ""%APP%"" --waitForUpdate %~6
(goto) 2>nul & del ""%~f0""
";

    private static void LaunchLegacyCmdUpdater(string newExePath, string? extraArgs = null)
    {
        try
        {
            var bat = Path.Combine(Path.GetTempPath(), "FluxControl_updater.cmd");
            File.WriteAllText(bat, UpdaterScript, Encoding.ASCII);

            var target = AppContext.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
            var pid = Environment.ProcessId;
            var dotnetRoot = Environment.GetEnvironmentVariable("DOTNET_ROOT") ?? string.Empty;
            var exeName = "FluxControl.exe";
            try
            {
                var main = System.Diagnostics.Process.GetCurrentProcess().MainModule?.FileName;
                if (!string.IsNullOrEmpty(main)) exeName = Path.GetFileName(main);
            }
            catch { }
            App.Log($"Update: legacy updater bat={bat} newExe={newExePath} target={target} pid={pid} dotnetRoot={dotnetRoot} exe={exeName}");

            var psi = new System.Diagnostics.ProcessStartInfo
            {
                FileName = bat,
                // %~6 — додаткові аргументи нового процесу (напр. --minimized, ТЗ 53)
                Arguments = $"\"{newExePath}\" \"{target}\" {pid} \"{dotnetRoot}\" \"{exeName}\" \"{(extraArgs ?? string.Empty).Trim()}\"",
                UseShellExecute = false,
                CreateNoWindow = true,
                WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden
            };
            System.Diagnostics.Process.Start(psi);
        }
        catch (Exception ex)
        {
            App.Log($"Update: failed to launch legacy updater: {ex}");
        }
    }

    /// <summary>
    /// Легасі-формат релізу: zip із FluxControl.exe всередині. Витягуємо exe
    /// в %TEMP% — його підміняє updater. Голий .exe використовується як є.
    /// </summary>
    public static Task<string> ExtractExeFromZipAsync(string zipPath)
        => Task.Run(() => ExtractExeFromZip(zipPath));

    public static string ExtractExeFromZip(string zipPath)
    {
        var destDir = Path.Combine(Path.GetTempPath(), "FluxControl-update-" + Guid.NewGuid().ToString("N").Substring(0, 8));
        Directory.CreateDirectory(destDir);
        using (var fs = File.OpenRead(zipPath))
        using (var za = new ZipArchive(fs, ZipArchiveMode.Read))
        {
            // 1) точне ім'я в корені архіву, 2) будь-який *.exe у корені (фолбек)
            var entry = za.GetEntry("FluxControl.exe")
                       ?? za.Entries.FirstOrDefault(e =>
                            e.FullName.IndexOf('/') < 0 &&
                            e.FullName.EndsWith(".exe", StringComparison.OrdinalIgnoreCase));
            if (entry == null)
                throw new InvalidOperationException("В архіві оновлення не знайдено FluxControl.exe");

            var dest = Path.Combine(destDir, "FluxControl.exe");
            using (var es = entry.Open())
            using (var ofs = new FileStream(dest, FileMode.Create, FileAccess.Write, FileShare.None))
                es.CopyTo(ofs);

            App.Log($"Update: extracted agent exe from zip → {dest} ({new FileInfo(dest).Length} bytes)");
            return dest;
        }
    }
}
