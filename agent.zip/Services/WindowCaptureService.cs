using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Text;

namespace FluxControl.Agent.Services;

/// <summary>
/// Перегляд вікон ПК (ТЗ: «на ПК хтось працює, а я через сайт роблю скріншот/
/// міністрім потрібного вікна — гри — не виходячи її на передній план»).
///  • список видимих вікон: EnumWindows + DWMWA_CLOAKED (виключає сховані UWP);
///  • знімок вікна БЕЗ активації: PrintWindow(PW_RENDERFULLCONTENT) — працює
///    навіть коли вікно перекрите іншими (для більшості застосунків і ігор
///    у windowed/borderless режимі).
/// </summary>
public static class WindowCaptureService
{
    public class WindowEntry
    {
        public long Hwnd { get; set; }
        public string Title { get; set; } = string.Empty;
        public string Process { get; set; } = string.Empty;
        public bool Minimized { get; set; }
    }

    public static List<WindowEntry> GetVisibleWindows()
    {
        var list = new List<WindowEntry>();
        var selfPid = Environment.ProcessId;
        try
        {
            EnumWindows((hWnd, lParam) =>
            {
                try
                {
                    if (!IsWindowVisible(hWnd)) return true;
                    // ТЗ-ФІКС «показує одне вікно»: ЗГОРНУТІ вікна більше НЕ
                    // викидаються — вони теж у списку (прапор Minimized), бо
                    // саме вони найчастіше і потрібні для перегляду.
                    bool iconic = IsIconic(hWnd);

                    // Сховані UWP/офлайн вікна (virtual desktops, minimized-to-tray).
                    if (IsCloaked(hWnd)) return true;

                    var len = GetWindowTextLengthW(hWnd);
                    if (len <= 0) return true;
                    var sb = new StringBuilder(len + 1);
                    _ = GetWindowTextW(hWnd, sb, sb.Capacity);
                    var title = sb.ToString();
                    if (string.IsNullOrWhiteSpace(title)) return true;

                    // WS_EX_TOOLWINDOW — службові підказки/тултипи.
                    var exStyle = GetWindowLongW(hWnd, -20); // GWL_EXSTYLE
                    if ((exStyle & 0x80) != 0) return true;  // WS_EX_TOOLWINDOW

                    _ = GetWindowThreadProcessId(hWnd, out uint pid);
                    if (pid == 0 || pid == (uint)selfPid) return true; // власні вікна агента

                    string processName;
                    try
                    {
                        using var p = Process.GetProcessById((int)pid);
                        processName = p.ProcessName;
                    }
                    catch { processName = $"pid{pid}"; }

                    // Рівні-сторожа: вікна десктопу/шеллу не показуємо.
                    if (processName is "ExplorerWorker" or "SearchHost" or "ShellExperienceHost" or "StartMenuExperienceHost") return true;

                    list.Add(new WindowEntry
                    {
                        Hwnd = hWnd.ToInt64(),
                        Title = title.Trim(),
                        Process = processName,
                        Minimized = iconic
                    });
                }
                catch { }
                return true;
            }, IntPtr.Zero);
        }
        catch (Exception ex)
        {
            App.Log($"[WinCap] enum failed: {ex.Message}");
        }

        return list
            .OrderBy(w => w.Minimized ? 1 : 0) // розгорнуті зверху списку
            .Take(80)
            .ToList();
    }

    /// <summary>
    /// Знімок вікна без фокусу/переміщення. quality 1..100 (JPEG), maxWidth —
    /// даунскейл (0 = як є). Повертає base64 JPEG або null при невдачі.
    /// DPI-фікси (ТЗ «перегляд вікон не працював»): на масштабованих екранах
    /// (125/150%) координати віртуалізуються → чорні/обрізані кадри. Тут
    /// пер-моніторний DPI-контекст + подвійна спроба PrintWindow.
    /// </summary>
    public static string? CaptureWindowBase64(long hwnd, int quality = 70, int maxWidth = 1600)
    {
        try
        {
            var hWnd = new IntPtr(hwnd);
            if (!IsWindow(hWnd)) return null;

            // Пер-моніторний DPI: без цього GetClientRect дає віртуалізовані
            // розміри і PrintWindow малює лише частину вікна.
            var prevCtx = SetThreadDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);
            try
            {
                return CaptureCore(hWnd, quality, maxWidth);
            }
            finally
            {
                if (prevCtx != IntPtr.Zero) _ = SetThreadDpiAwarenessContext(prevCtx);
            }
        }
        catch (Exception ex)
        {
            App.Log($"[WinCap] capture failed: {ex.Message}");
            return null;
        }
    }

    private static string? CaptureCore(IntPtr hWnd, int quality, int maxWidth)
    {
        try
        {
            _ = GetClientRect(hWnd, out RECT rc);
            int width = rc.Right - rc.Left;
            int height = rc.Bottom - rc.Top;
            if (width <= 0 || height <= 0)
            {
                _ = GetWindowRect(hWnd, out RECT wr);
                width = wr.Right - wr.Left;
                height = wr.Bottom - wr.Top;
                if (width <= 0 || height <= 0) return null;
            }

            // ТЗ-ФІКС «знімок недоступний»: остання надія — примарне розгортання
            // БЕЗ фокуса (SW_SHOWNOACTIVATE не краде активність) на ~120мс,
            // знімок, і повернення у згорнутий стан. Вікно лише блимне на
            // місці — на передній план з фокусом НЕ виходить.
            bool wasMinimized = IsIconic(hWnd);
            if (wasMinimized)
            {
                try
                {
                    _ = ShowWindowAsync(hWnd, SW_SHOWNOACTIVATE);
                    System.Threading.Thread.Sleep(140);
                    _ = GetClientRect(hWnd, out RECT rc2);
                    int w2 = rc2.Right - rc2.Left, h2 = rc2.Bottom - rc2.Top;
                    if (w2 > 0 && h2 > 0) { width = w2; height = h2; }
                }
                catch { }
            }

            try
            {
            var hdcWindow = GetWindowDC(hWnd);
            if (hdcWindow == IntPtr.Zero) return null;
            try
            {
                using var bmp = new Bitmap(width, height, PixelFormat.Format32bppArgb);
                using (var g = Graphics.FromImage(bmp))
                {
                    var hdcDest = g.GetHdc();
                    try
                    {
                        // PW_RENDERFULLCONTENT (2) — захоплює DirectComposition/Chrome/DX вікна.
                        bool ok = PrintWindow(hWnd, hdcDest, 2);
                        if (!ok)
                        {
                            // Друга спроба без прапора (старіші вікна не приймають
                            // PW_RENDERFULLCONTENT і повертають false).
                            ok = PrintWindow(hWnd, hdcDest, 0);
                        }
                        if (!ok)
                        {
                            // Фолбек: BitBlt того, що реально видно на екрані.
                            _ = BitBlt(hdcDest, 0, 0, width, height, hdcWindow, 0, 0, 0x00CC0020 /*SRCCOPY*/);
                        }
                    }
                    finally { g.ReleaseHdc(hdcDest); }
                }

                // Даунскейл до maxWidth для швидшої передачі.
                using var outBmp = (maxWidth > 0 && width > maxWidth)
                    ? new Bitmap(bmp, new Size(maxWidth, Math.Max(1, height * maxWidth / width)))
                    : bmp;

                using var ms = new MemoryStream();
                var jpegCodec = GetEncoder(ImageFormat.Jpeg);
                using var encParams = new EncoderParameters(1);
                encParams.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, (long)Math.Clamp(quality, 30, 95));
                if (jpegCodec != null) outBmp.Save(ms, jpegCodec, encParams);
                else outBmp.Save(ms, ImageFormat.Jpeg);

                return "data:image/jpeg;base64," + Convert.ToBase64String(ms.ToArray());
            }
            finally { _ = ReleaseDC(hWnd, hdcWindow); }
            }
            finally
            {
                // Повертаємо вікно у згорнутий стан, якщо воно було згорнутим.
                if (wasMinimized)
                {
                    try { _ = ShowWindowAsync(hWnd, SW_FORCEMINIMIZE); } catch { }
                }
            }
        }
        catch (Exception ex)
        {
            App.Log($"[WinCap] capture failed: {ex.Message}");
            return null;
        }
    }

    private static ImageCodecInfo? GetEncoder(ImageFormat format)
    {
        try
        {
            var codecs = ImageCodecInfo.GetImageEncoders();
            foreach (var c in codecs)
                if (c.FormatID == format.Guid) return c;
        }
        catch { }
        return null;
    }

    // ---------------------------------------------------------------- Win32

    private delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

    [DllImport("user32.dll")]
    private static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);

    [DllImport("user32.dll")]
    private static extern bool IsWindowVisible(IntPtr hWnd);

    [DllImport("user32.dll")]
    private static extern bool IsIconic(IntPtr hWnd);

    [DllImport("user32.dll")]
    private static extern bool IsWindow(IntPtr hWnd);

    [DllImport("user32.dll")]
    private static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);

    private const int SW_SHOWNOACTIVATE = 4;
    private const int SW_FORCEMINIMIZE = 11;

    [DllImport("user32.dll")]
    private static extern int GetWindowTextLengthW(IntPtr hWnd);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int GetWindowTextW(IntPtr hWnd, StringBuilder text, int maxCount);

    [DllImport("user32.dll")]
    private static extern int GetWindowLongW(IntPtr hWnd, int nIndex);

    [DllImport("user32.dll")]
    private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);

    [DllImport("user32.dll")]
    private static extern IntPtr GetWindowDC(IntPtr hWnd);

    [DllImport("user32.dll")]
    private static extern int ReleaseDC(IntPtr hWnd, IntPtr hDc);

    [DllImport("user32.dll")]
    private static extern bool GetClientRect(IntPtr hWnd, out RECT rect);

    [DllImport("user32.dll")]
    private static extern bool GetWindowRect(IntPtr hWnd, out RECT rect);

    [DllImport("user32.dll")]
    private static extern bool PrintWindow(IntPtr hWnd, IntPtr hdcBlt, uint nFlags);

    [DllImport("gdi32.dll")]
    private static extern bool BitBlt(IntPtr hdcDest, int x, int y, int w, int h, IntPtr hdcSrc, int x1, int y1, int rop);

    [DllImport("dwmapi.dll")]
    private static extern int DwmGetWindowAttribute(IntPtr hwnd, int attr, out int attrValue, int attrSize);

    // DPI-фікси захоплення (Win10 1803+).
    [DllImport("user32.dll")]
    private static extern IntPtr SetThreadDpiAwarenessContext(IntPtr dpiContext);

    private static readonly IntPtr DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2 = new(-4);

    private const int DWMWA_CLOAKED = 14;

    private static bool IsCloaked(IntPtr hWnd)
    {
        try
        {
            if (DwmGetWindowAttribute(hWnd, DWMWA_CLOAKED, out int cloaked, sizeof(int)) == 0)
                return cloaked != 0;
        }
        catch { }
        return false;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct RECT
    {
        public int Left;
        public int Top;
        public int Right;
        public int Bottom;
    }
}
