using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace FluxControl.Agent.Services;

/// <summary>Одна категорія очищення (кошик, temp, кеш браузера…).</summary>
public class CleanupCategoryDto
{
    public string Key { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public string Path { get; set; } = string.Empty;
    public long SizeBytes { get; set; }
    public long FileCount { get; set; }
    /// <summary>Позначка «за замовчуванням вибрано» (корзина/temp — так, системні речі — ні).</summary>
    public bool DefaultSelected { get; set; } = true;
    /// <summary>Категорію знайшло «Умне сканування» (ШІ) — на сайті має хрестик для видалення.</summary>
    public bool FromAi { get; set; }
}

public class CleanupScanDto
{
    public List<CleanupCategoryDto> Categories { get; set; } = new();
    public long TotalBytes { get; set; }
    public double ScanMs { get; set; }
}

/// <summary>Результат очищення однієї категорії.</summary>
public class CleanupResultDto
{
    public string Key { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public long FreedBytes { get; set; }
    public string Error { get; set; } = string.Empty;
    public bool Ok => string.IsNullOrEmpty(Error);
}

public class CleanupRunDto
{
    public long FreedBytes { get; set; }
    public List<CleanupResultDto> Results { get; set; } = new();
    public string Message { get; set; } = string.Empty;
}

/// <summary>
/// «Очистка диска» (ТЗ, вкладка «Додаткове»): кошик Windows, тимчасові папки
/// юзера і Windows, кеші популярних програм (Chrome, Edge, Firefox, Discord,
/// Steam HTML, Explorer thumbnails). Скан рахує розміри, Clean видаляє вміст.
/// Жодних видалень поза переліченими категоріями; файли, зайняті системою,
/// просто пропускаються (без падінь). Завжди best-effort, ніколи не кидає.
/// </summary>
public class DiskCleanupService
{
    private static readonly string[] CacheSubDirs =
    {
        "Cache", "Cache_Data", "Code Cache", "GPUCache", "Service Worker\\CacheStorage"
    };

    private readonly HashSet<string> _scanKeys = new()
    {
        "recycle_bin", "user_temp", "windows_temp",
        "chrome_cache", "edge_cache", "firefox_cache", "discord_cache", "steam_htmlcache",
        "thumbnails", "directx_shader", "deliveropt", "crashdumps", "windows_old_logs"
    };

    // ================= УМНЕ СКАНУВАННЯ (ТЗ: ШІ шукає кеші по всьому ПК) =================

    private sealed class SavedAiItem
    {
        public string Key { get; set; } = string.Empty;
        public string Title { get; set; } = string.Empty;
        public string Path { get; set; } = string.Empty;
    }

    private static readonly string AiStoreFile =
        Path.Combine(RuntimeFiles.DataRoot, "cleanup_ai.json");

    /// <summary>Мінімальний розмір знайденої AI-категорії, щоб потрапити у список.</summary>
    private const long AiMinCategoryBytes = 25L * 1024 * 1024;

    private static readonly JsonSerializerOptions AiStoreJson = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        WriteIndented = false
    };

    /// <summary>
    /// «Умне сканування» (ТЗ): ШІ-евристика шукає на ПК папки-кеші та тимчасові
    /// дані (AppData усіх типів), додає їх у список очищення і ЗАПАМ'ЯТОВУє на
    /// диску — при наступних сканах вони вже в списку. Користувач може прибрати
    /// елемент зі списку (RemoveAiKeys) — більше не повернеться.
    /// </summary>
    public async Task<CleanupScanDto> SmartScanAsync()
    {
        var dto = new CleanupScanDto();
        await Task.Run(() =>
        {
            var sw = System.Diagnostics.Stopwatch.StartNew();
            var saved = LoadAiStore();
            var found = new Dictionary<string, SavedAiItem>(StringComparer.OrdinalIgnoreCase);

            // 1) Зберегті раніше елементи — пере-мірюємо, щоб список був актуальний.
            foreach (var item in saved)
            {
                if (!IsSafeAiPath(item.Path)) continue;
                if (Directory.Exists(item.Path)) found[item.Path] = item;
            }

            // 2) Пошук нових кешів у профілях користувача (Local/Roaming/LocalLow).
            var roots = new List<string>
            {
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            };
            try
            {
                var localLow = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "AppData", "LocalLow");
                if (Directory.Exists(localLow)) roots.Add(localLow);
            }
            catch { }

            foreach (var root in roots)
            {
                if (string.IsNullOrEmpty(root) || !Directory.Exists(root)) continue;
                foreach (var dir in EnumerateCandidateCacheDirs(root, maxDepth: 3))
                {
                    if (found.ContainsKey(dir.FullName)) continue;
                    var (bytes, files) = MeasureDir(dir.FullName);
                    if (bytes < AiMinCategoryBytes) continue;
                    found[dir.FullName] = new SavedAiItem
                    {
                        Key = AiKeyForPath(dir.FullName),
                        Title = BuildAiTitle(dir.FullName),
                        Path = dir.FullName
                    };
                }
            }

            // 3) Зберігаємо оновлений список (ТЗ: «запам'ятовує»).
            SaveAiStore(found.Values.OrderBy(v => v.Key).ToList());

            // 4) Формуємо DTO (пере-мір для збережених, свіжі вже з розмірами).
            foreach (var item in found.Values.Take(40))
            {
                try
                {
                    var (bytes, files) = MeasureDir(item.Path);
                    if (bytes <= 0) continue; // уже вичищено — не показуємо пустий
                    dto.Categories.Add(new CleanupCategoryDto
                    {
                        Key = item.Key,
                        Title = item.Title,
                        Description = item.Path,
                        Path = item.Path,
                        SizeBytes = bytes,
                        FileCount = files,
                        DefaultSelected = true,
                        FromAi = true
                    });
                    dto.TotalBytes += Math.Max(0, bytes);
                }
                catch { }
            }

            sw.Stop();
            dto.ScanMs = Math.Round(sw.Elapsed.TotalMilliseconds);
        });

        dto.Categories = dto.Categories.OrderByDescending(c => c.SizeBytes).ToList();
        return dto;
    }

    /// <summary>Прибрати AI-елементи зі списку (ТЗ: «нажать — і вони видаляться зі списку»).</summary>
    public void RemoveAiKeys(List<string> keys)
    {
        try
        {
            if (keys == null || keys.Count == 0) return;
            var saved = LoadAiStore();
            var remaining = saved.Where(s => !keys.Contains(s.Key, StringComparer.OrdinalIgnoreCase)).ToList();
            SaveAiStore(remaining);
            App.Log($"[DiskCleanup] AI list: removed {keys.Count}, kept {remaining.Count}");
        }
        catch { }
    }

    // ================= РЕАЛЬНИЙ ШІ-АНАЛІЗ (ТЗ «умна очистка»): огляд ПК =================

    /// <summary>Компактний огляд ПК для ШІ: диски + великі папки профілю + програми.</summary>
    public sealed class AiOverviewDto
    {
        public List<object> Drives { get; set; } = new();
        public List<object> BigFolders { get; set; } = new();
        public List<object> Programs { get; set; } = new();
    }

    /// <summary>
    /// Збирає структуру ПК для ШІ (ТЗ: «ШІ вивчав структуру самого ПК — які
    /// файли/папки займають найбільше місця, чи можна видалити»):
    ///  • диски (вільно/всього);
    ///  • топ-16 великих папок профілю (глибина 2);
    ///  • топ-16 найважчих папок програм (Program Files + AppData).
    /// Компактно — щоб запит до Gemini лишався малим.
    /// </summary>
    public async Task<AiOverviewDto> GatherAiOverviewAsync()
    {
        var dto = new AiOverviewDto();
        await Task.Run(() =>
        {
            try
            {
                foreach (var d in DriveInfo.GetDrives().Where(v => v.IsReady && v.DriveType == DriveType.Fixed).Take(4))
                {
                    dto.Drives.Add(new
                    {
                        name = d.Name,
                        freeGb = Math.Round(d.AvailableFreeSpace / 1024.0 / 1024 / 1024, 1),
                        totalGb = Math.Round(d.TotalSize / 1024.0 / 1024 / 1024, 1)
                    });
                }
            }
            catch { }

            var candidates = new List<(string Path, string Name)>();
            try
            {
                var profile = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
                foreach (var sub in new[] { "AppData\\Local", "AppData\\Roaming", "Downloads", "Documents", "Desktop", "Videos", "Pictures" })
                {
                    var p = Path.Combine(profile, sub);
                    if (Directory.Exists(p)) candidates.Add((p, sub));
                }
            }
            catch { }

            // Великі папки профілю: м cachові/сміттєві кандидат (глибина 2, топ-16).
            var folderSizes = new List<(string Path, long Bytes)>();
            foreach (var (rootPath, _) in candidates)
            {
                try
                {
                    foreach (var child in Directory.EnumerateDirectories(rootPath).Take(40))
                    {
                        try
                        {
                            var bytes = MeasureDirShallow(child, maxFiles: 4000);
                            if (bytes > 200L * 1024 * 1024) folderSizes.Add((child, bytes));
                        }
                        catch { }
                    }
                }
                catch { }
            }

            foreach (var (p, b) in folderSizes.OrderByDescending(x => x.Bytes).Take(16))
            {
                dto.BigFolders.Add(new { path = p, sizeGb = Math.Round(b / 1024.0 / 1024 / 1024, 2) });
            }

            // Програми (Program Files, топ-16 за розміром папки).
            var progRoots = new List<string>();
            try
            {
                progRoots.Add(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles));
                progRoots.Add(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86));
            }
            catch { }

            var progSizes = new List<(string Path, string Name, long Bytes)>();
            foreach (var root in progRoots)
            {
                if (string.IsNullOrEmpty(root) || !Directory.Exists(root)) continue;
                try
                {
                    foreach (var child in Directory.EnumerateDirectories(root).Take(60))
                    {
                        try
                        {
                            var bytes = MeasureDirShallow(child, maxFiles: 3000);
                            if (bytes > 150L * 1024 * 1024) progSizes.Add((child, Path.GetFileName(child), bytes));
                        }
                        catch { }
                    }
                }
                catch { }
            }
            foreach (var (p, n, b) in progSizes.OrderByDescending(x => x.Bytes).Take(16))
            {
                dto.Programs.Add(new { name = n, path = p, sizeGb = Math.Round(b / 1024.0 / 1024 / 1024, 2) });
            }
        });
        return dto;
    }

    /// <summary>Швидкий замір папки з стелею (щоб огляд не тривав хвилинами).</summary>
    private static long MeasureDirShallow(string dir, int maxFiles)
    {
        long total = 0;
        int count = 0;
        var stack = new Stack<string>();
        stack.Push(dir);
        while (stack.Count > 0 && count < maxFiles && total < 60L * 1024 * 1024 * 1024)
        {
            var cur = stack.Pop();
            try { foreach (var d in Directory.EnumerateDirectories(cur)) stack.Push(d); } catch { }
            try
            {
                foreach (var f in Directory.EnumerateFiles(cur))
                {
                    try { total += new FileInfo(f).Length; count++; } catch { }
                    if (count >= maxFiles) break;
                }
            }
            catch { }
        }
        return total;
    }

    /// <summary>
    /// Застосувати затверджені користувачем ШІ-поради (ТЗ: питав «можна
    /// видалити?» → користувач «Так»): додаємо шляхи у запам'ятований список.
    /// Повертає нові категорії для миттєвого показу на сайті.
    /// </summary>
    public List<CleanupCategoryDto> ApplyAiItems(List<(string Title, string Path)> items)
    {
        var result = new List<CleanupCategoryDto>();
        try
        {
            var saved = LoadAiStore();
            var known = new HashSet<string>(saved.Select(s => s.Path), StringComparer.OrdinalIgnoreCase);
            foreach (var (title, rawPath) in items)
            {
                try
                {
                    var path = Path.GetFullPath(rawPath);
                    if (!IsSafeAiPath(path)) continue;
                    if (!Directory.Exists(path) && !File.Exists(path)) continue;
                    if (known.Contains(path)) continue;

                    var entry = new SavedAiItem
                    {
                        Key = AiKeyForPath(path),
                        Title = string.IsNullOrWhiteSpace(title) ? BuildAiTitle(path) : title,
                        Path = path
                    };
                    saved.Add(entry);
                    known.Add(path);

                    long bytes = 0; long files = 0;
                    if (Directory.Exists(path)) (bytes, files) = MeasureDir(path);
                    else if (File.Exists(path)) { bytes = new FileInfo(path).Length; files = 1; }
                    if (bytes <= 0) continue;

                    result.Add(new CleanupCategoryDto
                    {
                        Key = entry.Key,
                        Title = entry.Title,
                        Description = path,
                        Path = path,
                        SizeBytes = bytes,
                        FileCount = files,
                        DefaultSelected = true,
                        FromAi = true
                    });
                }
                catch { }
            }
            SaveAiStore(saved);
        }
        catch { }
        return result;
    }

    /// <summary>Стабільний ключ категорії за шляхом: ai:xxxxxxxx.</summary>
    private static string AiKeyForPath(string path)
    {
        var bytes = MD5.HashData(Encoding.UTF8.GetBytes(path.ToLowerInvariant()));
        var sb = new StringBuilder("ai:");
        for (int i = 0; i < 4; i++) sb.Append(bytes[i].ToString("x2", CultureInfo.InvariantCulture));
        return sb.ToString();
    }

    /// <summary>«Discord · кеш», «npm-cache · тимчасові дані» — коротка людська назва.</summary>
    private static string BuildAiTitle(string path)
    {
        try
        {
            var parts = path.TrimEnd('\\').Split('\\');
            var name = parts.Length >= 2 ? parts[^2] : parts[^1];
            var lower = name.ToLowerInvariant();
            if (lower.Contains("cache")) return $"{name} · кеш";
            if (lower.Contains("temp") || lower.Contains("tmp")) return $"{name} · тимчасові файли";
            return $"{name} · знайдено ШІ";
        }
        catch { return "Кеш (знайдено ШІ)"; }
    }

    /// <summary>
    /// Кандидати: папки, в імені яких cache/temp/tmp (і нічого системного).
    /// Шукаємо тільки в профілях користувача — Program Files/Windows не чіпаємо.
    /// </summary>
    private IEnumerable<DirectoryInfo> EnumerateCandidateCacheDirs(string root, int maxDepth)
    {
        var queue = new Queue<(DirectoryInfo dir, int depth)>();
        try { queue.Enqueue((new DirectoryInfo(root), 0)); } catch { yield break; }

        while (queue.Count > 0)
        {
            var (dir, depth) = queue.Dequeue();
            DirectoryInfo[] children;
            try { children = dir.GetDirectories(); }
            catch { continue; }

            foreach (var child in children)
            {
                var n = child.Name.ToLowerInvariant();
                if (n.StartsWith("$")) continue;
                bool isCache = n.Contains("cache") || n.Contains("temp") || n.Contains("tmp");
                if (isCache && IsSafeAiPath(child.FullName) && !IsTempRoot(child.FullName))
                {
                    yield return child;
                    continue; // усередині кешу шукати глибші кеші — зайве
                }
                if (depth + 1 < maxDepth) queue.Enqueue((child, depth + 1));
            }
        }
    }

    /// <summary>Шлях безпечний для ШІ-очищення: лише профіль користувача, не наш сховище/система.</summary>
    private static bool IsSafeAiPath(string? path)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(path)) return false;
            var full = Path.GetFullPath(path).TrimEnd('\\').ToLowerInvariant();
            if (!full.Contains("\\appdata\\") && !full.Contains("\\users\\")) return false;
            if (full.Contains("\\windows\\") || full.Contains("program files")) return false;
            if (full.Contains(RuntimeFiles.DataRoot.ToLowerInvariant())) return false;
            if (full.EndsWith("\\temp") && full.Count(c => c == '\\') <= 4) return false; // %TEMP% — окрема категорія
            return true;
        }
        catch { return false; }
    }

    private static bool IsTempRoot(string path)
    {
        try { return string.Equals(Path.TrimEndingDirectorySeparator(Path.GetTempPath()), Path.TrimEndingDirectorySeparator(path), StringComparison.OrdinalIgnoreCase); }
        catch { return false; }
    }

    private List<SavedAiItem> LoadAiStore()
    {
        try
        {
            if (!File.Exists(AiStoreFile)) return new List<SavedAiItem>();
            var json = File.ReadAllText(AiStoreFile);
            return JsonSerializer.Deserialize<List<SavedAiItem>>(json, AiStoreJson) ?? new List<SavedAiItem>();
        }
        catch { return new List<SavedAiItem>(); }
    }

    private void SaveAiStore(List<SavedAiItem> items)
    {
        try
        {
            var dir = Path.GetDirectoryName(AiStoreFile);
            if (!string.IsNullOrEmpty(dir)) Directory.CreateDirectory(dir);
            File.WriteAllText(AiStoreFile, JsonSerializer.Serialize(items, AiStoreJson));
        }
        catch { }
    }

    public async Task<CleanupScanDto> ScanAsync()
    {
        var dto = new CleanupScanDto();
        await Task.Run(() =>
        {
            var sw = System.Diagnostics.Stopwatch.StartNew();
            foreach (var key in _scanKeys)
            {
                var cat = BuildCategory(key, scan: true);
                if (cat != null)
                {
                    dto.Categories.Add(cat);
                    dto.TotalBytes += Math.Max(0, cat.SizeBytes);
                }
            }
            sw.Stop();
            dto.ScanMs = Math.Round(sw.Elapsed.TotalMilliseconds);
        });
        dto.Categories = dto.Categories.OrderByDescending(c => c.SizeBytes).ToList();
        return dto;
    }

    public async Task<CleanupRunDto> CleanAsync(List<string>? keys)
    {
        // AI-категорії (ключ "ai:xxx") чистимо за збереженим шляхом (вміст папки);
        // звичайні — за захардкодженими правилами. ТЗ: без ручного додавання шляхів.
        var aiKeys = (keys ?? new List<string>()).Where(k => k != null && k.StartsWith("ai:", StringComparison.OrdinalIgnoreCase)).ToList();
        var wanted = (keys == null || keys.Count == 0)
            ? _scanKeys.ToList()
            : keys.Where(k => k != null && _scanKeys.Contains(k)).ToList();

        var run = new CleanupRunDto();

        await Task.Run(() =>
        {
            // --- звичайні категорії ---
            foreach (var key in wanted)
            {
                try
                {
                    long before = 0;
                    var cat = BuildCategory(key, scan: true);
                    if (cat != null) before = Math.Max(0, cat.SizeBytes);

                    var error = CleanCategory(key);

                    long after = 0;
                    var afterCat = error == null ? BuildCategory(key, scan: true) : null;
                    if (afterCat != null) after = Math.Max(0, afterCat.SizeBytes);

                    run.Results.Add(new CleanupResultDto
                    {
                        Key = key,
                        Title = cat?.Title ?? key,
                        FreedBytes = error == null ? Math.Max(0, before - after) : 0,
                        Error = error ?? string.Empty
                    });
                    if (error == null) run.FreedBytes += Math.Max(0, before - after);
                }
                catch (Exception ex)
                {
                    run.Results.Add(new CleanupResultDto { Key = key, Title = key, FreedBytes = 0, Error = ex.Message });
                }
            }

            // --- AI-категорії (вміст знайденої папки, тільки в безпечних шляхах) ---
            var saved = LoadAiStore();
            foreach (var aiKey in aiKeys)
            {
                var item = saved.FirstOrDefault(s => string.Equals(s.Key, aiKey, StringComparison.OrdinalIgnoreCase));
                if (item == null || !IsSafeAiPath(item.Path))
                {
                    run.Results.Add(new CleanupResultDto { Key = aiKey, Title = aiKey, FreedBytes = 0, Error = "Шлях не знайдено або він не безпечний" });
                    continue;
                }
                try
                {
                    long before = 0, files = 0;
                    try { (before, files) = MeasureDir(item.Path); } catch { }
                    var error = Directory.Exists(item.Path) ? CleanDirContents(item.Path) : "Папку вже видалено";
                    long after = 0;
                    try { (after, _) = MeasureDir(item.Path); } catch { }
                    run.Results.Add(new CleanupResultDto
                    {
                        Key = aiKey,
                        Title = item.Title,
                        FreedBytes = error == null ? Math.Max(0, before - after) : 0,
                        Error = error ?? string.Empty
                    });
                    if (error == null) run.FreedBytes += Math.Max(0, before - after);
                }
                catch (Exception ex)
                {
                    run.Results.Add(new CleanupResultDto { Key = aiKey, Title = item.Title, FreedBytes = 0, Error = ex.Message });
                }
            }
        });

        run.FreedBytes = run.Results.Where(r => r.Ok).Sum(r => r.FreedBytes);
        run.Message = run.Results.All(r => r.Ok)
            ? "Очищення завершено"
            : "Частину файлів пропущено (зайняті системою)";
        return run;
    }

    // ------------------------------------------------------------ categories

    private CleanupCategoryDto? BuildCategory(string key, bool scan)
    {
        try
        {
            switch (key)
            {
                case "recycle_bin":
                {
                    var (bytes, count) = QueryRecycleBin();
                    return new CleanupCategoryDto
                    {
                        Key = key,
                        Title = "Корзина Windows",
                        Description = "Видалені файли з усіх дисків",
                        Path = "Кошик (Recycle Bin)",
                        SizeBytes = bytes,
                        FileCount = count,
                        DefaultSelected = true
                    };
                }
                case "user_temp":
                    return DirCategory(key, "Тимчасові файли (%TEMP%)",
                        "Тимчасові файли вашого профілю", Path.GetTempPath());
                case "windows_temp":
                    return DirCategory(key, "Тимчасові файли Windows",
                        "C:\\Windows\\Temp (системний temp)", Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "Temp"));
                case "chrome_cache":
                    return BrowserCacheCategory(key, "Google Chrome", "Кеш браузера Chrome",
                        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Google", "Chrome", "User Data"));
                case "edge_cache":
                    return BrowserCacheCategory(key, "Microsoft Edge", "Кеш браузера Edge",
                        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Microsoft", "Edge", "User Data"));
                case "firefox_cache":
                {
                    long bytes = 0, files = 0;
                    var profiles = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Mozilla", "Firefox", "Profiles");
                    if (Directory.Exists(profiles))
                    {
                        foreach (var profile in SafeDirs(profiles))
                        {
                            var (b, f) = MeasureCacheDirs(profile.FullName);
                            bytes += b; files += f;
                        }
                    }
                    return new CleanupCategoryDto
                    {
                        Key = key,
                        Title = "Firefox",
                        Description = "Кеш браузера Firefox",
                        Path = profiles,
                        SizeBytes = bytes,
                        FileCount = files,
                        DefaultSelected = bytes > 0
                    };
                }
                case "discord_cache":
                {
                    // Дві можливі схеми: app-<version>\\modules\\discord_desktop_core ... або локальний Cache
                    var baseDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Discord");
                    var (bytes, files) = MeasureCacheDirs(baseDir);
                    return new CleanupCategoryDto
                    {
                        Key = key,
                        Title = "Discord",
                        Description = "Кеш застосунку Discord",
                        Path = baseDir,
                        SizeBytes = bytes,
                        FileCount = files,
                        DefaultSelected = bytes > 0
                    };
                }
                case "steam_htmlcache":
                    return DirCategory(key, "Steam",
                        "HTML-кеш клієнта Steam",
                        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Steam", "htmlcache"),
                        autoSelected: false);
                case "thumbnails":
                    return DirCategory(key, "Мініатюри Explorer",
                        "Кеш ескізів зображень/відео у провіднику",
                        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Microsoft", "Windows", "Explorer"),
                        filter: "thumbcache_*.db");
                case "directx_shader":
                    return DirCategory(key, "Кеш шейдерів DirectX",
                        "Застарілі компільовані шейдери ігор",
                        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "D3DSCache"),
                        autoSelected: false);
                case "crashdumps":
                    return DirCategory(key, "Дампи помилок",
                        "Звіти про збої програм (wer/dumps)",
                        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "CrashDumps"),
                        autoSelected: false);
                case "deliveropt":
                    return DirCategory(key, "Кеш оновлень Windows",
                        "Завантажені патчі у SoftwareDistribution\\Download",
                        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "SoftwareDistribution", "Download"),
                        autoSelected: false);
                default:
                    return null;
            }
        }
        catch { return null; }
    }

    private CleanupCategoryDto? DirCategory(string key, string title, string description, string path, bool autoSelected = true, string? filter = null)
    {
        try
        {
            var (bytes, files) = MeasureDir(path, filter);
            return new CleanupCategoryDto
            {
                Key = key,
                Title = title,
                Description = description,
                Path = path,
                SizeBytes = bytes,
                FileCount = files,
                DefaultSelected = autoSelected && bytes > 0
            };
        }
        catch { return null; }
    }

    private CleanupCategoryDto? BrowserCacheCategory(string key, string title, string description, string userDataDir)
    {
        try
        {
            long bytes = 0, files = 0;
            if (Directory.Exists(userDataDir))
            {
                foreach (var profile in SafeDirs(userDataDir))
                {
                    var (b, f) = MeasureCacheDirs(profile.FullName);
                    bytes += b; files += f;
                }
            }
            return new CleanupCategoryDto
            {
                Key = key,
                Title = title,
                Description = description,
                Path = userDataDir,
                SizeBytes = bytes,
                FileCount = files,
                DefaultSelected = bytes > 0
            };
        }
        catch { return null; }
    }

    private (long bytes, long files) MeasureCacheDirs(string profileDir)
    {
        long bytes = 0, files = 0;
        try
        {
            foreach (var sub in CacheSubDirs)
            {
                var dir = Path.Combine(profileDir, sub);
                var (b, f) = MeasureDir(dir);
                bytes += b; files += f;
            }
            // Профілі типу «Profile 1», «Default»: вкладені профілі у User Data.
            foreach (var nested in SafeDirs(profileDir))
            {
                if (nested.Name.Equals("Default", StringComparison.OrdinalIgnoreCase) ||
                    nested.Name.StartsWith("Profile ", StringComparison.OrdinalIgnoreCase))
                {
                    var (b, f) = MeasureCacheDirs(nested.FullName);
                    bytes += b; files += f;
                }
            }
        }
        catch { }
        return (bytes, files);
    }

    private List<DirectoryInfo> SafeDirs(string dir)
    {
        try { return new DirectoryInfo(dir).Exists ? new DirectoryInfo(dir).GetDirectories().ToList() : new List<DirectoryInfo>(); }
        catch { return new List<DirectoryInfo>(); }
    }

    private (long bytes, long files) MeasureDir(string dir, string? filter = null)
    {
        long bytes = 0, files = 0;
        try
        {
            if (!Directory.Exists(dir)) return (0, 0);
            var stack = new Stack<string>();
            stack.Push(dir);
            while (stack.Count > 0 && bytes < 8L * 1024 * 1024 * 1024) // страховка: не рахуємо більше 8 ГБ на категорію
            {
                var current = stack.Pop();
                try
                {
                    foreach (var d in Directory.EnumerateDirectories(current))
                        stack.Push(d);
                }
                catch { }

                try
                {
                    var enumeration = string.IsNullOrEmpty(filter)
                        ? Directory.EnumerateFiles(current)
                        : Directory.EnumerateFiles(current, filter);
                    foreach (var f in enumeration)
                    {
                        try
                        {
                            var fi = new FileInfo(f);
                            if (fi.Exists) { bytes += fi.Length; files++; }
                        }
                        catch { }
                    }
                }
                catch { }
            }
        }
        catch { }
        return (bytes, files);
    }

    // ----------------------------------------------------------------- clean

    /// <summary>Повертає null при успіху або текст помилки.</summary>
    private string? CleanCategory(string key)
    {
        try
        {
            switch (key)
            {
                case "recycle_bin":
                    return EmptyRecycleBin();
                case "user_temp":
                    return CleanDirContents(Path.GetTempPath());
                case "windows_temp":
                    return CleanDirContents(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "Temp"));
                case "chrome_cache":
                    return CleanBrowserCache(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Google", "Chrome", "User Data"));
                case "edge_cache":
                    return CleanBrowserCache(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Microsoft", "Edge", "User Data"));
                case "firefox_cache":
                {
                    var profiles = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Mozilla", "Firefox", "Profiles");
                    if (Directory.Exists(profiles))
                        foreach (var profile in SafeDirs(profiles))
                            CleanCacheDirs(profile.FullName);
                    return null;
                }
                case "discord_cache":
                    CleanCacheDirs(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Discord"));
                    return null;
                case "steam_htmlcache":
                    return CleanDirContents(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Steam", "htmlcache"));
                case "thumbnails":
                    return CleanDirContents(
                        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Microsoft", "Windows", "Explorer"),
                        "thumbcache_*.db");
                case "directx_shader":
                    return CleanDirContents(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "D3DSCache"));
                case "crashdumps":
                    return CleanDirContents(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "CrashDumps"));
                case "deliveropt":
                    // Сервіс оновлень може тримати файли — помилка не критична.
                    return CleanDirContents(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "SoftwareDistribution", "Download"));
                default:
                    return "Невідома категорія";
            }
        }
        catch (Exception ex)
        {
            return ex.Message;
        }
    }

    private string? CleanBrowserCache(string userDataDir)
    {
        try
        {
            if (!Directory.Exists(userDataDir)) return null;
            foreach (var profile in SafeDirs(userDataDir))
                CleanCacheDirs(profile.FullName);
            return null;
        }
        catch (Exception ex) { return ex.Message; }
    }

    private void CleanCacheDirs(string profileDir)
    {
        try
        {
            foreach (var sub in CacheSubDirs)
                CleanDirContents(Path.Combine(profileDir, sub));
            foreach (var nested in SafeDirs(profileDir))
            {
                if (nested.Name.Equals("Default", StringComparison.OrdinalIgnoreCase) ||
                    nested.Name.StartsWith("Profile ", StringComparison.OrdinalIgnoreCase))
                    CleanCacheDirs(nested.FullName);
            }
        }
        catch { }
    }

    /// <summary>Видаляє ВМІСТ каталогу (не сам каталог). Зайняті файли пропускає.</summary>
    private string? CleanDirContents(string dir, string? filter = null)
    {
        try
        {
            if (!Directory.Exists(dir)) return null;
            long skipped = 0;

            foreach (var file in SafeFiles(dir, filter))
            {
                try { File.SetAttributes(file, FileAttributes.Normal); } catch { }
                try { File.Delete(file); } catch { skipped++; }
            }

            foreach (var sub in SafeDirs(dir))
            {
                try { Directory.Delete(sub.FullName, recursive: true); }
                catch
                {
                    // Часто частина файлів вільна — чистимо вміст вкладеної папки теж.
                    foreach (var file in SafeFiles(sub.FullName, null))
                    {
                        try { File.SetAttributes(file, FileAttributes.Normal); } catch { }
                        try { File.Delete(file); } catch { skipped++; }
                    }
                }
            }

            return null;
        }
        catch (Exception ex)
        {
            return ex.Message;
        }
    }

    private List<string> SafeFiles(string dir, string? filter)
    {
        try
        {
            var enumeration = string.IsNullOrEmpty(filter)
                ? Directory.EnumerateFiles(dir)
                : Directory.EnumerateFiles(dir, filter);
            return enumeration.ToList();
        }
        catch { return new List<string>(); }
    }

    // ------------------------------------------------------------- recycle bin

    [StructLayout(LayoutKind.Sequential, Pack = 4)]
    private struct SHQUERYRBINFO
    {
        public uint cbSize;
        public long i64Size;
        public long i64NumItems;
    }

    [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
    private static extern int SHQueryRecycleBin(string pszRootPath, ref SHQUERYRBINFO pSHQueryRBInfo);

    [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
    private static extern int SHEmptyRecycleBin(IntPtr hwnd, string? pszRootPath, uint dwFlags);

    private const uint SHERB_NOCONFIRMATION = 0x1;
    private const uint SHERB_NOPROGRESSUI = 0x2;
    private const uint SHERB_NOSOUND = 0x4;

    private (long bytes, long items) QueryRecycleBin()
    {
        long bytes = 0, items = 0;
        try
        {
            foreach (var drive in System.IO.DriveInfo.GetDrives().Where(d => d.DriveType == DriveType.Fixed))
            {
                try
                {
                    var info = new SHQUERYRBINFO();
                    info.cbSize = (uint)Marshal.SizeOf(typeof(SHQUERYRBINFO));
                    if (SHQueryRecycleBin(drive.Name, ref info) == 0)
                    {
                        bytes += info.i64Size;
                        items += info.i64NumItems;
                    }
                }
                catch { }
            }
        }
        catch { }
        return (bytes, items);
    }

    private string? EmptyRecycleBin()
    {
        try
        {
            var hr = SHEmptyRecycleBin(IntPtr.Zero, null, SHERB_NOCONFIRMATION | SHERB_NOPROGRESSUI | SHERB_NOSOUND);
            return hr == 0 ? null : $"Shell error 0x{hr:X8}";
        }
        catch (Exception ex)
        {
            return ex.Message;
        }
    }
}
