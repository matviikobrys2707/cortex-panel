using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;

namespace FluxControl.Agent.Services;

/// <summary>
/// «Функції для тролінгу» (ТЗ, вкладка Додаткова):
///  • ВСПЛИВЧІ ВІКНА — N вікон (до 100, ТЗ) з заданим текстом, КОЖНЕ у
///    ВЛАСНІЙ ВИПАДКОВІЙ позиції екрана (MB_DEFAULT_DESKTOP нецентрований:
///    після появи діалог рухається EnumThreadWindows + MoveWindow);
///  • ОЗВУЧИТИ ТЕКСТ — SAPI через PowerShell, script передається
///    -EncodedCommand (Base64) — БЕЗ проблем лапок (фікс «не працює»);
///  • КОНСОЛІ — N cmd-вікон у випадкових місцях, НЕВЕЛИКА ЗАТРИМКА між
///    відкриттями (ТЗ), опція «закрити всі після завершення»;
///  • ПЕРЕВОРОТ ЕКРАНА — 0/90/180/270° через НАТИВНЕ базове розмірнення:
///    фікс «код помилки 2» (DISP_CHANGE_BADMODE) і неможливості повернути
///    назад — завжди рахуємо W/H від базових (ландшафтних) розмірів.
/// Усе — для свого ПК через власну панель.
/// </summary>
public class TrollService
{
    private readonly Random _rnd = new();

    // ------------------------------------------------------------------ popups

    public (bool ok, string error) ShowMessageBoxes(string text, int count)
    {
        // ТЗ: «можно было открыть до 100 окон».
        count = Math.Clamp(count, 1, 100);
        if (string.IsNullOrWhiteSpace(text)) return (false, "Порожній текст");
        string msg = text.Length > 500 ? text[..500] : text;

        var screen = System.Windows.Forms.Screen.PrimaryScreen?.Bounds;
        int sw = screen?.Width ?? 1920;
        int sh = screen?.Height ?? 1080;

        for (int i = 0; i < count; i++)
        {
            // Кожне вікно — окремий потік: MessageBox блокує свій потік до
            // закриття, але всі N вікон відкриті ОДНОЧАСНО. Невеликий розкид
            // у часі (35мс) дає моверу час розставити кожне у свою позицію.
            int tx = _rnd.Next(Math.Max(1, sw - 420));
            int ty = _rnd.Next(Math.Max(1, sh - 220));
            _ = Task.Run(async () =>
            {
                try
                {
                    uint tid = GetCurrentThreadId();
                    // Мовер: чекає появи діалогу класу #32770 у ЦЬОМУ потоці
                    // і тягне його у випадкову точку (ТЗ: «на разных позициях»).
                    _ = Task.Run(async () =>
                    {
                        for (int attempt = 0; attempt < 20; attempt++)
                        {
                            await Task.Delay(60);
                            if (MoveDialogOfThread(tid, tx, ty)) return;
                        }
                    });
                    _ = MessageBoxW(IntPtr.Zero, msg, "FluxControl", 0x40 | 0x40000 | 0x10000); // INFO|TOPMOST|SETFOREGROUND
                }
                catch { }
            });
        }
        return (true, string.Empty);
    }

    private static bool MoveDialogOfThread(uint tid, int x, int y)
    {
        IntPtr hwnd = IntPtr.Zero;
        EnumThreadWindows(tid, (h, l) =>
        {
            var sb = new StringBuilder(256);
            _ = GetClassNameW(h, sb, 256);
            if (sb.ToString() == "#32770") { hwnd = h; return false; }
            return true;
        }, IntPtr.Zero);
        if (hwnd == IntPtr.Zero) return false;
        return MoveWindow(hwnd, x, y, 0, 0, true);
    }

    // --------------------------------------------------------------------- TTS

    public (bool ok, string error) SpeakText(string text, int repeat)
    {
        if (string.IsNullOrWhiteSpace(text)) return (false, "Порожній текст");
        repeat = Math.Clamp(repeat, 1, 50);

        // ТЗ-ФІКС «озвучка не працює»: попередній варіант клеїв PS-скрипт
        // рядком — лапки в тексті ламали команду. Тепер скрипт передається
        // через -EncodedCommand (UTF-16LE Base64) — будь-який текст безпечний.
        string safe = text.Replace("\r", " ").Replace("\n", " ");
        if (safe.Length > 400) safe = safe[..400];
        string script =
            "Add-Type -AssemblyName System.Speech; " +
            "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer; " +
            $"for($i=0; $i -lt {repeat}; $i++) {{ $s.Speak(@'\n{safe}\n'@); }}";
        string encoded = Convert.ToBase64String(Encoding.Unicode.GetBytes(script));

        var psi = new ProcessStartInfo
        {
            FileName = "powershell.exe",
            Arguments = $"-NoProfile -ExecutionPolicy Bypass -EncodedCommand {encoded}",
            UseShellExecute = true,
            CreateNoWindow = true,
            WindowStyle = ProcessWindowStyle.Hidden
        };
        try
        {
            Process.Start(psi);
            return (true, string.Empty);
        }
        catch (Exception ex)
        {
            return (false, ex.Message);
        }
    }

    // ---------------------------------------------------------------- consoles

    public (bool ok, string error) OpenConsoles(int count, bool autoClose)
    {
        count = Math.Clamp(count, 1, 50);
        var screen = System.Windows.Forms.Screen.PrimaryScreen?.Bounds;
        int sw = screen?.Width ?? 1920;
        int sh = screen?.Height ?? 1080;

        // ТЗ: «небольшая задержка» між відкриттями + розкид позицій + автозакриття.
        _ = Task.Run(async () =>
        {
            var pids = new List<int>();
            var rnd = new Random();
            try
            {
                for (int i = 0; i < count; i++)
                {
                    try
                    {
                        var psi = new ProcessStartInfo
                        {
                            FileName = "cmd.exe",
                            Arguments = "/k title FluxTroll",
                            UseShellExecute = true,
                            CreateNoWindow = false
                        };
                        var p = Process.Start(psi);
                        if (p != null) pids.Add(p.Id);
                    }
                    catch { }
                    await Task.Delay(220); // невелика затримка (ТЗ)
                }

                // Дамо вікнам з'явитись, потім розкидаємо у випадкові частини екрана.
                await Task.Delay(700);
                foreach (var pid in pids)
                {
                    try
                    {
                        int w = 420, h = 260;
                        int x = rnd.Next(Math.Max(0, sw - w));
                        int y = rnd.Next(Math.Max(0, sh - h));
                        MoveWindowOfPid(pid, x, y, w, h);
                    }
                    catch { }
                }

                if (autoClose)
                {
                    // ТЗ: «після відкриття всіх консолей — закрити, якщо обрано так».
                    await Task.Delay(2500);
                    foreach (var pid in pids)
                    {
                        try
                        {
                            using var proc = Process.GetProcessById(pid);
                            proc.Kill(entireProcessTree: true);
                        }
                        catch { }
                    }
                }
            }
            catch { }
        });
        return (true, string.Empty);
    }

    private static void MoveWindowOfPid(int pid, int x, int y, int w, int h)
    {
        IntPtr hwnd = IntPtr.Zero;
        EnumWindows((h, l) =>
        {
            _ = GetWindowThreadProcessId(h, out uint winPid);
            if (winPid == (uint)pid && IsWindowVisible(h))
            {
                var sb = new StringBuilder(256);
                _ = GetClassNameW(h, sb, 256);
                if (sb.ToString().Contains("ConsoleWindowClass")) { hwnd = h; return false; }
            }
            return true;
        }, IntPtr.Zero);
        if (hwnd != IntPtr.Zero) MoveWindow(hwnd, x, y, w, h, true);
    }

    // ---------------------------------------------------------------- rotation

    private static int _baseW;
    private static int _baseH;

    /// <summary>Поворот основного екрана: 0/90/180/270 градусів.
    /// ФІКС «код помилки 2 / не повертається назад»: розмірнення завжди
    /// рахується від БАЗОВОГО (нативного ландшафтного) режиму, а не від
    /// поточного — тому 90° після 180° більше не дає DISP_CHANGE_BADMODE,
    /// а 0° завжди повертає рідний режим.</summary>
    public (bool ok, string error) RotateScreen(int degrees)
    {
        int orientation = degrees switch
        {
            90 => 1,   // DMDO_90
            180 => 2,  // DMDO_180
            270 => 3,  // DMDO_270
            0 => 0,    // DMDO_DEFAULT
            _ => -1
        };
        if (orientation < 0) return (false, "Кут має бути 0/90/180/270");

        try
        {
            var dm = new DEVMODE { dmSize = (short)Marshal.SizeOf<DEVMODE>() };
            if (EnumDisplaySettingsW(null, ENUM_CURRENT_SETTINGS, ref dm) == 0)
                return (false, "Не вдалося прочитати параметри екрана");

            // Базовий (нативний ландшафтний) режим: фіксуємо першого разу, коли
            // екран ще не повернутий; якщо агент стартував уже на повернутому
            // екрані — база = поточні розміри, розвернуті назад.
            if (_baseW <= 0 || _baseH <= 0)
            {
                if (dm.dmDisplayOrientation is 1 or 3)
                {
                    _baseW = dm.dmPelsHeight;
                    _baseH = dm.dmPelsWidth;
                }
                else
                {
                    _baseW = dm.dmPelsWidth;
                    _baseH = dm.dmPelsHeight;
                }
                // Страховка: база має бути ландшафтною (W >= H) для типового монітора.
                if (_baseW < _baseH) (_baseW, _baseH) = (_baseH, _baseW);
            }

            // Для портретних орієнтацій міняємо місцями БАЗОВІ W/H.
            if (orientation == 1 || orientation == 3)
            {
                dm.dmPelsWidth = _baseH;
                dm.dmPelsHeight = _baseW;
            }
            else
            {
                dm.dmPelsWidth = _baseW;
                dm.dmPelsHeight = _baseH;
            }

            dm.dmFields = DM_DISPLAYORIENTATION | DM_PELSWIDTH | DM_PELSHEIGHT;
            dm.dmDisplayOrientation = orientation;

            const int CDS_UPDATEREGISTRY = 0x01;
            var res = ChangeDisplaySettingsW(ref dm, CDS_UPDATEREGISTRY);
            if (res != 0)
            {
                // Друга спроба БЕЗ запису в реєстр (тимчасово до перезавантаження) —
                // деякі драйвери відмовляють лише persistent-зміні.
                res = ChangeDisplaySettingsW(ref dm, 0);
            }
            return res == 0
                ? (true, string.Empty)
                : (false, res == 1 ? "Драйвер не підтримує цей поворот" : $"Код помилки: {res}");
        }
        catch (Exception ex)
        {
            return (false, ex.Message);
        }
    }

    // --------------------------------------------------------------- screamer

    private static bool _screamerActive;

    // ТЗ v1.3 «скример с GitHub-ассетами»: звук + фото лежат в папке assets
    // репозитория FluxControl (main). Агент ОДИН РАЗ скачивает их в своё
    // сховище (%AppData%\FluxControl\Assets) и дальше использует кеш —
    // при следующих скримерах старт мгновенный. Если файлов нет/битые —
    // фолбэк на встроенные scream.wav / screamer.jpg.
    // Файлы в репо НЕ переименовывает деплой: Web-Deploy.ps1 восстанавливает
    // assets\ из origin/main, Auto-Deploy.ps1 их вообще не трогает.
    private static readonly System.Net.Http.HttpClient ScreamerHttp = new() { Timeout = TimeSpan.FromSeconds(8) };

    private static readonly string[] ScreamerAssetBases =
    {
        "https://raw.githubusercontent.com/matviikobrys2707/FluxControl/main/assets/",
        "https://raw.githubusercontent.com/matviikobrys2707/FluxControl/master/assets/",
        "https://raw.githubusercontent.com/matviikobrys2707/FluxControl-Agent/main/assets/"
    };

    // Пробуем и короткие «каноничные» имена, и оригинальное имя файла юзера —
    // сработает любой вариант, как бы юзер ни назвал файл в assets.
    private static readonly string[] ScreamerSoundNames =
    {
        "screamer-sound.mp3",
        "jeremayjimenez-smile-dog-jumpscare-167171.mp3"
    };

    private static readonly string[] ScreamerImageNames =
    {
        "cover-screamer.jpg",
        "screamer-cover.jpg"
    };

    private static bool IsValidMp3Bytes(byte[]? b) =>
        b != null && b.Length > 1024 &&
        ((b[0] == 'I' && b[1] == 'D' && b[2] == '3') || (b[0] == 0xFF && (b[1] & 0xE0) == 0xE0));

    private static bool IsValidJpgBytes(byte[]? b) =>
        b != null && b.Length > 1024 && b[0] == 0xFF && b[1] == 0xD8;

    private static bool IsValidMp3File(string path)
    {
        try { return IsValidMp3Bytes(System.IO.File.ReadAllBytes(path)); }
        catch { return false; }
    }

    private static bool IsValidJpgFile(string path)
    {
        try { return IsValidJpgBytes(System.IO.File.ReadAllBytes(path)); }
        catch { return false; }
    }

    /// <summary>
    /// Гарантирует наличие ассетов скримера в сховище (кеш → сеть → фолбэк).
    /// Возвращает (путь к звуку, путь к картинке), которые МОЖНО запускать.
    /// </summary>
    private static (string sound, string image) EnsureScreamerAssets()
    {
        var assetsDir = Path.Combine(RuntimeFiles.DataRoot, "Assets");
        try { Directory.CreateDirectory(assetsDir); } catch { }
        var localSound = Path.Combine(assetsDir, "screamer-sound.mp3");
        var localImage = Path.Combine(assetsDir, "cover-screamer.jpg");

        bool haveSound = IsValidMp3File(localSound);
        bool haveImage = IsValidJpgFile(localImage);

        if (!haveSound || !haveImage)
        {
            // Скачиваем ОБА файла параллельно; общий бюджет ~9с, чтобы скример
            // не зависал надолго, если GitHub недоступен (тогда — фолбэк).
            try
            {
                var t1 = DownloadScreamerAssetAsync(ScreamerSoundNames, localSound, isMp3: true);
                var t2 = DownloadScreamerAssetAsync(ScreamerImageNames, localImage, isMp3: false);
                Task.WaitAll(new[] { t1, t2 }, TimeSpan.FromSeconds(9));
            }
            catch { }
            haveSound = IsValidMp3File(localSound);
            haveImage = IsValidJpgFile(localImage);
        }

        // Фолбэк: встроенные в сборку файлы (RuntimeFiles извлекает их в UI\).
        string sound = haveSound ? localSound : RuntimeFiles.ScreamerSoundPath;
        string image = haveImage ? localImage : RuntimeFiles.ScreamerImagePath;

        try
        {
            App.Log($"[Troll] Screamer assets: sound={(haveSound ? "github-cache" : "embedded-wav")}, " +
                    $"image={(haveImage ? "github-cache" : "embedded-jpg")} ({assetsDir})");
        }
        catch { }
        return (sound, image);
    }

    private static async Task DownloadScreamerAssetAsync(string[] names, string destFile, bool isMp3)
    {
        foreach (var name in names)
        {
            foreach (var baseUrl in ScreamerAssetBases)
            {
                try
                {
                    using var resp = await ScreamerHttp.GetAsync(baseUrl + name,
                        System.Net.Http.HttpCompletionOption.ResponseHeadersRead);
                    if (!resp.IsSuccessStatusCode) continue;
                    var bytes = await resp.Content.ReadAsByteArrayAsync();
                    bool ok = isMp3 ? IsValidMp3Bytes(bytes) : IsValidJpgBytes(bytes);
                    if (!ok) continue; // HTML-заглушка/битый файл — пробуем следующий кандидат

                    var tmp = destFile + ".part";
                    System.IO.File.WriteAllBytes(tmp, bytes);
                    if (System.IO.File.Exists(destFile)) System.IO.File.Delete(destFile);
                    System.IO.File.Move(tmp, destFile);
                    try { App.Log($"[Troll] Screamer asset downloaded: {name} ({bytes.Length} bytes)"); } catch { }
                    return;
                }
                catch { }
            }
        }
    }

    /// <summary>
    /// ТЗ 6 «скример»: на весь екран РІЗКО (через 400мс чорного) РАЗОМ
    /// з'являються страшне зображення І звук (ТЗ v1.3: «щоб звук не з'явився,
    /// а фотка ще прогружалась»). Звук качається з GitHub-ассетів, кешується
    /// у %AppData%\FluxControl\Assets і крутиться В ЦИКЛІ, доки не скінчиться
    /// час скримера (звук ~2с — перезапускається безперервно). Закриття
    /// скасовується, автозакриття — таймером 4–15с. Вікно — НА DISPATCHER.
    /// </summary>
    public (bool ok, string error) RunScreamer(int seconds)
    {
        if (seconds <= 0) seconds = 8;
        seconds = Math.Clamp(seconds, 4, 15);

        if (_screamerActive) return (true, string.Empty); // вже показуємо — не дублюємо

        _screamerActive = true;
        int duration = seconds;
        _ = Task.Run(() =>
        {
            try
            {
                // 1) Ассети: кеш → GitHub → фолбэк на встроенные (швидко і без сюрпризів).
                var (soundPath, imagePath) = EnsureScreamerAssets();

                bool haveAny = (System.IO.File.Exists(imagePath) && IsValidJpgFile(imagePath)) ||
                               System.IO.File.Exists(soundPath);
                if (!haveAny)
                {
                    try { App.Log("[Troll] Screamer: no usable assets (download failed, embedded missing)"); } catch { }
                    return;
                }

                // 2) Вікно мусить створюватись на WPF Dispatcher (ТЗ).
                var dispatcher = System.Windows.Application.Current?.Dispatcher;
                if (dispatcher == null || dispatcher.CheckAccess())
                    ShowScreamerOnUi(imagePath, soundPath, duration);
                else
                    dispatcher.Invoke(() => ShowScreamerOnUi(imagePath, soundPath, duration));
            }
            catch (Exception ex)
            {
                try { App.Log($"[Troll] Screamer failed: {ex.Message}"); } catch { }
            }
            finally
            {
                _screamerActive = false;
            }
        });
        return (true, string.Empty);
    }

    /// <summary>ПОВИННО викликатись на WPF Dispatcher (UI-потоку).</summary>
    private static void ShowScreamerOnUi(string imagePath, string soundPath, int seconds)
    {
        try
        {
            var win = new ScreamerWindow(imagePath, soundPath, TimeSpan.FromSeconds(seconds));
            win.Show();
        }
        catch (Exception ex)
        {
            try { App.Log($"[Troll] Screamer window failed: {ex.Message}"); } catch { }
        }
    }

    /// <summary>Фулскрін-вікно скримера: чорний фон; зображення (UniformToFill)
    /// і звук РАЗОМ різко проявляються через 400мс (ТЗ v1.3 — синхронно);
    /// MP3 крутиться в циклі (MediaEnded → Position=0 → Play), WAV — PlayLooping;
    /// закриття скасовується до автозакриття за таймером; курсор приховано.
    /// Картинка декодується ОДИН раз у обмежений розмір і Freeze — щоб не
    /// навантажувати систему (ТЗ).</summary>
    private sealed class ScreamerWindow : System.Windows.Window
    {
        private readonly System.Windows.Threading.DispatcherTimer _closeTimer;
        private readonly string _soundPath;
        private System.Media.SoundPlayer? _player;          // WAV-фолбэк (встроенный scream.wav)
        private System.Windows.Media.MediaPlayer? _mp3;     // MP3 з GitHub-ассетів
        private bool _mp3Ready;
        private bool _forceCloseAllowed;

        public ScreamerWindow(string imagePath, string soundPath, TimeSpan duration)
        {
            _soundPath = soundPath;

            WindowStyle = System.Windows.WindowStyle.None;
            ResizeMode = System.Windows.ResizeMode.NoResize;
            ShowInTaskbar = false;
            Topmost = true;
            ShowActivated = true;
            Background = System.Windows.Media.Brushes.Black;
            Cursor = System.Windows.Input.Cursors.None;
            WindowState = System.Windows.WindowState.Maximized;

            // Контент: чорна сітка + зображення на весь екран зі схованою прозорістю.
            var image = new System.Windows.Controls.Image
            {
                Stretch = System.Windows.Media.Stretch.UniformToFill,
                Opacity = 0d
            };
            try
            {
                // Продуктивність (ТЗ «щоб не навантажували систему»):
                //  • OnLoad        — файл читається у пам'ять ОДИН раз синхронно;
                //  • DecodePixelWidth 2560 — декодуємо у розмір монітора, а не
                //    у повний розмір вихідного jpg (економія RAM/CPU);
                //  • Freeze        — іммунний битмап, без диспетчер-накладних.
                var bmp = new System.Windows.Media.Imaging.BitmapImage();
                bmp.BeginInit();
                bmp.CacheOption = System.Windows.Media.Imaging.BitmapCacheOption.OnLoad;
                bmp.CreateOptions = System.Windows.Media.Imaging.BitmapCreateOptions.IgnoreImageCache;
                bmp.DecodePixelWidth = 2560;
                bmp.UriSource = new Uri(imagePath);
                bmp.EndInit();
                bmp.Freeze();
                image.Source = bmp;
            }
            catch { } // без картинки лишається чорний екран + звук

            var grid = new System.Windows.Controls.Grid { Background = System.Windows.Media.Brushes.Black };
            grid.Children.Add(image);
            Content = grid;

            Closing += (_, e) => { if (!_forceCloseAllowed) e.Cancel = true; };
            LocationChanged += (_, _) => ReassertFullscreen();
            StateChanged += (_, _) => ReassertFullscreen();

            // MP3-плеер готуємо ЗАЗДАЛЕГІДЬ: під час 400мс чорного екрану WMF
            // встигає відкрити/забуферизувати файл — тому на момент появи
            // картинки звук стартує МИТТЄВО (синхронність, ТЗ v1.3).
            if (string.Equals(Path.GetExtension(_soundPath), ".mp3", StringComparison.OrdinalIgnoreCase) &&
                System.IO.File.Exists(_soundPath))
            {
                try
                {
                    _mp3 = new System.Windows.Media.MediaPlayer { Volume = 1d };
                    _mp3.MediaOpened += (_, _) => _mp3Ready = true;
                    _mp3.MediaFailed += (_, e) =>
                    {
                        try { App.Log($"[Troll] MP3 failed: {e.ErrorMessage} — fallback to WAV"); } catch { }
                        _mp3 = null; _mp3Ready = false;
                    };
                    // Цикл: звук ~2с — перезапускаємо, доки скример не закриється (ТЗ).
                    _mp3.MediaEnded += (_, _) => LoopMp3();
                    _mp3.Open(new Uri(_soundPath));
                }
                catch (Exception ex)
                {
                    try { App.Log($"[Troll] MP3 init failed: {ex.Message}"); } catch { }
                    _mp3 = null;
                }
            }

            // Різка поява: 400мс чорного → ОДНОЧАСНО картинка (120мс анімація)
            // і звук. Саме тут ліквідується розсинхрон «звук є — фотка вантажиться».
            var revealTimer = new System.Windows.Threading.DispatcherTimer { Interval = TimeSpan.FromMilliseconds(400) };
            revealTimer.Tick += (_, _) =>
            {
                try
                {
                    revealTimer.Stop();
                    var anim = new System.Windows.Media.Animation.DoubleAnimation(0d, 1d, TimeSpan.FromMilliseconds(120));
                    image.BeginAnimation(System.Windows.Controls.Image.OpacityProperty, anim);
                    StartSoundLoop();
                }
                catch
                {
                    try { image.Opacity = 1d; } catch { }
                    try { StartSoundLoop(); } catch { }
                }
            };
            revealTimer.Start();

            // Автозакриття через `seconds`.
            _closeTimer = new System.Windows.Threading.DispatcherTimer { Interval = duration };
            _closeTimer.Tick += (_, _) =>
            {
                try
                {
                    _forceCloseAllowed = true;
                    StopSound();
                    Close();
                }
                catch { }
            };

            // WPF Window не має віртуального OnOpened (це WinForms-метод —
            // через нього падала компіляція CS0115). Старт логіки показу —
            // через Loaded: вікно вже показане, можна стягувати фулскрін
            // і запускати таймер закриття (звук стартує на reveal).
            Loaded += (_, _) =>
            {
                ReassertFullscreen();
                _closeTimer.Start();
            };
        }

        private void LoopMp3()
        {
            try
            {
                if (_mp3 == null) return;
                _mp3.Position = TimeSpan.Zero;
                _mp3.Play();
            }
            catch { }
        }

        private void ReassertFullscreen()
        {
            try { if (WindowState != System.Windows.WindowState.Maximized) WindowState = System.Windows.WindowState.Maximized; } catch { }
            try { Topmost = true; } catch { }
        }

        protected override void OnClosed(EventArgs e)
        {
            try { _closeTimer.Stop(); } catch { }
            StopSound();
            base.OnClosed(e);
        }

        /// <summary>Звук стартує РАЗОМ із появою картинки (викликається з reveal).
        /// MP3 → MediaPlayer (відкритий ще в конструкторі, тож старт миттєвий;
        /// якщо MediaOpened ще не встиг — підпишемось і стартуємо на події,
        /// нічого не блокуючи UI-потік). WAV → SoundPlayer.PlayLooping.</summary>
        private void StartSoundLoop()
        {
            try
            {
                if (_mp3 != null)
                {
                    if (_mp3Ready)
                    {
                        _mp3.Position = TimeSpan.Zero;
                        _mp3.Play();
                    }
                    else
                    {
                        System.Windows.Media.MediaPlayer mp = _mp3;
                        void OnOpen(object? s, EventArgs e)
                        {
                            try { mp.Position = TimeSpan.Zero; mp.Play(); } catch { }
                            try { mp.MediaOpened -= OnOpen; } catch { }
                        }
                        mp.MediaOpened += OnOpen;
                    }
                    return;
                }

                if (string.IsNullOrWhiteSpace(_soundPath) || !System.IO.File.Exists(_soundPath)) return;
                _player = new System.Media.SoundPlayer(_soundPath);
                _player.PlayLooping();
            }
            catch (Exception ex)
            {
                try { App.Log($"[Troll] Screamer sound failed: {ex.Message}"); } catch { }
                _player = null;
            }
        }

        private void StopSound()
        {
            try
            {
                if (_mp3 != null) { _mp3.Stop(); _mp3.Close(); }
            }
            catch { }
            _mp3 = null;
            _mp3Ready = false;
            try { _player?.Stop(); } catch { }
            try { _player?.Dispose(); } catch { }
            _player = null;
        }
    }

    // ------------------------------------------------------------------ Win32

    private delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int MessageBoxW(IntPtr hWnd, string text, string caption, uint type);

    [DllImport("user32.dll")]
    private static extern bool EnumWindows(EnumWindowsProc proc, IntPtr lParam);

    [DllImport("user32.dll")]
    private static extern bool EnumThreadWindows(uint dwThreadId, EnumWindowsProc proc, IntPtr lParam);

    [DllImport("kernel32.dll")]
    private static extern uint GetCurrentThreadId();

    [DllImport("user32.dll")]
    private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);

    [DllImport("user32.dll")]
    private static extern bool IsWindowVisible(IntPtr hWnd);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int GetClassNameW(IntPtr hWnd, StringBuilder sb, int max);

    [DllImport("user32.dll")]
    private static extern bool MoveWindow(IntPtr hWnd, int x, int y, int w, int h, bool repaint);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int EnumDisplaySettingsW(string? deviceName, int modeNum, ref DEVMODE dm);

    [DllImport("user32.dll")]
    private static extern int ChangeDisplaySettingsW(ref DEVMODE dm, int flags);

    private const int ENUM_CURRENT_SETTINGS = -1;
    private const int DM_DISPLAYORIENTATION = 0x00000080;
    private const int DM_PELSWIDTH = 0x00080000;
    private const int DM_PELSHEIGHT = 0x00100000;

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct DEVMODE
    {
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string dmDeviceName;
        public short dmSpecVersion;
        public short dmDriverVersion;
        public short dmSize;
        public short dmDriverExtra;
        public int dmFields;
        public int dmPositionX;
        public int dmPositionY;
        public int dmDisplayOrientation;
        public int dmDisplayFixedOutput;
        public short dmColor;
        public short dmDuplex;
        public short dmYResolution;
        public short dmTTOption;
        public short dmCollate;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string dmFormName;
        public short dmLogPixels;
        public int dmBitsPerPel;
        public int dmPelsWidth;
        public int dmPelsHeight;
        public int dmDisplayFlags;
        public int dmDisplayFrequency;
        public int dmICMMethod;
        public int dmICMIntent;
        public int dmMediaType;
        public int dmDitherType;
        public int dmReserved1;
        public int dmReserved2;
        public int dmPanningWidth;
        public int dmPanningHeight;
    }
}
