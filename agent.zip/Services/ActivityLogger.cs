using System.IO;
using System.Text;

namespace FluxControl.Agent.Services;

/// <summary>
/// Журнал дій користувача (ТЗ): усі дії в програмі — вхід/вихід, увімкнення/
/// вимкнення функцій, оновлення, підключення пристроїв тощо — пишуться у
/// %AppData%\FluxControl\activity.log (рядок на дію, UTF-8).
/// Файл обертается при >1 МБ у activity.old.log, щоб рости безмежно.
/// </summary>
public static class ActivityLogger
{
    private static readonly object _lock = new();
    private static string? _filePath;

    public static string FilePath => _filePath ?? Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
        "FluxControl", "activity.log");

    /// <summary>Створює папку/файл за потреби. Викликається один раз на старті.</summary>
    public static void Init()
    {
        try
        {
            // Кешуємо шлях один раз (усуває CS0649: поле отримує значення тут).
            _filePath ??= Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "FluxControl", "activity.log");
            var dir = Path.GetDirectoryName(FilePath)!;
            Directory.CreateDirectory(dir);
            if (!File.Exists(FilePath)) File.WriteAllText(FilePath, string.Empty, Encoding.UTF8);
            RotateIfNeeded();
        }
        catch { }
    }

    /// <summary>Запис дії. Ніколи не кидає винятків і не блокує UI надовго.</summary>
    public static void Log(string source, string action, string? details = null)
    {
        try
        {
            var line = details is { Length: > 0 }
                ? $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] [{source}] {action} — {details}\r\n"
                : $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] [{source}] {action}\r\n";
            lock (_lock)
            {
                var dir = Path.GetDirectoryName(FilePath)!;
                Directory.CreateDirectory(dir);
                File.AppendAllText(FilePath, line, Encoding.UTF8);
                RotateIfNeeded();
            }
        }
        catch { }
    }

    /// <summary>Якщо журнал перевалив 1 МБ — поточний стає activity.old.log.</summary>
    private static void RotateIfNeeded()
    {
        try
        {
            var fi = new FileInfo(FilePath);
            if (fi.Exists && fi.Length > 1024 * 1024)
            {
                var old = Path.Combine(Path.GetDirectoryName(FilePath)!, "activity.old.log");
                if (File.Exists(old)) File.Delete(old);
                File.Move(FilePath, old);
                File.WriteAllText(FilePath, string.Empty, Encoding.UTF8);
            }
        }
        catch { }
    }
}
