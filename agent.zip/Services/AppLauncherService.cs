using System.Collections.Concurrent;
using System.Diagnostics;
using System.IO;
using System.Text;

namespace FluxControl.Agent.Services;

/// <summary>
/// Запуск програм (ТЗ: «показ всіх встановлених застосунків, пошук як у Windows,
/// клік — програма запускається на ПК»). Джерела списку:
///  1) ярлики «Пуск» (ProgramData + %AppData%) — головний перелік програм;
///  2) ярлики Робочого столу (спільний + особистий) — ТЗ «навіть ті, що на столі»;
///  3) UWP-застосунки (Пуск → Appx) — через shell:AppsFolder (fallback).
///
/// ТЗ-фікс «запуск мертвого ярлика»: ярлики, ціль яких НЕ існує на диску
/// (видалена програма, типа Android Studio після uninstall), НЕ показуємо
/// взагалі — скан одноразово перевіряє File.Exists, результат КЕШУЄТЬСЯ
/// (оновлюється фоново раз на 10 хв, щоб нові програми з'являлись).
/// Дедуплікація — і за назвою, і за цільовим exe (стіл + Пуск = один запис).
/// Іконки — тим самим шляхом, що й у Процесах (SHDefExtractIcon 48px → PNG).
/// </summary>
public class AppLauncherService
{
    public class AppEntry
    {
        public string Name { get; set; } = string.Empty;
        /// <summary>Цільовий exe (або .lnk/.url шлях, якщо ціль не розпізнано).</summary>
        public string Path { get; set; } = string.Empty;
        /// <summary>Чи ціль реально існує на диску (мертві ярлики відфільтровано).</summary>
        public bool Exists { get; set; } = true;
    }

    private static readonly string[] StartMenuDirs =
    {
        Environment.GetFolderPath(Environment.SpecialFolder.CommonStartMenu),
        Environment.GetFolderPath(Environment.SpecialFolder.StartMenu),
    };

    /// <summary>
    /// ТЗ «тільки справжні ЛАУНЧЕРИ»: фільтр сміття зі списку запуску —
    /// деінсталятори (Uninstall *), сетапи, help/readme/release notes,
    /// crash-reporter'и, MaintenanceTool, службові утиліти (Git Bash/CMD/GUI),
    /// оновлювачі. Перевіряється І назва, І цільовий exe.
    /// </summary>
    private static readonly System.Text.RegularExpressions.Regex JunkAppRegex =
        new(
            @"uninst|деінсталяц|видалити|удалить|\bsetup\b|_setup|setup_|installer\.exe|\bupdate\b|updator|updater|\breleasenotes|release notes|\breadme\b|\blicense\b|\beula\b|whatsnew|what.s new|crash.?report|crashhandler|maintenance.?tool|\bweb ?site\b|documentation|\bmanual\b|^help(\.|\b| )|\bhelp(\.exe)?$|git (bash|cmd|gui|k)|msiexec|bootstrapper|\.chm$|\.hlp$",
            System.Text.RegularExpressions.RegexOptions.IgnoreCase |
            System.Text.RegularExpressions.RegexOptions.CultureInvariant);

    private static bool IsJunkApp(string name, string path)
    {
        if (JunkAppRegex.IsMatch(name)) return true;
        if (!string.IsNullOrEmpty(path))
        {
            var baseName = Path.GetFileNameWithoutExtension(path);
            if (baseName.Length > 0 && JunkAppRegex.IsMatch(baseName)) return true;
            // unins000.exe та подібні у папці програми.
            var fileName = Path.GetFileName(path);
            if (fileName.StartsWith("unins", StringComparison.OrdinalIgnoreCase)) return true;
        }
        return false;
    }

    private static readonly string[] DesktopDirs =
    {
        Environment.GetFolderPath(Environment.SpecialFolder.CommonDesktopDirectory),
        Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),
    };

    // Кеш сканування (ТЗ: «один раз перевіряє — дані зберігаються/кешуються,
    // а потім фонова перевірка ловить нові програми»).
    private readonly ConcurrentDictionary<string, byte> _seenNames = new(StringComparer.OrdinalIgnoreCase);
    private readonly ConcurrentDictionary<string, byte> _seenTargets = new(StringComparer.OrdinalIgnoreCase);
    private List<AppEntry>? _cachedApps;
    private DateTime _cachedAt = DateTime.MinValue;
    private readonly object _cacheSync = new();
    private const int CacheTtlMinutes = 10;

    public List<AppEntry> GetInstalledApps()
    {
        lock (_cacheSync)
        {
            if (_cachedApps != null && (DateTime.UtcNow - _cachedAt).TotalMinutes < CacheTtlMinutes)
            {
                return _cachedApps;
            }
        }

        var result = new List<AppEntry>();
        _seenNames.Clear();
        _seenTargets.Clear();
        try
        {
            // 1) Пуск (ProgramData + AppData).
            foreach (var root in StartMenuDirs)
            {
                if (string.IsNullOrEmpty(root) || !Directory.Exists(root)) continue;
                var programs = Path.Combine(root, "Programs");
                if (!Directory.Exists(programs)) continue;
                ScanDirectory(new DirectoryInfo(programs), result, depth: 0);
            }
            // 2) Робочий стіл (ТЗ: показувати навіть ярлики зі столу).
            foreach (var desk in DesktopDirs)
            {
                if (string.IsNullOrEmpty(desk) || !Directory.Exists(desk)) continue;
                ScanDirectory(new DirectoryInfo(desk), result, depth: 0);
            }
        }
        catch (Exception ex)
        {
            App.Log($"[AppLauncher] scan failed: {ex.Message}");
        }

        var final = result
            .OrderBy(a => a.Name, StringComparer.OrdinalIgnoreCase)
            .Take(300)
            .ToList();

        lock (_cacheSync)
        {
            _cachedApps = final;
            _cachedAt = DateTime.UtcNow;
        }
        return final;
    }

    private void ScanDirectory(DirectoryInfo dir, List<AppEntry> result, int depth)
    {
        if (depth > 4) return;
        try
        {
            foreach (var lnk in dir.EnumerateFiles("*.lnk"))
            {
                AddShortcut(lnk.FullName, result);
            }
            foreach (var url in dir.EnumerateFiles("*.url"))
            {
                var name = Path.GetFileNameWithoutExtension(url.Name);
                AddEntry(result, name, url.FullName, exists: File.Exists(url.FullName));
            }
            foreach (var sub in dir.EnumerateDirectories())
            {
                // Пропускаємо службові папки з великою кількістю сміття.
                var n = sub.Name;
                if (n.StartsWith("$") || n.Equals("Startup", StringComparison.OrdinalIgnoreCase)) continue;
                ScanDirectory(sub, result, depth + 1);
            }
        }
        catch { /* access denied on some dirs */ }
    }

    private void AddShortcut(string lnkPath, List<AppEntry> result)
    {
        try
        {
            var name = Path.GetFileNameWithoutExtension(lnkPath);
            // Ігноруємо службові ярлики Windows.
            if (name.Length == 0) return;
            var target = ResolveShortcut(lnkPath);

            // ТЗ-ФІКС «мертві ярлики»: ціль не існує → НЕ показуємо взагалі
            // (раніше «Android Studio.lnk» після uninstall падав при запуску).
            if (string.IsNullOrEmpty(target))
            {
                // Ціль не розпізнано (напр. UWP-ярлик) — лишаємо ярлик, якщо сам існує.
                if (File.Exists(lnkPath)) AddEntry(result, name, lnkPath, exists: true, isShortcut: true);
                return;
            }
            if (Directory.Exists(target)) return; // ярлик на папку — не програма
            if (!File.Exists(target)) return;     // мертвий ярлик — пропускаємо (ТЗ)

            var ext = System.IO.Path.GetExtension(target).ToLowerInvariant();
            if (ext != ".exe" && ext != ".bat" && ext != ".cmd")
            {
                // Ціль не виконувана (документ) — все одно дозволимо запуск,
                // але через shell: відкриється асоційована програма.
                AddEntry(result, name, target, exists: true);
                return;
            }
            AddEntry(result, name, target, exists: true);
        }
        catch { }
    }

    private void AddEntry(List<AppEntry> result, string name, string path, bool exists, bool isShortcut = false)
    {
        // ТЗ «прибрати сміття»: деінсталятори/setup/help/git-утиліти тощо
        // НЕ показуємо взагалі (перевірка за назвою і цільовим exe).
        if (IsJunkApp(name, path)) return;

        // Дедуплікація ЗА НАЗВОЮ: «Google Chrome» від Common, від AppData
        // і зі столу — один запис (ТЗ: «щоб не дублювались»).
        if (!_seenNames.TryAdd(name, 0)) return;

        // Дедуплікація за ЦІЛЮ: різні назви (Chrome, Google Chrome) на один exe.
        var targetKey = isShortcut ? "lnk:" + path.ToLowerInvariant() : path.ToLowerInvariant();
        if (path.EndsWith(".exe", StringComparison.OrdinalIgnoreCase) || (!isShortcut && !path.EndsWith(".url", StringComparison.OrdinalIgnoreCase)))
        {
            if (!_seenTargets.TryAdd(targetKey, 0)) return;
        }

        result.Add(new AppEntry { Name = name, Path = path, Exists = exists });
    }

    /// <summary>Розрізає .lnk через WScript.Shell COM (без NuGet).</summary>
    private static string? ResolveShortcut(string lnkPath)
    {
        try
        {
            var shellType = Type.GetTypeFromProgID("WScript.Shell");
            if (shellType == null) return null;
            var shell = Activator.CreateInstance(shellType);
            if (shell == null) return null;
            var shortcut = shellType.InvokeMember("CreateShortcut",
                System.Reflection.BindingFlags.InvokeMethod, null, shell, new object[] { lnkPath });
            if (shortcut == null) return null;
            var target = shortcut!.GetType().InvokeMember("TargetPath",
                System.Reflection.BindingFlags.GetProperty, null, shortcut, null) as string;
            return string.IsNullOrWhiteSpace(target) ? null : target;
        }
        catch { return null; }
    }

    /// <summary>
    /// Запуск програми на ПК (ТЗ). Перед запуском ПЕРЕВІРЯЄ існування цілі —
    /// мертвий ярлик дає зрозумілу помилку замість системного «Операція була
    /// скасована користувачем».
    /// </summary>
    public (bool ok, string error) Launch(string path)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(path)) return (false, "Порожній шлях програми");

            // .lnk: перевіряємо ціль — якщо мертвий, shell видасть незрозуміле
            // «Операція була скасована» → краще чесна помилка одразу.
            if (path.EndsWith(".lnk", StringComparison.OrdinalIgnoreCase))
            {
                if (!File.Exists(path)) return (false, "Ярлик більше не існує на ПК");
                var target = ResolveShortcut(path);
                if (!string.IsNullOrEmpty(target) && !Directory.Exists(target) && !File.Exists(target))
                {
                    return (false, $"Програму видалено з ПК (ціль ярлика відсутня): {System.IO.Path.GetFileName(target)}");
                }
            }
            else if (path.EndsWith(".url", StringComparison.OrdinalIgnoreCase))
            {
                if (!File.Exists(path)) return (false, "Інтернет-ярлик більше не існує");
            }
            else if (!File.Exists(path) && !Directory.Exists(path))
            {
                return (false, "Файл програми не знайдено на ПК — ймовірно, її видалено");
            }

            var psi = new ProcessStartInfo
            {
                FileName = path,
                UseShellExecute = true, // ярлики/документи/протоколи — все через shell
                WorkingDirectory = File.Exists(path)
                    ? System.IO.Path.GetDirectoryName(path) ?? Environment.GetFolderPath(Environment.SpecialFolder.UserProfile)
                    : Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
            };
            Process.Start(psi);
            App.Log($"[AppLauncher] launched: {path}");
            return (true, string.Empty);
        }
        catch (Exception ex)
        {
            App.Log($"[AppLauncher] launch failed: {path} — {ex.Message}");
            return (false, ex.Message);
        }
    }

    /// <summary>
    /// Іконки для партії exe-шляхів: { pathLower → "data:image/png;base64,…" }.
    /// Спільна логіка з ProcessManagerService.ExtractIconDataUrl.
    /// </summary>
    public static Dictionary<string, string> ExtractIconsBatch(IEnumerable<string> paths, int maxPerBatch = 10)
    {
        var icons = new Dictionary<string, string>(StringComparer.Ordinal);
        int count = 0;
        foreach (var rawPath in paths)
        {
            if (count >= maxPerBatch) break;
            var p = rawPath;
            // Ярлики: іконку беремо з .lnk (у ній вшита іконка цілі).
            try
            {
                if (p.EndsWith(".lnk", StringComparison.OrdinalIgnoreCase))
                {
                    var target = ResolveShortcut(p);
                    if (!string.IsNullOrEmpty(target) && File.Exists(target)) p = target;
                }
                if (p.EndsWith(".url", StringComparison.OrdinalIgnoreCase)) continue;

                var key = rawPath.ToLowerInvariant();
                var dataUrl = ProcessManagerService.ExtractIconDataUrl(p);
                if (!string.IsNullOrEmpty(dataUrl)) icons[key] = dataUrl;
                count++;
            }
            catch { }
        }
        return icons;
    }
}
