using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;

namespace FluxControl.Agent.Services;

/// <summary>
/// Хаб терміналів (ТЗ 46: «кілька вкладок у терміналі»): кожна вкладка сайту —
/// окрема shell-сесія (PowerShell/CMD) зі своїм cwd і виводом. Плюс ГЛОБАЛЬНА
/// історія команд, що живе в пам'яті агента до його перезапуску/перезавантаження
/// ПК (ТЗ: «історія зберігається, поки комп'ютер не перезавантажиться»).
/// </summary>
public class TerminalHubService : IDisposable
{
    private class TabSession
    {
        public TerminalService Terminal = new();
        public string Shell = "powershell";
    }

    private readonly ConcurrentDictionary<string, TabSession> _sessions = new();
    private readonly object _historyLock = new();
    private readonly List<string> _history = new();
    private const int MaxHistory = 500;
    private const int MaxSessions = 8;

    /// <summary>Вивід вкладки: (tabId, text).</summary>
    public event Action<string, string>? OnOutput;
    /// <summary>Вкладка завершилася сама (користувач набрав exit на ПК).</summary>
    public event Action<string>? OnTabExited;

    /// <summary>Чи процес агента виконується з правами адміністратора —
    /// дочірні shell успадковують ті самі права (бейдж ADMIN на сайті).</summary>
    public static bool IsAdmin
    {
        get
        {
            try
            {
                using var identity = WindowsIdentity.GetCurrent();
                var principal = new WindowsPrincipal(identity);
                return principal.IsInRole(WindowsBuiltInRole.Administrator);
            }
            catch { return false; }
        }
    }

    private static string NormTab(string? tabId)
    {
        var id = (tabId ?? "").Trim();
        if (id.Length == 0 || id.Length > 64) return "t1";
        return id;
    }

    public void StartSession(string? tabId, string shellType)
    {
        var id = NormTab(tabId);
        var shell = (shellType ?? "powershell").ToLowerInvariant() == "cmd" ? "cmd" : "powershell";

        if (_sessions.Count >= MaxSessions && !_sessions.ContainsKey(id))
        {
            // Нова вкладка понад ліміт — гасимо найстарішу (найменше нещодавно активну).
            var oldest = _sessions.Keys.FirstOrDefault();
            if (oldest != null) StopSession(oldest);
        }

        var session = _sessions.AddOrUpdate(
            id,
            _ => new TabSession { Terminal = CreateSession(id, shell), Shell = shell },
            (_, old) =>
            {
                try { old.Terminal.Dispose(); } catch { }
                return new TabSession { Terminal = CreateSession(id, shell), Shell = shell };
            });
        session.Shell = shell;
    }

    private TerminalService CreateSession(string tabId, string shell)
    {
        var ts = new TerminalService();
        ts.OnOutputReceived += text => OnOutput?.Invoke(tabId, text);
        ts.OnErrorReceived += text => OnOutput?.Invoke(tabId, text);
        ts.OnExited += () =>
        {
            OnOutput?.Invoke(tabId, "\n[сесію завершено]\n");
            OnTabExited?.Invoke(tabId);
        };
        ts.StartSession(shell);
        return ts;
    }

    public void SendInput(string? tabId, string input)
    {
        var id = NormTab(tabId);
        var cmd = (input ?? "").Trim();

        // Історія — глобальна на всі вкладки, лише в пам'яті (до перезапуску ПК).
        if (cmd.Length > 0 && cmd.Length <= 500)
        {
            lock (_historyLock)
            {
                // Останню ідентичну команду не дублюємо поспіль.
                if (_history.Count == 0 || !string.Equals(_history[^1], cmd, StringComparison.Ordinal))
                {
                    _history.Add(cmd);
                    if (_history.Count > MaxHistory) _history.RemoveAt(0);
                }
            }
        }

        if (!_sessions.TryGetValue(id, out var session))
        {
            StartSession(id, "powershell");
            session = _sessions[id];
        }
        session.Terminal.SendInput(input ?? "");
    }

    public string GetSessionShell(string? tabId)
    {
        return _sessions.TryGetValue(NormTab(tabId), out var s) ? s.Shell : "powershell";
    }

    public void StopSession(string? tabId)
    {
        var id = NormTab(tabId);
        if (_sessions.TryRemove(id, out var session))
        {
            try { session.Terminal.Dispose(); } catch { }
        }
    }

    /// <summary>Глобальна історія (нові — в кінці).</summary>
    public List<string> GetHistory()
    {
        lock (_historyLock) return _history.ToList();
    }

    public void Dispose()
    {
        foreach (var key in _sessions.Keys.ToList())
        {
            StopSession(key);
        }
    }
}
