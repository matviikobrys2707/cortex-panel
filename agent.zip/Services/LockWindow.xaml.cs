using System;
using System.IO;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Windows;
using System.Windows.Threading;

namespace FluxControl.Agent.Services;

/// <summary>
/// Fullscreen uncloseable window shown while WinLock is engaged.
/// ДИЗАЙН — ВИКЛЮЧНО WebView2 (ТЗ: нативний C#-фолбек видалено з коду).
/// Джерело дизайну — ЛОКАЛЬНИЙ файл <see cref="RuntimeFiles.WinLockHtmlPath"/>
/// (%AppData%\FluxControl\UI\winlock.html, вбудований у збірку): жодної мережі —
/// блокування миттєве і працює офлайн (ТЗ 6: завантаження з сайту прибрано).
/// Щоб не було білого/сірого спалаху і глітчів появи: вікно стартує Opacity=0,
/// WebView2 ініціалізується СЕРЕДИЩЕМ з <see cref="PreWarmWebView2"/> (прогрів
/// ще на старті застосунку — мінус 1–3с), а fade-in 250мс запускається лише
/// ПІСЛЯ першого NavigationCompleted. Alt+F4 etc. swallowed by the service's
/// keyboard hook; Closing guard cancels every external close attempt.
/// Only <see cref="WinLockService"/> may dismiss it via <see cref="ForceClose"/>.
/// </summary>
public partial class LockWindow : Window
{
    private readonly WinLockService _service;
    private readonly DispatcherTimer _topmostTimer;
    private readonly DispatcherTimer _retryTimer;
    private readonly string _mode;
    private readonly long _lockedAt;
    private bool _forceCloseAllowed;
    private bool _webShown;
    private bool _webReady;
    private bool _revealed;
    private int _retryCount;
    private bool _busy;

    /// <summary>
    /// Прогрів середовища WebView2 ще на старті застосунку (ТЗ: «блокування
    /// миттєве»). EnsureCoreWebView2Async без прогріву займає 1–3с.
    /// </summary>
    private static Task<Microsoft.Web.WebView2.Core.CoreWebView2Environment>? _envWarm;
    public static void PreWarmWebView2()
    {
        if (_envWarm != null) return;
        _envWarm = Task.Run(async () =>
        {
            var userDataDir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "FluxControl", "WebView2Lock");
            Directory.CreateDirectory(userDataDir);
            return await Microsoft.Web.WebView2.Core.CoreWebView2Environment.CreateAsync(null, userDataDir);
        });
    }

    public LockWindow(WinLockService service, string mode, long lockedAt)
    {
        InitializeComponent();

        _service = service;
        _mode = mode;
        _lockedAt = lockedAt;

        Loaded += OnLoaded;
        Deactivated += OnDeactivated;
        Closing += OnClosingGuard;

        // Re-assert Topmost/Fullscreen periodically in case something stole it.
        _topmostTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(2) };
        _topmostTimer.Tick += (_, _) =>
        {
            AssertTopmost();
            if (WindowState != WindowState.Maximized) AssertFullScreen();
        };

        // Ретраї завантаження локального дизайну (якщо WebView2 тимчасово впав —
        // нативної панелі більше немає, сплеш лишається до появи веб-дизайну).
        _retryTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(4) };
        _retryTimer.Tick += async (_, _) => await LoadDesignAsync();
    }

    private async void OnLoaded(object sender, RoutedEventArgs e)
    {
        // Повний екран (ТЗ): безрамкове максимізоване вікно в WPF зазвичай
        // покриває весь екран, але на деяких оболонках лишає смугу задачі —
        // тому додатково фіксуємо межі ВІРТУАЛЬНОГО екрана. Поки Opacity=0 —
        // жодних видимих перестрибувань.
        AssertFullScreen();
        AssertTopmost();
        _topmostTimer.Start();
        await LoadDesignAsync();
    }

    private string LocalDesignPath => RuntimeFiles.WinLockHtmlPath;

    private async Task LoadDesignAsync()
    {
        if (_webShown || _busy) return;
        _busy = true;
        try
        {
            _retryCount++;
            if (_retryCount > 3) _retryTimer.Interval = TimeSpan.FromSeconds(8);

            // Прогріте середовище (PreWarmWebView2) — те, що робить відкриття
            // без лагів: створення CoreWebView2Environment вже завершено.
            var env = await (_envWarm ?? Microsoft.Web.WebView2.Core.CoreWebView2Environment.CreateAsync(null,
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "FluxControl", "WebView2Lock")));
            await LockWeb.EnsureCoreWebView2Async(env);

            if (!_webReady)
            {
                LockWeb.DefaultBackgroundColor = System.Drawing.Color.FromArgb(0xFF, 0x05, 0x05, 0x08);
                LockWeb.CoreWebView2.Settings.AreDevToolsEnabled = false;
                LockWeb.CoreWebView2.Settings.IsZoomControlEnabled = false;
                LockWeb.CoreWebView2.Settings.AreDefaultContextMenusEnabled = false;
                LockWeb.CoreWebView2.Settings.IsStatusBarEnabled = false;
                LockWeb.CoreWebView2.WebMessageReceived += OnWebMessageReceived;
                LockWeb.NavigationCompleted += OnLockWebNavigationCompleted;
                _webReady = true;
            }

            // ЛОКАЛЬНИЙ файл (ТЗ 6: без мережі — миттєво і працює офлайн).
            if (!File.Exists(LocalDesignPath))
                throw new FileNotFoundException($"WinLock design file not found: {LocalDesignPath}");
            var pc = Uri.EscapeDataString(Environment.MachineName);
            var fileUrl = new Uri(LocalDesignPath).AbsoluteUri;
            LockWeb.CoreWebView2.Navigate($"{fileUrl}?mode={Uri.EscapeDataString(_mode)}&lockedAt={_lockedAt}&pc={pc}");
            _retryTimer.Stop();
        }
        catch (Exception ex)
        {
            App.Log($"[WinLock] web design load failed (attempt {_retryCount}): {ex.Message}");
            // Кілька ретраїв не допомогли — показуємо хоча б темне фулскрін-вікно
            // (замість невидимого): гачок і Closing-guard уже активні, власник
            // може розблокувати з сайту (сервіс закриє вікно через ForceClose()).
            if (_retryCount >= 3) RevealWindow();
            if (!_retryTimer.IsEnabled) _retryTimer.Start();
        }
        finally
        {
            _busy = false;
        }
    }

    private void OnLockWebNavigationCompleted(object? sender, Microsoft.Web.WebView2.Core.CoreWebView2NavigationCompletedEventArgs e)
    {
        if (_webShown) return;
        if (!e.IsSuccess)
        {
            // Локальний дизайн не завантажився (рідкісний збій WebView) — тихий
            // ретрай; після кількох невдач показуємо хоча б темне вікно.
            if (_retryCount >= 3) RevealWindow();
            if (!_retryTimer.IsEnabled) _retryTimer.Start();
            return;
        }

        try
        {
            _webShown = true;
            _retryTimer.Stop();

            // ТЗ: fade-in вікна 250мс ПІСЛЯ першого NavigationCompleted —
            // екран з'являється вже ПОВНІСТЮ готовим (без білого спалаху).
            RevealWindow();

            // разова синхронізація стану для сторінки
            PostToPage(new { type = "winlock_state", mode = _mode, lockedAt = _lockedAt, pc = Environment.MachineName });
        }
        catch { }
    }

    /// <summary>Плавна поява вікна Opacity 0→1 за 250мс (одноразово).</summary>
    private void RevealWindow()
    {
        if (_revealed) return;
        _revealed = true;
        try
        {
            var fade = new System.Windows.Media.Animation.DoubleAnimation(0d, 1d, TimeSpan.FromMilliseconds(250))
            {
                EasingFunction = new System.Windows.Media.Animation.CubicEase { EasingMode = System.Windows.Media.Animation.EasingMode.EaseOut }
            };
            BeginAnimation(OpacityProperty, fade);
        }
        catch
        {
            try { Opacity = 1d; } catch { }
        }
    }

    /// <summary>Межі вікна = віртуальний екран (усі монітори) + максимізація.</summary>
    private void AssertFullScreen()
    {
        try
        {
            WindowState = WindowState.Normal;
            Left = SystemParameters.VirtualScreenLeft;
            Top = SystemParameters.VirtualScreenTop;
            Width = SystemParameters.VirtualScreenWidth;
            Height = SystemParameters.VirtualScreenHeight;
            WindowState = WindowState.Maximized;
        }
        catch { }
    }

    private void OnWebMessageReceived(object? sender, Microsoft.Web.WebView2.Core.CoreWebView2WebMessageReceivedEventArgs e)
    {
        try
        {
            // ТЗ-ФІКС БАГА «код перевіряється, але нічого не відбувається»:
            // сторінка може надіслати ОБ'ЄКТ (WebMessageAsJson = {"type":...})
            // АБО JSON-рядок (WebMessageAsJson = "{\"type\"...}") — приймаємо обидва.
            JsonObject? msg = null;
            try
            {
                msg = JsonSerializer.Deserialize<JsonObject>(e.WebMessageAsJson);
            }
            catch
            {
                try
                {
                    var asString = JsonSerializer.Deserialize<string>(e.WebMessageAsJson);
                    if (!string.IsNullOrWhiteSpace(asString))
                        msg = JsonSerializer.Deserialize<JsonObject>(asString);
                }
                catch { }
            }

            var type = msg?["type"]?.GetValue<string>() ?? "";
            if (type == "winlock_try")
            {
                var code = msg?["code"]?.GetValue<string>() ?? string.Empty;
                var ok = _service.TryUnlock(code);
                if (!ok)
                {
                    PostToPage(new { type = "winlock_unlock_result", ok = false });
                }
                // ok == true → сервіс сам закриє це вікно через ForceClose()
            }
            else if (type == "winlock_ready")
            {
                PostToPage(new { type = "winlock_state", mode = _mode, lockedAt = _lockedAt, pc = Environment.MachineName });
            }
        }
        catch (Exception ex)
        {
            App.Log($"[WinLock] web message error: {ex.Message}");
        }
    }

    private void PostToPage(object payload)
    {
        try
        {
            LockWeb.CoreWebView2?.PostWebMessageAsJson(JsonSerializer.Serialize(payload));
        }
        catch { }
    }

    private void OnDeactivated(object? sender, EventArgs e)
    {
        AssertTopmost();
    }

    private void AssertTopmost()
    {
        try
        {
            Topmost = true;
            Activate();
        }
        catch { }
    }

    private void OnClosingGuard(object? sender, System.ComponentModel.CancelEventArgs e)
    {
        if (_forceCloseAllowed)
        {
            _topmostTimer.Stop();
            _retryTimer.Stop();
            return;
        }
        e.Cancel = true; // this window is the lock surface — nothing external may close it
    }

    /// <summary>Service-initiated dismissal (unlock): bypasses the OnClosing guard.</summary>
    internal void ForceClose()
    {
        _forceCloseAllowed = true;
        try { Close(); } catch { }
    }
}
