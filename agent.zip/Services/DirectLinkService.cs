using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.WebSockets;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;

namespace FluxControl.Agent.Services;

/// <summary>
/// «Пряме з'єднання» (ТЗ 49): канал між телефоном і ПК в обхід хмарного релея.
///
/// Як це працює:
///   1. При старті агент один раз завантажує компактне ядро каналу (linkcore.exe)
///      у %LOCALAPPDATA%\FluxControl\link (якщо його ще немає).
///   2. Поруч піднімається ЛОКАЛЬНИЙ WS-шлюз тільки на 127.0.0.1 (5081+) з
///      єдиним ендпоінтом /relay — назовні нічого, крім нього, не струмує.
///   3. Ядро відкриває публічний тунель до локального шлюза і віддає URL виду
///      https://....trycloudflare.com — без реєстрації, без акаунтів, без лімітів.
///   4. URL реєструється на хмарному релеї (direct_register). Веб-панель бере
///      його звідти і підключається НАПРЯМУКУ до ПК: стрим екрана, звук,
///      файли, скриншоти тощо не витрачають трафік сервера взагалі.
///
/// Безпека: /relay приймає сокет лише з правильним code (код пристрою) і
/// key (разовий 64-символьний ключ, який агент сам реєструє на сервері, а
/// сервер віддає тільки власнику пристрою). Усі інші ендпоінти через тунель
/// недоступні (шлюз слухає лише loopback і має один маршрут).
///
/// Ім'я навмисно нейтральне: в інтерфейсі й логах — «Пряме з'єднання».
/// </summary>
public class DirectLinkService : IDisposable
{
    public enum LinkStatus { Idle, Downloading, Starting, Active, Unavailable }

    // Джерело ядра каналу. Завантажується один раз і кешується назавжди.
    private const string CoreDownloadUrl =
        "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe";

    private static readonly Regex TunnelUrlRegex =
        new(@"https://[a-zA-Z0-9][a-zA-Z0-9-]*\.trycloudflare\.com", RegexOptions.Compiled);

    private static readonly HttpClient _downloadClient = new()
    {
        // Файл ~50 МБ: на повільних каналах даємо щедрий таймаут.
        Timeout = TimeSpan.FromMinutes(15)
    };

    private CancellationTokenSource? _cts;
    private WebApplication? _gateway;
    private Process? _coreProcess;
    private bool _started;
    private bool _disposed;
    private int _gwPort;
    private int _consecutiveFailures;

    public LinkStatus Status { get; private set; } = LinkStatus.Idle;
    public string? PublicUrl { get; private set; }
    public bool IsAvailable => Status == LinkStatus.Active && !string.IsNullOrEmpty(PublicUrl);

    public event Action<LinkStatus>? OnStatusChanged;
    public event Action<string?>? OnUrlChanged;

    /// <summary>
    /// Ставить MainWindow: прийняти панельний WS-сокет. Реалізація (релей-клієнт)
    /// перевіряє code+key і повертає Task життєвого циклу сесії (або null — відмова).
    /// </summary>
    public Func<WebSocket, string, string, Task?>? PanelAttach { get; set; }

    // Сховище компонентів програми (ТЗ): %AppData%\FluxControl\components\link.
    private static string CoreDir => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
        "FluxControl", "components", "link");

    private static string CorePath => Path.Combine(CoreDir, "linkcore.exe");

    /// <summary>Старе розташування ядра (LOCALAPPDATA) — мігрує в components/
    /// при першому запуску, щоб не качати ~50 МБ повторно.</summary>
    private static string LegacyCorePath => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "FluxControl", "link", "linkcore.exe");

    private static bool _migratedLegacy;

    private static void TryMigrateLegacyCore()
    {
        if (_migratedLegacy) return;
        _migratedLegacy = true;
        try
        {
            if (!File.Exists(LegacyCorePath) || File.Exists(CorePath)) return;
            var size = new FileInfo(LegacyCorePath).Length;
            if (size < 10 * 1024 * 1024) return;
            Directory.CreateDirectory(CoreDir);
            File.Copy(LegacyCorePath, CorePath, overwrite: false);
            App.Log($"[Direct] Ядро мігрувало зі старої папки: {CoreDir} ({size / 1024 / 1024} MB).");
        }
        catch { /* не критично — EnsureCoreAsync докачає за потреби */ }
    }

    public void Start()
    {
        if (_started || _disposed) return;
        _started = true;
        _cts = new CancellationTokenSource();
        var ct = _cts.Token;

        // Шлюз стартує першим (тунель цілитиметься в його порт).
        _ = Task.Run(() => RunGatewayAsync(ct), ct);
        // Ядро: завантаження (якщо треба) + супервізор процесу тунелю.
        _ = Task.Run(() => RunSupervisorAsync(ct), ct);
    }

    // ============================== ЛОКАЛЬНИЙ ШЛЮЗ ==============================

    private async Task RunGatewayAsync(CancellationToken ct)
    {
        try
        {
            var builder = WebApplication.CreateBuilder();
            builder.Logging.ClearProviders(); // без консольного шуму в WPF-додатку

            builder.WebHost.ConfigureKestrel(options =>
            {
                // Лише loopback: назовні (крім тунелю) шлюз недоступний.
                for (int port = 5081; port <= 5094; port++)
                {
                    try
                    {
                        options.Listen(IPAddress.Loopback, port);
                        _gwPort = port;
                        break;
                    }
                    catch { /* порт зайнятий — пробуємо наступний */ }
                }
            });

            var app = builder.Build();

            app.Map("/ping", () => Results.Ok(new { status = "ok" }));

            // Єдиний публічний маршрут: панель підключається через тунель сюди.
            app.Map("/relay", async (HttpContext ctx) =>
            {
                if (!ctx.WebSockets.IsWebSocketRequest)
                {
                    ctx.Response.StatusCode = StatusCodes.Status400BadRequest;
                    return;
                }

                var code = ctx.Request.Query["code"].ToString();
                var key = ctx.Request.Query["key"].ToString();
                var ws = await ctx.WebSockets.AcceptWebSocketAsync();

                var session = PanelAttach?.Invoke(ws, code, key);
                if (session == null)
                {
                    // Некоректні code/key — миттєво закриваємо.
                    try { await ws.CloseAsync(WebSocketCloseStatus.PolicyViolation, "auth failed", CancellationToken.None); } catch { }
                    try { ws.Dispose(); } catch { }
                    return;
                }

                // Сесія живе тут: сокет повністю у власності релей-клієнта.
                await session;
            });

            await app.StartAsync(ct);
            _gateway = app;
            App.Log($"[Direct] Local gateway listening on 127.0.0.1:{_gwPort}.");
        }
        catch (Exception ex)
        {
            App.Log($"[Direct] Gateway failed: {ex.Message}");
            SetStatus(LinkStatus.Unavailable);
        }
    }

    // ============================== ЯДРО ТУНЕЛЮ ==============================

    private async Task RunSupervisorAsync(CancellationToken ct)
    {
        while (!ct.IsCancellationRequested)
        {
            try
            {
                if (!await EnsureCoreAsync(ct))
                {
                    // Немає мережі/GitHub недоступний — повторимо пізніше.
                    SetStatus(LinkStatus.Unavailable);
                    await Task.Delay(TimeSpan.FromMinutes(10), ct).ContinueWith(_ => { });
                    continue;
                }

                SetStatus(LinkStatus.Starting);
                PublicUrl = null;
                OnUrlChanged?.Invoke(null);

                using var proc = StartCoreProcess();
                _coreProcess = proc;
                var startedAt = Environment.TickCount64;
                var exited = new TaskCompletionSource<object?>(TaskCreationOptions.RunContinuationsAsynchronously);
                proc.Exited += (_, _) => exited.TrySetResult(null);
                proc.OutputDataReceived += (_, e) => HandleCoreLine(e.Data);
                proc.ErrorDataReceived += (_, e) => HandleCoreLine(e.Data);
                proc.BeginOutputReadLine();
                proc.BeginErrorReadLine();

                App.Log("[Direct] Tunnel core started, waiting for a public link...");
                try
                {
                    await exited.Task.WaitAsync(ct);
                }
                catch (OperationCanceledException) { break; }

                // Процес вийшов (мережа/антивірус/оновлення edge). Backoff.
                _coreProcess = null;
                _consecutiveFailures = Environment.TickCount64 - startedAt > 300_000 ? 0 : _consecutiveFailures + 1;
                var delay = TimeSpan.FromSeconds(Math.Min(60, 5 * Math.Pow(2, Math.Min(_consecutiveFailures, 5))));
                App.Log($"[Direct] Tunnel core exited, restarting in {delay.TotalSeconds:F0}s...");
                PublicUrl = null;
                OnUrlChanged?.Invoke(null);
                SetStatus(LinkStatus.Starting);
                await Task.Delay(delay, ct).ContinueWith(_ => { });
            }
            catch (OperationCanceledException) { break; }
            catch (Exception ex)
            {
                App.Log($"[Direct] Supervisor error: {ex.Message}");
                await Task.Delay(TimeSpan.FromSeconds(10), ct).ContinueWith(_ => { });
            }
        }
    }

    private Process StartCoreProcess()
    {
        var psi = new ProcessStartInfo
        {
            FileName = CorePath,
            Arguments = $"tunnel --url http://127.0.0.1:{_gwPort} --no-autoupdate --protocol http2 --edge-ip-version 4",
            UseShellExecute = false,
            CreateNoWindow = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            WorkingDirectory = CoreDir
        };
        return Process.Start(psi) ?? throw new InvalidOperationException("Process.Start returned null");
    }

    private void HandleCoreLine(string? line)
    {
        if (string.IsNullOrEmpty(line)) return;
        var match = TunnelUrlRegex.Match(line);
        if (match.Success && !string.Equals(PublicUrl, match.Value, StringComparison.OrdinalIgnoreCase))
        {
            PublicUrl = match.Value;
            _consecutiveFailures = 0;
            SetStatus(LinkStatus.Active);
            App.Log($"[Direct] Public link is ready: {PublicUrl}");
            OnUrlChanged?.Invoke(PublicUrl);
        }
    }

    private async Task<bool> EnsureCoreAsync(CancellationToken ct)
    {
        try
        {
            TryMigrateLegacyCore();
            Directory.CreateDirectory(CoreDir);

            if (File.Exists(CorePath))
            {
                var fi = new FileInfo(CorePath);
                if (fi.Length > 10 * 1024 * 1024) return true; // вже завантажено
                try { fi.Delete(); } catch { }
            }

            SetStatus(LinkStatus.Downloading);
            App.Log("[Direct] Downloading the direct-link core (one time, ~50 MB)...");

            var tmpPath = CorePath + ".tmp";
            using (var resp = await _downloadClient.GetAsync(CoreDownloadUrl, HttpCompletionOption.ResponseHeadersRead, ct))
            {
                resp.EnsureSuccessStatusCode();
                await using var src = await resp.Content.ReadAsStreamAsync(ct);
                await using var dst = new FileStream(tmpPath, FileMode.Create, FileAccess.Write, FileShare.None, 1024 * 64, useAsync: true);
                var buffer = new byte[1024 * 64];
                long total = 0;
                int read;
                while ((read = await src.ReadAsync(buffer, ct)) > 0)
                {
                    await dst.WriteAsync(buffer.AsMemory(0, read), ct);
                    total += read;
                }
                await dst.FlushAsync(ct);
            }

            // Порожній/обрізаний файл не приймаємо.
            if (new FileInfo(tmpPath).Length < 10 * 1024 * 1024)
            {
                try { File.Delete(tmpPath); } catch { }
                return false;
            }

            if (File.Exists(CorePath)) try { File.Delete(CorePath); } catch { }
            File.Move(tmpPath, CorePath);
            App.Log($"[Direct] Direct-link core ready ({new FileInfo(CorePath).Length / 1024 / 1024} MB).");
            return true;
        }
        catch (OperationCanceledException) { throw; }
        catch (Exception ex)
        {
            App.Log($"[Direct] Core download failed: {ex.Message}");
            return false;
        }
    }

    private void SetStatus(LinkStatus status)
    {
        if (Status == status) return;
        Status = status;
        try { OnStatusChanged?.Invoke(status); } catch { }
    }

    public void Stop()
    {
        try { _cts?.Cancel(); } catch { }
        try { if (_coreProcess != null && !_coreProcess.HasExited) _coreProcess.Kill(true); } catch { }
        try { _gateway?.StopAsync().Wait(TimeSpan.FromSeconds(3)); } catch { }
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        Stop();
        try { _cts?.Dispose(); } catch { }
    }
}
