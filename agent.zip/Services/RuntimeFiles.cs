using System;
using System.IO;
using System.Windows;

namespace FluxControl.Agent.Services;

/// <summary>
/// Розтаутно-незалежний EXE (ТЗ користувача): програма може лежати де завгодно
/// (робочий стіл, Downloads…) — всі робочі файли вона тримає у своєму
/// сховищі %AppData%\FluxControl. Інтерфейс агента (UI/agent_ui.html) та
/// іконка (logo.ico) вбудовані в збірку як ресурси і витягуються в це сховище
/// при першому запуску (WebView2 читає html саме з диска).
///
/// Оновлені версії цих файлів (без пересборки exe) підтягує
/// BootstrapService.SyncExtraFilesFromManifest — звіряючи sha256 з манифестом
/// version.json у main-гілці репозиторію релізів.
/// </summary>
public static class RuntimeFiles
{
    /// <summary>Кореневе сховище програми: %AppData%\FluxControl.</summary>
    public static string DataRoot { get; } = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FluxControl");

    /// <summary>Повний шлях до agent_ui.html у сховищі (після EnsureRuntimeFiles).</summary>
    public static string UiHtmlPath { get; private set; } =
        Path.Combine(DataRoot, "UI", "agent_ui.html");

    /// <summary>Повний шлях до logo.ico у сховищі (після EnsureRuntimeFiles).</summary>
    public static string LogoIcoPath { get; private set; } =
        Path.Combine(DataRoot, "logo.ico");

    /// <summary>
    /// Повний шлях до офлайн-дизайну екрана блокування (ТЗ: «дизайн брав з файла
    /// на комп'ютері, щоб не ходити на сайт — швидко працювало»). Файл вбудовано
    /// в збірку і витягнуто у сховище при першому запуску; BootstrapService/агент
    /// оновлюють його з сайту у фоні, щоб дизайн свіжів без пересборки exe.
    /// </summary>
    public static string WinLockHtmlPath { get; private set; } =
        Path.Combine(DataRoot, "UI", "winlock.html");

    /// <summary>Повний шлях до зображення скримера (ТЗ «функції для тролінгу»).
    /// Вбудоване в збірку й витягнуте у сховище під час EnsureRuntimeFiles.</summary>
    public static string ScreamerImagePath { get; private set; } =
        Path.Combine(DataRoot, "UI", "screamer.jpg");

    /// <summary>Повний шлях до звуку скримера (WAV, System.Media.SoundPlayer).</summary>
    public static string ScreamerSoundPath { get; private set; } =
        Path.Combine(DataRoot, "UI", "scream.wav");

    /// <summary>Витягує вбудовані файли, яких бракує у сховищі. Ідемпотентно.</summary>
    public static void EnsureRuntimeFiles()
    {
        Directory.CreateDirectory(DataRoot);
        UiHtmlPath = ExtractIfNeeded("UI/agent_ui.html", "pack://application:,,,/UI/agent_ui.html");
        LogoIcoPath = ExtractIfNeeded("logo.ico", "pack://application:,,,/logo.ico");
        // winlock.html — overwriteIfChanged: інакше старий кеш від попередньої
        // збірки (пурпуровий дизайн) залишався б назавжди і новий дизайн ніколи
        // не з'явився б у користувача (BootstrapService оновлює його лише якщо
        // манифест сайту доступний).
        WinLockHtmlPath = ExtractIfNeeded("UI/winlock.html", "pack://application:,,,/UI/winlock.html", overwriteIfChanged: true);
        ScreamerImagePath = ExtractIfNeeded("UI/screamer.jpg", "pack://application:,,,/UI/screamer.jpg");
        ScreamerSoundPath = ExtractIfNeeded("UI/scream.wav", "pack://application:,,,/UI/scream.wav");
    }

    /// <summary>
    /// Отримати вбудований ресурс збірки як байти (null — ресурс відсутній).
    /// Використовується BootstrapService, щоб звіряти sha256 вбудованого
    /// agent_ui.html / logo.ico з манифестом version.json.
    /// </summary>
    public static byte[]? GetEmbeddedFile(string relPath)
    {
        try
        {
            var packUri = "pack://application:,,,/" + relPath.Replace('\\', '/');
            var sri = System.Windows.Application.GetResourceStream(new Uri(packUri, UriKind.Absolute));
            if (sri == null) return null;
            using var ms = new MemoryStream();
            using (var input = sri.Stream) input.CopyTo(ms);
            return ms.ToArray();
        }
        catch { return null; }
    }

    private static string ExtractIfNeeded(string relPath, string packUri, bool overwriteIfChanged = false)
    {
        var dest = Path.Combine(DataRoot, relPath.Replace('/', Path.DirectorySeparatorChar));
        try
        {
            if (File.Exists(dest))
            {
                if (!overwriteIfChanged) return dest; // вже витягнуто або синхронізовано

                // Оновлений вбудований файл (інша збірка) — перезаписуємо кеш.
                var embedded = GetEmbeddedFile(relPath);
                if (embedded == null) return dest;
                try
                {
                    var existing = File.ReadAllBytes(dest);
                    if (existing.Length == embedded.Length && existing.SequenceEqual(embedded)) return dest;
                }
                catch { return dest; }
            }

            var sri = System.Windows.Application.GetResourceStream(new Uri(packUri, UriKind.Absolute));
            if (sri == null)
            {
                App.Log($"RuntimeFiles: resource not found: {packUri}");
                return dest;
            }

            Directory.CreateDirectory(Path.GetDirectoryName(dest)!);
            using (var input = sri.Stream)
            using (var output = new FileStream(dest, FileMode.Create, FileAccess.Write, FileShare.Read))
            {
                input.CopyTo(output);
            }
            App.Log($"RuntimeFiles: extracted {relPath} ({new FileInfo(dest).Length} bytes)");
        }
        catch (Exception ex)
        {
            App.Log($"RuntimeFiles: extract {relPath} failed: {ex.Message}");
        }
        return dest;
    }
}
