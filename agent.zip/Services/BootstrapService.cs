using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Threading;
using System.Threading.Tasks;

namespace FluxControl.Agent.Services;

/// <summary>
/// Самоперевірка при старті (ТЗ користувача): програма перевіряє свої файли
/// у сховищі %AppData%\FluxControl. У самодостатньому single-file EXE
/// інтерфейс агента (UI/agent_ui.html) та іконка (logo.ico) вбудовані в
/// збірку — RuntimeFiles витягує їх у сховище при першому запуску (без мережі).
///
/// Оновлення цих файлів без пересборки exe: SyncExtraFilesFromManifest()
/// читає манифест version.json з ОФІЦІЙНОГО САЙТУ (fluxcontrol.pages.dev —
/// ТЗ «убери гитхаб»), звіряє sha256 кожного файлу з files[] і довантажує
/// змінені/відсутні з кореня сайту: {name}. Резервний канал — raw
/// головної гілки репозиторію сайту (той самий вміст).
/// </summary>
public static class BootstrapService
{
    /// <summary>Офіційний сайт — єдине джерело манифесту і робочих файлів.</summary>
    private const string SiteBase = "https://fluxcontrol.pages.dev";
    private const string VersionJsonUrl = SiteBase + "/version.json";
    private const string FilesBaseUrl = SiteBase + "/";

    /// <summary>Резервний канал (вміст ідентичний сайту): raw головної гілки репозиторію.</summary>
    private const string RawFilesBaseUrl =
        "https://raw.githubusercontent.com/matviikobrys2707/FluxControl/main/";
    private const string RawVersionJsonUrl =
        "https://raw.githubusercontent.com/matviikobrys2707/FluxControl/main/version.json";

    /// <summary>Файли, без яких програма не працює (шлях відносно %AppData%\FluxControl).</summary>
    private static readonly string[] RequiredFiles =
    {
        "UI/agent_ui.html", // інтерфейс агента
        "logo.ico"          // іконка вікна/трея/ярликів
    };

    /// <summary>Сховище програми: %AppData%\FluxControl (не залежить від розташування exe).</summary>
    public static string AppDir => RuntimeFiles.DataRoot;

    private static readonly HttpClient Http = new(new HttpClientHandler
    {
        AllowAutoRedirect = true // raw.githubusercontent.com може редіректити
    })
    {
        Timeout = TimeSpan.FromSeconds(30)
    };

    static BootstrapService()
    {
        Http.DefaultRequestHeaders.UserAgent.ParseAdd("FluxControl-Agent/1.0");
    }

    /// <summary>Список відсутніх критичних файлів (відносні шляхи з «/»).</summary>
    public static List<string> FindMissingFiles()
    {
        var missing = new List<string>();
        foreach (var rel in RequiredFiles)
        {
            var full = Path.Combine(AppDir, rel.Replace('/', Path.DirectorySeparatorChar));
            if (!File.Exists(full)) missing.Add(rel);
        }
        return missing;
    }

    /// <summary>
    /// Відновлення файлів: витягує вбудовані ресурси збірки у сховище
    /// (миттєво, без мережі). Повертає список файлів, яких БРАКУЄ ПІСЛЯ
    /// відновлення (порожній = успіх).
    /// </summary>
    public static async Task<List<string>> InstallMissingFilesAsync(
        IProgress<DownloadProgress>? downloadProgress,
        Action<string>? status,
        CancellationToken ct)
    {
        status?.Invoke("Відновлення вбудованих файлів…");
        await Task.Run(() => RuntimeFiles.EnsureRuntimeFiles(), ct);

        // вбудованих могло не вистачити (наприклад, файл додали в манифест
        // пізніше) — тоді тягнемо з репозиторію релізів
        var remaining = FindMissingFiles();
        if (remaining.Count > 0)
        {
            try
            {
                await SyncFilesFromManifestAsync(remaining, downloadProgress, status, ct);
            }
            catch (Exception ex)
            {
                App.Log($"Bootstrap sync from manifest failed: {ex.Message}");
            }
            remaining = FindMissingFiles();
        }

        status?.Invoke(remaining.Count == 0 ? "Готово" : "Частково встановлено");
        return remaining;
    }

    /// <summary>
    /// Фонова синхронізація робочих файлів з манифестом version.json
    /// (main-гілка репозиторію релізів): звіряє sha256 і довантажує тільки
    /// змінені/відсутні. Викликається після старту, не блокує інтерфейс.
    /// </summary>
    public static async Task SyncExtraFilesFromManifest()
    {
        try
        {
            await SyncFilesFromManifestAsync(null, null, null, CancellationToken.None);
        }
        catch (Exception ex)
        {
            App.Log($"Manifest sync skipped: {ex.Message}");
        }
    }

    /// <summary>
    /// Читає манифест version.json: спершу сайт, при недоступності — raw-резерв.
    /// </summary>
    private static async Task<JsonObject?> FetchManifestAsync(CancellationToken ct)
    {
        foreach (var url in new[] { VersionJsonUrl, RawVersionJsonUrl })
        {
            try
            {
                var manifestUrl = url + "?t=" + DateTimeOffset.UtcNow.ToUnixTimeSeconds();
                using var resp = await Http.GetAsync(manifestUrl, ct);
                resp.EnsureSuccessStatusCode();
                var body = await resp.Content.ReadAsStringAsync(ct);
                body = body.TrimStart('\uFEFF');
                var json = JsonSerializer.Deserialize<JsonObject>(body);
                if (json != null)
                {
                    if (!string.Equals(url, VersionJsonUrl, StringComparison.Ordinal))
                        App.Log("Manifest sync: fallback to raw.githubusercontent manifest");
                    return json;
                }
            }
            catch (OperationCanceledException) { throw; }
            catch (Exception ex)
            {
                App.Log($"Manifest fetch failed ({url}): {ex.Message}");
            }
        }
        return null;
    }

    private static async Task SyncFilesFromManifestAsync(
        List<string>? onlyThese,
        IProgress<DownloadProgress>? progress,
        Action<string>? status,
        CancellationToken ct)
    {
        var json = await FetchManifestAsync(ct);
        if (json?["files"] is not JsonArray entries) return;

        // Політика приоритету файлів (ТЗ «перевірка оновлень при кожному запуску»):
        // • останній реліз у манифесті НОВІШИЙ за збірку -> манифест головний
        //   (UI оновлюється без пересборки exe — базова фіча архітектури v4);
        // • збірка НЕ старіша за останній реліз (напр., exe пересобрали, а деплой
        //   ще не виконали) -> вбудовані в exe файли вважаємо найсвіжішими,
        //   манифест не може «даунгрейднути» їх.
        var latest = json?["latest_version"]?.GetValue<string>();
        var localVer = UpdateService.GetLocalVersion();
        bool preferEmbedded = !UpdateService.IsNewerVersion(latest, localVer);

        foreach (var entry in entries)
        {
            var name = entry?["name"]?.GetValue<string>();
            var sha = entry?["sha256"]?.GetValue<string>();
            if (string.IsNullOrWhiteSpace(name)) continue;
            if (onlyThese != null && !onlyThese.Contains(name)) continue;

            var target = SafeTargetPath(AppDir, name);
            if (target == null)
            {
                App.Log($"Manifest sync: skip unsafe path {name}");
                continue;
            }

            // вбудований ресурс поточної збірки (якщо він є)
            byte[]? embeddedBytes = null;
            string? embeddedHash = null;
            if (preferEmbedded)
            {
                embeddedBytes = RuntimeFiles.GetEmbeddedFile(name);
                if (embeddedBytes != null) embeddedHash = ComputeSha256(embeddedBytes);
            }

            bool exists = File.Exists(target);
            string? localHash = exists ? ComputeSha256(target) : null;

            if (preferEmbedded && embeddedBytes != null && embeddedHash != null)
            {
                // вбудований файл уже у сховищі — все актуально
                if (string.Equals(localHash, embeddedHash, StringComparison.OrdinalIgnoreCase)) continue;

                // інакше витягуємо вбудований: він відповідає саме цій збірці
                Directory.CreateDirectory(Path.GetDirectoryName(target)!);
                await File.WriteAllBytesAsync(target, embeddedBytes, ct);
                App.Log($"Manifest sync: {name} replaced with embedded build file (збірка не старіша за манифест)");
                continue;
            }

            // манифест-режим: збірка старіша за останній реліз
            bool need = !exists ||
                        (!string.IsNullOrEmpty(sha) && !string.Equals(localHash, sha, StringComparison.OrdinalIgnoreCase));
            if (!need) continue;

            status?.Invoke($"Завантаження {name}…");
            var rel = name.Replace('\\', '/').TrimStart('/');
            // спершу сайт, якщо не вийшло — raw-резерв того ж файлу
            var urls = new[]
            {
                FilesBaseUrl + rel + "?t=" + DateTimeOffset.UtcNow.ToUnixTimeSeconds(),
                RawFilesBaseUrl + rel + "?t=" + DateTimeOffset.UtcNow.ToUnixTimeSeconds()
            };
            var tmp = target + ".tmp";
            Directory.CreateDirectory(Path.GetDirectoryName(target)!);

            Exception? lastErr = null;
            bool downloaded = false;
            foreach (var url in urls)
            {
                try
                {
                    using (var src = await Http.GetStreamAsync(url, ct))
                    using (var dst = new FileStream(tmp, FileMode.Create, FileAccess.Write, FileShare.None, 81920, useAsync: true))
                        await src.CopyToAsync(dst, 81920, ct);
                    downloaded = true;
                    break;
                }
                catch (OperationCanceledException) { throw; }
                catch (Exception ex) { lastErr = ex; }
            }
            if (!downloaded)
                throw new InvalidOperationException($"download {name} failed: {lastErr?.Message}");

            if (File.Exists(target)) File.Delete(target);
            File.Move(tmp, target);
            App.Log($"Manifest sync: updated {name}");

            if (progress != null)
            {
                var len = new FileInfo(target).Length;
                progress.Report(new DownloadProgress { ReceivedBytes = len, TotalBytes = len });
            }
        }
    }

    private static string? ComputeSha256(string filePath)
    {
        try
        {
            using var sha = SHA256.Create();
            using var fs = File.OpenRead(filePath);
            return Convert.ToHexString(sha.ComputeHash(fs));
        }
        catch { return null; }
    }

    private static string? ComputeSha256(byte[] bytes)
    {
        try
        {
            using var sha = SHA256.Create();
            return Convert.ToHexString(sha.ComputeHash(bytes));
        }
        catch { return null; }
    }

    private static string? SafeTargetPath(string root, string relName)
    {
        try
        {
            var full = Path.GetFullPath(Path.Combine(root,
                relName.Replace('/', Path.DirectorySeparatorChar)));
            if (!full.StartsWith(root, StringComparison.OrdinalIgnoreCase)) return null;
            return full;
        }
        catch { return null; }
    }

    // ================================================================
    // Ярлик на робочому столі (ТЗ про іконки)
    // ================================================================

    /// <summary>
    /// ПРИБИРАЄ ярлик FluxControl з робочого столу, який сама програма
    /// створила автоматично (ТЗ: «убери створення ярлика — я не просив»).
    /// Видаляємо ЛИШЕ якщо на місці наш маркер shortcut.marker — доказ,
    /// що ярлик зробила програма, а не користувач. Свій ярлик користувача
    /// програма ніколи не чіпає. Після видалення скидається кеш іконок.
    /// </summary>
    public static void RemoveAutoCreatedDesktopShortcut()
    {
        var t = new Thread(() =>
        {
            try { RemoveAutoCreatedDesktopShortcutCore(); }
            catch (Exception ex) { App.Log($"Shortcut removal failed: {ex.Message}"); }
        });
        t.SetApartmentState(ApartmentState.STA);
        t.IsBackground = true;
        t.Start();
    }

    private static void RemoveAutoCreatedDesktopShortcutCore()
    {
        var marker = Path.Combine(AppDir, "shortcut.marker");
        if (!File.Exists(marker)) return; // нашого ярлика не було — нічого не чіпаємо

        var desktop = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
        if (string.IsNullOrEmpty(desktop)) return;
        var lnk = Path.Combine(desktop, "FluxControl.lnk");

        bool removed = false;
        if (File.Exists(lnk))
        {
            File.Delete(lnk);
            removed = true;
            App.Log("Shortcut: auto-created desktop shortcut removed (user opted out).");
            ActivityLogger.Log("APP", "Автостворений ярлик робочого столу прибрано");
        }
        File.Delete(marker);
        if (removed) FlushIconCache();
    }

    [System.Runtime.InteropServices.DllImport("shell32.dll")]
    private static extern void SHChangeNotify(int eventId, int flags, IntPtr item1, IntPtr item2);

    /// <summary>SHCNE_ASSOCCHANGED — глобальний скид кеша іконок Windows:
    /// робочий стіл/провідник перечитує іконки без перезавантаження ПК.</summary>
    private static void FlushIconCache()
    {
        try { SHChangeNotify(0x08000000, 0x0005, IntPtr.Zero, IntPtr.Zero); }
        catch { }
    }
}
