using System;
using System.Runtime.InteropServices;
using System.Threading;

namespace FluxControl.Agent.Services;

/// <summary>
/// Exact master volume control through Core Audio (WASAPI) COM interfaces —
/// lets the site apply "55" and get precisely 55%, unlike keyboard-step
/// simulation. Pure COM interop (no NuGet, no WinForms dependency).
/// All methods are static, thread-safe, never throw and return false when the
/// audio endpoint is unavailable so callers can fall back to key simulation.
/// </summary>
public static class AudioService
{
    private const int ClsCtxAll = 0x17;
    private const int ERender = 0;
    private const int EMultimedia = 1;

    private static readonly Guid MMDeviceEnumeratorClsid = new("BCDE0395-E52F-467C-8E3D-C4579291692E");
    private static readonly object _sync = new();
    private static volatile IAudioEndpointVolume? _endpoint;
    private static volatile IAudioMeterInformation? _meter;

    [ComImport, Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IMMDeviceEnumerator
    {
        int NotImpl1(); // EnumAudioEndpoints — vtable placeholder, never called

        [PreserveSig]
        int GetDefaultAudioEndpoint(int dataFlow, int role, out IMMDevice endpoint);
    }

    [ComImport, Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IMMDevice
    {
        [PreserveSig]
        int Activate(ref Guid iid, int dwClsCtx, IntPtr activationParams, [MarshalAs(UnmanagedType.IUnknown)] out object endpointObject);
    }

    [ComImport, Guid("5CDF2C82-841E-4546-9722-0CF74078229A"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IAudioEndpointVolume
    {
        [PreserveSig] int RegisterControlChangeNotify(IntPtr notify);
        [PreserveSig] int UnregisterControlChangeNotify(IntPtr notify);
        [PreserveSig] int GetChannelCount(out uint channelCount);
        [PreserveSig] int SetMasterVolumeLevel(float levelDb, ref Guid eventContext);
        [PreserveSig] int SetMasterVolumeLevelScalar(float level, ref Guid eventContext);
        [PreserveSig] int GetMasterVolumeLevel(out float levelDb);
        [PreserveSig] int GetMasterVolumeLevelScalar(out float level);
        [PreserveSig] int SetChannelVolumeLevel(uint channel, float levelDb, ref Guid eventContext);
        [PreserveSig] int SetChannelVolumeLevelScalar(uint channel, float level, ref Guid eventContext);
        [PreserveSig] int GetChannelVolumeLevel(uint channel, out float levelDb);
        [PreserveSig] int GetChannelVolumeLevelScalar(uint channel, out float level);
        [PreserveSig] int SetMute([MarshalAs(UnmanagedType.Bool)] bool mute, ref Guid eventContext);
        [PreserveSig] int GetMute([MarshalAs(UnmanagedType.Bool)] out bool mute);
    }

    [ComImport, Guid("C02216F6-8C67-4B5B-9D00-D008E73E0064"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IAudioMeterInformation
    {
        [PreserveSig] int GetPeakValue(out float peak);
        // далі в vtable існують метсоди метаданих — не викликаємо їх
        [PreserveSig] int GetMeterChannelCount(out uint channelCount);
        [PreserveSig] int GetChannelsPeakValues(uint channelCount, [Out] float[] peakValues);
        [PreserveSig] int GetPeakValueDuration(ref long duration);
    }

    /// <summary>
    /// РЕАЛЬНИЙ статус відтворення (ТЗ): пік гучності дефолтного аудіовиходу.
    /// Коли щось грає — пік > 0, коли пауза/тиша — пік ≈ 0. Жодних WinRT/NuGet:
    /// той самий WASAPI COM, що й для гучності. Бере максимум із ~12 замірів
    /// за ~180 мс, щоб не блимало на паузах між треками.
    /// </summary>
    public static bool TryGetPlaybackPeak(out int peakPercent)
    {
        float max = 0f;
        bool ok = WithMeter(meter =>
        {
            for (int i = 0; i < 12; i++)
            {
                try
                {
                    if (meter.GetPeakValue(out float p) == 0 && p > max) max = p;
                }
                catch { }
                Thread.Sleep(15);
            }
            return true;
        });
        peakPercent = ok ? Math.Clamp((int)Math.Round(max * 100f), 0, 100) : 0;
        return ok;
    }

    /// <summary>Комфортний поріг: пік ≥ 1.5% вважаємо «щось відтворюється».</summary>
    public static bool TryIsPlaying(out bool playing)
    {
        playing = false;
        if (!TryGetPlaybackPeak(out int peak)) return false;
        playing = peak >= 2;
        return true;
    }

    private static bool WithMeter(Func<IAudioMeterInformation, bool> action)
    {
        for (int attempt = 0; attempt < 2; attempt++)
        {
            var meter = GetMeter(invalidate: attempt > 0);
            if (meter == null) return false;
            try
            {
                if (action(meter)) return true;
            }
            catch { }
        }
        return false;
    }

    private static IAudioMeterInformation? GetMeter(bool invalidate)
    {
        lock (_sync)
        {
            if (invalidate) _meter = null;
            if (_meter != null) return _meter;
            try
            {
                var enumeratorType = Type.GetTypeFromCLSID(MMDeviceEnumeratorClsid);
                if (enumeratorType == null) return null;
                var instance = Activator.CreateInstance(enumeratorType);
                if (instance is not IMMDeviceEnumerator enumerator) return null;

                if (enumerator.GetDefaultAudioEndpoint(ERender, EMultimedia, out IMMDevice? device) != 0 || device == null) return null;

                var iid = typeof(IAudioMeterInformation).GUID;
                if (device.Activate(ref iid, ClsCtxAll, IntPtr.Zero, out object? meterObject) != 0 || meterObject == null) return null;

                _meter = (IAudioMeterInformation)meterObject;
                return _meter;
            }
            catch { return null; }
        }
    }

    /// <summary>Master volume in percent (0..100). False when unavailable.</summary>
    public static bool TryGetVolume(out int percent)
    {
        int value = 0;
        bool ok = WithEndpoint(endpoint =>
        {
            if (endpoint.GetMasterVolumeLevelScalar(out float scalar) != 0) return false;
            value = Math.Clamp((int)Math.Round(scalar * 100f), 0, 100);
            return true;
        });
        percent = value;
        return ok;
    }

    /// <summary>Sets the master volume to an exact percent (0..100); unmutes like the system slider.</summary>
    public static bool TrySetVolume(int percent)
    {
        percent = Math.Clamp(percent, 0, 100);
        return WithEndpoint(endpoint =>
        {
            var ctx = Guid.Empty;
            if (endpoint.SetMasterVolumeLevelScalar(percent / 100f, ref ctx) != 0) return false;
            // A muted endpoint would swallow the change → unmute on explicit set.
            if (endpoint.GetMute(out bool muted) == 0 && muted) endpoint.SetMute(false, ref ctx);
            return true;
        });
    }

    public static bool TrySetMute(bool mute) => WithEndpoint(endpoint =>
    {
        var ctx = Guid.Empty;
        return endpoint.SetMute(mute, ref ctx) == 0;
    });

    public static bool TryGetMute(out bool muted)
    {
        bool value = false;
        bool ok = WithEndpoint(endpoint =>
        {
            if (endpoint.GetMute(out bool isMuted) != 0) return false;
            value = isMuted;
            return true;
        });
        muted = value;
        return ok;
    }

    private static bool WithEndpoint(Func<IAudioEndpointVolume, bool> action)
    {
        for (int attempt = 0; attempt < 2; attempt++)
        {
            var endpoint = GetEndpoint(invalidate: attempt > 0);
            if (endpoint == null) return false;
            try
            {
                if (action(endpoint)) return true;
            }
            catch { }
            // COM call failed → drop the cached endpoint (device may have been
            // unplugged or changed) and retry once with a fresh one.
        }
        return false;
    }

    private static IAudioEndpointVolume? GetEndpoint(bool invalidate)
    {
        lock (_sync)
        {
            if (invalidate) _endpoint = null;
            if (_endpoint != null) return _endpoint;
            try
            {
                var enumeratorType = Type.GetTypeFromCLSID(MMDeviceEnumeratorClsid);
                if (enumeratorType == null) return null;
                var instance = Activator.CreateInstance(enumeratorType);
                if (instance is not IMMDeviceEnumerator enumerator) return null;

                if (enumerator.GetDefaultAudioEndpoint(ERender, EMultimedia, out IMMDevice? device) != 0 || device == null) return null;

                var iid = typeof(IAudioEndpointVolume).GUID;
                if (device.Activate(ref iid, ClsCtxAll, IntPtr.Zero, out object? endpointObject) != 0 || endpointObject == null) return null;

                _endpoint = (IAudioEndpointVolume)endpointObject;
                return _endpoint;
            }
            catch { return null; }
        }
    }
}
