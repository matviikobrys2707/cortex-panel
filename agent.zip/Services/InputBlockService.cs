using System;
using System.Runtime.InteropServices;

namespace FluxControl.Agent.Services;

/// <summary>
/// Блокування МИШІ ТА КЛАВІАТУРИ ПК (ТЗ: «як наче від'єднані від ПК»).
///
/// ВАЖЛИВО (ТЗ «блокувати тільки фізичний ввід»): низькоуровневі хуки
/// перевіряють прапор INJECTED і НЕ глотають події, згенеровані програмно
/// (SendInput / SendKeys) — тому віддалене керування з сайту продовжує
/// працювати, поки фізичні мишка/клавіатура «мертві».
/// BlockInput НЕ використовуємо: він блокує і ін'єкції, і вимагає адмін-прав.
///
/// АРХІТЕКТУРА (фікс «Ctrl+Shift+F12 не спрацьовує»):
///  • хуки встановлюються на ВИДІЛЕНОМУ ПОТОЦІ зі справжнім насосом повідомлень
///    (GetMessage) — саме так вимагає Windows: low-level хук доставляється
///    повідомленням у потік, який його встановив; якщо потік не качає повідомлення
///    (як колись — потік WS-циклу), події губляться або Windows прибирає хук;
///  • АВАРІЙНА КОМБІНАЦІЯ перевіряється ДВІЧА: миттєво в хуку (F12 + трекінг
///    модифікаторів) І кожні 400 мс watchdog-таймером через GetAsyncKeyState —
///    watchdog спрацьовує навіть якщо Windows «з'їв» хук за таймаутом або подія
///    губиться. Комбо: Ctrl+Shift+F12 АБО Ctrl+Shift+Alt+F12 (лише фізичні).
///
/// БЕЗПЕКА ВЛАСНИКА:
///  • Ctrl+Alt+Del / UAC завжди обходять блокування (вимоги Windows);
///  • при завершенні агент-процесу Windows сама знімає хуки;
///  • релейний розрив (RelayClientService викликає <see cref="Release"/>)
///    автоматично розблокує введення.
/// </summary>
public class InputBlockService
{
    /// <summary>Аварійна комбінація (основна): Ctrl + Shift + F12 (лише фізична).
    /// Також приймається подовжений варіант Ctrl+Shift+Alt+F12.</summary>
    public const string EmergencyComboLabel = "Ctrl+Shift+F12";

    // ТИПИ - int: GetAsyncKeyState(int) та vkCode з KBDLLHOOKSTRUCT — int;
    // const uint -> int неявно не конвертується (CS1503).
    private const int VK_SHIFT = 0x10;
    private const int VK_CONTROL = 0x11;
    private const int VK_MENU = 0x12; // Alt
    private const int VK_F12 = 0x7B;

    private const int WH_MOUSE_LL = 14;
    private const int WH_KEYBOARD_LL = 13;

    // Прапори ін'єкції в KBDLLHOOKSTRUCT.flags / MSLLHOOKSTRUCT.flags.
    private const uint LLKHF_INJECTED = 0x10;
    private const uint LLMHF_INJECTED = 0x01;

    private readonly object _sync = new();
    private bool _blocked;
    private long _blockedAt;
    private IntPtr _mouseHook = IntPtr.Zero;
    private IntPtr _keyboardHook = IntPtr.Zero;
    private int _hookThreadId;
    private string _lastMessage = string.Empty;

    // Стан модифікаторів для розпізнавання аварійної комбінації (оновлюється
    // хуком клавіатури на кожній фізичній події).
    private bool _ctrlDown;
    private bool _shiftDown;
    private bool _altDown;

    private System.Threading.Timer? _watchdog;

    private delegate IntPtr LowLevelProc(int nCode, IntPtr wParam, IntPtr lParam);
    private delegate int GetMessageProc(IntPtr hWnd, int msg, IntPtr wParam, IntPtr lParam);

    private readonly LowLevelProc _mouseProc;
    private readonly LowLevelProc _keyboardProc;

    /// <summary>Спрацювала аварійна комбінація на ПК — блокування знято локально.</summary>
    public event Action? AutoUnlocked;

    public InputBlockService()
    {
        _mouseProc = MouseHookProc;
        _keyboardProc = KeyboardHookProc;
    }

    public bool IsBlocked { get { lock (_sync) { return _blocked; } } }

    public long BlockedAt { get { lock (_sync) { return _blocked ? _blockedAt : 0; } } }

    public string LastMessage { get { lock (_sync) { return _lastMessage; } } }

    public InputBlockStateDto GetState()
    {
        lock (_sync)
        {
            return new InputBlockStateDto
            {
                Blocked = _blocked,
                BlockedAt = _blocked ? _blockedAt : 0,
                Method = _blocked ? "physical-hooks (remote passthrough)" : "",
                Message = _lastMessage
            };
        }
    }

    /// <summary>Блокує фізичний ввід. Повторний виклик — безопераційний.</summary>
    public InputBlockStateDto Engage()
    {
        lock (_sync)
        {
            if (_blocked)
            {
                _lastMessage = "Введення вже заблоковано";
                return GetState();
            }

            _blockedAt = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
            _ctrlDown = _shiftDown = _altDown = false;
            InstallHooks();
            _blocked = true;
            StartWatchdog();
            App.Log($"[InputBlock] engaged (dedicated hook thread, emergency combo {EmergencyComboLabel}).");
            _lastMessage = $"Фізичний ввід заблоковано (віддалений працює; зняття — {EmergencyComboLabel})";
            return GetState();
        }
    }

    /// <summary>Знімає блокування (з сайту, комбінацією або авто-безпека при розриві).</summary>
    public InputBlockStateDto Release()
    {
        lock (_sync)
        {
            if (!_blocked) return GetState();

            UninstallHooks();
            StopWatchdog();
            _blocked = false;
            _blockedAt = 0;
            _ctrlDown = _shiftDown = _altDown = false;
            _lastMessage = "Введення розблоковано";
            App.Log("[InputBlock] released.");
            return GetState();
        }
    }

    // ------------------------------------------------------------ internals

    /// <summary>
    /// Хуки живуть на ВИДІЛЕНОМУ потоці з GetMessage-насосом. Без насоса
    /// low-level хуки не доставляються (або зриваються за таймаутом) — це
    /// була головна причина «комбінація не працює».
    /// </summary>
    private void InstallHooks()
    {
        var pumpReady = new System.Threading.ManualResetEventSlim(false);
        var thread = new System.Threading.Thread(() =>
        {
            try
            {
                _hookThreadId = (int)GetCurrentThreadId();
                var module = GetModuleHandleW(null);
                _mouseHook = SetWindowsHookExW(WH_MOUSE_LL, _mouseProc, module, 0);
                _keyboardHook = SetWindowsHookExW(WH_KEYBOARD_LL, _keyboardProc, module, 0);
                if (_mouseHook == IntPtr.Zero || _keyboardHook == IntPtr.Zero)
                {
                    App.Log($"[InputBlock] hook install failed (mouse={_mouseHook != IntPtr.Zero}, kb={_keyboardHook != IntPtr.Zero}, err={Marshal.GetLastWin32Error()}).");
                }
                pumpReady.Set();

                // Насос повідомлень: поки не отримали WM_QUIT — хуки живі.
                while (GetMessageW(out _ , IntPtr.Zero, 0, 0) > 0) { }
            }
            catch (Exception ex)
            {
                App.Log($"[InputBlock] hook thread crashed: {ex.Message}");
            }
            finally { pumpReady.Set(); }
        })
        {
            IsBackground = true,
            Name = "FluxControl.InputHooks"
        };
        thread.SetApartmentState(System.Threading.ApartmentState.STA);
        thread.Start();
        _ = pumpReady.Wait(TimeSpan.FromSeconds(2));
    }

    private void UninstallHooks()
    {
        try { if (_mouseHook != IntPtr.Zero) UnhookWindowsHookEx(_mouseHook); } catch { }
        try { if (_keyboardHook != IntPtr.Zero) UnhookWindowsHookEx(_keyboardHook); } catch { }
        _mouseHook = IntPtr.Zero;
        _keyboardHook = IntPtr.Zero;
        // Будимо насос, щоб потік завершився.
        try { if (_hookThreadId != 0) _ = PostThreadMessageW((uint)_hookThreadId, 0x0012 /*WM_QUIT*/, IntPtr.Zero, IntPtr.Zero); } catch { }
        _hookThreadId = 0;
    }

    /// <summary>
    /// Watchdog (страховка ТЗ): кожні 400 мс перевіряємо стан модифікаторів
    /// через GetAsyncKeyState — комбінація спрацьовує навіть якщо хукові
    /// події загубились. Виклик Release — через Task.Run (без взаємного
    /// блокування з хуком).
    /// </summary>
    private void StartWatchdog()
    {
        StopWatchdog();
        _watchdog = new System.Threading.Timer(_ =>
        {
            try
            {
                bool f12 = GetAsyncKeyState(VK_F12) < 0;
                if (!f12) return;
                bool ctrl = GetAsyncKeyState(VK_CONTROL) < 0;
                bool shift = GetAsyncKeyState(VK_SHIFT) < 0;
                if (!ctrl || !shift) return;
                // Основна: Ctrl+Shift+F12; подовжена Ctrl+Shift+Alt+F12 —
                // обидві знімають блокування (Alt не заважає).
                App.Log("[InputBlock] Emergency combo detected by watchdog — releasing.");
                _lastMessage = $"Знято аварійною комбінацією {EmergencyComboLabel}";
                _ = System.Threading.Tasks.Task.Run(() =>
                {
                    Release();
                    _ = System.Windows.Application.Current?.Dispatcher.InvokeAsync(() => AutoUnlocked?.Invoke());
                });
            }
            catch { }
        }, null, 400, 400);
    }

    private void StopWatchdog()
    {
        _watchdog?.Dispose();
        _watchdog = null;
    }

    private static IntPtr MouseHookProc(int nCode, IntPtr wParam, IntPtr lParam)
    {
        if (nCode >= 0)
        {
            // MSLLHOOKSTRUCT: { POINT pt; DWORD mouseData; DWORD flags; ... }
            // flags — за зміщенням 12 байт (pt=8, mouseData=4).
            try
            {
                var flags = (uint)Marshal.ReadInt32(lParam, 12);
                if ((flags & LLMHF_INJECTED) != 0) return CallNextHookEx(IntPtr.Zero, nCode, wParam, lParam);
            }
            catch
            {
                // Не змогли прочитати структуру — безпечніше пропустити подію,
                // ніж заблокувати віддалене керування.
                return CallNextHookEx(IntPtr.Zero, nCode, wParam, lParam);
            }
            return (IntPtr)1; // фізична миша — глитаєм
        }
        return CallNextHookEx(IntPtr.Zero, nCode, wParam, lParam);
    }

    /// <summary>Аварійне зняття: F12 при затиснутих Ctrl+Shift (+/- Alt).
    /// Модифікатори перевіряємо ДВІЧА: і трекінгом хука, і GetAsyncKeyState —
    /// якщо модифікатори були затиснуті ДО увімкнення блокування (хук їх не
    /// побачив) або подія keyup губиться — стан усе одно коректний.</summary>
    private bool EmergencyComboHit(int vk, bool isKeyDown)
    {
        if (vk != VK_F12 || !isKeyDown) return false;
        bool ctrl = _ctrlDown || (GetAsyncKeyState(VK_CONTROL) < 0);
        bool shift = _shiftDown || (GetAsyncKeyState(VK_SHIFT) < 0);
        // Alt опційний: Ctrl+Shift+F12 (основна) або Ctrl+Shift+Alt+F12.
        return ctrl && shift;
    }

    private IntPtr KeyboardHookProc(int nCode, IntPtr wParam, IntPtr lParam)
    {
        if (nCode >= 0)
        {
            try
            {
                // KBDLLHOOKSTRUCT: vkCode (4), scanCode (4), flags (4), time (4), extraInfo (8).
                // flags — за зміщенням 8 після vkCode+scanCode.
                int vk = Marshal.ReadInt32(lParam);
                uint flags = (uint)Marshal.ReadInt32(lParam, 8);
                bool injected = (flags & LLKHF_INJECTED) != 0;
                bool isKeyDown = wParam == 0x0100 || wParam == 0x0104; // WM_KEYDOWN / WM_SYSKEYDOWN
                bool isKeyUp = wParam == 0x0101 || wParam == 0x0105;   // WM_KEYUP / WM_SYSKEYUP

                // Віддалений (програмний) ввід завжди пропускаємо (ТЗ).
                if (injected) return CallNextHookEx(IntPtr.Zero, nCode, wParam, lParam);

                // Трекінг модифікаторів для аварійної комбінації.
                if (vk == VK_CONTROL) _ctrlDown = isKeyDown;
                else if (vk == VK_SHIFT) _shiftDown = isKeyDown;
                else if (vk == VK_MENU) _altDown = isKeyDown;

                if (EmergencyComboHit(vk, isKeyDown))
                {
                    // АВАРІЙНЕ ЗНЯТТЯ (ТЗ: клавіатура реагує тільки на цю
                    // комбінацію; будь-яка інша — ігнорується повністю).
                    App.Log("[InputBlock] Emergency combo pressed — releasing.");
                    _lastMessage = $"Знято аварійною комбінацією {EmergencyComboLabel}";
                    _ = System.Threading.Tasks.Task.Run(() =>
                    {
                        Release();
                        _ = System.Windows.Application.Current?.Dispatcher.InvokeAsync(() => AutoUnlocked?.Invoke());
                    });
                    return CallNextHookEx(IntPtr.Zero, nCode, wParam, lParam);
                }

                return (IntPtr)1; // фізична клавіатура — глитаєм повністю
            }
            catch
            {
                return CallNextHookEx(IntPtr.Zero, nCode, wParam, lParam);
            }
        }
        return CallNextHookEx(IntPtr.Zero, nCode, wParam, lParam);
    }

    // ------------------------------------------------------------------ P/Invoke

    [DllImport("user32.dll", SetLastError = true)]
    private static extern IntPtr SetWindowsHookExW(int idHook, LowLevelProc lpfn, IntPtr hMod, uint dwThreadId);

    [DllImport("user32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool UnhookWindowsHookEx(IntPtr hhk);

    [DllImport("user32.dll")]
    private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);

    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern IntPtr GetModuleHandleW(string? lpModuleName);

    [DllImport("user32.dll")]
    private static extern short GetAsyncKeyState(int vKey);

    [DllImport("user32.dll")]
    private static extern int GetMessageW(out MSG lpMsg, IntPtr hWnd, uint wMsgFilterMin, uint wMsgFilterMax);

    [DllImport("kernel32.dll")]
    private static extern uint GetCurrentThreadId();

    [DllImport("user32.dll")]
    private static extern bool PostThreadMessageW(uint threadId, int msg, IntPtr wParam, IntPtr lParam);

    [StructLayout(LayoutKind.Sequential)]
    private struct MSG
    {
        public IntPtr hwnd;
        public uint message;
        public IntPtr wParam;
        public IntPtr lParam;
        public uint time;
        public int ptX;
        public int ptY;
    }
}

/// <summary>Стан блокування введення (відправляється на сайт).</summary>
public class InputBlockStateDto
{
    public bool Blocked { get; set; }
    public long BlockedAt { get; set; }
    public string Method { get; set; } = string.Empty;
    public string Message { get; set; } = string.Empty;
}
