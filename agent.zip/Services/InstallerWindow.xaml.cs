using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;

namespace FluxControl.Agent.Services;

/// <summary>
/// Красивий нативний вікно-інсталятор FluxControl. Два режими:
///  • Install       — bootstrap при першому/пошкодженому запуску: показує
///                    прогрес і довантажує відсутні файли з офіційного сайту застосунку;
///  • UpdateConfirm — «Доступна нова версія» з кнопкою «Оновити»;
///                    після завантаження запускає автономний updater-процес
///                    (ТЗ п.3) і коректно завершує програму.
/// </summary>
public partial class InstallerWindow : Window
{
    public enum InstallerMode { Install, UpdateConfirm }

    private readonly InstallerMode _mode;
    private CancellationTokenSource? _cts;
    private UpdateInfo? _update;
    private Func<Task<bool>>? _retryAction;

    public InstallerWindow(InstallerMode mode)
    {
        InitializeComponent();
        _mode = mode;
        SourceInitialized += (s, e) => TryRoundCorners();
        Closed += (s, e) => _cts?.Cancel();
        ApplyMode();
    }

    // ------------------------------------------------------------ режимы ---

    private void ApplyMode()
    {
        if (_mode == InstallerMode.Install)
        {
            TitleText.Text = "FluxControl — Встановлення";
            SubtitleText.Text = "Перевіряю файли програми…";
            HeadlineText.Text = "Готуємо файли програми";
            DetailText.Text = "Програма самостійно відновить вбудовані файли інтерфейсу. " +
                              "Це займе кілька секунд.";
            PrimaryBtn.Visibility = Visibility.Collapsed;
            SecondaryText.Text = "Скасувати";
            VersionChips.Visibility = Visibility.Collapsed;
            ShowProgress(false);
        }
        else
        {
            TitleText.Text = "FluxControl — Оновлення";
            SubtitleText.Text = "Доступна нова версія";
            HeadlineText.Text = "Оновити FluxControl?";
            DetailText.Text = "Буде завантажено останні файли з офіційного сайту fluxcontrol.pages.dev, " +
                              "і програма перезапуститься автоматично. Налаштування та код " +
                              "підключення залишаться незмінними.";
            PrimaryBtn.Visibility = Visibility.Visible;
            PrimaryText.Text = "Оновити";
            SecondaryText.Text = "Пізніше";
            VersionChips.Visibility = Visibility.Visible;
            ShowProgress(false);
        }
    }

    /// <summary>Заповнює чіпи версій у режимі оновлення.</summary>
    public void SetUpdateInfo(UpdateInfo info)
    {
        _update = info;
        LocalVerText.Text = info.LocalVersion;
        LatestVerText.Text = info.LatestVersion;
        SubtitleText.Text = $"Доступна нова версія {info.LatestVersion}";
    }

    // ------------------------------------------------- bootstrap install ---

    /// <summary>
    /// Режим Install: завантажує відсутні файли з офіційного сайту застосунку.
    /// true — файли встановлено і можна продовжувати запуск програми.
    /// </summary>
    public async Task<bool> RunInstallAsync(List<string> missingFiles)
    {
        Show();
        _cts = new CancellationTokenSource();
        _retryAction = () => RunInstallAsync(missingFiles);
        ShowProgress(true);
        var progress = new Progress<DownloadProgress>(SetProgress);
        try
        {
            StatusText.Text = "З'єднання з сайтом оновлень…";
            var remaining = await BootstrapService.InstallMissingFilesAsync(
                progress, s => StatusText.Text = s, _cts.Token);

            if (remaining.Count > 0)
            {
                Fail("Не вдалося встановити: " + string.Join(", ", remaining) +
                     ". Перевірте інтернет і натисніть «Повторити».");
                return false;
            }

            SetProgress(new DownloadProgress { ReceivedBytes = 1, TotalBytes = 1 });
            HeadlineText.Text = "Усе готово!";
            DetailText.Text = "Файли встановлено. Запускаю FluxControl…";
            StatusText.Text = "";
            await Task.Delay(900);
            CloseWindow();
            return true;
        }
        catch (OperationCanceledException)
        {
            return false; // користувач закрив вікно — App завершить роботу
        }
        catch (Exception ex)
        {
            App.Log($"Bootstrap install error: {ex}");
            Fail(ex.Message);
            return false;
        }
    }

    // ----------------------------------------------------------- update ---

    /// <summary>
    /// Режим UpdateConfirm: завантажує останній самодостатній FluxControl.exe
    /// у %TEMP% і запускає updater-процес, який чекатиме завершення програми,
    /// підмінить файл exe і перезапустить FluxControl (ТЗ, п.3).
    /// </summary>
    public async Task<bool> RunUpdateAsync()
    {
        if (_update == null) return false;
        _cts = new CancellationTokenSource();
        _retryAction = () => RunUpdateAsync();
        PrimaryBtn.Visibility = Visibility.Collapsed;
        SecondaryText.Text = "Скасувати";
        DetailText.Text = "Завантаження оновлення… не закривайте програму.";
        ShowProgress(true);
        try
        {
            var progress = new Progress<DownloadProgress>(SetProgress);
            StatusText.Text = "Завантаження оновлення…";
            var newExePath = await UpdateService.DownloadReleaseZipAsync(
                _update.DownloadUrl, _update.LatestVersion, progress, _cts.Token);

            // Легасі-релізи: zip із exe всередині — витягуємо; голий .exe — як є.
            if (newExePath.EndsWith(".zip", StringComparison.OrdinalIgnoreCase))
            {
                StatusText.Text = "Розпакування оновлення…";
                newExePath = await UpdateInstaller.ExtractExeFromZipAsync(newExePath);
            }

            StatusText.Text = "Запускаю оновлювач…";
            HeadlineText.Text = "Майже готово";
            DetailText.Text = "Програма зараз перезапуститься та встановить оновлення.";
            UpdateInstaller.Launch(newExePath);
            await Task.Delay(600);
            System.Windows.Application.Current.Shutdown(); // коректний вихід — updater чекає PID
            return true;
        }
        catch (OperationCanceledException)
        {
            ResetToConfirm();
            return false;
        }
        catch (Exception ex)
        {
            App.Log($"Update download error: {ex}");
            Fail(ex.Message);
            return false;
        }
    }

    private void ResetToConfirm()
    {
        ShowProgress(false);
        DetailText.Text = "Завантаження скасовано. Оновити зараз?";
        PrimaryBtn.Visibility = Visibility.Visible;
        PrimaryText.Text = "Оновити";
        SecondaryText.Text = "Пізніше";
    }

    private void Fail(string message)
    {
        ShowProgress(false);
        StatusText.Text = message;
        StatusText.Foreground = new SolidColorBrush(System.Windows.Media.Color.FromRgb(0xFF, 0x6B, 0x8E));
        HeadlineText.Text = "Помилка";
        PrimaryBtn.Visibility = Visibility.Visible;
        PrimaryText.Text = "Повторити";
        SecondaryText.Text = "Закрити";
    }

    // ------------------------------------------------- updater process ---

    // Оновлювач (bat-скрипт exe-swap) і розпакування zip винесені в
    // UpdateInstaller — спільна логіка для всіх шляхів оновлення.

    // ------------------------------------------------------------- UI ---

    private void ShowProgress(bool show)
    {
        ProgressSection.Visibility = show ? Visibility.Visible : Visibility.Collapsed;
        if (show)
            StatusText.Foreground = new SolidColorBrush(System.Windows.Media.Color.FromRgb(0x8E, 0x89, 0xA8));
    }

    private void SetProgress(DownloadProgress p)
    {
        var pct = p.TotalBytes > 0 ? Math.Min(100, Math.Round(p.Percent)) : 0;
        FillCol.Width = new GridLength(pct, GridUnitType.Star);
        RestCol.Width = new GridLength(100 - pct, GridUnitType.Star);
        PercentText.Text = $"{pct:0}%";
        StatusText.Text = p.TotalBytes > 0
            ? $"Завантажено {p.ReceivedBytes / 1048576.0:0.0} з {p.TotalBytes / 1048576.0:0.0} МБ"
            : $"Завантажено {p.ReceivedBytes / 1048576.0:0.0} МБ";
    }

    // ---------------------------------------------------------- events ---

    private async void OnPrimaryClick(object sender, MouseButtonEventArgs e)
    {
        e.Handled = true; // не віддаємо клік вікну (інакше спрацює DragMove)
        if (_retryAction != null)
        {
            await _retryAction();
        }
        else if (_mode == InstallerMode.UpdateConfirm)
        {
            await RunUpdateAsync();
        }
    }

    private void OnSecondaryClick(object sender, MouseButtonEventArgs e)
    {
        e.Handled = true;
        _cts?.Cancel();
        CloseWindow();
    }

    private void OnCloseClick(object sender, MouseButtonEventArgs e)
    {
        e.Handled = true;
        _cts?.Cancel();
        CloseWindow();
    }

    private void CloseWindow()
    {
        try { if (IsLoaded) Close(); } catch { }
    }

    private void OnDragMove(object sender, MouseButtonEventArgs e)
    {
        try { DragMove(); } catch { }
    }

    // ------------------------------------------------ DWM округлення ---

    [DllImport("dwmapi.dll")]
    private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int value, int size);

    private void TryRoundCorners()
    {
        try
        {
            var hwnd = new WindowInteropHelper(this).Handle;
            if (hwnd == IntPtr.Zero) return;
            int pref = 2; // DWMWCP_ROUND
            DwmSetWindowAttribute(hwnd, 33, ref pref, 4);
        }
        catch { }
    }
}
