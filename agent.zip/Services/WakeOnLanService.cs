using System;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Threading.Tasks;

namespace FluxControl.Agent.Services;

/// <summary>
/// Wake-on-LAN: будує та розсилає стандартний magic packet
/// (6 × 0xFF + MAC-адреса, повторена 16 разів) через UDP-broadcast.
/// Працює ТІЛЬКИ в межах локальної мережі — саме так його використовує сайт:
/// інший онлайн-агент у тій же мережі, що й «сплячий» ПК, надсилає пакет як донор.
/// </summary>
public static class WakeOnLanService
{
    // Класичні порти для magic packet: 9 (discard) і 7 (echo).
    private static readonly int[] Ports = { 9, 7 };

    /// <summary>
    /// Парсить MAC у форматах "AA:BB:CC:DD:EE:FF", "AA-BB-CC-DD-EE-FF",
    /// "AABB.CCDD.EEFF", "AABBCCDDEEFF". Повертає null, якщо рядок некоректний.
    /// </summary>
    public static byte[]? ParseMac(string? mac)
    {
        if (string.IsNullOrWhiteSpace(mac)) return null;
        var clean = new string(mac.Trim().Where(char.IsLetterOrDigit).ToArray());
        if (clean.Length != 12) return null;
        var bytes = new byte[6];
        for (int i = 0; i < 6; i++)
        {
            if (!byte.TryParse(clean.Substring(i * 2, 2),
                    System.Globalization.NumberStyles.HexNumber, null, out bytes[i]))
            {
                return null;
            }
        }
        // Нульовий MAC безглуздий — ймовірно, віртуальний адаптер без адреси.
        return bytes.All(b => b == 0) ? null : bytes;
    }

    /// <summary>MAC у канонічному вигляді "AA:BB:CC:DD:EE:FF".</summary>
    public static string FormatMac(byte[] mac) =>
        string.Join(":", mac.Select(b => b.ToString("X2")));

    /// <summary>
    /// Розсилає magic packet: класичний broadcast на всі звичайні WoL-порти.
    /// Якщо вказана <paramref name="broadcastIp"/> (ТЗ: поле IP у налаштуваннях
    /// WoL на сайті) — додатково шле спрямований пакет на цю адресу.
    /// Кожна спроба — окремий UDP-клієнт, помилки одного порту не ламають інші.
    /// </summary>
    public static async Task SendMagicPacketAsync(byte[] mac, string? broadcastIp = null)
    {
        var packet = new byte[6 + 16 * 6];
        for (int i = 0; i < 6; i++) packet[i] = 0xFF;
        for (int i = 0; i < 16; i++) Buffer.BlockCopy(mac, 0, packet, 6 + i * 6, 6);

        var targets = new List<IPEndPoint>();
        foreach (var port in Ports)
            targets.Add(new IPEndPoint(IPAddress.Broadcast, port));

        if (!string.IsNullOrWhiteSpace(broadcastIp) && System.Net.IPAddress.TryParse(broadcastIp.Trim(), out var ip))
            foreach (var port in Ports)
                targets.Add(new IPEndPoint(ip, port));

        foreach (var target in targets)
        {
            try
            {
                using var udp = new UdpClient();
                udp.EnableBroadcast = true;
                await udp.SendAsync(packet, packet.Length, target);
            }
            catch { /* наступна ціль всеодно спробується */ }
        }
    }
}
