using System;
using System.Linq;
using System.Net.Http;
using System.IO;
using System.Reflection;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Threading;
using System.Threading.Tasks;

namespace FluxControl.Agent.Services;

/// <summary>Результат перевірки оновлень (ТЗ: манифест version.json на сайті).</summary>
public sealed class UpdateInfo
{
    public string LocalVersion { get; init; } = "";
    public string LatestVersion { get; init; } = "";
    public string DownloadUrl { get; init; } = "";
    public bool UpdateAvailable { get; init; }
}

/// <summary>Прогрес завантаження оновлення.</summary>
public sealed class DownloadProgress
{
    public long ReceivedBytes { get; init; }
    public long TotalBytes { get; init; }
    public double Percent => TotalBytes > 0 ? Math.Min(100d, ReceivedBytes * 100d / TotalBytes) : 0d;
}

/// <summary>
/// Система автоматичних оновлень ЧЕРЕЗ ВЛАСНИЙ САЙТ (ТЗ «убери гитхаб»).
///
/// Джерело даних про версію і сам файл — офіційний сайт застосунку:
///     https://fluxcontrol.pages.dev/version.json      (манифест)
///     https://fluxcontrol.pages.dev/FluxControl.exe   (сам exe)
/// Сайт — це Cloudflare Pages над репозиторієм matviikobrys2707/FluxControl,
/// куди деплоїть Auto-Deploy.ps1: exe + version.json + UI + logo лежать
/// у корені гілки main і роздаються звідти як статика. Жодних GitHub
/// Releases / api.github.com більше немає.
///
/// Резервний канал (той самий вміст, якщо Cloudflare тимчасово недоступний):
///     https://raw.githubusercontent.com/matviikobrys2707/FluxControl/main/...
///
/// Кеш: Cloudflare Pages віддає статику з revalidation (etag), плюс ?t={timestamp}
/// і no-cache заголовки — манифест завжди свіжий, нова версія помічається одразу.
/// </summary>
public static class UpdateService
{
    /// <summary>Офіційний сайт застосунку (єдине джерело оновлень).</summary>
    public const string SiteBase = "https://fluxcontrol.pages.dev";

    public const string VersionJsonUrl = SiteBase + "/version.json";

    /// <summary>Резервний шлях до манифесту: raw головної гілки репозиторію сайту.</summary>
    public const string VersionJsonFallbackUrl =
        "https://raw.githubusercontent.com/matviikobrys2707/FluxControl/main/version.json";

    /// <summary>Константа-фолбек, якщо версію збірки не прочитано.</summary>
    public const string CurrentVersion = "1.0.0";

    private static readonly HttpClient CheckClient = new(new HttpClientHandler
    {
        AllowAutoRedirect = true
    })
    {
        Timeout = TimeSpan.FromSeconds(12)
    };

    private static readonly HttpClient DownloadClient = new(new HttpClientHandler
    {
        AllowAutoRedirect = true,
        AutomaticDecompression = System.Net.DecompressionMethods.None
    })
    {
        // Стрім великого файлу: таймаут не обмежуємо, скасування — через CancellationToken.
        Timeout = Timeout.InfiniteTimeSpan
    };

    static UpdateService()
    {
        foreach (var client in new[] { CheckClient, DownloadClient })
        {
            client.DefaultRequestHeaders.UserAgent.ParseAdd("FluxControl-Updater/1.0");
            client.DefaultRequestHeaders.Accept.ParseAdd("*/*");
        }
        // ТЗ «нова версія помічається ОДРАЗУ»: забороняємо кеш манифесту на
        // проміжних проксі; ?t={timestamp} дає свіжий ключ кеша Cloudflare.
        CheckClient.DefaultRequestHeaders.CacheControl =
            new System.Net.Http.Headers.CacheControlHeaderValue { NoCache = true, MustRevalidate = true };
        CheckClient.DefaultRequestHeaders.Pragma.ParseAdd("no-cache");
    }

    /// <summary>
    /// Локальна версія — ЛИШЕ з метаданих збірки (AssemblyInformationalVersion),
    /// які деплой-скрипт зашиває всередину exe через -p:Version.
    /// Фолбек — константа.
    /// </summary>
    public static string GetLocalVersion()
    {
        try
        {
            var entry = Assembly.GetEntryAssembly();
            var attr = entry?.GetCustomAttribute<AssemblyInformationalVersionAttribute>();
            var info = attr?.InformationalVersion;
            if (!string.IsNullOrEmpty(info))
            {
                // -p:Version=1.0.3 може дати "1.0.3+abc123" — відрізаємо хвіст
                var v = info.Split('+')[0].Trim();
                if (v.Length > 0) return NormalizeVersion(v);
            }
        }
        catch { }
        return CurrentVersion;
    }

    /// <summary>
    /// ТЗ юзера: версія ЗАВЖДИ з ТРЬОХ цифр (1.2.3), а не чотирьох (1.2.3.0).
    /// .NET додає четвертий сегмент «.0» до FileVersion — відрізаємо його всюди.
    /// </summary>
    public static string NormalizeVersion(string? raw)
    {
        var v = (raw ?? string.Empty).Trim().TrimStart('v', 'V').Split('+')[0].Trim();
        var parts = v.Split('.');
        if (parts.Length > 3) v = string.Join('.', parts.Take(3));
        return v;
    }

    /// <summary>URL exe КОНКРЕТНОЇ версії в архіві на сайті (ТЗ «скачати будь-яку версію»).</summary>
    public static string VersionArchiveUrl(string version)
        => $"{SiteBase}/versions/{Uri.EscapeDataString(NormalizeVersion(version))}/FluxControl.exe";

    /// <summary>
    /// Встановлення КОНКРЕТНОЇ версії (відкат або апгрейд за вибором юзера):
    /// скачує versions/&lt;version&gt;/FluxControl.exe з сайту (резерв — raw GitHub)
    /// і запускає штатний move-swap оновлювач. Працює навіть коли «нова» версія
    /// СТАРІША за поточну — це свідомий відкат.
    /// </summary>
    public static async Task<string> InstallSpecificVersionAsync(
        string version, IProgress<DownloadProgress>? progress, CancellationToken ct)
    {
        var target = NormalizeVersion(version);
        if (string.IsNullOrWhiteSpace(target) || !target.Contains('.'))
            throw new ArgumentException("Некоректна версія: " + version);

        var url = VersionArchiveUrl(target);
        App.Log($"Update: installing specific version {target} from {url}");
        var path = await DownloadReleaseZipAsync(url, "v" + target, progress, ct);
        App.Log($"Update: version {target} downloaded ({new FileInfo(path).Length} bytes)");
        return path;
    }

    /// <summary>Порівняння версій "1.0.1" / "v1.0.1" — System.Version.</summary>
    public static bool IsNewerVersion(string? remote, string? local)
    {
        remote = remote?.Trim().TrimStart('v', 'V') ?? "";
        local = local?.Trim().TrimStart('v', 'V') ?? "";
        if (!Version.TryParse(remote, out var rv)) return false;
        if (!Version.TryParse(local, out var lv)) return true; // локальну не прочитали — оновлюємось
        return rv > lv;
    }

    /// <summary>
    /// Читає манифест version.json з конкретної адреси. null = недоступний/пошкоджений.
    /// </summary>
    private static async Task<UpdateInfo?> TryFetchManifestAsync(string url)
    {
        var busted = url + (url.IndexOf('?') >= 0 ? "&t=" : "?t=") +
            DateTimeOffset.UtcNow.ToUnixTimeSeconds();
        using var resp = await CheckClient.GetAsync(busted);
        resp.EnsureSuccessStatusCode();
        var body = await resp.Content.ReadAsStringAsync();
        // захист від BOM, якщо version.json редагували руками
        body = body.TrimStart('\uFEFF');
        var json = JsonSerializer.Deserialize<JsonObject>(body);
        var latest = json?["latest_version"]?.GetValue<string>();
        var download = json?["download_url"]?.GetValue<string>();

        if (string.IsNullOrWhiteSpace(latest) || string.IsNullOrWhiteSpace(download))
        {
            App.Log($"Update check: manifest has empty fields ({url})");
            return null;
        }

        var local = GetLocalVersion();
        return new UpdateInfo
        {
            LocalVersion = local,
            LatestVersion = NormalizeVersion(latest),
            DownloadUrl = download.Trim(),
            UpdateAvailable = IsNewerVersion(latest, local)
        };
    }

    /// <summary>
    /// GET version.json: спершу офіційний сайт, при недоступності — raw-резерв
    /// того самого репозиторію. null = мережа/формат недоступні (тихий пропуск).
    /// </summary>
    public static async Task<UpdateInfo?> CheckForUpdateAsync()
    {
        try
        {
            var info = await TryFetchManifestAsync(VersionJsonUrl);
            if (info != null) return info;
        }
        catch (Exception ex)
        {
            App.Log($"Update check via site failed: {ex.Message}");
        }

        try
        {
            var info = await TryFetchManifestAsync(VersionJsonFallbackUrl);
            if (info != null)
            {
                App.Log("Update check: fallback to raw.githubusercontent manifest");
                return info;
            }
        }
        catch (Exception ex)
        {
            App.Log($"Update check fallback failed: {ex.Message}");
        }
        return null;
    }

    /// <summary>
    /// Адреса завантаження самого exe: download_url з манифесту (посилання на
    /// сайт), за потреби виправлена на резервний raw-канал того ж репозиторію.
    /// </summary>
    public static async Task<string?> GetLatestReleaseZipUrlAsync()
    {
        var info = await CheckForUpdateAsync();
        var url = info?.DownloadUrl;
        if (string.IsNullOrEmpty(url))
            url = SiteBase + "/FluxControl.exe";
        return NormalizeDownloadUrl(url);
    }

    /// <summary>
    /// Сайт недоступний? Той самий файл лежить у головній гілці репозиторію
    /// сайту — підміняємо хост на raw (вміст ідентичний, деплой пушить обидва).
    /// </summary>
    public static string NormalizeDownloadUrl(string url)
    {
        if (string.IsNullOrEmpty(url)) return url;
        if (url.StartsWith(SiteBase + "/", StringComparison.OrdinalIgnoreCase))
        {
            return "https://raw.githubusercontent.com/matviikobrys2707/FluxControl/main/" +
                   url.Substring(SiteBase.Length + 1);
        }
        return url;
    }

    /// <summary>
    /// Завантаження оновлення (FluxControl.exe або zip старого формату) у %TEMP%
    /// зі стрімінгом прогресу. Якщо сайт не відповів — автоматичний ретрай через
    /// raw-резерв того ж файлу. Редиректи проходять автоматично.
    /// </summary>
    public static async Task<string> DownloadReleaseZipAsync(
        string url, string versionTag, IProgress<DownloadProgress>? progress, CancellationToken ct)
    {
        try
        {
            return await DownloadToFileAsync(url, versionTag, progress, ct);
        }
        catch (Exception ex) when (!(ct.IsCancellationRequested) &&
                                   url.StartsWith(SiteBase, StringComparison.OrdinalIgnoreCase))
        {
            App.Log($"Update: site download failed ({ex.Message}) — retrying via raw fallback");
            progress?.Report(new DownloadProgress { ReceivedBytes = 0, TotalBytes = 0 });
            return await DownloadToFileAsync(NormalizeDownloadUrl(url), versionTag, progress, ct);
        }
    }

    private static async Task<string> DownloadToFileAsync(
        string url, string versionTag, IProgress<DownloadProgress>? progress, CancellationToken ct)
    {
        // ?t={timestamp} — свіжий ключ кеша, щоб не віддати старий exe
        var busted = url + (url.IndexOf('?') >= 0 ? "&t=" : "?t=") +
            DateTimeOffset.UtcNow.ToUnixTimeSeconds();
        using var resp = await DownloadClient.GetAsync(busted, HttpCompletionOption.ResponseHeadersRead, ct);
        resp.EnsureSuccessStatusCode();

        long total = resp.Content.Headers.ContentLength ?? 0;
        var safeTag = string.Concat(versionTag.Where(char.IsLetterOrDigit)).Replace(" ", "");
        if (safeTag.Length == 0) safeTag = "update";
        var ext = url.EndsWith(".exe", StringComparison.OrdinalIgnoreCase) ? ".exe" : ".zip";
        var tmpPath = Path.Combine(Path.GetTempPath(), $"FluxControl-{safeTag}{ext}");

        await using (var fs = new FileStream(tmpPath, FileMode.Create, FileAccess.Write, FileShare.None, 81920, useAsync: true))
        {
            await using (var net = await resp.Content.ReadAsStreamAsync(ct))
            {
                var buffer = new byte[81920];
                long received = 0;
                int read;
                while ((read = await net.ReadAsync(buffer, ct)) > 0)
                {
                    await fs.WriteAsync(buffer.AsMemory(0, read), ct);
                    received += read;
                    progress?.Report(new DownloadProgress { ReceivedBytes = received, TotalBytes = total });
                }
            }
        }
        App.Log($"Update: downloaded {tmpPath} ({total} bytes) from {url}");
        return tmpPath;
    }
}
