using System;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;

namespace FluxControl.Agent.Services;

/// <summary>
/// Стрим ЗВУКУ ПК (ТЗ 46: «трансляція екрана зі звуком комп'ютера»).
/// WASAPI loopback-захоплення дефолтного пристрою відтворення через чистий
/// COM interop — жодних NuGet. Потік мікшується в mono 16-біт / 24 кГц і
/// висилається вебу base64-чанками (~100 мс кожен): веб грає їх через
/// Web Audio API. Аналогічний формат — «мікрофон ПК для глядача стриму».
/// </summary>
public class AudioStreamService : IDisposable
{
    // ----- WASAPI GUID'и -----
    private static readonly Guid ClsidMMDeviceEnumerator = new("BCDE0395-E52F-467C-8E3D-C4579291692E");
    private static readonly Guid IidIAudioClient = new("1CB9AD4C-DBFA-4c32-B178-C2F568A703B2");
    private static readonly Guid IidIAudioCaptureClient = new("C8ADBD64-E71E-48a0-A4DE-185C395CD317");
    private static readonly Guid SubtypePcm = new("00000001-0000-0010-8000-00AA00389B71");
    private static readonly Guid SubtypeFloat = new("00000003-0000-0010-8000-00AA00389B71");

    private const int ClsCtxAll = 0x17;
    private const int ERender = 0;
    private const int EMultimedia = 1;
    private const int AudclntSharemodeShared = 0;
    private const int AudclntStreamflagsLoopback = 0x00020000;
    private const uint AudclntBufferflagsSilent = 0x2;
    private const short WaveFormatPcm = 1;
    private const short WaveFormatExtensible = unchecked((short)0xFFFE);

    // ----- vtable-сумісні COM-інтерфейси (порядок методів СУВОРИЙ) -----

    [ComImport, Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IMMDeviceEnumerator
    {
        int NotImpl1(); // EnumAudioEndpoints — placeholder
        [PreserveSig]
        int GetDefaultAudioEndpoint(int dataFlow, int role, out IMMDevice endpoint);
    }

    [ComImport, Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IMMDevice
    {
        [PreserveSig]
        int Activate(ref Guid iid, int dwClsCtx, IntPtr activationParams, [MarshalAs(UnmanagedType.IUnknown)] out object iface);
    }

    [ComImport, Guid("1CB9AD4C-DBFA-4c32-B178-C2F568A703B2"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IAudioClient
    {
        [PreserveSig] int Initialize(int shareMode, int streamFlags, long hnsBufferDuration, long hnsPeriodicity, IntPtr pFormat, IntPtr audioSessionGuid);
        [PreserveSig] int GetBufferSize(out uint bufferFrames);
        [PreserveSig] int GetStreamLatency(out long latency);
        [PreserveSig] int GetCurrentPadding(out uint padding);
        [PreserveSig] int IsFormatSupported(int shareMode, IntPtr pFormat, out IntPtr closestMatch);
        [PreserveSig] int GetMixFormat(out IntPtr mixFormat);
        [PreserveSig] int GetDevicePeriod(out long defaultPeriod, out long minPeriod);
        [PreserveSig] int Start();
        [PreserveSig] int Stop();
        [PreserveSig] int Reset();
        [PreserveSig] int SetEventHandle(IntPtr handle);
        [PreserveSig] int GetService(ref Guid iid, out IntPtr service);
    }

    [ComImport, Guid("C8ADBD64-E71E-48a0-A4DE-185C395CD317"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IAudioCaptureClient
    {
        [PreserveSig] int GetBuffer(out IntPtr data, out uint frames, out uint flags, out long devicePosition, out long qpcPosition);
        [PreserveSig] int ReleaseBuffer(uint frames);
        [PreserveSig] int GetNextPacketSize(out uint frames);
    }

    // ----- стан -----

    private CancellationTokenSource? _cts;
    private volatile bool _running;
    private readonly object _startLock = new();

    public bool IsRunning => _running;

    /// <summary>Запустити захоплення. onChunk = int16 mono 24кГц (~100 мс) СИРІ байти
    /// (без base64 — релею летить бінарний кадр, економія 25% трафіку, ТЗ 49).</summary>
    public void Start(Action<byte[]> onChunk)
    {
        lock (_startLock)
        {
            if (_running) return;
            _running = true;
            var cts = new CancellationTokenSource();
            _cts = cts;
            _ = Task.Run(() => CaptureLoop(onChunk, cts.Token), CancellationToken.None);
        }
    }

    public void Stop()
    {
        lock (_startLock)
        {
            _running = false;
            try { _cts?.Cancel(); } catch { }
            _cts = null;
        }
    }

    private async Task CaptureLoop(Action<byte[]> onChunk, CancellationToken token)
    {
        // Свій поток і своя COM-ініціалізація (MTA) — WASAPI вимагає.
        Win32Api.CoInitializeEx(IntPtr.Zero, Win32Api.COINIT_MULTITHREADED);
        IMMDeviceEnumerator? enumerator = null;
        IMMDevice? device = null;
        object? clientObj = null;
        IAudioClient? client = null;
        IAudioCaptureClient? capture = null;
        IntPtr mixFormatPtr = IntPtr.Zero;

        try
        {
            var enumeratorType = Type.GetTypeFromCLSID(ClsidMMDeviceEnumerator);
            if (enumeratorType == null) return;
            if (Activator.CreateInstance(enumeratorType) is not IMMDeviceEnumerator en) return;
            enumerator = en;

            if (enumerator.GetDefaultAudioEndpoint(ERender, EMultimedia, out IMMDevice? dev) != 0 || dev == null) return;
            device = dev;

            var iidClient = IidIAudioClient;
            if (device.Activate(ref iidClient, ClsCtxAll, IntPtr.Zero, out object? clientIface) != 0 || clientIface == null) return;
            clientObj = clientIface;
            client = (IAudioClient)clientIface;

            if (client.GetMixFormat(out mixFormatPtr) != 0 || mixFormatPtr == IntPtr.Zero) return;

            var fmt = Marshal.PtrToStructure<WAVEFORMATEX>(mixFormatPtr);
            bool isFloat;
            if (fmt.wFormatTag == WaveFormatExtensible && fmt.cbSize >= 22)
            {
                var sub = Marshal.PtrToStructure<WAVEFORMATEXTENSIBLE_SUB>(mixFormatPtr + 24);
                isFloat = sub.SubFormat == SubtypeFloat;
                if (sub.SubFormat != SubtypeFloat && sub.SubFormat != SubtypePcm) return;
            }
            else if (fmt.wFormatTag == WaveFormatPcm)
            {
                isFloat = false;
            }
            else return;

            if (fmt.wBitsPerSample != 32 || !isFloat)
            {
                if (fmt.wBitsPerSample != 16 || isFloat) return; // підтримуємо float32 та int16
            }

            int channels = Math.Max(1, (int)fmt.nChannels);
            int sourceRate = (int)fmt.nSamplesPerSec;

            // loopback: буфер ~40 мс, обробка кожні 10 мс — низька затримка.
            if (client.Initialize(AudclntSharemodeShared, AudclntStreamflagsLoopback, 400000, 0, mixFormatPtr, IntPtr.Zero) != 0) return;
            var iidCapture = IidIAudioCaptureClient;
            if (client.GetService(ref iidCapture, out IntPtr capturePtr) != 0 || capturePtr == IntPtr.Zero) return;
            capture = Marshal.GetObjectForIUnknown(capturePtr) as IAudioCaptureClient;
            if (capture == null) return;

            if (client.Start() != 0) return;

            // Даунсемпл у 24 кГц mono: коефіцієнт цілий (48к→2, 44.1к→2 з
            // приблизним темпом; 96к→4). Некратні частоти — найближчий коефіцієнт ≥1.
            int decim = Math.Max(1, sourceRate / 24000);

            // Вихідний буфер: 2 секунди mono int16.
            const int capSamples = 48000;
            var outBuf = new short[capSamples];
            int outCount = 0;
            // Акумулятор float-фреймів одного пакета (до ~2с стерео float на всяк випадок).
            var frameBuf = new float[capSamples * channels];

            long carryNumerator = 0; // дробовий прогрес для некратних коефіцієнтів

            while (!token.IsCancellationRequested)
            {
                uint packetFrames;
                if (capture.GetNextPacketSize(out packetFrames) != 0) break;

                if (packetFrames == 0)
                {
                    FlushIfReady(ref outCount, outBuf, onChunk);
                    await Task.Delay(8, token).ConfigureAwait(false);
                    continue;
                }

                if (capture.GetBuffer(out IntPtr dataPtr, out uint frames, out uint flags, out _, out _) != 0) break;

                int got = (int)Math.Min(frames, (uint)(frameBuf.Length / channels));
                if (flags != AudclntBufferflagsSilent && dataPtr != IntPtr.Zero)
                {
                    if (isFloat)
                    {
                        Marshal.Copy(dataPtr, frameBuf, 0, got * channels);
                    }
                    else
                    {
                        // int16 → float у frameBuf
                        for (int i = 0; i < got * channels; i++)
                        {
                            frameBuf[i] = Marshal.ReadInt16(dataPtr, i * 2) / 32768f;
                        }
                    }
                }
                else
                {
                    for (int i = 0; i < got * channels; i++) frameBuf[i] = 0f;
                }

                // Мікс каналів → mono float
                for (int f = 0; f < got; f++)
                {
                    float acc = 0f;
                    int baseIdx = f * channels;
                    for (int c = 0; c < channels; c++) acc += frameBuf[baseIdx + c];
                    float mono = acc / channels;

                    // Даунсемпл «переносом»: тримаємо дробовий індекс вихідних семплів.
                    carryNumerator += 24000;
                    if (carryNumerator >= sourceRate)
                    {
                        carryNumerator -= sourceRate;
                        if (outCount < capSamples)
                        {
                            float v = mono;
                            if (v > 1f) v = 1f; else if (v < -1f) v = -1f;
                            outBuf[outCount++] = (short)Math.Round(v * 32767f);
                        }
                    }
                }

                capture.ReleaseBuffer(frames);

                FlushIfReady(ref outCount, outBuf, onChunk);
            }
        }
        catch (OperationCanceledException) { }
        catch { }
        finally
        {
            try { client?.Stop(); } catch { }
            try { if (capture != null) Marshal.ReleaseComObject(capture); } catch { }
            try { if (clientObj != null) Marshal.ReleaseComObject(clientObj); } catch { }
            try { if (device != null) Marshal.ReleaseComObject(device); } catch { }
            try { if (enumerator != null) Marshal.ReleaseComObject(enumerator); } catch { }
            try { if (mixFormatPtr != IntPtr.Zero) Marshal.FreeCoTaskMem(mixFormatPtr); } catch { }
            _running = false;
        }
    }

    private static void FlushIfReady(ref int outCount, short[] outBuf, Action<byte[]> onChunk)
    {
        // ~100 мс = 2400 семплів @ 24кГц. Більші чанки — менше overhead релея.
        const int chunkSamples = 2400;
        if (outCount < chunkSamples) return;

        int emit = Math.Min(outCount, chunkSamples * 2);
        var bytes = new byte[emit * 2];
        Buffer.BlockCopy(outBuf, 0, bytes, 0, emit * 2);
        // Зсув залишку на початок.
        Buffer.BlockCopy(outBuf, emit * 2, outBuf, 0, (outCount - emit) * 2);
        outCount -= emit;

        try { onChunk(bytes); } catch { }
    }

    public void Dispose() => Stop();

    // ----- WAVEFORMATEX / EXTENSIBLE (лише потрібні поля) -----

    [StructLayout(LayoutKind.Sequential)]
    private struct WAVEFORMATEX
    {
        public short wFormatTag;
        public short nChannels;
        public int nSamplesPerSec;
        public int nAvgBytesPerSec;
        public short nBlockAlign;
        public short wBitsPerSample;
        public short cbSize;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct WAVEFORMATEXTENSIBLE_SUB
    {
        public Guid SubFormat;
    }
}
