﻿using System;
using System.IO;
using System.Text.Json;
using Microsoft.Win32;

namespace FluxControl.Agent.Services;

public class AppSettings
{
    public bool AutoRun { get; set; } = true;
    public bool MinimizeToTray { get; set; } = true;
    public bool StartMinimized { get; set; } = false;
    /// <summary>Автооновлення (ТЗ 53): тихо завантажувати й установлювати нові
    /// версії у фоні, без блокуючого екрана. Після оновлення GUI з'являється
    /// лише якщо користувач сам відкрив вікно; автозапуск із Windows → старт
    /// знову у трей.</summary>
    public bool AutoUpdate { get; set; } = true;
    /// <summary>«Примусовий запуск програми» (ТЗ 46): сторож перезапускає агента,
    /// якщо його закрили. Зберігається у settings.json.</summary>
    public bool ForcedLaunch { get; set; } = false;
}

public class SettingsService
{
    private readonly string _settingsFilePath;
    private const string AppName = "FluxControl";
    private const string RunRegistryKey = @"SOFTWARE\Microsoft\Windows\CurrentVersion\Run";

    public AppSettings Settings { get; private set; }

    /// <summary>true, якщо налаштування реально прочитані з settings.json.
    /// false = файлу немає (перший запуск) — тоді застосовуємо дефолти,
    /// а вимкнений користувачем автозапуск НІКОЛИ не вмикається знову.</summary>
    public bool LoadedFromFile { get; private set; }

    public SettingsService()
    {
        var appData = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), AppName);
        Directory.CreateDirectory(appData);
        _settingsFilePath = Path.Combine(appData, "settings.json");
        Settings = LoadSettings();
    }

    public AppSettings LoadSettings()
    {
        try
        {
            if (File.Exists(_settingsFilePath))
            {
                var json = File.ReadAllText(_settingsFilePath);
                var loaded = JsonSerializer.Deserialize<AppSettings>(json);
                if (loaded != null)
                {
                    LoadedFromFile = true;
                    return loaded;
                }
            }
        }
        catch { }

        return new AppSettings();
    }

    public void SaveSettings(AppSettings newSettings)
    {
        Settings = newSettings;
        try
        {
            var json = JsonSerializer.Serialize(Settings, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(_settingsFilePath, json);

            // Synchronize Windows Autorun in Registry
            ApplyAutorunRegistry(Settings.AutoRun);
        }
        catch { }
    }

    private void ApplyAutorunRegistry(bool enable)
    {
        try
        {
            using var key = Registry.CurrentUser.OpenSubKey(RunRegistryKey, true);
            if (key == null) return;

            string exePath = System.Diagnostics.Process.GetCurrentProcess().MainModule?.FileName ?? "";
            if (string.IsNullOrEmpty(exePath)) return;

            if (enable)
            {
                key.SetValue(AppName, $"\"{exePath}\" --minimized");
            }
            else
            {
                key.DeleteValue(AppName, false);
            }
        }
        catch { }
    }
}