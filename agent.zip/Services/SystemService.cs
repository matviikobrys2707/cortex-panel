using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Management;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace FluxControl.Agent.Services;

public class DiskInfo
{
    public string Name { get; set; } = string.Empty;
    public string Label { get; set; } = string.Empty;
    public double TotalGb { get; set; }
    public double FreeGb { get; set; }
    public double UsedGb { get; set; }
    public long TotalBytes { get; set; }
    public long FreeBytes { get; set; }
    public long UsedBytes { get; set; }
    public int PercentUsed { get; set; }
    public string DriveType { get; set; } = "fixed";
    /// Модель фізичного диска (Win32_DiskDrive.Model), напр. «Samsung SSD 870 EVO 1TB».
    public string Model { get; set; } = string.Empty;
    /// Тип носія: "SSD", "HDD", "NVMe", "USB" або "—".
    public string MediaType { get; set; } = string.Empty;
}

public class SystemMetricsDto
{
    public double CpuUsage { get; set; }
    public double CpuPercent { get; set; }
    public double RamUsage { get; set; }
    public double RamPercent { get; set; }
    public double RamUsedGb { get; set; }
    public double RamUsedMb { get; set; }
    public double RamTotalGb { get; set; }
    public double RamTotalMb { get; set; }
    public List<DiskInfo> Disks { get; set; } = new();
    public string Uptime { get; set; } = string.Empty;
    public string MachineName { get; set; } = string.Empty;
    public string UserName { get; set; } = string.Empty;
    public string OsVersion { get; set; } = string.Empty;
    public string CpuName { get; set; } = string.Empty;
    public string GpuName { get; set; } = string.Empty;
    public double GpuUsage { get; set; }
    public int GpuTemp { get; set; }
    public string GpuVram { get; set; } = string.Empty;
    public double GpuVramUsedGb { get; set; }
    public double GpuVramTotalGb { get; set; }
    public int GpuClockCoreMhz { get; set; }
    public int GpuClockMemMhz { get; set; }
    public int CpuCores { get; set; }
    public int CpuThreads { get; set; }
    public string RamSpeed { get; set; } = string.Empty;
    /// Тип пам’яті окремо: "DDR4", "DDR5"…
    public string RamType { get; set; } = string.Empty;
    /// Ефективна частота пам’яті окремо, МГц (ConfiguredClockSpeed).
    public int RamFreqMhz { get; set; }
    public double CpuTempC { get; set; }
    public string LanIp { get; set; } = string.Empty;
    public string WanIp { get; set; } = string.Empty;
    public double GpuSharedUsedGb { get; set; }
    public double GpuSharedTotalGb { get; set; }
    /// Акумулятор (для ноутбуків): 0..100, -1 = датчик відсутній.
    public double BatteryPercent { get; set; } = -1;
    public bool BatteryCharging { get; set; }
    public bool BatteryPresent { get; set; }
    /// <summary>Відеокарта ВБУДОВАНА (iGPU): немає власних сенсорів температури
    /// і власної пам'яті — веб показує температуру CPU і спільну пам'ять ОЗУ.</summary>
    public bool GpuIntegrated { get; set; }
    /// <summary>Паспортна ємність батареї (мВт·год, DesignCapacity).</summary>
    public int BatteryDesignCapacityMWh { get; set; }
    /// <summary>Поточна повна ємність (мВт·год) — зношування = Full/Design.</summary>
    public int BatteryFullCapacityMWh { get; set; }
    /// <summary>Напруга батареї (мВ).</summary>
    public int BatteryVoltageMv { get; set; }
    /// <summary>Миттєва потужність: +заряджання / -розряджання (мВт).</summary>
    public int BatteryRateMw { get; set; }
    /// <summary>Орієнтовний час до повного заряду (сек; 0 — невідомо).</summary>
    public int BatteryTimeToFullSec { get; set; }
    /// <summary>Кількість циклів заряд/розряд (якщо батарея віддає).</summary>
    public int BatteryCycleCount { get; set; }
    /// Материнська плата «Manufacturer Model» (Win32_BaseBoard).
    public string Motherboard { get; set; } = string.Empty;
    /// Екран (ТЗ «Екран»): модель монітора, роздільність, герцовка, масштаб.
    public string ScreenModel { get; set; } = string.Empty;
    public string ScreenResolution { get; set; } = string.Empty;
    public int ScreenRefreshHz { get; set; }
    public int ScreenScalePercent { get; set; }
    /// Орієнтовний час роботи батареї (сек). -1 — відомий; 0 — на зарядці/невідомо.
    public int BatteryRunTimeSec { get; set; } = 0;
    /// <summary>Пристрій для рамки «Пристрої» (як у Диспетчері пристроїв).</summary>
    public class DeviceEntryDto
    {
        /// <summary>Категорія: Audio, Camera, Keyboard, Mouse, Printer, DiskDrive, Monitor, Bluetooth, USB, Net, Gamepad, Display.</summary>
        public string Cls { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string Manufacturer { get; set; } = string.Empty;
    }
}

public class SystemService
{
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    private class MEMORYSTATUSEX
    {
        public uint dwLength;
        public uint dwMemoryLoad;
        public ulong ullTotalPhys;
        public ulong ullAvailPhys;
        public ulong ullTotalPageFile;
        public ulong ullAvailPageFile;
        public ulong ullTotalVirtual;
        public ulong ullAvailVirtual;
        public ulong ullAvailExtendedVirtual;

        public MEMORYSTATUSEX()
        {
            dwLength = (uint)Marshal.SizeOf(typeof(MEMORYSTATUSEX));
        }
    }

    [return: MarshalAs(UnmanagedType.Bool)]
    [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    private static extern bool GlobalMemoryStatusEx([In, Out] MEMORYSTATUSEX lpBuffer);

    [DllImport("user32.dll")]
    private static extern IntPtr SendMessage(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam);

    private PerformanceCounter? _cpuCounter;
    private readonly ConcurrentDictionary<string, PerformanceCounter> _gpuEngineCounters = new();
    private bool _nvidiaSmiAvailable;

    private string _cachedCpuName = string.Empty;
    private string _cachedGpuName = string.Empty;
    private string _cachedOsName = string.Empty;
    private double _cachedTotalRamGb = 0;
    private string _cachedRamSpeed = "DDR4";
    private string _cachedRamType = string.Empty;
    private int _cachedRamFreqMhz = 0;
    // letter ("C:") → (model, mediaType) — повільні WMI-запити дисків кешуємо назавжди.
    private readonly ConcurrentDictionary<string, (string Model, string Media)> _diskModels = new();
    // Когда В ОСТАННІЙ раз модель не знайшлась (TickCount64 мс) — ретрай через 60с, а не «ніколи».
    private readonly ConcurrentDictionary<string, long> _diskModelsEmptyAt = new();
    private int _cachedCpuCores = 0;
    private int _cachedCpuThreads = 0;
    private string _cachedGpuVram = string.Empty;
    private double _cachedGpuUsage = 0;
    private int _cachedGpuTemp = 0;
    private double _cachedGpuVramUsedGb = 0;
    private double _cachedGpuVramTotalGb = 0;
    private int _cachedGpuClockCore = 0;
    private int _cachedGpuClockMem = 0;
    private double _cachedGpuSharedUsedGb = 0;
    private double _cachedGpuSharedTotalGb = 0;
    private DateTime _lastGpuQuery = DateTime.MinValue;
    private double _cachedCpuTempC = 0;
    private DateTime _lastCpuTempQuery = DateTime.MinValue;
    private double _cachedBatteryPercent = -1;
    private bool _cachedBatteryCharging;
    private bool _cachedBatteryPresent;
    private DateTime _lastBatteryQuery = DateTime.MinValue;
    private string _cachedMotherboard = string.Empty;
    // Екран статичний — читаємо WMI один раз за сеанс (повільні запити).
    private string _cachedScreenModel = string.Empty;
    private string _cachedScreenResolution = string.Empty;
    private int _cachedScreenRefreshHz;
    private int _cachedScreenScalePercent;
    private bool _screenQueried;
    private int _cachedBatteryRunTimeSec;
    private int _cachedBatteryDesignMWh;
    private int _cachedBatteryFullMWh;
    private int _cachedBatteryVoltageMv;
    private int _cachedBatteryRateMw;
    private int _cachedBatteryTimeToFullSec;
    private int _cachedBatteryCycleCount;
    private bool? _cachedGpuIntegrated;
    private List<object>? _cachedDevices;
    private DateTime _lastDevicesQuery = DateTime.MinValue;
    private string _cachedLanIp = string.Empty;
    private string _cachedWanIp = string.Empty;
    private DateTime _lastWanIpQuery = DateTime.MinValue;
    private List<object>? _cachedAdapters;
    private DateTime _lastAdaptersQuery = DateTime.MinValue;

    public string CpuName => !string.IsNullOrEmpty(_cachedCpuName) ? _cachedCpuName : (_cachedCpuName = GetCpuNameFast());
    public string GpuName => !string.IsNullOrEmpty(_cachedGpuName) ? _cachedGpuName : (_cachedGpuName = GetGpuNameFast());
    public string OsName => !string.IsNullOrEmpty(_cachedOsName) ? _cachedOsName : (_cachedOsName = GetFriendlyOsNameFast());
    public int CpuCores => _cachedCpuCores > 0 ? _cachedCpuCores : (_cachedCpuCores = QueryCpuCoresFast());
    public int CpuThreads => _cachedCpuThreads > 0 ? _cachedCpuThreads : (_cachedCpuThreads = Environment.ProcessorCount);
    public double TotalRamGb => _cachedTotalRamGb > 0 ? _cachedTotalRamGb : (_cachedTotalRamGb = GetTotalRamFast());
    /// <summary>Локальний IPv4 (перший адаптер зі шлюзом) — для реєстрації та WoL.</summary>
    public string LanIp => QueryLanIp();

    public SystemService()
    {
        // 1. Instant sync initialization (takes < 2ms)
        _cachedCpuName = GetCpuNameFast();
        _cachedGpuName = GetGpuNameFast();
        _cachedOsName = GetFriendlyOsNameFast();
        _cachedTotalRamGb = GetTotalRamFast();

        // 2. Heavy performance counters & WMI initialized in background
        Task.Run(() =>
        {
            try
            {
                _cpuCounter = new PerformanceCounter("Processor", "% Processor Time", "_Total");
                _cpuCounter.NextValue();
            }
            catch { }

            // Warm up WMI/сенсорные источники в фоне (без kernel-драйвера:
            // WinRing0 из LibreHardwareMonitor был flagged как VulnerableDriver,
            // тепер температури — лише user-mode: nvidia-smi + ACPI thermal zone),
            // щоб перший запит температури не гальмував цикл телеметрії.

            try
            {
                _cachedGpuName = QueryGpuNameWmi();
            }
            catch
            {
                _cachedGpuName = "Відеокарта";
            }

            try
            {
                QueryRamDetailsWmi();
            }
            catch { }
        });
    }

    public SystemMetricsDto GetMetrics()
    {
        float cpu = 0;
        try { if (_cpuCounter != null) cpu = _cpuCounter.NextValue(); } catch { }

        UpdateGpuMetrics();

        GetRamInfoFast(out double totalRamGb, out double freeRamGb);
        double usedRamGb = Math.Max(0, totalRamGb - freeRamGb);
        double ramPct = totalRamGb > 0 ? (usedRamGb / totalRamGb) * 100 : 0;

        var uptime = TimeSpan.FromMilliseconds(Environment.TickCount64);
        string uptimeStr = $"{uptime.Days}d {uptime.Hours}h {uptime.Minutes}m";

        var cpuTemp = QueryCpuTempC();
        var lanIp = QueryLanIp();
        QueryScreenInfo(); // рамка «Екран»: WMI один раз на сеанс
        _ = Task.Run(() => QueryWanIpAsync());

        // ТЗ «встройка»: температура GPU = температура CPU, «відеопам'ять» =
        // скільки GPU бере з ОЗУ (спільна пам'ять). Дискретні карти не чіпаємо.
        // ТЗ 6: вбудовані GPU часто мають НЕНУЛЬОВУ виділену пам'ять у реєстрі
        // (HardwareInformation.qwMemorySize ≈ 0.5 ГБ) — показуємо саме її.
        if (IsGpuIntegrated())
        {
            if (_cachedGpuTemp <= 0) _cachedGpuTemp = (int)Math.Round(cpuTemp);
            if (_cachedGpuVramTotalGb <= 0)
            {
                try
                {
                    var dedicatedBytes = GetDedicatedVramBytesFromRegistry();
                    if (dedicatedBytes > 0)
                        _cachedGpuVramTotalGb = Math.Round(dedicatedBytes / (1024.0 * 1024.0 * 1024.0), 2);
                }
                catch { }
            }
            if (_cachedGpuVramTotalGb <= 0) _cachedGpuVramTotalGb = _cachedGpuSharedTotalGb;
            if (_cachedGpuVramUsedGb <= 0) _cachedGpuVramUsedGb = _cachedGpuSharedUsedGb;
        }

        var disks = new List<DiskInfo>();
        try
        {
            foreach (var drive in DriveInfo.GetDrives())
            {
                if (drive.IsReady && (drive.DriveType == DriveType.Fixed || drive.DriveType == DriveType.Removable))
                {
                    long totalB = drive.TotalSize;
                    long freeB = drive.AvailableFreeSpace;
                    long usedB = Math.Max(0, totalB - freeB);
                    double totalG = totalB / (1024.0 * 1024.0 * 1024.0);
                    double freeG = freeB / (1024.0 * 1024.0 * 1024.0);
                    double usedG = usedB / (1024.0 * 1024.0 * 1024.0);

                    var (diskModel, diskMedia) = QueryDiskModel(drive.Name);
                    if (drive.DriveType == DriveType.Removable && string.IsNullOrEmpty(diskMedia)) diskMedia = "USB";
                    disks.Add(new DiskInfo
                    {
                        Name = drive.Name,
                        Label = string.IsNullOrWhiteSpace(drive.VolumeLabel) ? "Диск" : drive.VolumeLabel,
                        TotalGb = Math.Round(totalG, 2),
                        FreeGb = Math.Round(freeG, 2),
                        UsedGb = Math.Round(usedG, 2),
                        TotalBytes = totalB,
                        FreeBytes = freeB,
                        UsedBytes = usedB,
                        PercentUsed = totalB > 0 ? (int)Math.Round(((double)usedB / totalB) * 100) : 0,
                        DriveType = drive.DriveType == DriveType.Removable ? "removable" :
                                    drive.DriveType == DriveType.Network ? "network" : "fixed",
                        Model = diskModel,
                        MediaType = diskMedia
                    });
                }
            }
        }
        catch { }

        return new SystemMetricsDto
        {
            CpuUsage = Math.Round(cpu, 1),
            CpuPercent = Math.Round(cpu, 1),
            RamUsage = Math.Round(ramPct, 1),
            RamPercent = Math.Round(ramPct, 1),
            RamUsedGb = Math.Round(usedRamGb, 2),
            RamUsedMb = Math.Round(usedRamGb * 1024, 0),
            RamTotalGb = Math.Round(totalRamGb, 2),
            RamTotalMb = Math.Round(totalRamGb * 1024, 0),
            Disks = disks,
            Uptime = uptimeStr,
            MachineName = Environment.MachineName,
            UserName = Environment.UserName,
            OsVersion = OsName,
            CpuName = CpuName,
            GpuName = GpuName,
            GpuUsage = Math.Round(_cachedGpuUsage, 1),
            GpuTemp = _cachedGpuTemp,
            // ТЗ 6: {:F0} давав «0 GB» для вбудованих GPU (~0.5 ГБ) — дробові
            // обсяги показуємо як є.
            GpuVram = _cachedGpuVramTotalGb > 0
                ? (_cachedGpuVramTotalGb >= 10 ? $"{_cachedGpuVramTotalGb:F0} GB" : $"{_cachedGpuVramTotalGb:0.##} GB")
                : QueryGpuVramFast(),
            GpuVramUsedGb = _cachedGpuVramUsedGb,
            GpuVramTotalGb = _cachedGpuVramTotalGb,
            // ВБУДОВАНА графіка (ТЗ): у неї немає власного сенсора температури
            // і власної пам'яті — віддаємо температуру ПРОЦЕСОРА і спільну
            // пам'ять (бере з ОЗУ). Дискретна — усе як є.
            GpuIntegrated = _cachedGpuIntegrated == true,
            GpuClockCoreMhz = _cachedGpuClockCore,
            GpuClockMemMhz = _cachedGpuClockMem,
            CpuCores = CpuCores,
            CpuThreads = CpuThreads,
            RamSpeed = _cachedRamSpeed,
            RamType = _cachedRamType,
            RamFreqMhz = _cachedRamFreqMhz,
            CpuTempC = cpuTemp,
            LanIp = lanIp,
            WanIp = _cachedWanIp,
            GpuSharedUsedGb = _cachedGpuSharedUsedGb,
            GpuSharedTotalGb = _cachedGpuSharedTotalGb,
            BatteryPercent = QueryBattery(),
            BatteryCharging = _cachedBatteryCharging,
            BatteryPresent = _cachedBatteryPresent,
            BatteryRunTimeSec = _cachedBatteryRunTimeSec,
            BatteryDesignCapacityMWh = _cachedBatteryDesignMWh,
            BatteryFullCapacityMWh = _cachedBatteryFullMWh,
            BatteryVoltageMv = _cachedBatteryVoltageMv,
            BatteryRateMw = _cachedBatteryRateMw,
            BatteryTimeToFullSec = _cachedBatteryTimeToFullSec,
            BatteryCycleCount = _cachedBatteryCycleCount,
            Motherboard = QueryMotherboard(),
            ScreenModel = _cachedScreenModel,
            ScreenResolution = _cachedScreenResolution,
            ScreenRefreshHz = _cachedScreenRefreshHz,
            ScreenScalePercent = _cachedScreenScalePercent
        };
    }

    private string GetCpuNameFast()
    {
        try
        {
            using var key = Registry.LocalMachine.OpenSubKey(@"HARDWARE\DESCRIPTION\System\CentralProcessor\0");
            if (key != null)
            {
                var val = key.GetValue("ProcessorNameString")?.ToString();
                if (!string.IsNullOrWhiteSpace(val)) return val.Trim();
            }
        }
        catch { }
        return Environment.GetEnvironmentVariable("PROCESSOR_IDENTIFIER") ?? "AMD / Intel Processor";
    }

    private string GetFriendlyOsNameFast()
    {
        try
        {
            using var key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion");
            if (key != null)
            {
                var productName = key.GetValue("ProductName")?.ToString() ?? "";
                var displayVer = key.GetValue("DisplayVersion")?.ToString() ?? "";
                var buildStr = key.GetValue("CurrentBuild")?.ToString() ?? key.GetValue("CurrentBuildNumber")?.ToString() ?? "";
                if (string.IsNullOrEmpty(buildStr)) buildStr = Environment.OSVersion.Version.Build.ToString();

                if (int.TryParse(buildStr, out int build) && build >= 22000)
                {
                    if (productName.Contains("Windows 10"))
                    {
                        productName = productName.Replace("Windows 10", "Windows 11");
                    }
                    else if (!productName.Contains("Windows 11"))
                    {
                        productName = "Windows 11 Pro";
                    }
                }

                if (!string.IsNullOrEmpty(productName))
                {
                    return string.IsNullOrEmpty(displayVer) ? productName : $"{productName} ({displayVer})";
                }
            }
        }
        catch { }
        return RuntimeInformation.OSDescription;
    }

    private static string GetGpuNameFast()
    {
        try
        {
            using var classKey = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}");
            if (classKey != null)
            {
                string bestName = "";
                foreach (var subName in classKey.GetSubKeyNames())
                {
                    if (subName.Length == 4 && subName.All(char.IsDigit))
                    {
                        using var subKey = classKey.OpenSubKey(subName);
                        var driverDesc = subKey?.GetValue("DriverDesc")?.ToString();
                        if (!string.IsNullOrWhiteSpace(driverDesc))
                        {
                            var trimmed = driverDesc.Trim();
                            if (trimmed.Contains("NVIDIA", StringComparison.OrdinalIgnoreCase) ||
                                trimmed.Contains("GeForce", StringComparison.OrdinalIgnoreCase) ||
                                trimmed.Contains("Radeon", StringComparison.OrdinalIgnoreCase) ||
                                trimmed.Contains("RTX", StringComparison.OrdinalIgnoreCase) ||
                                trimmed.Contains("GTX", StringComparison.OrdinalIgnoreCase) ||
                                trimmed.Contains("Arc", StringComparison.OrdinalIgnoreCase))
                            {
                                return trimmed;
                            }
                            if (string.IsNullOrEmpty(bestName) && !trimmed.Contains("Basic Display", StringComparison.OrdinalIgnoreCase))
                            {
                                bestName = trimmed;
                            }
                        }
                    }
                }
                if (!string.IsNullOrEmpty(bestName)) return bestName;
            }
        }
        catch { }
        return "Графічний прискорювач";
    }

    private double GetTotalRamFast()
    {
        try
        {
            var mem = new MEMORYSTATUSEX();
            if (GlobalMemoryStatusEx(mem))
            {
                return Math.Round(mem.ullTotalPhys / (1024.0 * 1024.0 * 1024.0), 1);
            }
        }
        catch { }
        return 16.0;
    }

    private void GetRamInfoFast(out double totalGb, out double freeGb)
    {
        try
        {
            var mem = new MEMORYSTATUSEX();
            if (GlobalMemoryStatusEx(mem))
            {
                totalGb = mem.ullTotalPhys / (1024.0 * 1024.0 * 1024.0);
                freeGb = mem.ullAvailPhys / (1024.0 * 1024.0 * 1024.0);
                return;
            }
        }
        catch { }
        totalGb = 16.0;
        freeGb = 8.0;
    }

    private string QueryGpuNameWmi()
    {
        try
        {
            using var searcher = new ManagementObjectSearcher("Select Name from Win32_VideoController");
            foreach (var item in searcher.Get())
            {
                var name = item["Name"]?.ToString();
                if (!string.IsNullOrWhiteSpace(name)) return name.Trim();
            }
        }
        catch { }
        return "Графічний адаптер";
    }

    private void QueryRamDetailsWmi()
    {
        try
        {
            using var searcherRAM = new ManagementObjectSearcher("Select Speed, ConfiguredClockSpeed, MemoryType, SMBIOSMemoryType from Win32_PhysicalMemory");
            uint speed = 0;
            uint typeNum = 0;
            foreach (var item in searcherRAM.Get())
            {
                uint conf = 0;
                if (item["ConfiguredClockSpeed"] != null) conf = Convert.ToUInt32(item["ConfiguredClockSpeed"]);
                uint raw = 0;
                if (item["Speed"] != null) raw = Convert.ToUInt32(item["Speed"]);
                // ConfiguredClockSpeed is the active XMP/DOCP speed.  Read all
                // DIMMs and retain the highest valid configured value instead of
                // trusting the first module's JEDEC/SMBIOS fallback.
                var moduleSpeed = conf > 0 ? conf : raw;
                if (moduleSpeed > speed) speed = moduleSpeed;

                if (item["SMBIOSMemoryType"] != null) typeNum = Convert.ToUInt32(item["SMBIOSMemoryType"]);
                else if (item["MemoryType"] != null) typeNum = Convert.ToUInt32(item["MemoryType"]);
            }

            string ddrType = typeNum switch
            {
                20 => "DDR",
                21 => "DDR2",
                24 => "DDR3",
                26 => "DDR4",
                34 => "DDR5",
                _ => "DDR4"
            };

            _cachedRamSpeed = speed > 0 ? $"{ddrType} @ {speed} MHz" : ddrType;
            _cachedRamType = ddrType;
            _cachedRamFreqMhz = (int)speed;
        }
        catch { }
    }

    /// Модель фізичного диска та тип носія (SSD/HDD/NVMe/USB) для букви логічного диска.
    /// Ланцюг: Win32_LogicalDisk → Win32_LogicalDiskToPartition → Win32_DiskDriveToDiskPartition → Win32_DiskDrive,
    /// тип носія — MSFT_PhysicalDisk.MediaType (3=HDD, 4=SSD) + BusType (7=USB, 17=NVMe) за Index диска.
    ///
    /// КРИТИЧНИЙ ФІКС (фідбек юзера: «пишеться тільки Диск C, вільно/всього»):
    /// Win32_LogicalDisk.DeviceID — це «C:» БЕЗ хвостового слеша. Стара версія
    /// шукала об'єкт DeviceID='C:\' — таких об'єктів у WMI НЕ ІСНУЄ, запит
    /// повертав 0 рядків, модель і тип НІКОЛИ не знаходились, а порожній
    /// результат кешувався НАЗАВЖДИ. Тепер: правильний DeviceID + BusType +
    /// порожній результат кешується максимум на 60с (ретрай).
    private (string Model, string Media) QueryDiskModel(string driveName)
    {
        if (_diskModels.TryGetValue(driveName, out var cached)) return cached;

        // Порожній результат раніше — ретраїмо не частіше ніж раз на 60с
        // (щоб не спамити WMI щосекунди), але й НЕ «назавжди», як було.
        if (_diskModelsEmptyAt.TryGetValue(driveName, out var emptyAt) &&
            (Environment.TickCount64 - emptyAt) < 60_000)
            return (string.Empty, string.Empty);

        var result = (string.Empty, string.Empty);
        try
        {
            // «C:» — рівно те значення, яке WMI зберігає у DeviceID (без слеша!)
            string deviceId = driveName.TrimEnd('\\', '/', ':').ToUpperInvariant() + ":";
            if (deviceId.Length != 2) return result; // не логічний диск (мережеві шляхи тощо)

            // 1) логічний диск → розділ(и)
            string? partitionId = null;
            using (var partSearcher = new ManagementObjectSearcher(
                $"ASSOCIATORS OF {{Win32_LogicalDisk.DeviceID='{deviceId}'}} WHERE AssocClass = Win32_LogicalDiskToPartition"))
            {
                foreach (var p in partSearcher.Get())
                {
                    partitionId = p["DeviceID"]?.ToString();
                    if (partitionId != null) break;
                }
            }
            // 2) розділ → фізичний диск
            if (partitionId != null)
            {
                using var driveSearcher = new ManagementObjectSearcher(
                    $"ASSOCIATORS OF {{Win32_DiskPartition.DeviceID='{partitionId}'}} WHERE AssocClass = Win32_DiskDriveToDiskPartition");
                foreach (var d in driveSearcher.Get())
                {
                    string model = d["Model"]?.ToString() ?? string.Empty;
                    string rawIndex = d["Index"]?.ToString() ?? string.Empty;
                    string media = string.Empty;
                    // 3) тип носія за MSFT_PhysicalDisk (Index == DeviceId):
                    //    MediaType 3=HDD 4=SSD, BusType 7=USB 17=NVMe (ТЗ: тип обов'язково)
                    if (uint.TryParse(rawIndex, out uint diskIdx))
                    {
                        try
                        {
                            using var physSearcher = new ManagementObjectSearcher(
                                "root\\microsoft\\windows\\storage", $"SELECT MediaType, BusType FROM MSFT_PhysicalDisk WHERE DeviceId = {diskIdx}");
                            foreach (var m in physSearcher.Get())
                            {
                                ushort mt = Convert.ToUInt16(m["MediaType"] ?? (ushort)0);
                                ushort bt = 0;
                                try { bt = Convert.ToUInt16(m["BusType"] ?? (ushort)0); } catch { }
                                if (bt == 7) media = "USB";                  // USB-накопичувач
                                else if (mt == 4) media = bt == 17 ? "NVMe" : "SSD";
                                else if (mt == 3) media = "HDD";
                            }
                        }
                        catch { }
                    }
                    if (string.IsNullOrEmpty(media))
                    {
                        // Евристика за назвою моделі (коли Storage-провайдер недоступний)
                        var up = model.ToUpperInvariant();
                        if (up.Contains("NVME")) media = "NVMe";
                        else if (up.Contains("SSD")) media = "SSD";
                        else if (up.Contains("HDD") || up.Contains("HARD DISK")) media = "HDD";
                        else if (up.Contains("USB")) media = "USB";
                    }
                    result = (model, media);
                    break;
                }
            }
        }
        catch { }
        if (string.IsNullOrEmpty(result.Item1) && string.IsNullOrEmpty(result.Item2))
            _diskModelsEmptyAt[driveName] = Environment.TickCount64; // ретрай через 60с
        else
            _diskModels[driveName] = result; // успіх кешуємо надовго
        return result;
    }

    private int QueryCpuCoresFast()
    {
        try
        {
            using var searcher = new ManagementObjectSearcher("Select NumberOfCores, NumberOfLogicalProcessors from Win32_Processor");
            foreach (var item in searcher.Get())
            {
                if (item["NumberOfCores"] != null)
                    _cachedCpuCores = Convert.ToInt32(item["NumberOfCores"]);
                if (item["NumberOfLogicalProcessors"] != null)
                    _cachedCpuThreads = Convert.ToInt32(item["NumberOfLogicalProcessors"]);
                if (_cachedCpuCores > 0) return _cachedCpuCores;
            }
        }
        catch { }
        return Math.Max(1, Environment.ProcessorCount / 2);
    }

    /// <summary>
    /// Реальний обсяг ВИДІЛЕНОЇ відеопам'яти з реєстру (ТЗ 6 — фікс «0 ГБ» для
    /// вбудованих GPU): ключі адаптерів класу {4d36e968-…}\0000..0005, значення
    /// HardwareInformation.qwMemorySize (REG_QWORD, точні байти навіть для iGPU
    /// — типово 0.125–0.5 ГБ, які Win32_VideoController.AdapterRAM втрачає
    /// через 32-бітне обмеження/недозвіл WMI). Фолбек —
    /// HardwareInformation.MemorySize (REG_DWORD/REG_BINARY 4-8 байт).
    /// Повертає 0, якщо реєстр не дав нічого (тоді працює старий WMI-шлях).
    /// </summary>
    private static long GetDedicatedVramBytesFromRegistry()
    {
        long total = 0;
        try
        {
            using var classKey = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}");
            if (classKey == null) return 0;
            foreach (var subName in classKey.GetSubKeyNames())
            {
                if (subName.Length != 4 || !subName.All(char.IsDigit)) continue;
                try
                {
                    using var subKey = classKey.OpenSubKey(subName);
                    if (subKey == null) continue;

                    var qw = subKey.GetValue("HardwareInformation.qwMemorySize");
                    if (qw is long q && q > 0) { total += q; continue; }
                    if (qw is int i32 && i32 > 0) { total += i32; continue; }
                    if (qw != null && long.TryParse(qw.ToString(), out long parsed) && parsed > 0) { total += parsed; continue; }

                    if (subKey.GetValue("HardwareInformation.MemorySize") is byte[] bin && bin.Length is 4 or 8)
                    {
                        var v = bin.Length == 8 ? BitConverter.ToInt64(bin, 0) : BitConverter.ToInt32(bin, 0);
                        if (v > 0) total += v;
                    }
                }
                catch { }
            }
        }
        catch { }
        return total;
    }

    /// <summary>Розумний формат «ГБ»: для малих обсягів (вбудовані GPU ~0.5 ГБ)
    /// показує дробову частину замість «0 GB» (ТЗ 6 — фікс «0 ГБ»).</summary>
    private static string FormatGbSmart(double gb)
    {
        if (gb <= 0) return "Недоступно";
        return gb >= 10 ? $"{Math.Round(gb)} GB" : $"{gb:0.##} GB";
    }

    private string QueryGpuVramFast()
    {
        if (!string.IsNullOrEmpty(_cachedGpuVram)) return _cachedGpuVram;

        try
        {
            // 1. Реєстрові байти (qwMemorySize/MemorySize) — найточніше джерело,
            //    працює і для вбудованих GPU (ТЗ 6).
            var regBytes = GetDedicatedVramBytesFromRegistry();
            if (regBytes > 0)
            {
                return _cachedGpuVram = FormatGbSmart(regBytes / (1024.0 * 1024.0 * 1024.0));
            }
        }
        catch { }

        try
        {
            // 2. Try WMI Win32_VideoController
            using var searcher = new ManagementObjectSearcher("Select AdapterRAM from Win32_VideoController");
            foreach (var item in searcher.Get())
            {
                if (item["AdapterRAM"] != null)
                {
                    long bytes = Convert.ToInt64(item["AdapterRAM"]);
                    if (bytes > 0)
                    {
                        return _cachedGpuVram = FormatGbSmart(bytes / (1024.0 * 1024.0 * 1024.0));
                    }
                }
            }
        }
        catch { }

        return _cachedGpuVram = "Недоступно";
    }

    private void UpdateGpuMetrics()
    {
        if ((DateTime.UtcNow - _lastGpuQuery).TotalSeconds < 1.5) return;
        _lastGpuQuery = DateTime.UtcNow;

        bool haveTemp = false;
        bool haveUsage = false;
        bool haveVramUsed = false;
        bool haveVramTotal = false;

        // (a) nvidia-smi — user-mode GPU-сенсоры NVIDIA (температура/загрузка/VRAM),
        // единственный источник для частот ядра/памяти. Kernel-драйвер НЕ
        // используется: WinRing0 (LibreHardwareMonitor) триггерил антивирус
        // (VulnerableDriver:WinNT/Wiring0).
        if (_nvidiaSmiAvailable || _cachedGpuClockCore <= 0 || !haveTemp || !haveUsage || !haveVramUsed || !haveVramTotal)
        {
            try
            {
                var psi = new ProcessStartInfo
                {
                    FileName = "nvidia-smi",
                    Arguments = "--query-gpu=utilization.gpu,temperature.gpu,memory.used,memory.total,clocks.gr,clocks.mem --format=csv,noheader,nounits",
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    CreateNoWindow = true
                };
                using var proc = Process.Start(psi);
                if (proc != null)
                {
                    string output = proc.StandardOutput.ReadToEnd();
                    proc.WaitForExit(300);
                    if (!string.IsNullOrWhiteSpace(output))
                    {
                        var parts = output.Trim().Split(',', StringSplitOptions.TrimEntries);
                        if (parts.Length >= 2)
                        {
                            if (!haveUsage && double.TryParse(parts[0], out double util)) { _cachedGpuUsage = util; haveUsage = true; }
                            if (!haveTemp && int.TryParse(parts[1], out int temp)) { _cachedGpuTemp = temp; haveTemp = true; }
                        }
                        if (parts.Length >= 4)
                        {
                            if (!haveVramUsed && double.TryParse(parts[2], out double vramUsedMb)) { _cachedGpuVramUsedGb = Math.Round(vramUsedMb / 1024.0, 1); haveVramUsed = true; }
                            if (!haveVramTotal && double.TryParse(parts[3], out double vramTotMb)) { _cachedGpuVramTotalGb = Math.Round(vramTotMb / 1024.0, 1); haveVramTotal = true; }
                        }
                        if (parts.Length >= 6)
                        {
                            if (int.TryParse(parts[4], out int clkCore)) _cachedGpuClockCore = clkCore;
                            if (int.TryParse(parts[5], out int clkMem)) _cachedGpuClockMem = clkMem;
                        }
                        _nvidiaSmiAvailable = true;
                    }
                }
            }
            catch { }
        }

        // (b) GPU Engine counters — Task-Manager style sum over ALL current
        // instances. Integrated GPUs have no nvidia-smi and often no load
        // sensor, so this is the only honest usage source there.
        if (!haveUsage)
        {
            var engineUsage = QueryGpuEngineUsageSum();
            if (engineUsage >= 0) _cachedGpuUsage = Math.Round(engineUsage, 1);
        }

        // VRAM total for iGPUs: registry qwMemorySize → WMI AdapterRAM chain
        // (LHM usually reports VRAM totals for discrete cards only).
        if (!haveVramTotal && _cachedGpuVramTotalGb <= 0)
        {
            try
            {
                var vramText = QueryGpuVramFast();
                if (vramText.EndsWith("GB", StringComparison.OrdinalIgnoreCase) &&
                    double.TryParse(vramText.Replace("GB", "", StringComparison.OrdinalIgnoreCase).Trim(), out double totalGb) &&
                    totalGb > 0)
                {
                    _cachedGpuVramTotalGb = totalGb;
                }
            }
            catch { }
        }

        // (d) GPU Adapter Memory counters — shared/dedicated memory pressure.
        UpdateGpuMemoryCounters();
    }

    /// <summary>
    /// Sums "Utilization Percentage" over ALL current "GPU Engine" instances —
    /// exactly what Task Manager shows. GPU Engine instances come and go with
    /// D3D workloads, so counters are created on demand into a cache and pruned
    /// when their instance disappears (a single engtype_3D counter captured at
    /// startup returned 0 forever after that churn — the old 0% bug).
    /// Returns -1 when the category is unavailable.
    /// </summary>
    private double QueryGpuEngineUsageSum()
    {
        try
        {
            string[] instances;
            try { instances = new PerformanceCounterCategory("GPU Engine").GetInstanceNames(); }
            catch { return -1; }
            if (instances.Length == 0) return -1;

            double sum = 0;
            foreach (var instance in instances)
            {
                try
                {
                    var counter = _gpuEngineCounters.GetOrAdd(instance, static name => new PerformanceCounter("GPU Engine", "Utilization Percentage", name, readOnly: true));
                    sum += counter.NextValue();
                }
                catch { }
            }

            var cachedKeys = _gpuEngineCounters.Keys;
            if (cachedKeys.Count > instances.Length)
            {
                var live = new HashSet<string>(instances, StringComparer.Ordinal);
                foreach (var key in cachedKeys)
                {
                    if (!live.Contains(key) && _gpuEngineCounters.TryRemove(key, out PerformanceCounter? stale))
                    {
                        try { stale.Dispose(); } catch { }
                    }
                }
            }

            return Math.Clamp(sum, 0, 100);
        }
        catch { return -1; }
    }

    private void UpdateGpuMemoryCounters()
    {
        try
        {
            double dedicatedBytes = 0;
            double sharedBytes = 0;
            var category = new PerformanceCounterCategory("GPU Adapter Memory");
            foreach (var instance in category.GetInstanceNames())
            {
                foreach (var counterName in new[] { "Dedicated Usage", "Shared Usage" })
                {
                    try
                    {
                        using var counter = new PerformanceCounter("GPU Adapter Memory", counterName, instance, readOnly: true);
                        var value = counter.NextValue();
                        if (counterName == "Dedicated Usage") dedicatedBytes += value;
                        else sharedBytes += value;
                    }
                    catch { }
                }
            }

            if (dedicatedBytes > 0 && _cachedGpuVramUsedGb <= 0)
            {
                _cachedGpuVramUsedGb = Math.Round(dedicatedBytes / (1024.0 * 1024.0 * 1024.0), 2);
            }
            if (sharedBytes > 0)
            {
                _cachedGpuSharedUsedGb = Math.Round(sharedBytes / (1024.0 * 1024.0 * 1024.0), 2);
                // Shared GPU memory is capped by half of system RAM on Windows.
                _cachedGpuSharedTotalGb = Math.Round(TotalRamGb / 2, 1);
            }
            else if (_cachedGpuSharedTotalGb <= 0 && IsGpuIntegrated())
            {
                // ТЗ 6: встройка без GPU-лічильників — чесний бюджет спільної
                // пам'яті: до половини ОЗУ, обмежено 8 ГБ (Windows резерви так само).
                _cachedGpuSharedTotalGb = Math.Round(Math.Min(0.5 * TotalRamGb, 8.0), 2);
                if (_cachedGpuSharedTotalGb < 0.5) _cachedGpuSharedTotalGb = 0.5;
            }
        }
        catch { }
    }

    /// <summary>
    /// Best-effort CPU temperature — ЛИШЕ user-mode (WinRing0 з LibreHardwareMonitor
    /// флагався антивірусом як VulnerableDriver, тому kernel-драйвер заборонено).
    /// Джерела: 1) MSAcpi_ThermalZoneTemperature (root/WMI) — беремо МАКСИМУМ по
    /// всіх зонах (CPU-зона зазвичай найгарячіша, а не перша-ліпша); 2) лічильник
    /// Win32_PerfFormattedData_Counters_ThermalZoneInformation (root/CIMV2), який
    /// працює на більшій кількості плат. Чесно повертає 0, коли сенсорів немає.
    /// </summary>
    private double QueryCpuTempC()
    {
        if ((DateTime.UtcNow - _lastCpuTempQuery).TotalSeconds < 10) return _cachedCpuTempC;
        _lastCpuTempQuery = DateTime.UtcNow;

        double best = 0;
        try
        {
            using var searcher = new ManagementObjectSearcher("root\\WMI", "Select CurrentTemperature from MSAcpi_ThermalZoneTemperature");
            foreach (var item in searcher.Get())
            {
                if (item["CurrentTemperature"] != null)
                {
                    // Tenths of Kelvin → Celsius
                    var tempC = Convert.ToDouble(item["CurrentTemperature"]) / 10.0 - 273.15;
                    if (tempC is > 0 and < 120 && tempC > best)
                    {
                        best = tempC;
                    }
                }
            }
        }
        catch { }

        // 2) Performance-counter thermal zones (інший, ширший набір плат).
        try
        {
            using var perf = new ManagementObjectSearcher(
                "root\\CIMV2", "Select Temperature, HighPrecisionTemperature FROM Win32_PerfFormattedData_Counters_ThermalZoneInformation");
            foreach (var item in perf.Get())
            {
                double tempC = 0;
                if (item["HighPrecisionTemperature"] != null)
                    tempC = Convert.ToDouble(item["HighPrecisionTemperature"]) / 10.0 - 273.15;
                else if (item["Temperature"] != null)
                    tempC = Convert.ToDouble(item["Temperature"]) - 273.15;
                if (tempC is > 0 and < 120 && tempC > best)
                {
                    best = tempC;
                }
            }
        }
        catch { }

        if (best > 0) _cachedCpuTempC = Math.Round(best, 1);
        return _cachedCpuTempC;
    }

    /// <summary>
    /// Детекція ВБУДОВАНОЇ графіки (ТЗ: «встройка» показує температуру CPU і
    /// пам'ять з ОЗУ). Кешується назавжди — тип графіки за сеанс не змінюється.
    /// Евристики: Intel(R) UHD/HD/Iris, AMD Radeon(TM) (з ™ — це встройки),
    /// AMD Radeon 6xxM/7xxM; NVIDIA/GeForce/RTX/GTX/RX/Arc — дискретні.
    /// </summary>
    private bool IsGpuIntegrated()
    {
        if (_cachedGpuIntegrated.HasValue) return _cachedGpuIntegrated.Value;
        bool integrated;
        var name = (GpuName ?? string.Empty);
        if (string.IsNullOrWhiteSpace(name))
        {
            integrated = false;
        }
        else
        {
            var up = name.ToUpperInvariant();
            if (up.Contains("NVIDIA") || up.Contains("GEFORCE") || up.Contains("RTX") ||
                up.Contains("GTX") || up.Contains(" ARC"))
                integrated = false;
            else if (up.Contains("INTEL") &&
                     (up.Contains("UHD") || up.Contains(" HD ") || up.Contains("HD GRAPHICS") ||
                      up.Contains("IRIS") || up.Contains("GRAPHICS")))
                integrated = true;
            else if (up.Contains("RADEON(TM)") || System.Text.RegularExpressions.Regex.IsMatch(up, @"RADEON\s+\d{3}M"))
                integrated = true;
            else if (up.Contains("RADEON") || up.Contains("RX "))
                integrated = false;
            else
            {
                // Останній евристичний критерій: немає nvidia-smi, дискретної
                // пам'яті мало/немає, а спільна пам'ять активно використовується.
                integrated = !_nvidiaSmiAvailable && _cachedGpuVramTotalGb is > 0 and < 1.0;
            }
        }
        _cachedGpuIntegrated = integrated;
        return integrated;
    }

    /// <summary>Акумулятор ноутбука (Win32_Battery): відсоток заряду + «на зарядці».
    /// Кеш 20с; на десктопі BatteryPresent = false (картка не показується).
    /// Заодно читаємо EstimatedRunTime (сек) — орієнтовний час роботи (ТЗ).</summary>
    private double QueryBattery()
    {
        if ((DateTime.UtcNow - _lastBatteryQuery).TotalSeconds < 20) return _cachedBatteryPercent;
        _lastBatteryQuery = DateTime.UtcNow;
        try
        {
            using var searcher = new ManagementObjectSearcher("Select EstimatedChargeRemaining, BatteryStatus FROM Win32_Battery");
            foreach (var item in searcher.Get())
            {
                if (item["EstimatedChargeRemaining"] != null)
                {
                    var pct = Convert.ToDouble(item["EstimatedChargeRemaining"]);
                    var status = 0;
                    try { if (item["BatteryStatus"] != null) status = Convert.ToInt32(item["BatteryStatus"]); } catch { }
                    _cachedBatteryPercent = Math.Clamp(pct, 0, 100);
                    _cachedBatteryCharging = status == 2; // 2 = на змінному струмі
                    _cachedBatteryPresent = true;
                    try
                    {
                        // EstimatedRunTime — орієнтовний залишок у секундах
                        // (0xFFFFFFFF / 0 — «невідомо»); на зарядці завжди 0.
                        int run = Convert.ToInt32(item["EstimatedRunTime"] ?? 0);
                        _cachedBatteryRunTimeSec = (_cachedBatteryCharging || run <= 0 || run >= 0x7FFFFFF0) ? 0 : run;
                    }
                    catch { _cachedBatteryRunTimeSec = 0; }
                    break;
                }
            }

            // ТЗ «більше інформації про батарею»: напруга (DesignVoltage, мВ),
            // паспортна/фактична ємність, миттєва потужність і цикли.
            try
            {
                using var voltSearcher = new ManagementObjectSearcher("Select DesignVoltage, FullChargeCapacity, DesignCapacity FROM Win32_Battery");
                foreach (var item in voltSearcher.Get())
                {
                    if (item["DesignVoltage"] != null) _cachedBatteryVoltageMv = Convert.ToInt32(item["DesignVoltage"]);
                    if (item["FullChargeCapacity"] != null) _cachedBatteryFullMWh = Convert.ToInt32(item["FullChargeCapacity"]);
                    if (item["DesignCapacity"] != null && _cachedBatteryDesignMWh <= 0)
                        _cachedBatteryDesignMWh = Convert.ToInt32(item["DesignCapacity"]);
                }
            }
            catch { }

            // root/WMI: BatteryStaticData (паспортна ємність + CycleCount),
            // BatteryFullChargedCapacity (точна повна ємність), BatteryStatus
            // (ChargeRate/DischargeRate, мВт) — все best-effort.
            try
            {
                using var s1 = new ManagementObjectSearcher("root\\WMI", "Select DesignedCapacity, CycleCount FROM BatteryStaticData");
                foreach (var item in s1.Get())
                {
                    if (item["DesignedCapacity"] != null && _cachedBatteryDesignMWh <= 0)
                        _cachedBatteryDesignMWh = Convert.ToInt32(item["DesignedCapacity"]);
                    if (item["CycleCount"] != null) _cachedBatteryCycleCount = Convert.ToInt32(item["CycleCount"]);
                }
            }
            catch { }
            try
            {
                using var s2 = new ManagementObjectSearcher("root\\WMI", "Select FullChargedCapacity FROM BatteryFullChargedCapacity");
                foreach (var item in s2.Get())
                {
                    if (item["FullChargedCapacity"] != null)
                        _cachedBatteryFullMWh = Convert.ToInt32(item["FullChargedCapacity"]);
                }
            }
            catch { }
            try
            {
                using var s3 = new ManagementObjectSearcher("root\\WMI", "Select ChargeRate, DischargeRate, Charging FROM BatteryStatus");
                foreach (var item in s3.Get())
                {
                    int charge = 0, discharge = 0;
                    bool chargingFlag = false;
                    try { charge = Convert.ToInt32(item["ChargeRate"] ?? 0); } catch { }
                    try { discharge = Convert.ToInt32(item["DischargeRate"] ?? 0); } catch { }
                    try { chargingFlag = Convert.ToBoolean(item["Charging"] ?? false); } catch { }
                    _cachedBatteryRateMw = charge > 0 ? charge : (discharge > 0 ? -discharge : 0);
                    if (chargingFlag) _cachedBatteryCharging = true;

                    // Оцінка часу до повного заряду: (Full - Charge) / Rate.
                    // Заряд у мВт·год маємо лише через повну/паспортну ємність і %.
                    if (_cachedBatteryCharging && _cachedBatteryRateMw > 0 && _cachedBatteryFullMWh > 0)
                    {
                        double remainingMWh = _cachedBatteryFullMWh * (1.0 - _cachedBatteryPercent / 100.0);
                        if (remainingMWh > 0)
                        {
                            double sec = remainingMWh / _cachedBatteryRateMw * 3600.0;
                            _cachedBatteryTimeToFullSec = sec is > 0 and < 86400 ? (int)sec : 0;
                        }
                    }
                    else
                    {
                        _cachedBatteryTimeToFullSec = 0;
                    }
                }
            }
            catch { }
        }
        catch { }
        return _cachedBatteryPercent;
    }

    /// <summary>
    /// СПИСОК ПРИСТРОЇВ (фідбек 2: «куча сміття — WAN Miniport, хаби, HID-дублікати»).
    /// Джерело: Win32_PnPEntity (Present = підключені зараз). Кеш 90с.
    /// ЧИСТКА: WAN Miniport / віртуальні адаптери / хаби й контролери USB /
    /// composite / HID-дублікати клавіатур-мишей більше НЕ показуються.
    /// ЗБАГАЧЕННЯ: реальні моделі моніторів із WmiMonitorID (root\wmi),
    /// USB-накопичувачі — з Ven/Prod свого PNPDeviceID (як у Провідника).
    /// </summary>
    public List<SystemMetricsDto.DeviceEntryDto> GetDevicesList()
    {
        if (_cachedDevices != null && (DateTime.UtcNow - _lastDevicesQuery).TotalSeconds < 90)
            return _cachedDevices.Cast<SystemMetricsDto.DeviceEntryDto>().ToList();

        var result = new List<SystemMetricsDto.DeviceEntryDto>();
        try
        {
            // Реальні моделі моніторів: WmiMonitorID дає ManufacturerName (3-літерний
            // PnP-код) + UserFriendlyName («AOC 24B2XH»), які Диспетчер пристроїв ховає
            // за «Generic PnP Monitor».
            var monitorModels = new List<string>();
            try
            {
                using var ms = new ManagementObjectSearcher("root\\wmi", "SELECT ManufacturerName, UserFriendlyName, ProductCodeID FROM WmiMonitorID");
                foreach (var m in ms.Get())
                {
                    try
                    {
                        string man = DecodeWmiStringArray(m["ManufacturerName"]);
                        string friendly = DecodeWmiStringArray(m["UserFriendlyName"]);
                        string combined = string.Join(" ", new[] { man, friendly }.Where(s => !string.IsNullOrWhiteSpace(s))).Trim();
                        if (combined.Length > 0) monitorModels.Add(combined);
                    }
                    catch { }
                }
            }
            catch { }

            using var searcher = new ManagementObjectSearcher(
                "SELECT Name, PNPClass, Manufacturer, Status, PNPDeviceID FROM Win32_PnPEntity");
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            // Дженерики клавіатур/мишей: якщо є конкретна модель — дублікати-дженерики
            // прибираємо; якщо ВСІ дженерики — лишаємо рівно один запис на клас.
            var genericKeyboards = new List<SystemMetricsDto.DeviceEntryDto>();
            var genericMice = new List<SystemMetricsDto.DeviceEntryDto>();
            var hasRealKeyboard = false;
            var hasRealMouse = false;

            foreach (var item in searcher.Get())
            {
                try
                {
                    var status = item["Status"]?.ToString() ?? string.Empty;
                    if (status.Equals("Error", StringComparison.OrdinalIgnoreCase)) continue;

                    var name = item["Name"]?.ToString()?.Trim() ?? string.Empty;
                    if (name.Length == 0) continue;
                    var cls = item["PNPClass"]?.ToString()?.Trim() ?? string.Empty;
                    var manufacturer = item["Manufacturer"]?.ToString()?.Trim() ?? string.Empty;
                    var pnpId = item["PNPDeviceID"]?.ToString()?.Trim() ?? string.Empty;

                    string norm = cls switch
                    {
                        "AudioEndpoint" => "Audio",
                        "Media" => "Audio",
                        "Camera" or "Image" => "Camera",
                        "Keyboard" => "Keyboard",
                        "Mouse" => "Mouse",
                        "Printer" or "PrintQueue" => "Printer",
                        "DiskDrive" => "DiskDrive",
                        "Monitor" => "Monitor",
                        "Bluetooth" => "Bluetooth",
                        "USB" => "USB",
                        "Net" => "Net",
                        "HIDClass" => "HID",
                        "Display" => "Display",
                        _ => string.Empty
                    };
                    if (norm.Length == 0) continue;

                    // СМІТТЯ (фідбек юзера): WAN Miniport (12 штук!), Wi-Fi Direct
                    // віртуальні адаптери, хаби/контролери USB, composite, HID-дублікати,
                    // службові ACPI/перечислювачі — жодне з цього цікавим не є.
                    if (System.Text.RegularExpressions.Regex.IsMatch(
                            name,
                            @"WAN Miniport|Wi-Fi Direct|Virtual Adapter|Virtual Bluetooth|Host Controller|Root Hub|USB Hub|Composite Device|USB Input Device|HID-compliant|Bluetooth Device \(Personal|Bluetooth Link|Bluetooth ENUM|Kernel Debug|HID-|ACPI|Composite Bus|Root Print Queue|Microsoft Basic|UMBus|Kernel|Bus Enumerator|Volume Manager|Logical Disk Manager|Microcode|Software Device|Remote Desktop|Network Switch|Printer Port|Print Queue|SSDP|UM PassThru|Програмний|Код мікропрограм|Диспетчер логічних дисків|Менеджер логічних дисків",
                            System.Text.RegularExpressions.RegexOptions.IgnoreCase))
                        continue;
                    if (System.Text.RegularExpressions.Regex.IsMatch(
                            manufacturer ?? string.Empty,
                            @"\(Standard USB HUBs\)|\(Standard system devices\)|\(Стандартні системні пристрої\)|Microsoft$",
                            System.Text.RegularExpressions.RegexOptions.IgnoreCase) &&
                        norm is "USB" or "HID")
                    {
                        // дженерик-USB/HID від Microsoft без живої назви — сміття,
                        // ЯКЩО назва сама теж дженерик (перевірка нижче)
                        if (IsGenericDeviceName(name, norm)) continue;
                    }

                    // ЗБАГАЧЕННЯ: USB-накопичувачі — реальна модель із PNPDeviceID
                    // (USBSTOR\DISK&VEN_MIBRAND&PROD_SPIDER_240GB_SSD → «MIBRAND SPIDER 240GB SSD»).
                    if (pnpId.StartsWith("USBSTOR\\", StringComparison.OrdinalIgnoreCase))
                    {
                        var pretty = PrettyFromUsbStorId(pnpId);
                        if (!string.IsNullOrEmpty(pretty) && IsGenericDeviceName(name, "DiskDrive")) name = pretty;
                    }

                    // ЗБАГАЧЕННЯ: монітори — WmiMonitorID замість «Generic PnP Monitor».
                    if (norm == "Monitor" && monitorModels.Count > 0 && IsGenericDeviceName(name, "Monitor"))
                    {
                        var real = monitorModels[Math.Min(result.Count(x => x.Cls == "Monitor"), monitorModels.Count - 1)];
                        if (!string.IsNullOrWhiteSpace(real)) name = real;
                    }

                    // Дженерики вводу складаємо окремо — вирішимо після циклу.
                    if (norm == "Keyboard")
                    {
                        if (IsGenericDeviceName(name, "Keyboard"))
                        {
                            if (!seen.Add("KB|" + name)) continue;
                            genericKeyboards.Add(new SystemMetricsDto.DeviceEntryDto { Cls = norm, Name = CleanDeviceName(name, norm), Manufacturer = manufacturer });
                            continue;
                        }
                        hasRealKeyboard = true;
                    }
                    if (norm == "Mouse")
                    {
                        if (IsGenericDeviceName(name, "Mouse"))
                        {
                            if (!seen.Add("MS|" + name)) continue;
                            genericMice.Add(new SystemMetricsDto.DeviceEntryDto { Cls = norm, Name = CleanDeviceName(name, norm), Manufacturer = manufacturer });
                            continue;
                        }
                        hasRealMouse = true;
                    }

                    // ТЗ 6: ЧИСТКА назв перед дедуплікацією — «Мікрофон (2- Fifine…)»
                    // → «Fifine…» (аудіо-кінцеві точки), знімає префікси «1- » і
                    // дженерик-суфікси; бонус — екран-точка і Media-пристрій з
                    // однаковою назвою склеюються в один запис.
                    name = CleanDeviceName(name, norm);

                    // Дедуплікація (одна модель часто дає кілька екземплярів).
                    if (!seen.Add(norm + "|" + name)) continue;

                    if (manufacturer is "(Standard USB Host Controller)" or "(Стандартний контролер хоста USB)" or "(Standard system devices)" or "(Стандартні системні пристрої)" or "(Standard disk drives)" or "(Стандартні дискові накопичувачі)")
                        manufacturer = "Standard";

                    result.Add(new SystemMetricsDto.DeviceEntryDto { Cls = norm, Name = name, Manufacturer = manufacturer });
                    if (result.Count >= 80) break;
                }
                catch { }
            }

            // Фінал: дженерики вводу показуємо ТІЛЬКИ коли немає моделей-конкретики.
            if (!hasRealKeyboard && genericKeyboards.Count > 0)
                result.Add(new SystemMetricsDto.DeviceEntryDto { Cls = "Keyboard", Name = "Стандартна клавіатура", Manufacturer = "Standard" });
            if (!hasRealMouse && genericMice.Count > 0)
                result.Add(new SystemMetricsDto.DeviceEntryDto { Cls = "Mouse", Name = "Стандартна миша", Manufacturer = "Standard" });
        }
        catch { }

        _cachedDevices = result.Cast<object>().ToList();
        _lastDevicesQuery = DateTime.UtcNow;
        return result;
    }

    /// <summary>
    /// ТЗ 6: чистить сирі PnP-назви перед показом.
    /// «Мікрофон (2- Fifine MicrophoneWo66)» → «Fifine MicrophoneWo66»:
    /// знімає обгортку аудіо/камера-кінцевих точок, числові префікси «1- »/«2- »,
    /// дженерик-токени (standalone → узагальнена назва; як суфікс — зрізаємо),
    /// стискає пробіли. Клавіатура/миша: дженерики → «Стандартна клавіатура»/
    /// «Стандартна миша»; реальні моделі (напр. «Logitech G102») проходять як є.
    /// </summary>
    private static string CleanDeviceName(string raw, string category)
    {
        var name = (raw ?? string.Empty).Trim();
        if (name.Length == 0) return name;

        try
        {
            // 1) Обгортка кінцевої точки: «Мікрофон (…)», «Динаміки (…)», «Speakers (…)».
            var wrap = System.Text.RegularExpressions.Regex.Match(
                name,
                @"^(?:мікрофон|microphone|динамік|динаміки|гучномовці|speakers?|headphones?|навушники|лінійний вхід|line in|цифровий звук|digital audio|стерео|stereo|камера|camera|веб-камера|webcam)\s*\((.+)\)\s*$",
                System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            if (wrap.Success && wrap.Groups[1].Value.Trim().Length > 0)
                name = wrap.Groups[1].Value.Trim();

            // 2) Префікс кінцевої точки: «2- Fifine…» → «Fifine…».
            name = System.Text.RegularExpressions.Regex.Replace(name, @"^\s*\d+\s*-\s*", string.Empty).Trim();

            // 3) Клавіатура/миша: дженерик-назва → стандартна (дедуплікується далі).
            var low = name.ToLowerInvariant();
            if (category == "Keyboard" &&
                (low.Contains("hid keyboard device") || low.Contains("standard ps/2") ||
                 low.Contains("usb input device") || low.StartsWith("стандартн")))
                return "Стандартна клавіатура";
            if (category == "Mouse" &&
                (low.Contains("hid-compliant mouse") || low.Contains("hid-сумісна") ||
                 low.Contains("standard ps/2") || low.Contains("usb input device") ||
                 low.StartsWith("ps/2-сумісна") || low.StartsWith("стандартн")))
                return "Стандартна миша";

            // 4) Дженерик-токени.
            string[] tokens =
            {
                "High Definition Audio Device", "USB Audio Device", "HID Keyboard Device",
                "HID-compliant mouse", "Standard PS/2 Keyboard", "Standard PS/2 Mouse"
            };
            foreach (var token in tokens)
            {
                if (string.Equals(name, token, StringComparison.OrdinalIgnoreCase))
                {
                    if (category == "Keyboard") return "Стандартна клавіатура";
                    if (category == "Mouse") return "Стандартна миша";
                    if (category == "Audio") return "Аудіопристрій";
                    break;
                }
                if (name.Length > token.Length + 1 &&
                    name.EndsWith(token, StringComparison.OrdinalIgnoreCase))
                {
                    name = name[..^token.Length].Trim().TrimEnd('-', ',').Trim();
                }
            }
        }
        catch { }
        return System.Text.RegularExpressions.Regex.Replace(name, @"\s{2,}", " ").Trim();
    }

    /// <summary>Дженерик-назви, за якими не видно реальну модель пристрою.</summary>
    private static bool IsGenericDeviceName(string name, string cls)
    {
        var n = name.Trim();
        return (cls switch
        {
            "Keyboard" => n.Equals("HID Keyboard Device", StringComparison.OrdinalIgnoreCase)
                       || n.StartsWith("Standard PS/2", StringComparison.OrdinalIgnoreCase)
                       || n.StartsWith("Стандартная клавиатура", StringComparison.OrdinalIgnoreCase)
                       || n.StartsWith("Стандартна клавіатура", StringComparison.OrdinalIgnoreCase),
            "Mouse" => n.Equals("HID-compliant mouse", StringComparison.OrdinalIgnoreCase)
                    || n.Equals("HID-сумісна мишь", StringComparison.OrdinalIgnoreCase)
                    || n.Equals("HID-сумісна миша", StringComparison.OrdinalIgnoreCase)
                    || n.StartsWith("Standard PS/2", StringComparison.OrdinalIgnoreCase)
                    || n.StartsWith("PS/2-сумісна миша", StringComparison.OrdinalIgnoreCase),
            "Monitor" => n.StartsWith("Generic PnP", StringComparison.OrdinalIgnoreCase)
                      || n.StartsWith("Універсальний монітор", StringComparison.OrdinalIgnoreCase),
            _ => n.StartsWith("USB Mass Storage", StringComparison.OrdinalIgnoreCase)
              || n.StartsWith("USB Composite Device", StringComparison.OrdinalIgnoreCase)
              || n.StartsWith("USB-сумісний пристрій", StringComparison.OrdinalIgnoreCase)
              || n.StartsWith("Складений USB", StringComparison.OrdinalIgnoreCase)
        }) || n.Length == 0;
    }

    /// <summary>«USBSTOR\DISK&VEN_MIBRAND&PROD_SPIDER_240GB_SSSD&...» → «MIBRAND SPIDER 240GB SSD».</summary>
    private static string PrettyFromUsbStorId(string pnpId)
    {
        try
        {
            var ven = System.Text.RegularExpressions.Regex.Match(pnpId, @"&VEN_([^&]+)", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            var prod = System.Text.RegularExpressions.Regex.Match(pnpId, @"&PROD_([^&]+)", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            string v = ven.Success ? ven.Groups[1].Value.Replace('_', ' ').Trim() : "";
            string p = prod.Success ? prod.Groups[1].Value.Replace('_', ' ').Trim() : "";
            var combined = string.Join(" ", new[] { v, p }.Where(s => s.Length > 0));
            if (combined.Length > 2) return combined;
        }
        catch { }
        return string.Empty;
    }

    /// <summary>WmiMonitorID віддає масиви ushort (нуль-терміновані) — збираємо в рядок.</summary>
    private static string DecodeWmiStringArray(object? arr)
    {
        try
        {
            if (arr is ushort[] shorts)
            {
                var chars = shorts.Where(b => b > 32 && b < 127).Select(b => (char)b).ToArray();
                return new string(chars).Trim();
            }
            if (arr != null) return arr.ToString()?.Trim() ?? string.Empty;
        }
        catch { }
        return string.Empty;
    }

    /// <summary>Материнська плата (Win32_BaseBoard) — один повільний запит на сеанс.</summary>
    private string QueryMotherboard()
    {
        if (!string.IsNullOrEmpty(_cachedMotherboard)) return _cachedMotherboard;
        try
        {
            using var searcher = new ManagementObjectSearcher("Select Manufacturer, Product FROM Win32_BaseBoard");
            foreach (var item in searcher.Get())
            {
                var man = item["Manufacturer"]?.ToString()?.Trim() ?? string.Empty;
                var prod = item["Product"]?.ToString()?.Trim() ?? string.Empty;
                var combined = string.Join(" ", new[] { man, prod }.Where(s => !string.IsNullOrWhiteSpace(s) && !s.StartsWith("Default")));
                if (!string.IsNullOrWhiteSpace(combined))
                {
                    _cachedMotherboard = combined;
                    break;
                }
            }
        }
        catch { }
        return _cachedMotherboard;
    }

    /// <summary>
    /// Інформація про екран для рамки «Екран» (ТЗ): модель монітора (WmiMonitorID),
    /// роздільність і герцовка (Win32_VideoController Current*), масштаб інтерфейсу
    /// (AppliedDPI з реєстру: 96=100%, 120=125%…). Один повільний запит на сеанс.
    /// </summary>
    private void QueryScreenInfo()
    {
        if (_screenQueried) return;
        _screenQueried = true;

        // 1) Модель монітора (root\wmi\WmiMonitorID — масиви UTF-16 кодів).
        try
        {
            using var searcher = new ManagementObjectSearcher("root\\wmi", "SELECT ManufacturerName, UserFriendlyName FROM WmiMonitorID WHERE Active = TRUE");
            foreach (var item in searcher.Get())
            {
                string ReadName(string field)
                {
                    try
                    {
                        if (item[field] is not ushort[] codes) return string.Empty;
                        var chars = codes.Where(c => c != 0).Select(c => (char)c);
                        var s = new string(chars.ToArray()).Trim();
                        return s;
                    }
                    catch { return string.Empty; }
                }

                var man = ReadName("ManufacturerName");
                var friendly = ReadName("UserFriendlyName");
                // Прибираємо дублювання: «AUS ASUS VG248» → «ASUS VG248».
                if (!string.IsNullOrWhiteSpace(friendly) && !string.IsNullOrWhiteSpace(man) &&
                    friendly.StartsWith(man, StringComparison.OrdinalIgnoreCase))
                    man = string.Empty;
                var combined = string.Join(" ", new[] { man, friendly }.Where(s => !string.IsNullOrWhiteSpace(s)));
                if (!string.IsNullOrWhiteSpace(combined))
                {
                    _cachedScreenModel = combined;
                    break;
                }
            }
        }
        catch { }

        // 2) Роздільність + герцовка активного режиму відеоконтролера.
        try
        {
            using var searcher = new ManagementObjectSearcher("SELECT CurrentHorizontalResolution, CurrentVerticalResolution, CurrentRefreshRate FROM Win32_VideoController");
            foreach (var item in searcher.Get())
            {
                try
                {
                    int w = Convert.ToInt32(item["CurrentHorizontalResolution"] ?? 0);
                    int h = Convert.ToInt32(item["CurrentVerticalResolution"] ?? 0);
                    int hz = Convert.ToInt32(item["CurrentRefreshRate"] ?? 0);
                    if (w > 0 && h > 0)
                    {
                        _cachedScreenResolution = $"{w} × {h}";
                        _cachedScreenRefreshHz = hz;
                        break;
                    }
                }
                catch { }
            }
        }
        catch { }

        // 3) Масштаб інтерфейсу: AppliedDPI реєстру (96 dpi = 100%).
        try
        {
            using var key = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(@"Control Panel\Desktop\WindowMetrics");
            if (key != null && key.GetValue("AppliedDPI") is int dpi && dpi > 0)
                _cachedScreenScalePercent = (int)Math.Round(dpi / 96.0 * 100);
        }
        catch { }
    }

    private string QueryLanIp()
    {
        if (!string.IsNullOrEmpty(_cachedLanIp)) return _cachedLanIp;
        try
        {
            foreach (var nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
            {
                if (nic.OperationalStatus != System.Net.NetworkInformation.OperationalStatus.Up ||
                    nic.NetworkInterfaceType == System.Net.NetworkInformation.NetworkInterfaceType.Loopback) continue;
                var props = nic.GetIPProperties();
                if (props.GatewayAddresses.Count == 0) continue;
                foreach (var addr in props.UnicastAddresses)
                {
                    if (addr.Address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork &&
                        !System.Net.IPAddress.IsLoopback(addr.Address))
                    {
                        return _cachedLanIp = addr.Address.ToString();
                    }
                }
            }
        }
        catch { }
        return _cachedLanIp = string.Empty;
    }

    // ---- Мережеві адаптери (Wake-on-LAN, вкладка «Додаткове») ---------------

    /// <summary>
    /// Усі піднятий адаптери з IPv4: ім'я, MAC, IP, тип, наявність шлюза.
    /// Агент надсилає їх на сервер при кожній реєстрації — сайт потім
    /// використовує MAC, щоб розбудити цей ПК через Wake-on-LAN.
    /// Кеш на 5 хвилин: список адаптерів не змінюється щосекунди.
    /// </summary>
    public List<object> GetNetworkAdapters()
    {
        if (_cachedAdapters != null && (DateTime.UtcNow - _lastAdaptersQuery).TotalMinutes < 5)
        {
            return _cachedAdapters;
        }
        var list = new List<object>();
        try
        {
            foreach (var nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
            {
                if (nic.NetworkInterfaceType == System.Net.NetworkInformation.NetworkInterfaceType.Loopback) continue;
                if (nic.OperationalStatus != System.Net.NetworkInformation.OperationalStatus.Up) continue;

                // ВІРТУАЛЬНІ АДАПТЕРИ (ТЗ: «лише ті варіанти, які реально підходять»):
                // Hyper-V «Default Switch», vEthernet, WSL, TAP, VirtualBox, VMware,
                // Bluetooth PAN, Wi-Fi Direct, WAN Miniport, VPN-тунелі — для пробудження
                // марні й лише плутають список.
                static bool IsVirtual(string s)
                {
                    s = s.ToLowerInvariant();
                    return s.Contains("virtual") || s.Contains("vethernet")
                        || s.Contains("default switch") || s.Contains("hyper-v")
                        || s.Contains("wsl") || s.Contains("loopback") || s.Contains("tap-")
                        || s.Contains("tap windows") || s.Contains("vmware") || s.Contains("virtualbox")
                        || s.Contains("bluetooth") || s.Contains("wan miniport")
                        || s.Contains("wi-fi direct") || s.Contains("hosted network")
                        || s.Contains("teredo") || s.Contains("isatap") || s.Contains("6to4")
                        || s.Contains("npcap") || s.Contains("vpn") || s.Contains("zerotier")
                        || s.Contains("tailscale") || s.Contains("hamachi") || s.Contains("radmin")
                        || s.Contains("km-test");
                }
                if (IsVirtual(nic.Name) || IsVirtual(nic.Description)) continue;

                string? ipv4 = null;
                string? broadcast = null;
                var props = nic.GetIPProperties();
                foreach (var addr in props.UnicastAddresses)
                {
                    if (addr.Address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork &&
                        !System.Net.IPAddress.IsLoopback(addr.Address))
                    {
                        ipv4 = addr.Address.ToString();
                        // ТЗ (WoL «Налаштувати автоматично»): спрямований бродкаст
                        // = IP | ~маска (напр. 192.168.1.24/24 -> 192.168.1.255).
                        try
                        {
                            if (addr.IPv4Mask != null)
                            {
                                var ipB = addr.Address.GetAddressBytes();
                                var mB = addr.IPv4Mask.GetAddressBytes();
                                var bB = new byte[4];
                                for (int i = 0; i < 4; i++) bB[i] = (byte)(ipB[i] | ~mB[i]);
                                broadcast = new System.Net.IPAddress(bB).ToString();
                            }
                        }
                        catch { }
                        break;
                    }
                }
                // Без IPv4 адаптер марний і для налаштування, і для донора.
                if (string.IsNullOrEmpty(ipv4)) continue;
                if (string.IsNullOrEmpty(broadcast))
                {
                    // Фолбек: класова /24 підстановка.
                    int lastDot = ipv4.LastIndexOf('.');
                    if (lastDot > 0) broadcast = ipv4[..(lastDot + 1)] + "255";
                }

                var macBytes = nic.GetPhysicalAddress().GetAddressBytes();
                if (macBytes.Length != 6 || macBytes.All(b => b == 0)) continue;
                var mac = string.Join(":", macBytes.Select(b => b.ToString("X2")));
                bool hasGateway = props.GatewayAddresses.Count > 0;

                list.Add(new
                {
                    name = nic.Name,
                    description = nic.Description,
                    type = nic.NetworkInterfaceType.ToString().ToLowerInvariant(),
                    mac,
                    ip = ipv4,
                    broadcast,
                    hasGateway
                });
            }
        }
        catch { }
        _cachedAdapters = list;
        _lastAdaptersQuery = DateTime.UtcNow;
        return list;
    }

    private async Task QueryWanIpAsync()
    {
        if (!string.IsNullOrEmpty(_cachedWanIp) && (DateTime.UtcNow - _lastWanIpQuery).TotalMinutes < 15) return;
        try
        {
            using var http = new System.Net.Http.HttpClient { Timeout = TimeSpan.FromSeconds(6) };
            var trace = await http.GetStringAsync("https://www.cloudflare.com/cdn-cgi/trace");
            foreach (var line in trace.Split('\n'))
            {
                if (line.StartsWith("ip="))
                {
                    var ip = line[3..].Trim();
                    if (ip.Length > 0) _cachedWanIp = ip;
                    break;
                }
            }
            _lastWanIpQuery = DateTime.UtcNow;
        }
        catch { }
    }

    public void Shutdown() => Process.Start("shutdown", "/s /t 0");
    public void Restart() => Process.Start("shutdown", "/r /t 0");
    public void Sleep() => System.Windows.Forms.Application.SetSuspendState(System.Windows.Forms.PowerState.Suspend, true, true);
    public void Hibernate() => System.Windows.Forms.Application.SetSuspendState(System.Windows.Forms.PowerState.Hibernate, true, true);

    public void MonitorOff()
    {
        try
        {
            SendMessage((IntPtr)0xFFFF /* HWND_BROADCAST */, 0x0112 /* WM_SYSCOMMAND */, (IntPtr)0xF170 /* SC_MONITORPOWER */, (IntPtr)2 /* off */);
        }
        catch { }
    }

    public void LockScreen() => Process.Start("rundll32.exe", "user32.dll,LockWorkStation");

    public void StartTimer(string action, int seconds)
    {
        string flag = action == "restart" ? "/r" : "/s";
        Process.Start("shutdown", $"{flag} /t {seconds}");
    }

    public void CancelTimer() => Process.Start("shutdown", "/a");

    public void OpenUrl(string url)
    {
        if (!url.StartsWith("http://") && !url.StartsWith("https://")) url = "https://" + url;
        Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
    }
}
